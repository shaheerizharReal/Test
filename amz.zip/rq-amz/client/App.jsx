import React from 'react';
import { hot } from 'react-hot-loader';
import { Switch, Route } from 'react-router-dom';
import { LicenseManager } from 'ag-grid-enterprise';

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';

import AuthenticationRoute from './routes/AuthenticationRoute.jsx';
import AppRoute from './routes/AppRoute.jsx';
import AdminRoute from './routes/AdminRoute.jsx';

import PageNotFound from './pages/PageNotFound.jsx';
import PrivacyPolicy from './pages/PrivacyPolicy.jsx';
import TermsAndConditionPolicy from './pages/TermsAndConditionPolicy.jsx';

LicenseManager.setLicenseKey('Kingston_Studios_The_One_APP_1Devs28_March_2020__MTU4NTM1MzYwMDAwMA==9975caa0047adeaf83d24ed70e0f63f8');

class App extends React.Component {
  render() {
    return (
      <Switch>
        <AdminRoute path="/admin" />
        <AuthenticationRoute path="/auth" />
        <Route exact path='/not-found' component={PageNotFound} />
        <Route exact path='/privacy-policy' component={PrivacyPolicy} />
        <Route exact path='/terms-and-condition-policy' component={TermsAndConditionPolicy} />
        <AppRoute path="/" />
      </Switch>
    );
  }
}

export default hot(module)(App);
