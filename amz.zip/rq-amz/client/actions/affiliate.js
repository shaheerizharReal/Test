import axios from 'axios';
import { notification } from 'antd';

export const addAffiliate = ({ name, email, referralCode, couponOffPercent, duration }) => (dispatch) => {
  dispatch({ type: 'ADD_AFFILIATE_REQUEST' });

  const url = '/api/v1/affiliate/add-affiliate';

  return axios.post(url, {
    name,
    email,
    referralCode,
    couponOffPercent,
    duration
  }).then((res) => {
    const { affiliates } = res.data;
    return dispatch({ type: 'ADD_AFFILIATE_SUCCESS', payload: affiliates });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Add Affiliate',
      description: data
    });

    dispatch({ type: 'ADD_AFFILIATE_FAILED' });
  });
};

export const getAffiliates = () => (dispatch) => {
  dispatch({ type: 'GET_AFFILIATES_REQUEST' });

  const url = '/api/v1/affiliate/get-affiliates';

  return axios.get(url)
    .then((res) => {
      const { affiliates, noOfAffiliatedUsers } = res.data.affiliatesData;
      return dispatch({ type: 'GET_AFFILIATES_SUCCESS', payload: { affiliates, noOfAffiliatedUsers } });
    }).catch((error) => {
      const { data } = error.response;

      notification.error({
        message: 'Get Affiliates',
        description: data
      });
    });
};

export const getExportDetails = () => () => {
  const url = '/api/v1/get-affiliates-export';
  window.open(url, '_blank');
};

export const setAffiliateToDelete = data => (dispatch) => {
  dispatch({ type: 'SET_AFFILIATES_TO_DELETE', payload: data });
};

export const deleteAffiliates = param => (dispatch) => {
  dispatch({ type: 'DELETE_AFFILIATES_REQUEST' });
  const url = '/api/v1/affiliate/delete-affiliates';

  axios.delete(url, {
    params: {
      ...param
    }
  }).then(() => {
    return dispatch({ type: 'DELETE_AFFILIATES_SUCCESS' });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Delete Affiliates',
      description: data
    });
  });
};
