import axios from 'axios';

export const getAgendaJobs = () => (dispatch, getState) => {
  const { pageSize, pageNumber } = getState().agendaJobs.pagination;
  const { filters } = getState().agendaJobs;
  dispatch({ type: 'GET_AGENDA_JOBS_REQUEST' });

  axios({
    method: 'get',
    url: '/api/v1/agendaJobs/fetchJobs',
    params: {
      limit: pageSize || 25,
      skip: (pageNumber - 1) * (pageSize || 25),
      filters
    }
  }).then(({ data }) => {
    dispatch({ type: 'GET_AGENDA_JOBS_SUCCESS', payload: data });
  });
};

export const setPage = pageNumber => (dispatch) => {
  dispatch({ type: 'SET_PAGE_AGENDA_JOBS', payload: { pageNumber } });
};

export const requeueAgendaJob = agendaJobId => (dispatch, getState) => {
  const { filters } = getState().agendaJobs;

  dispatch({ type: 'REQUEUE_AGENDA_JOB_REQUEST' });
  return axios({
    method: 'post',
    url: '/api/v1/agendaJobs/requeueJob',
    params: {
      id: agendaJobId,
      filters
    }
  }).then(({ data }) => {
    return dispatch({ type: 'AGENDA_JOB_REQUEUED_SUCCESSFULLY', payload: data });
  });
};

export const removeAgendaJob = agendaJobId => (dispatch, getState) => {
  const { filters } = getState().agendaJobs;
  dispatch({ type: 'REMOVE_AGENDA_JOB_REQUEST' });
  axios({
    method: 'delete',
    url: '/api/v1/agendaJobs/removeJob',
    params: {
      id: agendaJobId,
      filters
    }
  }).then(({ data }) => {
    dispatch({ type: 'AGENDA_JOB_REMOVED_SUCCESSFULLY', payload: data });
  });
};

export const setPageSize = pageSize => (dispatch) => {
  localStorage.setItem('agendaJobsPerPage', pageSize);
  dispatch({ type: 'SET_PAGE_SIZE_AGENDA_JOBS', payload: { pageSize } });
};


export const setFilters = filters => (dispatch) => {
  dispatch({ type: 'SET_FILTER_AGENDA_JOBS', payload: filters });
};

export const resetAgendaJobsFilters = () => (dispatch) => {
  dispatch({ type: 'RESET_FILTERS_AGENDA_JOBS' });
};
