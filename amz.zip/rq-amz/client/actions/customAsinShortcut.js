import axios from 'axios';
import { notification } from 'antd';

export const addShortcut = ({ url, displayName, iconText, visibility }) => (dispatch) => {
  dispatch({ type: 'ADD_SHORTCUT_REQUEST' });

  return axios.post('/api/v1/custom-asin-shortcut/add-shortcut', {
    url,
    displayName,
    iconText,
    visibility
  }).then((res) => {
    const { shortcuts } = res.data;
    return dispatch({ type: 'ADD_SHORTCUT_SUCCESS', payload: { shortcuts } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Add Shortcut',
      description: data
    });

    dispatch({ type: 'ADD_SHORTCUT_FAILED' });
  });
};

export const getShortcuts = () => (dispatch) => {
  dispatch({ type: 'GET_SHORTCUTS_REQUEST' });

  return axios.get('/api/v1/custom-asin-shortcut/get-shortcuts').then((res) => {
    const { shortcuts } = res.data;
    return dispatch({ type: 'GET_SHORTCUTS_SUCCESS', payload: { shortcuts } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Get Shortcut',
      description: data
    });

    dispatch({ type: 'GET_SHORTCUTS_FAILED' });
  });
};

export const editShortcut = param => (dispatch) => {
  dispatch({ type: 'EDIT_SHORTCUT_REQUEST' });
  const url = '/api/v1/custom-asin-shortcut/edit-shortcut';

  axios.post(url, {
    ...param
  }).then(({ data }) => {
    notification.success({
      message: 'Edit Shortcut',
      description: 'Shortcut has been Edited Successfully'
    });

    dispatch({ type: 'UPDATE_SHORTCUT', payload: data });
    return dispatch({ type: 'EDIT_SHORTCUT_SUCCESS' });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Edit User',
      description: data
    });

    dispatch({ type: 'EDIT_SHORTCUT_FAILED' });
  });
};

export const deleteShortcut = param => (dispatch) => {
  dispatch({ type: 'DELETE_SHORTCUT_REQUEST' });
  const url = '/api/v1/custom-asin-shortcut/delete-shortcut';

  axios.delete(url, {
    params: {
      ...param
    }
  }).then((res) => {
    const { shortcutId } = res.data;
    notification.success({
      message: 'Delete Shortcut',
      description: 'Shortcut has been Deleted Successfully'
    });

    return dispatch({ type: 'DELETE_SHORTCUT_SUCCESS', payload: { shortcutId } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Delete User',
      description: data
    });

    dispatch({ type: 'DELETE_SHORTCUT_FAILED' });
  });
};
