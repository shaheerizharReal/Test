import axios from 'axios';

export const getSales = () => (dispatch) => {
  dispatch({ type: 'GET_SALES_REQUEST' });

  axios({
    method: 'get',
    url: '/api/v1/dashboard/get-sales',
    params: {
    }
  }).then(({ data }) => dispatch({ type: 'GET_SALES_SUCCESS', payload: data }));
};

export const setPage = pageNumber => (dispatch) => {
  dispatch({ type: 'SET_PAGE_INVENTORY', payload: { pageNumber } });
};

export const resetStateOfDashboard = () => (dispatch) => {
  dispatch({ type: 'RESET_STATE_OF_DASHBOARD' });
};
