import axios from 'axios';
import { notification } from 'antd';
import { extend } from 'lodash';

export const getProducts = () => (dispatch, getState) => {
  const { pageSize, pageNumber } = getState().inventory.pagination;
  const { filters, sort } = getState().inventory;
  dispatch({ type: 'GET_PRODUCTS_REQUEST' });

  axios({
    method: 'get',
    url: '/api/v1/inventory',
    params: {
      limit: pageSize || 25,
      skip: (pageNumber - 1) * (pageSize || 25),
      filters,
      sort
    }
  }).then(({ data }) => {
    return dispatch({ type: 'GET_PRODUCTS_SUCCESS', payload: data });
  });
};

export const setPage = pageNumber => (dispatch) => {
  dispatch({ type: 'SET_PAGE_INVENTORY', payload: { pageNumber } });
};

export const setPageSize = pageSize => (dispatch) => {
  localStorage.setItem('inventoryItemsPerPage', pageSize);
  dispatch({ type: 'SET_PAGE_SIZE_INVENTORY', payload: { pageSize } });
};

export const setSortFilters = sortFilter => (dispatch) => {
  dispatch({ type: 'SET_SORT_FILTERS', payload: sortFilter });
};

export const setFilters = filters => (dispatch) => {
  dispatch({ type: 'SET_FILTER_INVENTORY', payload: filters });
};

export const resetAllFiltersAndSelections = () => (dispatch) => {
  dispatch({ type: 'RESET_FILTERS_AND_SELECTIONS_INVENTORY' });

  axios({
    method: 'get',
    url: '/api/v1/inventory/get-suppliers-and-categories'
  }).then(({ data }) => {
    if (data) {
      return dispatch({ type: 'GET_CATEGORIES_AND_SUPPLIERS_SUCCESS', payload: data });
    }
  }).catch((err) => {
    if (err.request.status === 403) {
      notification.error({
        message: 'Access Rights',
        description: "Sorry! You don't have access rights!!",
        duration: 5
      });
    }
    return dispatch({ type: 'GET_CATEGORIES_AND_SUPPLIERS_FAIL' });
  });
};

export const setSellectedItems = selectedItems => (dispatch) => {
  dispatch({ type: 'SET_SELECTED_ITEMS', payload: selectedItems });
};

export const setCostPrice = product => (dispatch) => {
  dispatch({ type: 'SET_COST_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/inventory/set-cost-price',
    params: {
      ...product
    }
  }).then(({ data }) => {
    if (data) {
      dispatch({ type: 'UPDATE_PRODUCT', payload: data });
      return dispatch({ type: 'SET_COST_SUCCESS', payload: data });
    }
  }).catch((err) => {
    if (err.request.status === 403) {
      notification.error({
        message: 'Access Rights',
        description: "Sorry! You don't have access rights!!",
        duration: 5
      });
    }
    return dispatch({ type: 'SET_COST_FAIL' });
  });
};

export const setDecideBuyQuantity = product => (dispatch) => {
  dispatch({ type: 'SET_DECIDE_BUY_QUANTITY_RQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/inventory/set-decide-buy-quantity',
    params: {
      ...product
    }
  }).then(({ data }) => {
    if (data) {
      dispatch({ type: 'UPDATE_PRODUCT', payload: data });
      return dispatch({ type: 'SET_DECIDE_BUY_QUANTITY_SUCCESS', payload: data });
    }
  }).catch((err) => {
    if (err.request.status === 403) {
      notification.error({
        message: 'Access Rights',
        description: "Sorry! You don't have access rights!!",
        duration: 5
      });
    }
    return dispatch({ type: 'SET_DECIDE_BUY_QUANTITY_FAIL' });
  });
};

export const setShippingCost = product => (dispatch) => {
  dispatch({ type: 'SET_SHIPPING_COST_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/inventory/set-shipping-cost',
    params: {
      ...product
    }
  }).then(({ data }) => {
    if (data) {
      dispatch({ type: 'UPDATE_PRODUCT', payload: data });
      return dispatch({ type: 'SET_SHIPPING_COST_SUCCESS', payload: data });
    }
  }).catch((err) => {
    if (err.request.status === 403) {
      notification.error({
        message: 'Access Rights',
        description: "Sorry! You don't have access rights!!",
        duration: 5
      });
    }
    return dispatch({ type: 'SET_SHIPPING_COST_FAIL' });
  });
};

export const setSupplier = product => (dispatch) => {
  dispatch({ type: 'SET_SUPPLIER_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/inventory/set-supplier',
    params: {
      ...product
    }
  }).then(({ data }) => {
    if (data) {
      return dispatch({ type: 'SET_SUPPLIER_SUCCESS', payload: data });
    }
  }).catch((err) => {
    if (err.request.status === 403) {
      notification.error({
        message: 'Access Rights',
        description: "Sorry! You don't have access rights!!",
        duration: 5
      });
    }
    return dispatch({ type: 'SET_SUPPLIER_FAIL' });
  });
};

export const setPurchaseLink = product => (dispatch) => {
  dispatch({ type: 'SET_PURCHASE_LINK_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/inventory/set-purchase-link',
    params: {
      ...product
    }
  }).then(({ data }) => {
    if (data) {
      dispatch({ type: 'UPDATE_PRODUCT', payload: data });
      return dispatch({ type: 'SET_PURCHASE_LINK_SUCCESS', payload: data });
    }
  }).catch((err) => {
    if (err.request.status === 403) {
      notification.error({
        message: 'Access Rights',
        description: "Sorry! You don't have access rights!!",
        duration: 5
      });
    }
    return dispatch({ type: 'SET_PURCHASE_LINK_FAIL' });
  });
};

export const setStoreSection = product => (dispatch) => {
  dispatch({ type: 'SET_STORE_SECTION_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/inventory/set-store-section',
    params: {
      ...product
    }
  }).then(({ data }) => {
    if (data) {
      dispatch({ type: 'UPDATE_PRODUCT', payload: data });
      return dispatch({ type: 'SET_STORE_SECTION_SUCCESS', payload: data });
    }
  }).catch((err) => {
    if (err.request.status === 403) {
      notification.error({
        message: 'Access Rights',
        description: "Sorry! You don't have access rights!!",
        duration: 5
      });
    }
    return dispatch({ type: 'SET_STORE_SECTION_FAIL' });
  });
};

export const setNotesSection = product => (dispatch) => {
  dispatch({ type: 'SET_NOTES_SECTION_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/inventory/set-notes-section',
    params: {
      ...product
    }
  }).then(({ data }) => {
    if (data) {
      dispatch({ type: 'UPDATE_PRODUCT', payload: data });
      return dispatch({ type: 'SET_NOTES_SECTION_SUCCESS', payload: data });
    }
  }).catch((err) => {
    if (err.request.status === 403) {
      notification.error({
        message: 'Access Rights',
        description: "Sorry! You don't have access rights!!",
        duration: 5
      });
    }
    return dispatch({ type: 'SET_NOTES_SECTION_FAIL' });
  });
};

export const setToReplen = ({ skuList, isReplen }) => (dispatch) => {
  dispatch({ type: 'SET_TO_REPLEN_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/inventory/set-to-replen',
    params: {
      skuList,
      isReplen
    }
  }).then(({ data }) => {
    if (data) {
      dispatch({ type: 'UPDATE_PRODUCT', payload: data });
      return dispatch({ type: 'SET_TO_REPLEN_SUCCESS', payload: data });
    }
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Replen Product',
      description: data
    });
    dispatch({ type: 'SET_TO_REPLEN_FAIL' });
  });
};

export const resetAllDecidedBuyQuantites = () => (dispatch) => {
  dispatch({ type: 'RESET_ALL_DECIDED_QUANTITES_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/inventory/reset-decided-quantities'
  }).then(({ data }) => {
    notification.success({
      message: 'SUCCESS',
      description: 'You have successfully reset all decided buy quantities',
      style: {
        width: 350
      },
      duration: 5
    });
    return dispatch({ type: 'RESET_ALL_DECIDED_QUANTITES_SUCCESS', payload: data });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'RESET DECIDED PRODUCTS',
      description: data
    });
    dispatch({ type: 'RESET_ALL_DECIDED_QUANTITES_FAIL' });
  });
};

export const exportProducts = (
  userId,
  noOfselectedItems,
  selectedItems,
  columnsWanted,
  exportReplen
) => () => {
  const jsonSelectedItems = JSON.stringify(selectedItems.map(item => item.sellerSku));
  const blobSelectedItems = new Blob([jsonSelectedItems], {
    type: 'application/json'
  });

  const jsonColumnsWanted = JSON.stringify(columnsWanted);
  const blobColumnsWanted = new Blob([jsonColumnsWanted], {
    type: 'application/json'
  });

  const formData = new FormData();
  formData.append('selectedItems', blobSelectedItems);
  formData.append('columnsWanted', blobColumnsWanted);

  axios({
    method: 'post',
    url: '/api/v1/inventory/save-export-products-params',
    data: formData
  }).then(({ data }) => {
    if (data) {
      const params = {
        _id: userId,
        selectAll: noOfselectedItems
      };
      if (exportReplen) {
        extend(params, { isReplen: true });
      } else {
        extend(params, { isReplen: false });
      }
      const getQueryString = (p) => {
        const esc = encodeURIComponent;
        return Object.keys(p)
          .map(k => `${esc(k)}=${esc(params[k])}`)
          .join('&');
      };

      const url = `/api/v1/export-products?${getQueryString(params)}`;
      window.open(url, '_blank');
    }
  }).catch((err) => {
    if (err.request.status === 403) {
      notification.error({
        message: 'Access Rights',
        description: "Sorry! You don't have access rights!!",
        duration: 5
      });
    }
  });
};

export const importProducts = (products, costCheck) => (dispatch) => {
  dispatch({ type: 'IMPORT_INVENTORY_REQUEST' });

  const json = JSON.stringify(products);
  const blob = new Blob([json], {
    type: 'application/json'
  });
  const costCheckJson = JSON.stringify(costCheck);
  const costCheckBlob = new Blob([costCheckJson], {
    type: 'application/json'
  });

  const formData = new FormData();
  formData.append('document', blob);
  formData.append('costCheck', costCheckBlob);

  axios({
    method: 'post',
    url: '/api/v1/inventory/import-products',
    data: formData
  }).then(({ data }) => {
    if (data) {
      notification.success({
        message: 'Import Products',
        description: 'Importing now, product information will be updated shortly.',
        style: {
          width: 350
        },
        duration: 5
      });

      return dispatch({ type: 'IMPORT_INVENTORY_SUCCESS', payload: data });
    }
    notification.error({
      message: 'Import Products',
      description: 'Products are Previously being Imported !!',
      style: {
        width: 350
      },
      duration: 5
    });

    return dispatch({ type: 'IMPORT_INVENTORY_FAIL' });
  }).catch((err) => {
    if (err.request.status === 403) {
      notification.error({
        message: 'Access Rights',
        description: "Sorry! You don't have access rights!!",
        duration: 5
      });
    }
    return dispatch({ type: 'IMPORT_INVENTORY_FAIL' });
  });
};

export const resetImportProducts = () => (dispatch) => {
  dispatch({ type: 'RESET_IMPORT_INVENTORY' });
};

export const resetStateOfInventory = () => (dispatch) => {
  dispatch({ type: 'RESET_STATE_OF_INVENTORY' });
};
