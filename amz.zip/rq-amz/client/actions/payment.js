import axios from 'axios';
import { notification } from 'antd';

export const getStripeData = () => (dispatch) => {
  dispatch({ type: 'GET_STRIPE_DATA_REQUEST' });

  const url = '/api/v1/stripe/get-stripe-data';

  return axios.get(url).then((res) => {
    const { stripePlans, stripeCoupons } = res.data;
    return dispatch({ type: 'GET_STRIPE_DATA_SUCCESS', payload: { stripePlans, stripeCoupons } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Stripe Data',
      description: data
    });

    dispatch({ type: 'GET_STRIPE_DATA_FAILED' });
  });
};

export const setSelectedPlan = (selectedPlan, selectedTier) => (dispatch) => {
  return dispatch({ type: 'SET_SELECTED_PLAN', payload: { selectedPlan, selectedTier } });
};

export const resetSelectedPlan = () => (dispatch) => {
  return dispatch({ type: 'RESET_SELECTED_PLAN', payload: { selectedPlan: null, selectedTier: null } });
};

export const setShowPaymentCard = showPaymentCard => (dispatch) => {
  return dispatch({ type: 'SET_SHOW_PAYMENT_CARD', payload: { showPaymentCard } });
};

export const setShowUpdateCard = showUpdateCard => (dispatch) => {
  return dispatch({ type: 'SET_SHOW_UPDATE_CARD', payload: { showUpdateCard } });
};
