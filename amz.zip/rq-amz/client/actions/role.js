import axios from 'axios';
import { notification } from 'antd';

export const addRole = ({
  name, modules, grantType
}) => (dispatch) => {
  dispatch({ type: 'ADD_ROLE_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/grants/new-grant',
    data: { name, modules, grantType }
  })
    .then(({ data }) => dispatch({ type: 'ADD_ROLE_SUCCESS', payload: data.roles }))
    .catch((error) => {
      const { data } = error.response;

      notification.error({
        message: 'Add Affiliate',
        description: data
      });
      dispatch({ type: 'ADD_ROLE_FAILED' });
    });
};

export const getRoles = () => (dispatch) => {
  dispatch({ type: 'GET_ROLE_REQUEST' });

  const url = '/api/v1/grants/get-grant';

  return axios.get(url)
    .then((res) => {
      const { grants } = res.data;
      return dispatch({ type: 'GET_ROLE_SUCCESS', payload: { roles: grants } });
    }).catch((error) => {
      const { data } = error.response;

      notification.error({
        message: 'Get Roles',
        description: data
      });
    });
};

export const deleteRole = param => (dispatch) => {
  dispatch({ type: 'DELETE_ROLE_REQUEST' });
  const url = '/api/v1/grants/delete-grant';

  axios.delete(url, {
    params: {
      ...param
    }
  }).then((res) => {
    const { _id } = res.data;
    notification.success({
      message: 'Delete User',
      description: 'Role has been Deleted Successfully'
    });

    return dispatch({ type: 'DELETE_ROLE_SUCCESS', payload: { _id } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Delete Role',
      description: data
    });
  });
};
