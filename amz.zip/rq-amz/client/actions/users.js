import axios from 'axios';
import { notification } from 'antd';

export const getMwsCredentials = () => (dispatch) => {
  dispatch({ type: 'GET_MWS_CREDENTIALS_REQUEST' });

  return axios({
    method: 'get',
    url: '/api/v1/users/mws',
    params: {
    }
  }).then(({ data }) => {
    const { mws } = data;
    return dispatch({ type: 'GET_MWS_CREDENTIALS_SUCCESS', payload: { mws } });
  });
};

export const getColumnsWanted = () => (dispatch) => {
  dispatch({ type: 'GET_COLUMNS_WANTED_REQUEST' });

  return axios({
    method: 'get',
    url: '/api/v1/users/columnsWanted',
    params: {
    }
  }).then(({ data }) => {
    const { columnsWanted } = data;
    return dispatch({ type: 'GET_COLUMNS_WANTED_SUCCESS', payload: { columnsWanted } });
  });
};

export const updateUserPassword = (oldPassword, newPassword) => (dispatch) => {
  dispatch({ type: 'UPDATE_USER_PASSWORD_REQUEST' });
  const url = '/api/v1/users/update-user-password';
  return axios.post(url, {
    oldPassword,
    newPassword
  }).then((result) => {
    if (result.data.status) {
      notification.success({
        duration: 4,
        message: 'Update Password',
        description: result.data.message
      });
    } else {
      notification.error({
        duration: 3,
        message: 'Error',
        description: result.data.message
      });
    }

    return dispatch({ type: 'UPDATE_USER_PASSWORD_SUCCESS' });
  }).catch((error) => {
    const { data } = error.response;

    notification['error']({
      message: 'Update Password',
      description: data
    });
  });
};

export const updateMwsCredentials = ({ mws }) => (dispatch) => {
  dispatch({ type: 'UPDATE_MWS_CREDENTIALS_REQUEST' });

  const url = '/api/v1/users/update-mws-credentials';

  return axios.post(url, {
    mws
  }).then(({ data }) => {
    const { mws } = data;
    const updatedSuccessfully = true;
    notification.info({
      duration: 3,
      message: 'MWS Synced',
      description: (
        <div>
          <p>Your Credentials have been Updated Successfully.</p>
          <p>Data will be Synced in 24-48 hours.</p>
        </div>
      )
    });
    return dispatch({ type: 'UPDATE_MWS_CREDENTIALS_SUCCESS', payload: { mws, updatedSuccessfully } });
  }).catch((error) => {
    const { data } = error.response;

    notification['error']({
      message: 'Update Credentials',
      description: data
    });

    dispatch({ type: 'UPDATE_MWS_CREDENTIALS_FAILED' });
  });
};

export const forgotPassword = ({ email }) => (dispatch) => {
  dispatch({ type: 'RESET_PASSWORD_REQUEST' });

  const url = '/api/v1/forgot-password';

  return axios.post(url, {
    email
  }).then(() => {
    notification['success']({
      message: 'Forgot Password',
      description: `Reset password link send to ${email} successfully !`
    });

    return dispatch({ type: 'RESET_PASSWORD_SUCCESS' });
  }).catch((error) => {
    const { data } = error.response;

    notification['error']({
      message: 'Forgot Password',
      description: data,
    });

    dispatch({ type: 'RESET_PASSWORD_FAILED' });
  })
};

export const updatePassword = ({ resetPasswordToken, password }) => (dispatch) => {
  dispatch({ type: 'UPDATE_PASSWORD_REQUEST' });

  const url = '/api/v1/update-password';

  return axios.post(url, {
    resetPasswordToken,
    password
  }).then(() => {
    notification['success']({
      message: 'Update Password',
      description: `Password changed successfully !`
    });

    return dispatch({ type: 'UPDATE_PASSWORD_SUCCESS', payload: { showLoginTag: true } });
  }).catch((error) => {
    const { data } = error.response;

    notification['error']({
      message: 'Update Password',
      description: data,
    });

    dispatch({ type: 'UPDATE_PASSWORD_FAILED' });
  })
};

export const registerUser = ({ userName, email, password, referralCode }) => (dispatch) => {
  dispatch({ type: 'REGISTER_USER_REQUEST' });

  const url = '/api/v1/register';

  return axios.post(url, {
    userName,
    email,
    password,
    referralCode
  }).then(({ data }) => {
    const { user, token, invalidReferralCode } = data;

    localStorage.setItem('loginToken', token);
    axios.defaults.headers.common['Authorization'] = `JWT ${token}`;

    notification['success']({
      message: 'Register User',
      description: 'You are registered successfully !'
    });

    if (invalidReferralCode) {
      notification.warn({
        message: 'Invalid Referral Code',
        description: 'Referral Code you have entered is not valid.\n\n Kindly coordinate with your Affiliator.'
      });
    }
    dispatch({ type: 'AUTH_LOGIN_SUCCESS', payload: {
      admin: (user.admin || false) }
    });

    return dispatch({ type: 'REGISTER_USER_SUCCESS', payload: user });
  }).catch((error) => {
    const { data } = error.response;

    notification['error']({
      message: 'Register User',
      description: data,
    });

    dispatch({ type: 'AUTH_LOGIN_FAILED' });
    dispatch({ type: 'REGISTER_USER_FAILED' });
  });
};

export const loginUser = ({ email, password }) => (dispatch) => {
  dispatch({ type: 'LOGIN_USER_REQUEST' });

  const url = '/api/v1/login';

  return axios.post(url, {
    email,
    password
  }).then(({ data }) => {
    const { user, token } = data;

    localStorage.setItem('loginToken', token);
    axios.defaults.headers.common['Authorization'] = `JWT ${token}`;

    notification['success']({
      message: 'Login User',
      description: 'You are sign in successfully !'
    });

    dispatch({ type: 'LOGIN_USER_SUCCESS', payload: user });

    return dispatch({ type: 'AUTH_LOGIN_SUCCESS', payload: {
      admin: (user.admin || false) }
    });
  }).catch((error) => {
    const { data } = error.response;

    notification['error']({
      message: 'Login User',
      description: data,
    });

    dispatch({ type: 'AUTH_LOGIN_FAILED' });
    dispatch({ type: 'LOGIN_USER_FAILED' });
  })
};

export const getDefaultShippingRate = () => (dispatch) => {
  dispatch({ type: 'GET_DEFAULT_SHIPPING_RATE_REQUEST' });
  return axios({
    method: 'get',
    url: '/api/v1/users/get-default-shipping-rate'
  }).then(({ data }) => {
    const { shippingData } = data;
    return dispatch({ type: 'GET_DEFAULT_SHIPPING_RATE_SUCCESS', payload: shippingData });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'GET DEFAULT SHIPPING RATE',
      description: data
    });
    return dispatch({ type: 'GET_DEFAULT_SHIPPING_RATE_FAILED' });
  });
};

export const saveDefaultShippingRates = shippingRateData => (dispatch) => {
  dispatch({ type: 'SAVE_DEFAULT_SHIPPING_RATE_REQUEST' });
  return axios({
    method: 'post',
    url: '/api/v1/users/set-default-shipping-rate',
    params: {
      ...shippingRateData
    }
  }).then(() => {
    notification.success({
      message: 'SAVE DEFAULT SHIPPING RATE',
      description: 'Default Shipping Rate Successfully Saved!!. Please wait it will take some time to update your profits.'
    });
    return dispatch({ type: 'SAVE_DEFAULT_SHIPPING_RATE_SUCCESS', payload: { ...shippingRateData } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'SAVE DEFAULT SHIPPING RATE',
      description: data
    });
    return dispatch({ type: 'SAVE_DEFAULT_SHIPPING_RATE_FAILED' });
  });
};

export const saveCalculationChanges = calculationData => (dispatch) => {
  dispatch({ type: 'SAVE_DEFAULT_CALCULATION_PRICE_REQUEST' });
  return axios({
    method: 'post',
    url: '/api/v1/users/set-default-calculation-price',
    params: {
      ...calculationData
    }
  }).then(() => {
    notification.success({
      message: 'Save Price For Calculation',
      description: 'Price For Calculation Successfully Saved!!. Please wait it will take some time to update your profits.'
    });
    return dispatch({ type: 'SAVE_DEFAULT_CALCULATION_PRICE_SUCCESS', payload: { ...calculationData } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'SAVE DEFAULT SHIPPING RATE',
      description: data
    });
    return dispatch({ type: 'SAVE_DEFAULT_CALCULATION_PRICE_FAILED' });
  });
};

export const getDefaultCalculationPrice = () => (dispatch) => {
  dispatch({ type: 'GET_DEFAULT_CALCULATION_PRICE_REQUEST' });
  return axios({
    method: 'get',
    url: '/api/v1/users/get-default-calculation-price'
  }).then(({ data }) => {
    const { profitCalculatedBy } = data;
    return dispatch({ type: 'GET_DEFAULT_CALCULATION_PRICE_SUCCESS', payload: { profitCalculatedBy } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'GET DEFAULT CALCULATION PRICE',
      description: data
    });
    return dispatch({ type: 'GET_DEFAULT_CALCULATION_PRICE_FAILED' });
  });
};

export const loadDemoUserData = () => (dispatch) => {
  dispatch({ type: 'LOAD_DEMO_USER_DATA_REQUEST' });
  return axios({
    method: 'get',
    url: '/api/v1/users/loadDemoAccountData'
  }).then(() => {
    notification.success({
      message: 'DEMO USER DATA',
      description: 'Demo Account Data Successfully Loaded!!'
    });
    return dispatch({ type: 'LOAD_DEMO_USER_DATA_SUCCESS' });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'DEMO USER DATA',
      description: data
    });
    return dispatch({ type: 'LOAD_DEMO_USER_DATA_FAILED' });
  });
};

export const getUser = () => (dispatch) => {
  dispatch({ type: 'GET_USER_REQUEST' });
  dispatch({ type: 'SET_AUTH_LOADING' });

  const url = '/api/v1/findUser';

  return axios.get(url).then(({ data }) => {
    const { user } = data;

    dispatch({ type: 'AUTH_LOGIN_SUCCESS', payload: {
      admin: (user.admin || false) }
    });

    return dispatch({ type: 'GET_USER_SUCCESS', payload: user });
  }).catch((error) => {
    const { data } = error.response;

    notification['error']({
      message: 'Get User',
      description: data,
    });

    dispatch({ type: 'AUTH_LOGIN_FAILED' });
    dispatch({ type: 'GET_USER_FAILED' });
  });
};

export const logoutUser = () => (dispatch) => {
  localStorage.removeItem('loginToken');
  localStorage.removeItem('adminToken');

  dispatch({ type: 'AUTH_LOGOUT' });
  return dispatch({ type: 'LOGOUT_USER_SUCCESS' });
};

export const getUsers = () => (dispatch, getState) => {
  const { pageSize, pageNumber } = getState().users.pagination;
  const { filters, sort } = getState().users;
  dispatch({ type: 'GET_ALL_USERS_REQUEST' });
  axios({
    method: 'get',
    url: '/api/v1/users/fetchUsers',
    params: {
      limit: pageSize || 25,
      skip: (pageNumber - 1) * (pageSize || 25),
      filters,
      sort
    }
  }).then(({ data }) => {
    return dispatch({ type: 'GET_ALL_USERS_SUCCESS', payload: data });
  });
};

export const getAllUsersAgendaJobs = () => (dispatch, getState) => {
  const { filters } = getState().users;
  dispatch({ type: 'GET_ALL_USERS_REQUEST' });
  axios({
    method: 'get',
    url: '/api/v1/users/fetchAllUsersAgendaJobs',
    params: {
      filters
    }
  }).then(({ data }) => {
    return dispatch({ type: 'GET_ALL_USERS_SUCCESS', payload: data });
  });
};

export const impersonate = userId => (dispatch) => {
  dispatch({ type: 'IMPERSONATE_USER_REQUEST' });

  const url = '/api/v1/impersonate';

  return axios.post(url, {
    userId
  }).then(({ data }) => {
    const { user, token } = data;

    const loginToken = localStorage.getItem('loginToken');
    localStorage.setItem('adminToken', loginToken);

    localStorage.setItem('loginToken', token);
    axios.defaults.headers.common['Authorization'] = `JWT ${token}`;

    notification.success({
      message: 'Impersonate User',
      description: 'User impersonated successfully !'
    });

    dispatch({ type: 'IMPERSONATE_USER_SUCCESS', payload: user });

    return dispatch({ type: 'AUTH_LOGIN_SUCCESS', payload: { admin: (user.admin || false) } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Impersonate User',
      description: data
    });

    return dispatch({ type: 'IMPERSONATE_USER_FAILED' });
  });
};

export const setPage = pageNumber => (dispatch) => {
  dispatch({ type: 'SET_PAGE_USERS', payload: { pageNumber } });
};

export const setPageSize = pageSize => (dispatch) => {
  localStorage.setItem('usersPerPage', pageSize);
  dispatch({ type: 'SET_PAGE_SIZE_USERS', payload: { pageSize } });
};

export const setFilters = filters => (dispatch) => {
  dispatch({ type: 'SET_FILTER_USERS', payload: filters });
};

export const setSortFilters = sortFilter => (dispatch) => {
  dispatch({ type: 'SET_SORT_FILTERS', payload: sortFilter });
};

export const resetUserFilters = () => (dispatch) => {
  dispatch({ type: 'RESET_FILTERS_USERS' });

  axios({
    method: 'get',
    url: '/api/v1/users/get-referral-codes'
  }).then(({ data }) => {
    if (data) {
      return dispatch({ type: 'GET_REFERRAL_CODE_SUCCESS', payload: { referralCodes: data } });
    }
  });
};

export const resetUser = () => (dispatch) => {
  const adminToken = localStorage.getItem('adminToken');
  localStorage.removeItem('adminToken');

  localStorage.setItem('loginToken', adminToken);
  axios.defaults.headers.common['Authorization'] = `JWT ${adminToken}`;

  dispatch(getUser());
};

export const stopAuthLoading = () => (dispatch) => {
  dispatch({ type: 'STOP_AUTH_LOADING' });
};

export const resetUpdatedSuccessfully = () => (dispatch) => {
  dispatch({ type: 'RESET_UPDATED_SUCCESSFULLY' });
};

export const setUserStatus = data => (dispatch) => {
  dispatch({ type: 'SET_USER_STATUS_REQUEST' });

  return axios({
    method: 'post',
    url: '/api/v1/users/set-user-status',
    params: {
      ...data
    }
  }).then((res) => {
    const { user } = res.data;
    return dispatch({ type: 'SET_USER_STATUS_SUCCESS', payload: user });
  });
};

export const getNoOfActiveProducts = () => (dispatch) => {
  dispatch({ type: 'GET_NO_OF_ACTIVE_PRODUCTS_REQUEST' });

  axios({
    method: 'get',
    url: '/api/v1/users/no-of-active-products',
    params: {
    }
  }).then(({ data }) => {
    return dispatch({ type: 'GET_NO_OF_ACTIVE_PRODUCTS_SUCCESS', payload: data });
  });
};

export const updateReferralCode = updatedReferralCode => (dispatch) => {
  axios({
    method: 'post',
    url: '/api/v1/users/update-referral-code',
    params: {
      referralCode: updatedReferralCode
    }
  }).then((res) => {
    const { status, referralCode } = res.data;

    if (status) {
      notification.success({
        duration: 4,
        message: 'Referral Code',
        description: 'Your Referral Code has been Updated Successfully!'
      });
      return dispatch({ type: 'UPDATE_USER_REFERRAL_CODE_SUCCESS', payload: { referralCode } });
    }
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Update Referral Code',
      description: data
    });
  });
};

export const deleteUsers = params => (dispatch) => {
  dispatch({ type: 'DELETE_USER_REQUEST' });
  const url = '/api/v1/users/delete-user';

  axios.delete(url, {
    params: {
      ...params
    }
  }).then((res) => {
    const { userId } = res.data;
    notification.success({
      message: 'Delete User',
      description: "User's Data has been removed Successfully"
    });

    return dispatch({ type: 'DELETE_USER_SUCCESS', payload: { userId } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Delete User',
      description: data
    });
  });
};

export const setUserReferralCode = param => (dispatch) => {
  dispatch({ type: 'SET_REFERRAL_CODE_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/users/set-referral-code',
    params: {
      ...param
    }
  }).then((res) => {
    const { user } = res.data;
    return dispatch({ type: 'SET_REFERRAL_CODE_SUCCESS', payload: user });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Set Referral Code',
      description: data
    });
    return dispatch({ type: 'SET_REFERRAL_CODE_FAILED' });
  });
};

export const setUserSignedUpDate = param => (dispatch) => {
  dispatch({ type: 'SET_SIGNED_UP_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/users/set-signed-up',
    params: {
      ...param
    }
  }).then((res) => {
    const { user } = res.data;
    return dispatch({ type: 'SET_SIGNED_UP_SUCCESS', payload: user });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Set Referral Code',
      description: data
    });
    return dispatch({ type: 'SET_SIGNED_UP_FAILED' });
  });
};

export const sendInvite = param => (dispatch) => {
  dispatch({ type: 'SEND_INVITE_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/users/send-invite',
    params: {
      ...param
    }
  }).then((res) => {
    const { newChild } = res.data;

    notification.success({
      message: 'Invited Sub User',
      description: `${newChild.name} has been Invited via Emailed Successfully`
    });

    dispatch({ type: 'SEND_INVITE_SUCCESS', payload: newChild });
    dispatch({ type: 'UNSET_INVENTORY_READ_ATTRIBUTES_FLAG', payload: { setAttributesFlag: false, attributes: null } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Send Invite Fail',
      description: data
    });
    return dispatch({ type: 'SEND_INVITE_FAILED' });
  });
};

export const sendInviteAgain = param => (dispatch) => {
  dispatch({ type: 'SEND_INVITE_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/users/send-invite-again',
    params: {
      ...param
    }
  }).then((res) => {
    const { updatedChild } = res.data;

    notification.success({
      message: 'Invited Sub User',
      description: `${updatedChild.name} has been Invited Again via Emailed Successfully`
    });

    dispatch({ type: 'SEND_INVITE_AGAIN_SUCCESS', payload: updatedChild });
    dispatch({ type: 'UNSET_INVENTORY_READ_ATTRIBUTES_FLAG', payload: { setAttributesFlag: false, attributes: null } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Send Invite Fail',
      description: data
    });
    return dispatch({ type: 'SEND_INVITE_FAILED' });
  });
};

export const getChildUser = () => (dispatch) => {
  dispatch({ type: 'GET_CHILD_USERS_REQUEST' });

  return axios({
    method: 'get',
    url: '/api/v1/users/get-child-users',
    params: {
    }
  }).then(({ data }) => {
    const { childUsers } = data;
    return dispatch({ type: 'GET_CHILD_USERS_SUCCESS', payload: { childUsers } });
  });
};

export const getDistinctRolesForDropdown = () => (dispatch) => {
  dispatch({ type: 'GET_DISTINCT_ROLES_FOR_DROPDOWN_REQUEST' });

  return axios({
    method: 'get',
    url: '/api/v1/grants/get-distinct-roles-for-dropdown',
    params: {
    }
  }).then(({ data }) => {
    const { distinctRoles } = data;
    return dispatch({ type: 'GET_DISTINCT_ROLES_FOR_DROPDOWN_SUCCESS', payload: { distinctRoles } });
  });
};

export const deleteChildUser = param => (dispatch) => {
  dispatch({ type: 'DELETE_CHILD_USER_REQUEST' });
  const url = '/api/v1/users/delete-child-user';

  axios.delete(url, {
    params: {
      ...param
    }
  }).then((res) => {
    const { _id } = res.data;
    notification.success({
      message: 'Delete Sub User',
      description: 'Sub User has been Deleted Successfully'
    });

    return dispatch({ type: 'DELETE_CHILD_USER_SUCCESS', payload: { _id } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Delete User',
      description: data
    });
  });
};

export const openSetInventoryReadAttributesModal = () => (dispatch) => {
  dispatch({ type: 'SET_INVENTORY_READ_ATTRIBUTES_FLAG', payload: { setAttributesFlag: true } });
};

export const closeSetInventoryReadAttributesModal = inventortAttributes => (dispatch) => {
  dispatch({ type: 'UNSET_INVENTORY_READ_ATTRIBUTES_FLAG', payload: { setAttributesFlag: false, attributes: inventortAttributes } });
};

export const openUpdateRoleModal = childToBeUpdated => (dispatch) => {
  dispatch({ type: 'SET_ROLE_UPDATE_FLAG', payload: { setRoleUpdateFlag: true, childToBeUpdated } });
};

export const closeUpdateRoleModal = () => (dispatch) => {
  dispatch({ type: 'SET_ROLE_UPDATE_FLAG', payload: { setRoleUpdateFlag: false, childToBeUpdated: null, attributes: null } });
};

export const hideAttributeFieldOfUpdateRoleModal = () => (dispatch) => {
  dispatch({ type: 'SET_ROLE_UPDATE_FLAG', payload: { attributes: null } });
};

export const setValidateFormFlag = validateFormFlag => (dispatch) => {
  dispatch({ type: 'SET_VALIDATE_FORM_FLAG', payload: { validateFormFlag } });
};

export const fetchAttributes = roleToFetchAttribute => (dispatch) => {
  dispatch({ type: 'FETCH_ATTRIBUTES_TO_UPDATE_CHILD_USERS_ROLE_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/users/fetch-attributes-to-update-inventory-read-role',
    params: {
      roleToFetchAttribute
    }
  }).then((res) => {
    const { attributes } = res.data;
    return dispatch({ type: 'FETCH_ATTRIBUTES_TO_UPDATE_CHILD_USERS_ROLE_SUCCESS', payload: { attributes } });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Fetch Attributes Of Inventory Read Role',
      description: data
    });
    return dispatch({ type: 'FETCH_ATTRIBUTES_TO_UPDATE_CHILD_USERS_ROLE_FAILED', payload: { childToBeUpdated: null, attributes: null } });
  });
};

export const updateChildRole = param => (dispatch) => {
  dispatch({ type: 'UPDATE_CHILD_USERS_ROLE_REQUEST' });

  axios({
    method: 'post',
    url: '/api/v1/users/set-child-user-role',
    params: {
      ...param
    }
  }).then((res) => {
    const { childUser } = res.data;
    return dispatch({ type: 'UPDATE_CHILD_USERS_ROLE_SUCCESS', payload: childUser });
  }).catch((error) => {
    const { data } = error.response;

    notification.error({
      message: 'Update Sub User Role',
      description: data
    });
    return dispatch({ type: 'UPDATE_CHILD_USERS_ROLE_FAILED' });
  });
};
