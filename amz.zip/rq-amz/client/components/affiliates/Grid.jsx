import React from 'react';
import { AgGridReact } from 'ag-grid-react';
import { connect } from 'react-redux';
import { find, includes } from 'lodash';

import { getAffiliates, setAffiliateToDelete } from '../../actions/affiliate';
import './Grid.less';

const sideBarDef = {
  toolPanels: [{
    id: 'columns',
    labelDefault: 'Columns',
    labelKey: 'columns',
    iconKey: 'columns',
    toolPanel: 'agColumnsToolPanel',
    toolPanelParams: {
      suppressPivots: true,
      suppressPivotMode: true,
      suppressValues: true
    }
  }, {
    id: 'filters',
    labelDefault: 'Filters',
    labelKey: 'filters',
    iconKey: 'filter',
    toolPanel: 'agFiltersToolPanel'
  }]
};

let rowNodeToBeRemembered;

class AffiliateGrid extends React.Component {
  componentDidMount() {
    const {  getAffiliates } = this.props;
    getAffiliates();
  }

  gridReady = (params) => {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
    const { delAffiliates } = this.props.affiliate;
    const delIds = delAffiliates.map(affi => affi._id);

    this.gridApi.forEachNode((node) => {
      if (includes(delIds, node.data._id)) {
        node.setSelected(true);
      }
    });
  }

  handleSelectionChange = (params) => {
    const rows = params.api.getSelectedNodes();
    const delAffiliates = [];
    const { setAffiliateToDelete } = this.props;

    rows.map(({data}) => {
      delAffiliates.push(data);
    });
    setAffiliateToDelete({delAffiliates});
  }

  getNoOfUsers = (userId) => {
    const { noOfAffiliatedUsers } = this.props.affiliate;

    for (let i = 0; i < noOfAffiliatedUsers.length; i += 1) {
      if (noOfAffiliatedUsers[i]._id === userId) 
        return noOfAffiliatedUsers[i].noOfUsers;
    };
  }

  componentDidUpdate(prevProps) {
    const { fetching, affiliates } = this.props.affiliate;

    if (!fetching && this.gridApi) {
      if (affiliates && affiliates.length > 0) {
        // Update node of saved affiliate
        if (rowNodeToBeRemembered) {
          const { email } = rowNodeToBeRemembered.data;
          const affiliate = find(affiliates, { email });
          rowNodeToBeRemembered.data = affiliate;
          this.gridApi.redrawRows({
            rowNodes: [rowNodeToBeRemembered]
          });

          rowNodeToBeRemembered = undefined;
        }
      }
    }
  }

  columnDefinitions = [{
    headerName: '',
    field: '',
    menuTabs: [],
    pinned: true,
    width: 40,
    checkboxSelection: true,
    headerCheckboxSelection: true,
    sortable: false,
  }, {
    headerName: 'Name',
    field: 'name',
    width: 150,
    resizable: true,
    sortable: true,
  }, {
    headerName: 'Email',
    field: 'email',
    width: 240,
    resizable: true,
    sortable: true,
  }, {
    headerName: 'Referral Code',
    field: 'referralCode',
    width: 130
  }, {
    headerName: 'No of Referred Users',
    field: '_id',
    width: 170,
    cellRendererFramework: ({ value }) => {
      const noOfUsers = this.getNoOfUsers(value);
      return (
        <div>
          {noOfUsers}
        </div>
      );
    }
  },{
    headerName: 'Duration',
    field: 'duration',
    width: 100
  }, {
    headerName: 'Coupon Off Percentage',
    field: 'couponOffPercent',
    width: 180
  }];

  render() {
    const { affiliates } = this.props.affiliate;
    return (
      <div style={{ height: 'calc(100% - 52px)' }}>
        <div className='ag-theme-balham' style={{ height: 'calc(100% - 32px)', padding: 10 }}>
          <AgGridReact
            reactNext={true}
            onGridReady={this.gridReady}
            rowSelection='multiple'
            deltaRowDataMode={true}
            animateRows={true}
            columnDefs={this.columnDefinitions}
            rowData={affiliates}
            rowHeight={30}
            getRowNodeId={({ _id }) => _id}
            pagination={false}
            suppressRowClickSelection={true}
            suppressPaginationPanel={true}
            suppressScrollOnNewData={true}
            singleClickEdit={true}
            sideBar={sideBarDef}
            // onSelectionChanged={this.handleSelectionChange}
          />
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ users, affiliate }) => ({ users, affiliate });
const mapDispatchToProps = dispatch => ({
  getAffiliates: () => dispatch(getAffiliates()),
  setAffiliateToDelete: (data) => dispatch(setAffiliateToDelete(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(AffiliateGrid)
