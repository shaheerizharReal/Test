import React from 'react';
import {
  Input,
  Modal,
  Form,
  Button,
  notification,
  Select
} from 'antd';
import { connect } from 'react-redux';

import { addAffiliate } from '../../actions/affiliate'

const { Option } = Select;

const ModalFormToAddAffilate = Form.create({ name: 'form_in_modal' })(
  class extends React.Component {
    state = {
      duration: 'once'
    };

    handleSubmit = (e) => {
      e.preventDefault();
      let isReferrelCodeUnique = true;
      const { form } = this.props;
      const { affiliates } = this.props.affiliate;
      const usedReferralCodes = affiliates.map((affi) => affi.referralCode);

      form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          const { name, referralCode, couponOffPercent, duration } = values;
          let { email } = values;

          email = email.toLowerCase();
          usedReferralCodes.map((refCode) => {
            if (refCode === referralCode) {
              isReferrelCodeUnique = false;
            }
          });
          if (isReferrelCodeUnique) {
            const { duration } = this.state;
            this.props.addAffiliate({ name, email, referralCode, couponOffPercent, duration });
            const { onCancel } = this.props;
            form.resetFields();
            onCancel();
          } else {
            notification.error({
              message: 'Referral Code',
              description: ' Please Enter Unique a Refferal Code '
            });
          }
        }
      });
    }

    handleChange = ({key}) => {
      this.setState({ duration: key });
    }

    render() {
      const { visible, onCancel, handleSubmit, form } = this.props;
      const { getFieldDecorator } = form;
      return (
        <Modal
          visible={visible}
          title="Want to Add Affiliate"
          okText='Add Affiliate'
          closable={false}
          footer={[
            <Button key="cancel" type="primary" onClick={onCancel}>
              Cancel
            </Button>,
            <Button key="submit" type="primary"  onClick={this.handleSubmit}>
              Ok
            </Button>
          ]}
        >
          <Form layout="vertical" onSubmit={handleSubmit}>
            <Form.Item >
                {getFieldDecorator('name', {
                rules: [{ required: true, message: 'Please input the Name of Affiliate!' }],
                })(<Input placeholder="Name"/>)}
            </Form.Item>

            <Form.Item >
                {getFieldDecorator('email', {
                rules: [{ required: true, message: 'Please input the Email of Affiliate!' }],
                })(<Input type="email"  placeholder="Email" />)}
            </Form.Item>

            <Form.Item >
                {getFieldDecorator('referralCode', {
                rules: [{ required: true, message: 'Please input the Referral Code of Affiliate!' }],
                })(<Input type="text"  placeholder="Referral Code" />)}
            </Form.Item>

            <Form.Item >
                {getFieldDecorator('couponOffPercent', {
                rules: [{ required: true, message: 'Please input the Coupon Off Percentage of Affiliate!' }],
                })(<Input type="number"  placeholder="Coupon Off Percentage" />)}
            </Form.Item>

            <Form.Item >
              <Select
                labelInValue
                defaultValue={{ key: 'once' }}
                style={{ width: 470 }}
                onChange={this.handleChange}
              >
                <Option value="once">Once</Option>
                <Option value="forever">Forever</Option>
              </Select>
            </Form.Item>
          </Form>
        </Modal>
      );
    }
  }
);

const mapStateToProps = ({ users, affiliate }) => ({
  users, affiliate
});

const mapDispatchToProps = dispatch => ({
  addAffiliate: ({ name, email, referralCode, couponOffPercent, duration }) => 
    dispatch(addAffiliate({ name, email, referralCode, couponOffPercent, duration }))
});

export default connect(mapStateToProps, mapDispatchToProps)(ModalFormToAddAffilate);
