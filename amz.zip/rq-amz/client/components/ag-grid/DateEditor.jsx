import moment from 'moment';

function DateEditor() { }

DateEditor.prototype.init = function (params) {
  this.eInput = document.createElement('input');
  this.eInput.type = 'date';
  this.eInput.style.width = '100%';
  this.eInput.style.height = '100%';

  this.eInput.value = moment(params.value).format("YYYY-MM-DD");
};

DateEditor.prototype.getGui = function () {
  return this.eInput;
};

DateEditor.prototype.afterGuiAttached = function () {
  this.eInput.focus();
  this.eInput.select();
};

DateEditor.prototype.getValue = function () {
  const value = this.eInput.value;
  if (moment(value).isValid()) {
    return moment(this.eInput.value, "YYYY-MM-DD");
  }
  return null;
};

DateEditor.prototype.destroy = function () {

};

DateEditor.prototype.isPopup = function () {
  return false;
};

export default DateEditor;
