import React from 'react';
import moment from 'moment';
import { DatePicker } from 'antd';

class DatePickerCell extends React.Component {
  constructor(props) {
    super(props);
  }

  disabledDate = (currentDate) => {
    return currentDate <= moment({ month: 11, day: 1, year: 2019 });
  }

  selectDate = (updatedDate) => {
    this.props.setValue(updatedDate);
  }

  render() {
    const { value } = this.props;

    return (
      <div>
        <DatePicker
          size='small' 
          allowClear={false} 
          value={value ? moment(value) : null} 
          format='LL'
          defaultPickerValue={moment({ month: 11, day: 1, year: 2019 })}
          disabledDate={this.disabledDate}
          onChange={this.selectDate}
        />
      </div>
    );
  }
}

export default DatePickerCell;
