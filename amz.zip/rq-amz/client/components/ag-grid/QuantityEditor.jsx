function quantityInputEditor() { }

quantityInputEditor.prototype.init = function (params) {
  this.eInput = document.createElement('input');
  this.eInput.type = 'number';
  this.eInput.min = 1;
  this.eInput.style.width = '100%';
  this.eInput.style.height = '100%';
};

quantityInputEditor.prototype.getGui = function () {
  return this.eInput;
};

quantityInputEditor.prototype.afterGuiAttached = function () {
  this.eInput.focus();
  this.eInput.select();
};

quantityInputEditor.prototype.getValue = function () {
  return this.eInput.value;
};

quantityInputEditor.prototype.destroy = function () {

};

quantityInputEditor.prototype.isPopup = function () {
  return false;
};

export default quantityInputEditor;
