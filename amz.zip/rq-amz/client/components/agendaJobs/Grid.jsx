import React from 'react';
import { notification, Button, Pagination, Spin } from 'antd';
import { AgGridReact } from 'ag-grid-react';
import { connect } from 'react-redux';
import moment from 'moment';

import { requeueAgendaJob, removeAgendaJob, getAgendaJobs, setPage, setPageSize } from '../../actions/agendaJobs';
import './Grid.less';


const sideBarDef = {
  toolPanels: [{
    id: 'columns',
    labelDefault: 'Columns',
    labelKey: 'columns',
    iconKey: 'columns',
    toolPanel: 'agColumnsToolPanel',
    toolPanelParams: {
      suppressPivots: true,
      suppressPivotMode: true,
      suppressValues: true
    }
  }, {
    id: "filters",
    labelDefault: "Filters",
    labelKey: "filters",
    iconKey: "filter",
    toolPanel: "agFiltersToolPanel"
  }]
};

class AgendaJobsGrid extends React.Component {
  columnDefinitions = [{
    headerName: '',
    field: '',
    menuTabs: [],
    pinned: true,
    width: 40,
    checkboxSelection: true,
    headerCheckboxSelection: true,
    sortable: false,
  }, {
    headerName: 'Name',
    field: 'name',
    width: 170
  }, {
    headerName: 'User',
    field: 'userName',
    width: 130
  }, {
    headerName: 'State',
    field: 'state',
    width: 120
  }, {
    headerName: 'Progress',
    field: 'progress',
    width: 100
  }, {
    headerName: 'Last Started',
    field: 'lastRunAt',
    width: 150,
    cellRenderer: ({ value }) => {
      return moment(value).fromNow()
    }
  }, {
    headerName: 'Next Run Starts',
    field: 'nextRunAt',
    width: 150,
    cellRenderer: ({ value }) => {
      return moment(value).fromNow()
    }
  }, {
    headerName: 'Last Finished',
    field: 'lastFinishedAt',
    width: 150,
      cellRenderer: ({ value }) => {
        return moment(value).fromNow()
    }
  }, {
    headerName: 'Locked At',
    field: 'lockedAt',
    width: 210,
    cellRenderer: ({ value }) => {
      if (value){
        return moment(value).format('LLL');
      }
      return 'N/A';
    }
  }, {
    headerName: 'Actions',
    width: 200,
    pinned: 'right',
    cellRendererFramework: (params) => {
      return (
        <div style={{ textAlign: 'center' }}>
          <Button onClick={() => this.removeJob(params.data)} icon="close" style={{ width:50, marginRight: '10px' }} size='small'></Button>
          <Button onClick={() => this.reQueueJob(params.data)} icon="reload" style={{ width: 50, marginRight: '10px' }} size='small'></Button>
        </div>
      );
    }
  }];


  componentDidMount() {
    const { getAgendaJobs } = this.props;
    getAgendaJobs();
  }

  reQueueJob = (selectedJob) => {
    const { _id } = selectedJob
    const { requeueAgendaJob } = this.props;
    requeueAgendaJob(_id);
  }

  removeJob = (selectedJob) => {
    const {_id} = selectedJob
    const { removeAgendaJob } = this.props;
    removeAgendaJob(_id);

    notification['success']({
      duration: 2,
      message: 'Agenda job removed successfully'
    });

  }

  gridReady = (params) => {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
  }

  render() {
    const { fetching, pagination,onPageChange,onPageSizeChange, agendaJobs, total } = this.props;

    return (
      <div style={{ height: 'calc(100% - 52px)' }}>
        <div className='ag-theme-balham' style={{ height: 'calc(100% - 32px)', padding: 10 }}>
          <Spin tip="Loading..." spinning={fetching}>
            <AgGridReact
              reactNext={true}
              onGridReady={this.gridReady}
              rowSelection='multiple'
              deltaRowDataMode={true}
              animateRows={true}
              columnDefs={this.columnDefinitions}
              rowData={agendaJobs}
              rowHeight={30}
              getRowNodeId={({ _id }) => _id}
              pagination={false}
              suppressRowClickSelection={true}
              suppressPaginationPanel={true}
              suppressScrollOnNewData={true}
              sideBar={sideBarDef}
            />
          </Spin>
        </div>
        <div style={{ float: 'right' }}>
          <Pagination
            current={pagination.pageNumber}
            defaultPageSize={pagination.pageSize ? pagination.pageSize:25}
            pageSizeOptions={['25', '50', '100']}
            showSizeChanger
            onShowSizeChange={onPageSizeChange}
            showQuickJumper
            defaultCurrent={1}
            total={total}
            onChange={onPageChange}
            showTotal={(total, range) => `${range[0]}-${range[1]} of ${total} items`}
          />
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ agendaJobs }) => (agendaJobs);
const mapDispatchToProps = dispatch => ({
  removeAgendaJob: (id) => dispatch(removeAgendaJob(id)),
  requeueAgendaJob: (id) => dispatch(requeueAgendaJob(id)),
  getAgendaJobs: () => dispatch(getAgendaJobs()),
  onPageChange: (pageNumber) => {
    dispatch(setPage(pageNumber));
    dispatch(getAgendaJobs())
  },
  onPageSizeChange: (current, pageSize) => {
    dispatch(setPage(1));
    dispatch(setPageSize(pageSize));
    dispatch(getAgendaJobs());
  },
  handleFilterChanged: (params) => {
    const filter = params.api.getFilterModel();
    dispatch(setFilters(filter));
    dispatch(setPage(1));
    dispatch(getAgendaJobs());
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(AgendaJobsGrid)
