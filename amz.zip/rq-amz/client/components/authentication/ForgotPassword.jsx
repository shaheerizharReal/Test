import React from 'react';
import {
  Form,
  Input,
  Button
} from 'antd';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

import './ForgotPassword.less';

import { forgotPassword } from '../../actions/users';

class ForgotPasswordForm extends React.Component {
  handleSubmit = (e) => {
    e.preventDefault();

    const { form, forgotPassword } = this.props;
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let { email } = values;
        email = email.toLowerCase();
        forgotPassword({ email });
      }
    });
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <div className="forgot-password-form">
        <Form onSubmit={this.handleSubmit}>
          <Form.Item>
            {getFieldDecorator('email', {
              rules: [{
                type: 'email', message: 'Please enter valid email!',
              }, {
                required: true, message: 'Please input your email!'
              }],
            })(
              <Input autoComplete="email" placeholder="Email" />
            )}
          </Form.Item>
          <Form.Item>
            <Button loading={this.props.fetching} type="primary" htmlType="submit" className="forgot-password-button">
              Reset Password
            </Button>
            <Link style={{ float: 'right' }} to='/auth/login'>login now!</Link>
          </Form.Item>
        </Form>
      </div>
    );
  }
}

const WrappedForgotPasswordForm = Form.create({ name: 'forgot-password' })(ForgotPasswordForm);

const mapStateToProps = ({ user }) => ({
  fetching: user.fetching,
});

const mapDispatchToProps = (dispatch) => ({
  forgotPassword: ({ email }) => {
    return dispatch(forgotPassword({ email }));
  }
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(WrappedForgotPasswordForm);
