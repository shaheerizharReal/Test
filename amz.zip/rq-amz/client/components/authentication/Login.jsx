import React from 'react';
import axios from 'axios';
import {
  Form,
  Input,
  Button,
  Checkbox
} from 'antd';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

const AUTHORIZATION = localStorage.getItem('loginToken');
axios.defaults.headers.common['Authorization'] = `JWT ${AUTHORIZATION}`;

import { loginUser } from '../../actions/users';
import { NavbarDataSource } from '../../../config/data.source';
import Navbar from '../landing/Navbar.jsx';
import './Login.less';
import '../../public/images/replen-dashboard_logo.svg';

class NormalLoginForm extends React.Component {
  handleSubmit = (e) => {
    e.preventDefault();

    const { form, loginUser } = this.props;
    this.props.form.validateFields((err, values) => {
      if (!err) {
        const { password } = values;
        let { email } = values;
        email = email.toLowerCase();
        loginUser({ email, password });
      }
    });
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <div style={{background: 'url(../../public/images/landing-bg.png)'}}>
        <div>
          <Navbar
            id="Nav0_0"
            key="Nav0_0"
            dataSource={NavbarDataSource}
          />
        </div>
        <div>
          <div className="form-login" >
            <Form onSubmit={this.handleSubmit} className="login-form">
              <Form.Item>
                {getFieldDecorator('email', {
                  rules: [{
                    type: 'email', message: 'Please enter valid email!',
                  }, {
                    required: true, message: 'Please input your email!'
                  }],
                })(
                  <Input autoComplete="email" placeholder="Email" />
                )}
              </Form.Item>
              <Form.Item>
                {getFieldDecorator('password', {
                  rules: [{ required: true, message: 'Please input your Password!' }],
                })(
                  <Input type="password" autoComplete="new-password" placeholder="Password" />
                )}
              </Form.Item>
              <Form.Item>
                {getFieldDecorator('remember', {
                  valuePropName: 'checked',
                  initialValue: true,
                })(
                  <Checkbox>Remember me</Checkbox>
                )}
                <Link className="login-form-forgot" to='/auth/forgot-password'>Forgot Password</Link>
                <Button type="primary" htmlType="submit" className="login-form-button">
                  Log in
                </Button>
                Or <Link to='/auth/register'>Register now!</Link>
              </Form.Item>
            </Form>
          </div>
        </div>
      </div>
    );
  }
}

const WrappedNormalLoginForm = Form.create({ name: 'normal_login' })(NormalLoginForm);

const mapStateToProps = ({ user }) => ({
  fetching: user.fetching,
});

const mapDispatchToProps = (dispatch) => ({
  loginUser: ({ email, password }) => {
    return dispatch(loginUser({ email, password }));
  }
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(WrappedNormalLoginForm);
