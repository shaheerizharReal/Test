import React from 'react';
import {
  Form,
  Input,
  Button
} from 'antd';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

import { registerUser } from '../../actions/users';
import { NavbarDataSource } from '../../../config/data.source';
import Navbar from '../landing/Navbar.jsx';
import './Register.less';

class RegistrationForm extends React.Component {
  state = {
    confirmDirty: false
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const { form, registerUser } = this.props;
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        const { userName, password } = values;
        let { email, referralCode } = values;
        email = email.toLowerCase();
        referralCode = referralCode ? referralCode.trim() : '';
        registerUser({ userName, email, password, referralCode });
      }
    });
  }

  handleConfirmBlur = (e) => {
    const value = e.target.value;
    this.setState({ confirmDirty: this.state.confirmDirty || !!value });
  }
  compareToRepeatPassword = (rule, value, callback) => {
    const { form } = this.props;
    const { setFields } = this.props.form;
    if (value && value !== form.getFieldValue('confirm')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      setFields({
        confirm: {
          value: form.getFieldValue('confirm'),
          errors: null
        },
      });
      callback();
    }
  }

  compareToFirstPassword = (rule, value, callback) => {
    const { form } = this.props;
    const { setFields } = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      setFields({
        password: {
          value: form.getFieldValue('password'),
          errors: null
        },
      });
      callback();
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <div style={{background: '../../public/images/landing-bg.png'}}>
        <div>
          <Navbar
            id="Nav0_0"
            key="Nav0_0"
            dataSource={NavbarDataSource}
          />
        </div>
        <div className="form">
          <Form onSubmit={this.handleSubmit}>
            <Form.Item>
              {getFieldDecorator('userName', {
                rules: [{
                  required: true, message: 'Please input your Full Name',
                }],
              })(
                <Input placeholder="Name" />
              )}
            </Form.Item>
            <Form.Item>
              {getFieldDecorator('email', {
                rules: [{
                  type: 'email', message: 'Please enter valid email!',
                }, {
                  required: true, message: 'Please input your email!'
                }],
              })(
                <Input autoComplete="email" placeholder="Email" />
              )}
            </Form.Item>
            <Form.Item>
              {getFieldDecorator('password', {
                rules: [{ required: true, message: 'Please input your Password!' },{
                  validator: this.compareToRepeatPassword,
                }],
              })(
                <Input type="password" autoComplete="new-password" placeholder="Password" />
              )}
            </Form.Item>
            <Form.Item
            >
              {getFieldDecorator('confirm', {
                rules: [{
                  required: true, message: 'Please confirm your password!',
                }, {
                  validator: this.compareToFirstPassword,
                }],
              })(
                <Input type="password" autoComplete="new-password" placeholder="Confirm Password" onBlur={this.handleConfirmBlur} />
              )}
            </Form.Item>
            <Form.Item>
              {getFieldDecorator('referralCode', {
                rules: [{
                  required: false, message: 'Please input your Refferal Code!',
                }],
              })(
                <Input placeholder="Refferal Code" />
              )}
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" className="login-form-button">
                Register
              </Button>
              Or <Link to='/auth/login'>login now!</Link>
            </Form.Item>
          </Form>
        </div>
      </div>
    );
  }
}

const WrappedRegistrationForm = Form.create({ name: 'register' })(RegistrationForm);

const mapStateToProps = ({ user }) => ({
  fetching: user.fetching,
});

const mapDispatchToProps = (dispatch) => ({
  registerUser: ({ userName, email, password, referralCode }) => {
    return dispatch(registerUser({ userName, email, password, referralCode }));
  }
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(WrappedRegistrationForm)
