import React from 'react';
import {
  Form, Input, Button
} from 'antd';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

import { updatePassword } from '../../actions/users';

import './ResetPassword.less';

class ResetPasswordForm extends React.Component {
  state = {
    confirmDirty: false
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const { form, updatePassword } = this.props;
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        const { password } = values;

        const resetPasswordToken = this.props.match.params.resetPasswordToken;
        updatePassword({ resetPasswordToken, password });
      }
    });
  }

  handleConfirmBlur = (e) => {
    const value = e.target.value;
    this.setState({ confirmDirty: this.state.confirmDirty || !!value });
  }

  compareToFirstPassword = (rule, value, callback) => {
    const { form } = this.props;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      callback();
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <div className="reset-password-form">
        <Form onSubmit={this.handleSubmit}>
          <Form.Item>
            {getFieldDecorator('password', {
              rules: [{ required: true, message: 'Please input your New Password!' }],
            })(
              <Input type="password" autoComplete="new-password" placeholder="New Password" />
            )}
          </Form.Item>
          <Form.Item>
            {getFieldDecorator('confirm', {
              rules: [{
                required: true, message: 'Please confirm your New password!',
              }, {
                validator: this.compareToFirstPassword,
              }],
            })(
              <Input type="password" autoComplete="new-password" placeholder="Confirm New Password" onBlur={this.handleConfirmBlur} />
            )}
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit" className="login-form-button">
              Update Password
            </Button>
            { 
              (this.props.showLogin) ?
                <Link to='/auth/login'>Login Now!</Link> :
                null
            }
          </Form.Item>
        </Form>
      </div>
    );
  }
}

const WrappedResetPasswordForm = Form.create({ name: 'reset-password' })(ResetPasswordForm);

const mapStateToProps = ({ user }) => ({
  fetching: user.fetching,
  showLogin: user.showLoginTag
});

const mapDispatchToProps = (dispatch) => ({
  updatePassword: ({ password, resetPasswordToken }) => {
    return dispatch(updatePassword({ resetPasswordToken, password }));
  }
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(WrappedResetPasswordForm)
