import React from 'react';
import {
  Input,
  Modal,
  Form,
  Button,
  Switch,
  Row,
  Col,
  Tag
} from 'antd';
import { connect } from 'react-redux';

import { addShortcut } from '../../actions/customAsinShortcut';

const ModalFormToAddShortcut = Form.create({ name: 'form_in_modal' })(
  class extends React.Component {
    state = {
      next: false,
      visibility: true
    }

    handleSubmit = (e) => {
      e.preventDefault();
      const { form, addShortcut } = this.props;
  
      form.validateFields((err, values) => {
        if (!err) {
          const { visibility } = this.state;
          const { displayName, iconText } = values;
          let { url } = values;
          let asin = url.substring(url.indexOf('B0'),url.indexOf('B0')+10);
          url = url.replace(asin, 'ASIN');
  
          addShortcut({ url, displayName, iconText, visibility });
          form.resetFields();
          this.setState({ next: false });
          this.props.onCancel();
        }
      });
    };
 
    validateUrl = (rule, url, callback) => {
      let asin = url.substring(url.indexOf('B0'),url.indexOf('B0')+10);
      let isAsin = asin.match(/(B0[\d\w]{8})|[\d]{10}/);
      if (url !== '' && !!isAsin && (url.indexOf('https://') !== -1 || url.indexOf('http://') !== -1)) {
        this.setState({ next: true });
        callback();
      } else {
        this.setState({ next: false });
        callback('Please Input Valid URL!');
      }
    };
   
    valdateIconText = (rule, value, callback) => {
      const { form } = this.props;
      const { setFields } = form;
  
      if (value !== '' && value.length <= 2 ) {
        setFields({
          iconText: {
            value: form.getFieldValue('iconText').toUpperCase(),
            errors: null
          },
        });
        callback();
      } else {
        callback('Please Input Icon Text of just 2 Characters in Capital Case!');
      }
    };
  
    toggle = () => {
      this.setState({
        visibility: !this.state.visibility,
      });
    };

    render() {
      const { visible, onCancel, form } = this.props;
      const { getFieldDecorator } = form;
      return (
        <Modal
          width={'850px'}
          visible={visible}
          title="Want to Add Shortcut"
          closable={false}
          maskClosable={true}
          onCancel={onCancel}
          footer={null}
        >
          <Form layout="vertical" onSubmit={this.handleSubmit}>

            <Form.Item label='URL:'>
              {getFieldDecorator('url', {
                rules: [
                  { required: true, message: 'Please input URL!' },
                  { validator: this.validateUrl }
                ],
              })(
                <Row gutter={24}>
                  <Col span={12}>
                    <Input placeholder="Enter URL" />
                  </Col>
                  <Col span={12}>
                    <Row>
                      <Tag style={{ float: 'left' }} color="gold">Instructions For adding URL</Tag>
                    </Row>
                    <Row>
                        Pick Any Valid ASIN (Ignore Book's ASIN) and search it on site where you want your shortcut to search on. Now pick the search result URL(containing the ASIN you searched) and place it in this Field.<br/>
                        Just Like:
                        <Tag color="magenta">https://www.amazon.com/gp/product/B0000VMEYY</Tag>
                    </Row>
                  </Col>
                </Row>
              )}
            </Form.Item>

            {(this.state.next) ?
              <div>
                <Form.Item label='Display Name:'>
                  {getFieldDecorator('displayName', {
                    rules: [{ required: true, message: 'Please input Display Name!' }],
                  })(
                    <Row gutter={24}>
                      <Col span={12}>
                        <Input placeholder=" Enter Display Name" />
                      </Col>
                      <Col span={12}>
                        <Row>
                          <Tag style={{ float: 'left' }} color="gold">Instructions For adding Display Name</Tag>
                        </Row>
                        <Row>
                            Display Name is the text which appears when you hover on your created shortcut button. Just to remember for which site you created this shortcut.<br/>
                            For URL in above instruction someone can place:
                            <Tag color="magenta">Amazon.com</Tag><br/>
                            You can also update it.
                        </Row>
                      </Col>
                    </Row>
                  )}
                </Form.Item>

                <Form.Item label='Icon Text:'>
                  {getFieldDecorator('iconText', {
                    rules: [
                      { required: true, message: 'Please input Icon Text!' },
                      { validator: this.valdateIconText }
                    ],
                  })(
                    <Row gutter={24}>
                      <Col span={12}>
                        <Input placeholder=" Enter Icon Text" />
                      </Col>
                      <Col span={12}>
                        <Row>
                          <Tag style={{ float: 'left' }} color="gold">Instructions For adding Icon Text</Tag>
                        </Row>
                        <Row>
                            Icon Text is the text which appears in your shortcut button. It must of 2 characters.<br/>
                            Following above instruction someone can place:
                            <Tag color="magenta">AZ</Tag><br/>
                            You can also update it.
                        </Row>
                      </Col>
                    </Row>
                  )}
                </Form.Item>

                <Form.Item label='Visible in List:'>
                  <Row gutter={24}>
                    <Col span={12}>
                      <Switch checked={this.state.visibility} onChange={this.toggle}/>
                    </Col>
                    <Col span={12}>
                      <Row>
                        <Tag style={{ float: 'left' }} color="gold">"Visibility" for what? </Tag>
                      </Row>
                      <Row>
                        This toggle button just let you decide, Do you want to show this shortcut in your inventory grid or just making it for later use. You can also change it later on. <br/>
                      </Row>
                    </Col>
                  </Row>
                </Form.Item>

                <Form.Item>
                  <div>
                    <Button type="primary" htmlType="submit" style={{ float: 'right' }}>Create</Button>
                    <Button key="cancel" type="primary" onClick={onCancel} style={{ float: 'right', marginRight: '10px' }}>Cancel</Button>
                  </div>
                </Form.Item>
              </div>
              : null
            }
            </Form>
        </Modal>
      );
    }
  }
);

const mapStateToProps = ({ users }) => ({ users });

const mapDispatchToProps = (dispatch) => ({
  addShortcut: (shortcut) => dispatch(addShortcut(shortcut)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ModalFormToAddShortcut);
