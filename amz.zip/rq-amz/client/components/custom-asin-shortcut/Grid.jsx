import React from 'react';
import { AgGridReact } from 'ag-grid-react';
import { connect } from 'react-redux';
import { find } from 'lodash';
import { Spin, Modal, Button, Icon, Switch } from 'antd';

import { getShortcuts, editShortcut, deleteShortcut } from '../../actions/customAsinShortcut';

import './Grid.less';

const { confirm } = Modal;

const sideBarDef = {
  toolPanels: [{
    id: 'columns',
    labelDefault: 'Columns',
    labelKey: 'columns',
    iconKey: 'columns',
    toolPanel: 'agColumnsToolPanel',
    toolPanelParams: {
      suppressPivots: true,
      suppressPivotMode: true,
      suppressValues: true
    }
  }]
};

let rowNodeToBeRemembered;

class ShortcutsGrid extends React.Component {
  urlSetter = (params) => {
    const { _id: shortcutId } = params.data;
    const { newValue, oldValue } = params;
  
    let isValueChanged = false;
    let asin = newValue.substring(newValue.indexOf('B0'), newValue.indexOf('B0') + 10);
    let isAsin = asin.match(/(B0[\d\w]{8})|[\d]{10}/);
    if (newValue && !!isAsin && (newValue.indexOf('https://') !== -1 || newValue.indexOf('http://') !== -1)
      && newValue !== oldValue) {
      isValueChanged = true;
      asin = newValue.substring(newValue.indexOf('B0'), newValue.indexOf('B0') + 10);
      const url = newValue.replace(asin, 'ASIN');
      params.data.url = url;
  
      // save node
      rowNodeToBeRemembered = params.node;

      const { handleEditShortcut } = this.props;
      handleEditShortcut({ shortcutId, setObj: { url } });
    }

    return isValueChanged;
  };

  displayNameSetter = (params) => {
    const { _id: shortcutId } = params.data;
    const { newValue, oldValue } = params;
  
    let isValueChanged = false;
    if (newValue && newValue !== oldValue) {
      isValueChanged = true;
      params.data.displayName = newValue;
  
      // save node
      rowNodeToBeRemembered = params.node;

      const { handleEditShortcut } = this.props;
      handleEditShortcut({ shortcutId, setObj: { displayName: newValue } });
    }

    return isValueChanged;
  };

  iconTextSetter = (params) => {
    const { _id: shortcutId } = params.data;
    const { newValue, oldValue } = params;
  
    let isValueChanged = false;
    if (newValue && newValue.length === 2 && newValue !== oldValue) {
      isValueChanged = true;
      params.data.iconText = newValue;
  
      // save node
      rowNodeToBeRemembered = params.node;

      const { handleEditShortcut } = this.props;
      handleEditShortcut({ shortcutId, setObj: { iconText: newValue } });
    }

    return isValueChanged;
  };

  visibilitySetter = (checked, params) => {
    const { _id: shortcutId } = params.data;
  
    params.data.visibility = checked;
  
    // save node
    rowNodeToBeRemembered = params.node;

    const { handleEditShortcut } = this.props;
    handleEditShortcut({ shortcutId, setObj: { visibility: checked } });

    return true;
  };

  handleDelete = (e, params) => {
    e.preventDefault();
    const { _id: shortcutId } = params.data;
    
    const instance = this;
    confirm({
      title: 'Delete Shortcut',
      content: 'Do you really want to delete this Shortcut?',
      okText: 'Yes',
      cancelText: 'No',
      onOk() {
        // save node
        rowNodeToBeRemembered = params.node;

        const { deleteShortcut } = instance.props;
        deleteShortcut({ shortcutId });
      },
      onCancel() {
      },
    });
  };

  componentDidUpdate(prevProps) {
    if (!this.props.customAsinShortcut.fetching && this.gridApi) {
      if (this.props.customAsinShortcut.shortcuts && this.props.customAsinShortcut.shortcuts.length > 0) {
        // Update node of saved product
        if (rowNodeToBeRemembered) {
          const { _id } = rowNodeToBeRemembered.data;
          const shortcut = find(this.props.customAsinShortcut.shortcuts, { _id });
          rowNodeToBeRemembered.data = shortcut;
          this.gridApi.redrawRows({
            rowNodes: [rowNodeToBeRemembered]
          });

          rowNodeToBeRemembered = undefined;
        }
      }
    }
  };

  columnDefinitions = [{
    headerName: '',
    field: '',
    menuTabs: [],
    pinned: true,
    width: 40,
    checkboxSelection: true,
    headerCheckboxSelection: true,
    sortable: false,
  }, {
    headerName: 'URL',
    field: 'url',
    width: 500,
    editable: true,
    valueSetter: this.urlSetter,
    cellRendererFramework: ({ value }) => {
      return (
        <div>
          <Icon type="edit" style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '5px' }} />
          {value}
        </div>
      );
    }
  }, {
    headerName: 'Display Name',
    field: 'displayName',
    width: 150,
    editable: true,
    valueSetter: this.displayNameSetter,
    cellRendererFramework: ({ value }) => {
      return (
        <div>
          <Icon type="edit" style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '5px' }} />
          {value}
        </div>
      );
    }
  }, {
    headerName: 'Icon Text',
    field: 'iconText',
    width: 100,
    editable: true,
    valueSetter: this.iconTextSetter,
    cellRendererFramework: ({ value }) => {
      return (
        <div>
          <Icon type="edit" style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '5px' }} />
          {value}
        </div>
      );
    }
  }, {
    headerName: 'Visible in List',
    field: 'visibility',
    width: 120,
    editable: true,
    cellRendererFramework: (params) => {
      return (
        <div style={{ textAlign: 'center' }}>
          <Switch checked={params.value} onChange={(e) => this.visibilitySetter(e, params)}/>
        </div>
      );
    }
  }, {
    headerName: 'Actions',
    width: 250,
    pinned: 'right',
    cellRendererFramework: (params) => {
      return (
        <div style={{ textAlign: 'center' }}>
          <Button style={{ marginRight: '10px' }} size='small' onClick={(e) => this.handleDelete(e, params)}>Delete</Button>
        </div>
      );
    }
  }];

  componentDidMount() {
    const { getShortcuts } = this.props;
    getShortcuts();
  }

  gridReady = (params) => {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
  }

  render() {
    const { shortcuts, fetching } = this.props.customAsinShortcut;

    return (
      <div style={{ height: 'calc(100% - 52px)' }}>
        <div className='ag-theme-balham' style={{ height: 'calc(100% - 32px)', padding: 10 }}>
          <Spin tip="Loading..." spinning={fetching}>
            <AgGridReact
              reactNext={true}
              onGridReady={this.gridReady}
              rowSelection='multiple'
              deltaRowDataMode={true}
              animateRows={true}
              columnDefs={this.columnDefinitions}
              rowData={shortcuts}
              rowHeight={30}
              getRowNodeId={({ _id }) => _id}
              pagination={false}
              suppressRowClickSelection={true}
              suppressPaginationPanel={true}
              suppressScrollOnNewData={true}
              sideBar={sideBarDef}
            />
          </Spin>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ customAsinShortcut }) => ({ customAsinShortcut });
const mapDispatchToProps = dispatch => ({
  getShortcuts: () => dispatch(getShortcuts()),
  handleEditShortcut: (data) => dispatch(editShortcut(data)),
  deleteShortcut: (id) => dispatch(deleteShortcut(id))
});

export default connect(mapStateToProps, mapDispatchToProps)(ShortcutsGrid)
