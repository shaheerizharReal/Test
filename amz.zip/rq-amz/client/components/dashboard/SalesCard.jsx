import React from 'react';
import {
  Card,
  Row,
  Col,
  List,
  Statistic
} from 'antd';
import moment from 'moment';

class SalesCard extends React.Component {
  constructor(props) {
    super(props);
  }

  getColorBody = (period) => {
    if (period === 'today') {
      return '#0da899';
    } else if (period === 'yesterday'){
      return '#c1666b';
    } else if (period === '15-days') {
      return '#777777';
    } else if (period === '30-days') {
      return '#4c9be8';
    } else if (period === '60-days') {
      return '#d59bd3';
    } else {
      return '#d48652'
    }
  };

  getColorHeader = (period) => {
    if (period === 'today') {
      return '#139488';
    } else if (period === 'yesterday'){
      return '#aa5d62';
    } else if (period === '15-days') {
      return '#6c6c6c';
    } else if (period === '30-days') {
      return '#0e7ce6';
    } else if (period === '60-days') {
      return '#967094';
    } else {
      return '#ba784d'
    }
  };

  getTitle = (period) => {
    if (period === 'today') {
      return `Today : ${moment().format('l')}`;
    } else if (period === 'yesterday'){
      return `Yesterday : ${moment().subtract(1, 'day').format('l')}`;
    } else if (period === '15-days') {
      return `15 Days : ${moment().subtract(15, 'days').format('l')} to ${moment().format('l')}`;
    } else if (period === '30-days') {
      return `30 Days : ${moment().subtract(30, 'days').format('l')} to ${moment().format('l')}`;
    } else if (period === '60-days') {
      return `60 Days : ${moment().subtract(60, 'days').format('l')} to ${moment().format('l')}`;
    } else {
      return `90 Days : ${moment().subtract(90, 'days').format('l')} to ${moment().format('l')}`;
    }
  };

  render() {
    const { data } = this.props;

    if (!data) {
      return null;
    }
    const leftListData = [
      { 
        title: 'Ordered Product Sales',
        value: `$${data.totalSaleAmount}`
      },
      {
        title: 'Revenue',
        value: `$${data.totalGrossProfit}`
      },
      {
        title: 'Estimated Profit',
        value: `$${data.totalNetProfit}`
      }
    ];
    const rightListData = [
      {
        title: 'Orders',
        value: data.totalOrders
      },
      {
        title: 'Units',
        value: data.totalUnitsSold
      },
      {
        title: 'Promo',
        value: `$${data.totalPromotionDiscount}`
      },
      {
        title: 'Net Margin',
        value: `${data.totalProfitPercentage}%`
      },
      {
        title: 'Net ROI',
        value: `${data.totalRoiPercentage}%`
      }
    ];
    return (
      <Card style={{ width: '100%', color: 'white', fontSize: '12px', textAlign: 'center' }}
        headStyle={{ padding: '0 10px', background: `${this.getColorHeader(data.period)}` }}
        bodyStyle={{ padding: '0 5px', background: `${this.getColorBody(data.period)}` }}
        title={
          <span style={{ color: 'white'}}> 
            {this.getTitle(data.period)}
          </span>
        }
      >
        
        <Row gutter={24} style={{margin: '0'}}>
          <Col span={12} style={{ padding: '0px' }}>
            <List
              dataSource={leftListData}
              renderItem={item => (
                <List.Item style={{ padding: '10px 0' }}>
                  <Row style={{ width: '100%', color: 'white' }}>
                    <Row style={{ fontSize: '14px' }}>
                      <b>{item.value}</b>
                    </Row>
                    <Row style={{ fontSize: '12px'}}>
                      {item.title}
                    </Row>
                  </Row>
                </List.Item>
              )}
              split={false}
            />
          </Col>
          <Col span={12} style={{ padding: '0px' }}>
            <List
              dataSource={rightListData}
              renderItem={item => (
                <List.Item style={{ padding: '9 0px' }}>
                  <Row style={{ width: '100%' }}>
                    <Statistic value={item.title} valueStyle={{color: 'white', fontSize: '10px', float: 'left' }}	/>
                    <Statistic value={item.value} valueStyle={{color: 'white', fontSize: '10px', float: 'right' }}	/>
                  </Row>
                </List.Item>
              )}
              split={true}
            />
            <hr style={{ marginTop: '0px', borderStyle: 'solid', borderWidth: '0.5px' }} />
          </Col>
        </Row>
      </Card>
    );
  };
};

export default SalesCard;
