import React from 'react';
import {
  Spin,
  Row,
  Col
} from 'antd';
import { connect } from 'react-redux';

import SalesCard from './SalesCard.jsx';

class SalesHeader extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { fetching, sales } = this.props;
    return (
      <div>
        <Spin tip="Loading..." spinning={fetching}>
          <div style={{ background: '#cdccce', padding: '10px' }}>
            <Row gutter={24}>
              <Col span={8} style={{ paddingLeft: '5px', paddingRight: '5px'}}>
                <SalesCard data={sales['today']} />
              </Col>
              <Col span={8} style={{ paddingLeft: '5px', paddingRight: '5px'}}>
                <SalesCard data={sales['yesterday']} />
              </Col>
              <Col span={8} style={{ paddingLeft: '5px', paddingRight: '5px'}}>
                <SalesCard data={sales['15-days']} />
              </Col>
            </Row>
            <Row gutter={24}>
              <Col span={8} style={{ paddingLeft: '5px', paddingRight: '5px'}}>
                <SalesCard data={sales['30-days']}/>
              </Col>
              <Col span={8} style={{ paddingLeft: '5px', paddingRight: '5px'}}>
                <SalesCard data={sales['60-days']} />
              </Col>
              <Col span={8} style={{ paddingLeft: '5px', paddingRight: '5px'}}>
                <SalesCard data={sales['90-days']} />
              </Col>
            </Row>
          </div>
        </Spin>
      </div>
    );
  };
};

const mapStateToProps = ({ dashboard }) => dashboard;

export default connect(mapStateToProps)(SalesHeader);
