import React from 'react';
import { Form, Select, Input } from 'antd';

const FormItem = Form.Item;
const { Option } = Select;

export const SelectField = ({
  label, getFieldDecorator, name, message, options, required, initialValue, onChange
}) => {
  return (
  <FormItem label={label} >
    {getFieldDecorator(name, {
      initialValue,
      rules: [{ required, message }],
    })(
      <Select onChange={onChange} style={{ 'width': '300px' }}>
        {options.map(({ value, key }) => <Option key={value} value={value}>{key}</Option>)}
      </Select>
    )}
  </FormItem>
  )
}

export const InputField = ({
  getFieldDecorator, name, message, placeholderName, iconType, required, label, initialValue, disabled
}) => {
  return (
    <FormItem label={label}>
      {getFieldDecorator(name, {
        initialValue,
        rules: [{ required, message }],
      })(
        <Input placeholder={placeholderName} disabled={disabled} />
      )}
    </FormItem>
  )
}
