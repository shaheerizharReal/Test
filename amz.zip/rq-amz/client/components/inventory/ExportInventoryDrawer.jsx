import React from 'react';
import {
  Drawer,
  Row,
  Col,
  notification,
  Button,
  Icon,
  Radio,
  Checkbox
} from 'antd';

import './Drawer.less';

const plainOptions = [
  'title',
  'asin',
  'sellerSku',
  'fnsku',
  'fulfilmentType',
  'condition',
  'status',
  'afnInboundQuantity',
  'afnReservedQuantity',
  'decidedBuyQuantity',
  'sellableQuantity',
  'afnUnsellableQuantity',
  'afnTotalQuantity',
  'suggestedBuyQuantity30Days',
  'suggestedBuyQuantity60Days',
  'suggestedBuyQuantity90Days',
  'ordersLast30Days',
  'salesLast30Days',
  'salesAmountLast30Days',
  'ordersLast60Days',
  'salesLast60Days',
  'salesAmountLast60Days',
  'ordersLast90Days',
  'salesLast90Days',
  'salesAmountLast90Days',
  'listPrice',
  'buyBoxPrice',
  'lowestOfferPrice',
  'lowestFBAOfferPrice',
  'costPrice',
  'noOfSellers',
  'referralFee',
  'fbaFee',
  'storageFee',
  'profit',
  'profitPercentage',
  'roiPercentage',
  'supplier',
  'salesRank',
  'productGroup',
  'purchaseLink',
  'storeSection',
  'notesSection',
  'enrolledInSnL',
  'openDate'
];

const CheckboxGroup = Checkbox.Group;

class ExportInventoryDrawer extends React.Component {
  constructor(props) {
    super(props);
  };

  state = {
    shouldInitializeSelectedItems: true,
    noOfselectedItems: '',
    shouldInitializeCheckedList: true,
    checkedList: [],
    isExport: false,
    indeterminate: true,
    checkAll: false,
    exportReplen: false
  };

  clearData = () => {
    this.setState({
      shouldInitializeSelectedItems: true,
      noOfselectedItems: '',
      shouldInitializeCheckedList: true,
      checkedList: [],
      isExport: false,
      indeterminate: true,
      checkAll: false,
      exportReplen: false
    });
  };

  hideDrawer = () => {
    const { isExport } = this.state;
    this.clearData();

    const { closeExportDrawer } = this.props;
    closeExportDrawer(isExport);
  };

  exportData = e => {
    const { checkedList } = this.state;
    if (checkedList && checkedList.length > 0) {
      const { selectedItems } = this.props;
      const { userId, onExportProducts } = this.props;
      const { noOfselectedItems, exportReplen } = this.state;
      onExportProducts(userId, noOfselectedItems, selectedItems, checkedList, exportReplen);

      this.setState({
        isExport: true
      });
    }
     else {
      notification.error({
        message: 'Export Products',
        description: 'No Columns Selected !!',
        style: {
          width: 350
        },
        duration: 5
      });
    }
  };

  onChange = checkedList => {
    this.setState({
      checkedList,
      indeterminate: !!checkedList.length && checkedList.length < plainOptions.length,
      checkAll: checkedList.length === plainOptions.length,
    });
  };

  onCheckAllChange = e => {
    this.setState({
      checkedList: e.target.checked ? plainOptions : [],
      indeterminate: false,
      checkAll: e.target.checked,
    });
  };

  changeNoOfSelectedItems = e => {
    this.setState({
      noOfselectedItems: e.target.value,
    });
  };

  optionsForSelectedItems = () => {
    const { selectedItems } = this.props;
    if (selectedItems && selectedItems.length > 0) {
      return (
        <div>
          <Radio value={String(selectedItems.length)}>{selectedItems.length} Products</Radio>
          <Radio value='All'>All Products</Radio>
        </div>
      );  
    }

    return <Radio value='All'>All Products</Radio>;
  };

  handleSelectReplen = () => {
    const { exportReplen } = this.state;
    this.setState({ exportReplen: !exportReplen });
  };

  showData() {
    const { noOfselectedItems, exportReplen } = this.state;

    return (
      <Row gutter={24} style={{ marginLeft: '0px', marginRight: '0px' }}>
        <Row gutter={24} style={{ borderBottom: '1px solid #E9E9E9' }}>
          <Radio.Group style={{ margin: '10px' }} onChange={this.changeNoOfSelectedItems} value={noOfselectedItems}>
            {this.optionsForSelectedItems()}
          </Radio.Group>
        </Row>
        <Row gutter={24} style={{ marginLeft: '0px', marginRight: '0px' }}>
          {
            (this.props.replenExportOption) ?
              <Row gutter={24} style={{ borderBottom: '1px solid #E9E9E9' }}>
                <Checkbox
                  style={{ margin: '10px' }}
                  onChange={this.handleSelectReplen}
                  checked={exportReplen}
                >
                  Replen
                </Checkbox>
              </Row> :
              null
          }
          <Row gutter={24} style={{ borderBottom: '1px solid #E9E9E9' }}>
            <Checkbox
              style={{ margin: '10px' }}
              indeterminate={this.state.indeterminate}
              onChange={this.onCheckAllChange}
              checked={this.state.checkAll}
            >
              Check all
            </Checkbox>
          </Row>
          <Row gutter={24} style={{ marginLeft: '10px', marginRight: '10px' }}>
            <CheckboxGroup style={{ marginTop: '10px',width: '100%' }} onChange={this.onChange} value={this.state.checkedList}>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="title" style={{ float: 'left' }}>Title</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="asin" style={{ float: 'left' }}>Asin</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="sellerSku" style={{ float: 'left' }}>Seller Sku</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="fnsku" style={{ float: 'left' }}>Fnsku</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="fulfilmentType" style={{ float: 'left' }}>Fulfilled By</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="condition" style={{ float: 'left' }}>Condition</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="status" style={{ float: 'left' }}>Status</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="afnInboundQuantity" style={{ float: 'left' }}>Inbound Quantity</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="afnReservedQuantity" style={{ float: 'left' }}>Reserved Quantity</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="sellableQuantity" style={{ float: 'left' }}>Sellable Quantity</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="afnUnsellableQuantity" style={{ float: 'left' }}>Unsellable Quantity</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="afnTotalQuantity" style={{ float: 'left' }}>Total Quantity</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="salesAmountLast30Days" style={{ float: 'left' }}>Sales Amount Last 30 Days</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="ordersLast30Days" style={{ float: 'left' }}>Orders Last 30 Days</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="salesLast30Days" style={{ float: 'left' }}>Sales Last 30 Days</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="salesAmountLast60Days" style={{ float: 'left' }}>Sales Amount Last 60 Days</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="ordersLast60Days" style={{ float: 'left' }}>Orders Last 60 Days</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="salesLast60Days" style={{ float: 'left' }}>Sales Last 60 Days</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="salesAmountLast90Days" style={{ float: 'left' }}>Sales Amount Last 90 Days</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="ordersLast90Days" style={{ float: 'left' }}>Orders Last 90 Days</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="salesLast90Days" style={{ float: 'left' }}>Sales Last 90 Days</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="suggestedBuyQuantity30Days" style={{ float: 'left' }}>Suggested Buy Quantity 30 Days</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="suggestedBuyQuantity60Days" style={{ float: 'left' }}>Suggested Buy Quantity 60 Days</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="suggestedBuyQuantity90Days" style={{ float: 'left' }}>Suggested Buy Quantity 90 Days</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="decidedBuyQuantity" style={{ float: 'left' }}>Decided Buy Quantity</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="listPrice" style={{ float: 'left' }}>Sale Price</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="buyBoxPrice" style={{ float: 'left' }}>Buy Box Price</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="lowestOfferPrice" style={{ float: 'left' }}>Lowest Offer Price</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="lowestFBAOfferPrice" style={{ float: 'left' }}>Lowest FBA Offer Price</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="costPrice" style={{ float: 'left' }}>Cost Price</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="noOfSellers" style={{ float: 'left' }}>No of Sellers</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="referralFee" style={{ float: 'left' }}>Referral Fee</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="fbaFee" style={{ float: 'left' }}>FBA Fee</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="storageFee" style={{ float: 'left' }}>Storage Fee</Checkbox>
                </Col>
               <Col span={8}>
                  <Checkbox value="profit" style={{ float: 'left' }}>Net Profit</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="profitPercentage" style={{ float: 'left' }}>Profit%</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="roiPercentage" style={{ float: 'left' }}>ROI%</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="supplier" style={{ float: 'left' }}>Supplier</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="salesRank" style={{ float: 'left' }}>Sales Rank</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="productGroup" style={{ float: 'left' }}>Category</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="purchaseLink" style={{ float: 'left' }}>Purchase Link</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="storeSection" style={{ float: 'left' }}>Store Section</Checkbox>
                </Col>
              </Row>
              <Row gutter={24}>
                <Col span={8}>
                  <Checkbox value="notesSection" style={{ float: 'left' }}>Notes Section</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="enrolledInSnL" style={{ float: 'left' }}>Enrolled in Snl</Checkbox>
                </Col>
                <Col span={8}>
                  <Checkbox value="openDate" style={{ float: 'left' }}>Date Added</Checkbox>
                </Col>
              </Row>
            </CheckboxGroup>
          </Row>
        </Row>
        <Row gutter={24} style={{ margin: '10px' }}>
          <Button onClick={(e)=>this.exportData()}>
            <Icon type="download" /> Download
          </Button>
        </Row>
      </Row>
    );
  };

  componentDidUpdate(prevProps) {
    const { visible, columnsWanted, selectedItems } = this.props;
    if (visible && columnsWanted && columnsWanted.length > 0 && this.state.shouldInitializeCheckedList) {
      this.setState({
        checkedList: columnsWanted,
        shouldInitializeCheckedList: false
      });
    }

    if (visible && this.state.shouldInitializeSelectedItems) {
      this.setState({
        noOfselectedItems: selectedItems && selectedItems.length > 0 ? String(selectedItems.length) : 'All',
        shouldInitializeSelectedItems: false
      });
    }
  };

  render() {
    const {
      visible
    } = this.props;

    return (
      <Drawer
        title="Export Inventory"
        placement="right"
        closable={false}
        destroyOnClose={true}
        onClose={this.hideDrawer}
        visible={visible}
        getContainer={false}
        width={850}
        style={{ position: 'absolute', textAlign: 'center' }}
      >
        {this.showData()}
      </Drawer>
    );
  };
};

export default ExportInventoryDrawer;
