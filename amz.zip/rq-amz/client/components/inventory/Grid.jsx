import React from 'react';
import { Icon, Pagination, Spin, Button, Popover, Checkbox, Switch, Input, notification, Alert } from 'antd';
import { AgGridReact } from 'ag-grid-react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { round, find, uniqBy } from 'lodash';
import moment from 'moment';
import AccessControl from 'accesscontrol';

import {
  getProducts,
  setPage,
  setPageSize,
  setSortFilters,
  setFilters,
  resetAllFiltersAndSelections,
  setSellectedItems,
  setCostPrice,
  setDecideBuyQuantity,
  setSupplier,
  setPurchaseLink,
  setStoreSection,
  setNotesSection,
  setToReplen,
  setShippingCost
} from '../../actions/inventory';
import { getDefaultCalculationPrice } from '../../actions/users';
import { getShortcuts } from '../../actions/customAsinShortcut';
import { CONDITION_TYPE } from '../../../config/constants';
import './Grid.less';
import ChooseDefaultCalculationPrice from '../../utils/functions';

import '../../public/images/no-image.png';

const sideBar = {
  toolPanels: [{
    id: 'columns',
    labelDefault: 'Columns',
    labelKey: 'columns',
    iconKey: 'columns',
    toolPanel: 'agColumnsToolPanel',
    toolPanelParams: {
      suppressPivots: true,
      suppressPivotMode: true,
      suppressValues: true
    }
  }, {
    id: 'filters',
    labelDefault: 'Filters',
    labelKey: 'filters',
    iconKey: 'filter',
    toolPanel: 'agFiltersToolPanel'
  }],
  defaultToolPanel: false
};
let columnDefinitions = [];
let rowNodeToBeRemembered;
let rowNodeToBeRememberedForShippingRate;
class InventoryGrid extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: undefined,
      categoriesLength: 0,
      suppliersLength: 0,
      shippingRate: 0.25,
      shippingRateForByItem: 1,
      newColumnExists: false
    };
  }

  handleSelectionChange = () => {
    if (this.gridApi && this.state.pagination && this.props.inventory.pagination.pageNumber === this.state.pagination.pageNumber) {
      // db Items
      let { selectedItems } = this.props.inventory;

      // del this page items
      selectedItems = selectedItems.filter(item => item.pageNo !== this.props.inventory.pagination.pageNumber);

      // this page items
      const selectedItemsThisPage = this.gridApi.getSelectedNodes().map((row) => {
        return {
          pageNo: this.props.inventory.pagination.pageNumber,
          sellerSku: row.data.sellerSku,
          isReplen: (row.data.isReplen) ? row.data.isReplen : false
        };
      });

      // concat db and this page items
      selectedItems = selectedItems.concat(selectedItemsThisPage);

      // unique items
      selectedItems = uniqBy(selectedItems, 'sellerSku');

      // if this page items not exists
      if (selectedItemsThisPage.length === 0) {
        selectedItems = selectedItems.filter(item => item.pageNo !== this.props.inventory.pagination.pageNumber);
      }

      const { handleSellection } = this.props;
      handleSellection(selectedItems);
    }
  };

  handlePaginationChange = () => {
    const { pagination } = this.props.inventory;
    this.state.pagination = pagination;
  };

  // saveColumnState = () => {
  //   if(localStorage) {
  //     const state = JSON.stringify({
  //       columnState: this.columnApi.getColumnState()
  //     });
  //     localStorage.setItem('inventoryPageColumnsState', state);
  //   } else {
  //     console.warn('Your browser does not support localStorage');
  //   }
  // };

  saveColumnState = () => {
    if (localStorage) {
      let state = JSON.stringify({
        columnState: this.columnApi.getColumnState()
      });
      const realColumnState = this.columnApi.getColumnState();
      let localState = localStorage.getItem('inventoryPageColumnsState');
      if(localState) {
        let localColumnState = JSON.parse(localState).columnState;
        if(localColumnState.length !== realColumnState.length) {
          const columnState = realColumnState.filter((colS) => {
            const { colId } = colS;
            const item = find(localColumnState, { colId });
            return item ? true :false;
          });
          state = JSON.stringify({ columnState });
        }
      }
      localStorage.setItem('inventoryPageColumnsState', state);
    } else {
      console.warn('Your browser does not support localStorage');
    }
  };


  saveAndApplyFilters = (params) => {
    const filtersState = params.api.getFilterModel();
    const { handleFilterChanged } = this.props;
    handleFilterChanged(filtersState);

    if (localStorage) {
      const state = JSON.stringify({
        filtersState
      });
      localStorage.setItem('inventoryPageFiltersState', state);
    } else {
      console.warn('Your browser does not support localStorage');
    }
  }

  rowStyle = (params) => {
    const { status, listPrice, buyBoxPrice, isBuyBoxWinner, noOfSellers, lowestOfferPrice } = params.data;

    if (['Active', 'Inactive'].includes(status)) {
      // Buybox Exists & we are not Buybox Winner & Sale Price is less than Buybox Price
      if (buyBoxPrice && !isBuyBoxWinner && buyBoxPrice < listPrice) {
        // Compete to Buybox
        return { background: '#eabbbb' };
      } else if (!buyBoxPrice && noOfSellers) { // Buybox Not Exists or Suppressed and Sellers are available
        // Multiple Sellers and Lowest Price seller is other than us
        if (noOfSellers > 1 && lowestOfferPrice && lowestOfferPrice < listPrice) {
          // Lower Price to Compete with Lowest
          return { background: '#eabbbb' };
        }
      }
    }

    return { background: 'white' };
  };

  costPriceSetter = (params) => {
    const { sellerSku } = params.data;
    let { newValue, oldValue } = params;

    let isValueChanged = false;
    if (newValue) {
      const newValue = parseFloat(params.newValue);
      if (newValue >= 0 && newValue !== oldValue) {
        isValueChanged = true;
        params.data.costPrice = newValue;

        // save node
        rowNodeToBeRemembered = params.node;

        const { handleSetCostPrice } = this.props;
        handleSetCostPrice({ sellerSku, costPrice: newValue });
      }
    }

    return isValueChanged;
  };

  decideQuantitySetter = (params) => {
    const { sellerSku } = params.data;
    let { newValue, oldValue } = params;

    let isValueChanged = false;
    if (newValue) {
      const newValue = parseFloat(params.newValue);
      if (newValue >= 0 && newValue !== oldValue) {
        isValueChanged = true;
        params.data.decidedBuyQuantity = newValue;

        // save node
        rowNodeToBeRemembered = params.node;

        const { handleSetDecideBuyQuantity } = this.props;
        handleSetDecideBuyQuantity({ sellerSku, decidedBuyQuantity: newValue });
      }
    }

    return isValueChanged;
  };

  shippingRateSetter = (params) => {
    const { sellerSku, shipBy } = params.data;
    let { newValue, oldValue } = params;

    let isValueChanged = false;
    if (newValue) {
      const newValue = parseFloat(params.newValue);
      if (newValue >= 0 && newValue !== oldValue) {
        isValueChanged = true;
        params.data.shippingRate = newValue;

        // save node
        rowNodeToBeRemembered = params.node;

        const { handleSetShippingCosts } = this.props;
        handleSetShippingCosts({ sellerSku, shipBy, shippingRate: parseFloat(newValue) });
      }
    }

    return isValueChanged;
  };

  supplierSetter = (params) => {
    const { sellerSku } = params.data;
    const { newValue, oldValue } = params;

    let isValueChanged = false;
    if (newValue && newValue !== oldValue) {
      isValueChanged = true;
      params.data.supplier = newValue;

      // save node
      rowNodeToBeRemembered = params.node;

      const { handleSetSupplier } = this.props;
      handleSetSupplier({ sellerSku, supplier: newValue });
    }

    return isValueChanged;
  };

  purchaseLinkSetter = (params) => {
    const { sellerSku } = params.data;
    const { newValue, oldValue } = params;

    let isValueChanged = false;
    if (newValue !== oldValue) {
      isValueChanged = true;
      params.data.purchaseLink = newValue;

      // save node
      rowNodeToBeRemembered = params.node;

      const { handleSetPurchaseLink } = this.props;
      handleSetPurchaseLink({ sellerSku, purchaseLink: newValue });
    }

    return isValueChanged;
  };

  storeSectionSetter = (params) => {
    const { sellerSku } = params.data;
    const { newValue, oldValue } = params;

    let isValueChanged = false;
    if (newValue !== oldValue) {
      isValueChanged = true;
      params.data.storeSection = newValue;

      // save node
      rowNodeToBeRemembered = params.node;

      const { handleSetStoreSectionSetter } = this.props;
      handleSetStoreSectionSetter({ sellerSku, storeSection: newValue });
    }

    return isValueChanged;
  }

  notesSectionSetter = (params) => {
    const { sellerSku } = params.data;
    const { newValue, oldValue } = params;

    let isValueChanged = false;
    if (newValue !== oldValue) {
      isValueChanged = true;
      params.data.notesSection = newValue;

      // save node
      rowNodeToBeRemembered = params.node;

      const { handleSetNotesSectionSetter } = this.props;
      handleSetNotesSectionSetter({ sellerSku, notesSection: newValue });
    }

    return isValueChanged;
  }

  handleReplenChange = (e, params) => {
    const { sellerSku } = params.data;

    // save node
    rowNodeToBeRemembered = params.node;

    const { handleSetToReplen } = this.props;
    handleSetToReplen({ skuList: [sellerSku], isReplen: e.target.checked });
  };

  editableColumnDecider = (resorce) => {
    let permit = false;
    if (this.props.user && this.props.user.roles) {
      const ac = new AccessControl(this.props.user.roles);
      permit = ac.can(this.props.user.permission.role).updateAny(resorce).granted;
    }
    return permit;
  };

  onByWeightChange = (params) => {
    const { shippingRate } = this.state;
    if (parseFloat(shippingRate) > 0) {
      const { sellerSku } = params.data;
      params.data.shipBy = 'byWeight';

      // save node
      rowNodeToBeRemembered = params.node;

      const { handleSetShippingCosts } = this.props;
      handleSetShippingCosts({ sellerSku, shipBy: 'byWeight', shippingRate: parseFloat(shippingRate) });
    } else {
      notification.warning({
        message: 'INVALID SHIPPING RATE',
        description: 'Please enter a valid shipping rate!',
        duration: 5
      });
    }
  }

  onByItemChange = (params) => {
    const { shippingRateForByItem } = this.state;
    if (parseFloat(shippingRateForByItem) > 0) {
      const { sellerSku } = params.data;
      params.data.shipBy = 'byItem';

      // save node
      rowNodeToBeRemembered = params.node;

      const { handleSetShippingCosts } = this.props;
      handleSetShippingCosts({ sellerSku, shipBy: 'byItem', shippingRate: parseFloat(shippingRateForByItem) });
    } else {
      notification.warning({
        message: 'INVALID SHIPPING RATE',
        description: 'Please enter a valid shipping rate!',
        duration: 5
      });
    }
  }

  componentDidMount() {
    const {
      resetAllFiltersAndSelections,
      getProducts,
      getShortcuts,
      getDefaultCalculationPrice
    } = this.props;
    resetAllFiltersAndSelections();
    getProducts();
    getShortcuts();
    getDefaultCalculationPrice();

    if (this.props.user && this.props.user.roles) {
      const ac = new AccessControl(this.props.user.roles);
      const permissionControl = ac.can(this.props.user.permission.role).readAny('Inventory');
      const { attributes } = permissionControl;

      columnDefinitions = columnDefinitions.concat([{
        headerName: '',
        field: '',
        menuTabs: [],
        pinned: true,
        width: 40,
        checkboxSelection: true,
        headerCheckboxSelection: true,
        sortable: false,
        cellRenderer: (params) => {
          if (find(this.props.inventory.selectedItems, { sellerSku: params.data.sellerSku })) {
            params.node.setSelected(true, false, true);
          }
        }
      }]);
      if (attributes.includes('*') || attributes.includes('title')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Title',
          field: 'title',
          width: 250,
          filter: false,
          sortable: false,
          pinned: 'left',
          cellRenderer: ({ data, value }) => {
            const { imageUrl } = data;
            return `<img style='margin-right:10px' width='30px' height='30px' src='${imageUrl ? `https://images-na.ssl-images-amazon.com/images/I/${imageUrl}` : '/images/no-image.png'}' />${value}`;
          }
        }]);
      }
      if (attributes.includes('*') || attributes.includes('asin')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'ASIN',
          field: 'asin',
          width: 120,
          filter: false,
          sortable: false,
          cellRenderer: ({ value }) => `<a target="_blank" href='https://www.amazon.com/gp/product/${value}'>${value}</a>`
        }]);
      }
      if (attributes.includes('*') || attributes.includes('asinShortcut')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Custom ASIN Shortcuts',
          field: '',
          width: 200,
          filter: false,
          sortable: false,
          cellRendererFramework: (params) => {
            const { asin } = params.data;
            const { shortcuts } = this.props.customAsinShortcut;

            return (
              <div>
                <span style={{ float: 'right' }}>
                  <Popover key='1' placement="top" content={'Add ASIN Shortcut'}>
                    <Link to='/settings/custom-asin-shortcut'>
                      <Button shape='circle' icon='plus' size='small' target='_blank' style={{ float: 'right', marginLeft: '3px' }} />
                    </Link>
                  </Popover>
                </span>
                {
                  shortcuts.map((shortcut) => {
                    if (shortcut.visibility) {
                      return (
                        <Popover key={shortcut._id} placement='top' content={shortcut.displayName}>
                          <Button size='small' target='_blank' href={shortcut.url.replace('ASIN', asin)} style={{ float: 'right', marginLeft: '3px' }}>{shortcut.iconText}</Button>
                        </Popover>
                      )
                    }
                  })
                }
              </div>
            );
          }
        }]);
      }
      if (attributes.includes('*') || attributes.includes('sellerSku')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Seller SKU',
          field: 'sellerSku',
          width: 200,
          filter: false,
          sortable: false
        }]);
      }
      if (attributes.includes('*') || attributes.includes('fnsku')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'FNSKU',
          field: 'fnsku',
          width: 150,
          filter: false,
          sortable: false
        }]);
      }
      if (attributes.includes('*') || attributes.includes('fulfilmentType')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Fulfilled By',
          field: 'fulfilmentType',
          width: 140,
          filter: true,
          sortable: true,
          filterParams: {
            values: ['Amazon', 'Merchant'],
            cellHeight: 20,
            newRowsAction: 'keep'
          }
        }]);
      }
      if (attributes.includes('*') || attributes.includes('condition')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Condition',
          field: 'condition',
          width: 120,
          filter: true,
          sortable: true,
          filterParams: {
            values: Object.values(CONDITION_TYPE).map(({ value }) => value),
            cellRenderer: ({ value }) => {
              const condition = Object.values(CONDITION_TYPE)
                .find(conditionType => conditionType.value === Number(value));
              return !!condition && condition.label;
            },
            cellHeight: 20,
            newRowsAction: 'keep'
          },
          cellRenderer: ({ value }) => {
            const condition = Object.values(CONDITION_TYPE)
              .find(conditionType => conditionType.value === Number(value));
            return !!condition && condition.label;
          }
        }]);
      }
      if (attributes.includes('*') || attributes.includes('status')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Status',
          field: 'status',
          width: 100,
          filter: true,
          sortable: true,
          filterParams: {
            values: ['Active', 'Inactive', 'Incomplete'],
            cellHeight: 20,
            newRowsAction: 'keep'
          }
        }]);
      }
      if (attributes.includes('*') || attributes.includes('quantity')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Quantity',
          children: [{
            headerName: 'Inbound',
            field: 'afnInboundShippedQuantity',
            width: 90,
            filter: false,
            sortable: true,
            cellRenderer: (params) => (params.value || 0)
          }, {
            headerName: 'Reserved',
            field: 'afnReservedQuantity',
            width: 100,
            filter: false,
            sortable: true,
            cellRenderer: (params) => (params.value || 0)
          }, {
            headerName: 'Sellable',
            field: 'sellableQuantity',
            width: 90,
            filter: false,
            sortable: true,
            cellRenderer: (params) => params.value || 0
          }, {
            headerName: 'Unsellable',
            field: 'afnUnsellableQuantity',
            width: 105,
            filter: false,
            sortable: true,
            cellRenderer: (params) => (params.value || 0)
          }, {
            headerName: 'Total',
            field: 'afnTotalQuantity',
            width: 70,
            filter: false,
            sortable: false,
            cellRenderer: (params) => {
              const {
                fulfilmentType,
                afnInboundShippedQuantity,
                afnReservedQuantity,
                sellableQuantity,
                afnUnsellableQuantity
              } = params.data;

              let totalQuantity = sellableQuantity;
              if (fulfilmentType === 'Amazon') {
                if (afnInboundShippedQuantity)
                  totalQuantity += afnInboundShippedQuantity;

                if (afnReservedQuantity)
                  totalQuantity += afnReservedQuantity;

                if (afnUnsellableQuantity)
                  totalQuantity += afnUnsellableQuantity;
              }
              return totalQuantity;
            }
          }]
        }]);
      }
      if ( attributes.includes('*') || attributes.includes('decidedBuyQuantity')){
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Decided Buy Quantity',
          field: 'decidedBuyQuantity',
          width: 170,
          editable: this.editableColumnDecider('Decided Buy Quantity'),
          valueSetter: this.decideQuantitySetter,
          filter: false,
          cellRendererFramework: ({ value }) => {
            return (
              <div>
                {(this.editableColumnDecider('Decided Buy Quantity')) ?
                  <Icon type="edit" style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '5px' }} /> :
                  null
                }
                {(value && value >= 0) ? value : 'N/A'}
              </div>
            );
          }
        }]);
      }
      if (attributes.includes('*') || attributes.includes('sales30days')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: '30 Days',
          children: [{
            headerName: 'Orders',
            field: 'totalOrdersLast30Days',
            width: 120,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => (value >= 0 && value) ? value : 0
          }, {
            headerName: 'Units',
            field: 'salesLast30Days',
            width: 120,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => (value >= 0 && value) ? value : 0
          }, {
            headerName: 'Sale Amount',
            field: 'salesAmountLast30Days',
            width: 120,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => value >= 0 ? `$${round(value, 2).toFixed(2)}` : '$0.00'
          }, {
            headerName: 'Pending Orders',
            field: 'totalPendingOrdersLast30Days',
            width: 140,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => (value >= 0 && value) ? value : 0
          }, {
            headerName: 'Suggested Buy Quantity',
            field: 'suggestedBuyQuantity30Days',
            width: 200,
            filter: false,
            sortable: true,
            cellRenderer: (params) => (params.value || 0)
          }]
        }]);
      }
      if (attributes.includes('*') || attributes.includes('sales60days')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: '60 Days',
          children: [{
            headerName: 'Orders',
            field: 'totalOrdersLast60Days',
            width: 120,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => (value >= 0 && value) ? value : 0
          }, {
            headerName: 'Units',
            field: 'salesLast60Days',
            width: 120,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => (value >= 0 && value) ? value : 0
          }, {
            headerName: 'Sale Amount',
            field: 'salesAmountLast60Days',
            width: 120,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => value >= 0 ? `$${round(value, 2).toFixed(2)}` : '$0.00'
          }, {
            headerName: 'Pending Orders',
            field: 'totalPendingOrdersLast60Days',
            width: 140,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => (value >= 0 && value) ? value : 0
          }, {
            headerName: 'Suggested Buy Quantity',
            field: 'suggestedBuyQuantity60Days',
            width: 200,
            filter: false,
            sortable: true,
            cellRenderer: (params) => (params.value || 0)
          }]
        }]);
      }
      if (attributes.includes('*') || attributes.includes('sales90days')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: '90 Days',
          children: [{
            headerName: 'Orders',
            field: 'totalOrdersLast90Days',
            width: 120,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => (value >= 0 && value) ? value : 0
          }, {
            headerName: 'Units',
            field: 'salesLast90Days',
            width: 120,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => (value >= 0 && value) ? value : 0
          }, {
            headerName: 'Sale Amount',
            field: 'salesAmountLast90Days',
            width: 120,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => value >= 0 ? `$${round(value, 2).toFixed(2)}` : '$0.00'
          }, {
            headerName: 'Pending Orders',
            field: 'totalPendingOrdersLast90Days',
            width: 140,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => (value >= 0 && value) ? value : 0
          }, {
            headerName: 'Suggested Buy Quantity',
            field: 'suggestedBuyQuantity90Days',
            width: 200,
            filter: false,
            sortable: true,
            cellRenderer: (params) => (params.value || 0)
          }]}]);
      }
      if (attributes.includes('*') || attributes.includes('prices')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Price',
          children: [{
            headerName: 'Sale',
            field: 'listPrice',
            width: 75,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => `$${round(value, 2).toFixed(2)}`
          }, {
            headerName: 'Buy Box',
            field: 'buyBoxPrice',
            width: 95,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => value > 0 ? `$${round(value, 2).toFixed(2)}` : 'N/A'
          }, {
            headerName: 'Lowest',
            field: 'lowestOfferPrice',
            width: 85,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => value > 0 ? `$${round(value, 2).toFixed(2)}` : 'N/A'
          }, {
            headerName: 'Lowest FBA',
            field: 'lowestFBAOfferPrice',
            width: 110,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => value > 0 ? `$${round(value, 2).toFixed(2)}` : 'N/A'
          }, {
            headerName: 'Cost',
            field: 'costPrice',
            width: 105,
            filter: false,
            editable: this.editableColumnDecider('Cost Price'),
            sortable: true,
            valueSetter: this.costPriceSetter,
            cellRendererFramework: ({ value }) => {
              return (
                <div>
                  {(this.editableColumnDecider('Cost Price')) ?
                    <Icon type="edit" style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '5px' }} /> :
                    null
                  }
                  {value >= 0 ? `$${round(value, 2).toFixed(2)}` : 'N/A'}
                </div>
              );
            }
          }, {
            headerName: 'FBA Inbound Shipping Cost',
            field: 'shipBy',
            width: 210,
            filter: false,
            sortable: false,
            cellRendererFramework: (params) => {
              const { data } = params;
              const { shipBy, shippingRate } = data;
              return (
                <div style={{ paddingTop: '2px' }}>
                  <div>
                    <Popover
                      onVisibleChange={(isVisible) => {
                        if (!isVisible) {
                          this.setState({ shippingRateForByItem: 1 });
                          this.gridApi.redrawRows({ rowNodes: [rowNodeToBeRememberedForShippingRate] });
                          rowNodeToBeRememberedForShippingRate = undefined;
                        }
                      }}
                      placement='right'
                      content={this.popOverContentForByItem(params)}
                      title='Input the Shipping rate to be calculated per item'
                      trigger="click">
                      <Switch
                        style={{ marginRight: '10px', marginLeft: '5px', marginBottom: '4px' }}
                        unCheckedChildren='byItem'
                        checkedChildren='byItem'
                        checked={shipBy === 'byItem' ? true : false}
                        disabled={shipBy === 'byItem' ? true : false}
                        onClick={() => {
                          rowNodeToBeRememberedForShippingRate = params.node
                        }}
                      />
                    </Popover>
                    <Popover
                      onVisibleChange={(isVisible) => {
                        if (!isVisible) {
                          this.setState({ shippingRate: 0.25 });
                          this.gridApi.redrawRows({ rowNodes: [rowNodeToBeRememberedForShippingRate] });
                          rowNodeToBeRememberedForShippingRate = undefined;
                        }
                      }}
                      placement='right'
                      content={this.popOverContent(params)}
                      title='Input the Shipping rate to be calculated per pound'
                      trigger="click">
                      <Switch
                        style={{ marginBottom: '4px' }} 
                        onClick={() => {
                          rowNodeToBeRememberedForShippingRate = params.node
                        }} 
                        unCheckedChildren='byWeight'
                        checkedChildren='byWeight'
                        checked={shipBy === 'byWeight' ? true : false}
                        disabled={shipBy === 'byWeight' ? true : false}
                      />
                    </Popover>
                  </div>
                </div>
              );
            }
          }, {
            headerName: 'Shipping Rate',
            field: 'shippingRate',
            width: 150,
            editable: ({ data }) => {
              const { shipBy } = data;
              if (shipBy === 'byItem' || shipBy === 'byWeight') {
                return true;
              }
              return false;
            },
            valueSetter: this.shippingRateSetter,
            filter: false,
            sortable: true,
            cellRendererFramework: ({ data }) => {
              const { shipBy, shippingRate } = data;
              return (
                <div>
                  { shipBy === 'byItem' || shipBy === 'byWeight' ?
                    <div>
                      <Icon type="edit" style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '5px' }} />
                      {shipBy === 'byItem' ? `$${shippingRate}/item` : `$${shippingRate}/pound`}
                    </div>
                     :
                    'N/A'
                  }
                </div>
              );
            }
          }]
        }]);
      }
      if (attributes.includes('*') || attributes.includes('noOfSellers')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'No Of Sellers',
          field: 'noOfSellers',
          width: 120,
          filter: false,
          sortable: true
        }]);
      }
      if (attributes.includes('*') || attributes.includes('fees')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Fees',
          children: [{
            headerName: 'Referral',
            field: 'referral',
            width: 90,
            filter: false,
            sortable: false,
            cellRenderer: (params) => {
              const { listPrice, buyBoxPrice, lowestOfferPrice, lowestFBAOfferPrice, fee } = params.data;
              const defaltPrice = ChooseDefaultCalculationPrice({ profitCalculatedBy: this.props.user.profitCalculatedBy, listPrice, buyBoxPrice, lowestOfferPrice, lowestFBAOfferPrice });
              if (defaltPrice > 0 && fee && fee.feePercentage) {
                return `$${round(defaltPrice * (fee.feePercentage / 100), 2).toFixed(2)}`
              }

              return 'N/A';
            }
          }, {
            headerName: 'FBA',
            field: 'fba',
            width: 85,
            filter: false,
            sortable: true,
            cellRenderer: (params) => {
              const { fee } = params.data;
              if (fee && fee.otherFees) {
                return `$${fee.otherFees.toFixed(2)}`
              }

              return 'N/A';
            }
          }, {
            headerName: 'Storage',
            field: 'storage',
            width: 90,
            filter: false,
            sortable: false,
            cellRenderer: (params) => {
              const { fulfilmentType, fee } = params.data;
              if (fulfilmentType === 'Amazon' && fee) {
                if ([9, 10, 11].includes(moment().month())) {
                  if (fee.monthlyStorageFeeOct) {
                    return `$${round(fee.monthlyStorageFeeOct, 2).toFixed(2)}`
                  }
                } else if (fee.monthlyStorageFeeJan) {
                  return `$${round(fee.monthlyStorageFeeJan, 2).toFixed(2)}`
                }
              }

              return 'N/A';
            }
          }]
        }]);
      }
      if (attributes.includes('*') || attributes.includes('profits')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Profit',
          children: [{
            headerName: 'Net',
            field: 'profit',
            width: 75,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => value ? `$${value}` : 'N/A'
          }, {
            headerName: 'Margin',
            field: 'profitPercentage',
            width: 85,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => value ? `${value}%` : 'N/A'
          }, {
            headerName: 'ROI',
            field: 'roiPercentage',
            width: 75,
            filter: false,
            sortable: true,
            cellRenderer: ({ value }) => value ? `${value}%` : 'N/A'
          }]
        }]);
      }
      if (attributes.includes('*') || attributes.includes('supplier')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Supplier',
          field: 'supplier',
          width: 110,
          filter: true,
          filterParams: {
            cellHeight: 20
          },
          editable: this.editableColumnDecider('Suppliers'),
          sortable: true,
          valueSetter: this.supplierSetter,
          cellRendererFramework: ({ value }) => {
            return (
              <div>
                {(this.editableColumnDecider('Suppliers')) ?
                  <Icon type="edit" style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '5px' }} /> :
                  null
                }
                {value}
              </div>
            );
          }
        }]);
      }
      if (attributes.includes('*') || attributes.includes('salesRank')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Sales Rank',
          field: 'salesRank',
          width: 105,
          filter: false,
          sortable: true,
          cellRenderer: ({ value }) => value ? value : 'N/A'
        }]);
      }
      if (attributes.includes('*') || attributes.includes('productGroup')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Category',
          field: 'productGroup',
          width: 115,
          filter: true,
          filterParams: {
            cellHeight: 20
          },
          sortable: true,
          cellRenderer: ({ value }) => value ? value : 'N/A'
        }]);
      }
      if (attributes.includes('*') || attributes.includes('purchaseLink')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Purchase Link',
          field: 'purchaseLink',
          width: 125,
          filter: false,
          editable: this.editableColumnDecider('Purchase Link'),
          sortable: true,
          valueSetter: this.purchaseLinkSetter,
          cellRendererFramework: ({ value }) => {
            return (
              <div>
                {(this.editableColumnDecider('Purchase Link')) ?
                  <Icon type="edit" style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '5px' }} /> :
                  null
                }
                {value ? <a target="_blank" href={value}>{value}</a> : 'N/A'}
              </div>
            );
          }
        }]);
      }
      if (attributes.includes('*') || attributes.includes('storeSection')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Store Section',
          field: 'storeSection',
          width: 160,
          editable: this.editableColumnDecider('Store Section'),
          sortable: true,
          valueSetter: this.storeSectionSetter,
          cellRendererFramework: ({ value }) => {
            return (
              <div>
                {(this.editableColumnDecider('Store Section')) ?
                  <Icon type="edit" style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '5px' }} /> :
                  null
                }
                {value ? value : 'N/A'}
              </div>
            );
          }
        }]);
      }
      if (attributes.includes('*') || attributes.includes('notesSection')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Notes Section',
          field: 'notesSection',
          width: 160,
          editable: this.editableColumnDecider('Notes Section'),
          sortable: true,
          valueSetter: this.notesSectionSetter,
          cellRendererFramework: ({ value }) => {
            return (
              <div>
                {(this.editableColumnDecider('Notes Section')) ?
                  <Icon type="edit" style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '5px' }} /> :
                  null
                }
                {value ? value : 'N/A'}
              </div>
            );
          }
        }]);
      }
      if (attributes.includes('*') || attributes.includes('enrolledInSnL')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Enrolled in SnL',
          field: 'enrolledInSnL',
          width: 150,
          filter: true,
          sortable: true,
          filterParams: {
            values: ['Yes', 'No'],
            cellHeight: 20,
            newRowsAction: 'keep'
          },
        }]);
      }
      if (attributes.includes('*') || attributes.includes('openDate')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Date Added',
          field: 'openDate',
          width: 140,
          filter: false,
          sortable: true,
          cellRenderer: ({ value }) => value ? moment(value).format('LL') : 'N/A'
        }]);
      }
      if (attributes.includes('*') || attributes.includes('isReplen')) {
        columnDefinitions = columnDefinitions.concat([{
          headerName: 'Replen?',
          field: 'isReplen',
          width: 100,
          menuTabs: [],
          pinned: 'right',
          sortable: true,
          resizable: false,
          filter: true,
          filterParams: {
            values: ['Yes', 'No'],
            cellHeight: 20,
            newRowsAction: 'keep'
          },
          cellRendererFramework: (params) => {
            return (
              <div style={{ textAlign: 'center' }}>
                <Checkbox defaultChecked={params.value === 'Yes'} style={{ marginRight: '10px' }} onChange={(e) => this.handleReplenChange(e, params)} >  </Checkbox>
              </div>
            );
          }
        }]);
      }
    }
  };

  componentWillUnmount() {
    columnDefinitions = [];
  }

  defaultColDef = {
    singleClickEdit: true,
    resizable: true,
    sortable: true
  };

  componentDidUpdate(prevProps) {
    if (!this.props.inventory.fetching && this.gridApi) {
      if (this.props.inventory.products && this.props.inventory.products.length > 0) {
        // Update node of saved product

        if (rowNodeToBeRemembered) {
          const sellerSku = rowNodeToBeRemembered.data.sellerSku;
          const product = find(this.props.inventory.products, { sellerSku });
          rowNodeToBeRemembered.data = product;
          this.gridApi.redrawRows({
            rowNodes: [rowNodeToBeRemembered]
          });

          rowNodeToBeRemembered = undefined;
          rowNodeToBeRememberedForShippingRate = undefined;
        }
      }

      const ac = new AccessControl(this.props.user.roles);
      const permissionControl = ac.can(this.props.user.permission.role).readAny('Inventory');
      const { attributes } = permissionControl;

      // Update Categories
      if (attributes.includes('*') || attributes.includes('productGroup')) {
        if (this.props.inventory.categories && this.props.inventory.categories.length !== this.state.categoriesLength) {
          const { categories } = this.props.inventory;
          const categoriesFilterComp = this.gridApi.getFilterInstance('productGroup');
          categoriesFilterComp.setFilterValues(categories, false, false, []);
          this.state.categoriesLength = categories.length;
        }
      }

      // Update Suppliers
      if (attributes.includes('*') || attributes.includes('supplier')) {
        if (this.props.inventory.suppliers && this.props.inventory.suppliers.length !== this.state.suppliersLength) {
          const { suppliers } = this.props.inventory;
          const supplierFilterComp = this.gridApi.getFilterInstance('supplier');
          supplierFilterComp.setFilterValues(suppliers, false, false, []);
          this.state.suppliersLength = suppliers.length;
        }
      }
    }
  };

  gridReady = (params) => {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;

    const ac = new AccessControl(this.props.user.roles);
    const permissionControl = ac.can(this.props.user.permission.role).readAny('Inventory');
    const { attributes } = permissionControl;

    if (localStorage) {
      let state = localStorage.getItem('inventoryPageColumnsState');
      if (state) {
        const columnState = JSON.parse(state).columnState;
        const realColState = this.columnApi.getColumnState();

        if(columnState.length !== realColState.length) {
          this.setState({ newColumnExists: true });
        }
        this.columnApi.setColumnState(columnState);
      }

      state = localStorage.getItem('inventoryPageFiltersState');
      if (state) {
        const filtersState = JSON.parse(state).filtersState;
        this.gridApi.setFilterModel(filtersState);
      } else {
        // Updating Status Filter to display just Active and Inactive Products
        if (attributes.includes('*') || attributes.includes('status')) {
          const statusFilterComp = this.gridApi.getFilterInstance("status");
          statusFilterComp.selectNothing();
          statusFilterComp.selectValue('Active');
          statusFilterComp.selectValue('Inactive');
          statusFilterComp.onFilterChanged();
        }
      }
    } else {
      // Updating Status Filter to display just Active and Inactive Products
      if (attributes.includes('*') || attributes.includes('status')) {
        const statusFilterComp = this.gridApi.getFilterInstance("status");
        statusFilterComp.selectNothing();
        statusFilterComp.selectValue('Active');
        statusFilterComp.selectValue('Inactive');
        statusFilterComp.onFilterChanged();
      }

      console.warn('Your browser does not support localStorage');
    }

    // Update Categories
    if (attributes.includes('*') || attributes.includes('productGroup')) {
      if (this.props.inventory.categories && this.props.inventory.categories.length > 0) {
        const { categories } = this.props.inventory;
        const categoriesFilterComp = this.gridApi.getFilterInstance('productGroup');
        categoriesFilterComp.setFilterValues(categories, false, false, []);
        this.state.categoriesLength = categories.length;
      }
    }

    // Update Suppliers
    if (attributes.includes('*') || attributes.includes('supplier')) {
      if (this.props.inventory.suppliers && this.props.inventory.suppliers.length > 0) {
        const { suppliers } = this.props.inventory;
        const supplierFilterComp = this.gridApi.getFilterInstance('supplier');
        supplierFilterComp.setFilterValues(suppliers, false, false, []);
        this.state.suppliersLength = suppliers.length;
      }
    }
  };

  popOverContent = (params) => {
    const { shippingRate } = this.state;
    return (
      <div>
        <Input defaultValue={shippingRate} onChange={({ target }) => this.setState({ shippingRate: target.value })} addonAfter='per pound' />
        <Button type='primary' onClick={() => this.onByWeightChange(params)} style={{ marginTop: '5px' }}>Add</Button>
      </div>
    );
  };

  popOverContentForByItem = (params) => {
    const { shippingRateForByItem } = this.state;
    return (
      <div>
        <Input defaultValue={shippingRateForByItem} onChange={({ target }) => this.setState({ shippingRateForByItem: target.value })} addonAfter='per item' />
        <Button type='primary' onClick={() => this.onByItemChange(params)} style={{ marginTop: '5px' }}>Add</Button>
      </div>
    );
  };

  render() {
    const { fetching, pagination, products, total } = this.props.inventory;
    const { onPageChange, onPageSizeChange, setSortingFilter } = this.props;
    const { newColumnExists } = this.state;

    return (
      <div style={{ height: 'calc(100% - 52px)' }}>
        {newColumnExists ?
          <div>
            <Alert
              message='Please Reset your column state. There are some new columns.'
              type='info'
              showIcon
              closable
              onClose={() => this.setState({ newColumnExists: false })}
            />
          </div> : null
        }
        <div className='ag-theme-balham' style={{ height: newColumnExists ?'calc(100% - 78px)':'calc(100% - 42px)', padding: 10 }}>
          <Spin tip="Loading..." spinning={fetching}>
            <AgGridReact
              reactNext={true}
              onGridReady={this.gridReady}
              rowSelection='multiple'
              deltaRowDataMode={true}
              animateRows={true}
              columnDefs={columnDefinitions}
              rowData={products}
              rowHeight={30}
              getRowNodeId={({ sellerSku }) => sellerSku}
              pagination={false}
              getRowStyle={this.rowStyle}
              suppressRowClickSelection={true}
              onPaginationChanged={this.handlePaginationChange}
              onSelectionChanged={this.handleSelectionChange}
              onColumnVisible={this.saveColumnState}
              onDragStopped={this.saveColumnState}
              suppressPaginationPanel={true}
              suppressScrollOnNewData={true}
              onSortChanged={setSortingFilter}
              onFilterChanged={this.saveAndApplyFilters}
              sideBar={sideBar}
              defaultColDef={this.defaultColDef}
            />
          </Spin>
        </div>
        <div style={{ float: 'right' }}>
          <Pagination
            current={pagination.pageNumber}
            defaultPageSize={pagination.pageSize ? pagination.pageSize : 25}
            pageSizeOptions={['25', '50', '100']}
            showSizeChanger
            onShowSizeChange={onPageSizeChange}
            showQuickJumper
            total={total}
            onChange={onPageChange}
            showTotal={(total, range) => `${range[0]}-${range[1]} of ${total} items`}
          />
        </div>
      </div>
    );
  };
}

const mapStateToProps = ({ inventory, user, customAsinShortcut }) => ({ inventory, user, customAsinShortcut });

const mapDispatchToProps = (dispatch) => ({
  getProducts: () => dispatch(getProducts()),
  onPageChange: (pageNumber) => {
    dispatch(setPage(pageNumber));
    dispatch(getProducts())
  },
  onPageSizeChange: (currentPage, pageSize) => {
    dispatch(setPage(1));
    dispatch(setPageSize(pageSize));
    dispatch(getProducts());
  },
  setSortingFilter: (params) => {
    const sort = params.api.getSortModel();
    let sortOptions = {};
    if (sort.length > 0) {
      sort.forEach(({ colId, sort }) => {
        sortOptions = {
          ...sortOptions,
          [colId]: sort
        }
      });
    }
    dispatch(setSortFilters(sortOptions));
    dispatch(getProducts());
  },
  handleFilterChanged: (filter) => {
    dispatch(setFilters(filter));
    dispatch(setPage(1));
    dispatch(getProducts());
  },
  resetAllFiltersAndSelections: () => dispatch(resetAllFiltersAndSelections()),
  handleSellection: (selectedItems) => {
    dispatch(setSellectedItems(selectedItems))
  },
  handleSetShippingCosts: (product) => {
    dispatch(setShippingCost(product))
  },
  handleSetCostPrice: (product) => {
    dispatch(setCostPrice(product))
  },
  handleSetDecideBuyQuantity: (product) => {
    dispatch(setDecideBuyQuantity(product))
  },
  handleSetSupplier: (product) => {
    dispatch(setSupplier(product))
  },
  handleSetPurchaseLink: (product) => {
    dispatch(setPurchaseLink(product))
  },

  getShortcuts: () => dispatch(getShortcuts()),
  getDefaultCalculationPrice: () => dispatch(getDefaultCalculationPrice()),
  handleSetStoreSectionSetter: (product) => {
    dispatch(setStoreSection(product))
  },
  handleSetNotesSectionSetter: (product) => {
    dispatch(setNotesSection(product))
  },
  handleSetToReplen: (product) => {
    dispatch(setToReplen(product))
  }
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(InventoryGrid);
