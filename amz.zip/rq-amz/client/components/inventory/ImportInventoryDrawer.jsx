import React from 'react';
import { isEmpty, includes } from 'lodash';
import {
  Drawer,
  Upload,
  Button,
  Icon,
  message,
  Form,
  Col,
  Select,
  notification,
  Spin
} from 'antd';
import papa from 'papaparse';

import './Drawer.less';

class ImportInventoryDrawer extends React.Component {
  constructor(props) {
    super(props);

    this.sellerSkuRef = React.createRef();
    this.costPriceRef = React.createRef();
    this.supplierRef = React.createRef();
    this.purchaseLinkRef = React.createRef();
  };
  
  state = {
    disabled: false,
    isUploading: false,
    fileList: [],
    uploadedFileList: [],
    fieldsToMap: [],
    data: null,
    mappedFields: {},
    previousSellerSkuField: null,
    previousCostPriceField: null,
    previousSupplierField: null,
    previousPurchaseLinkField: null,
    optionsSelectedCount: 0
  };

  clearData = () => {
    const { form } = this.props;
    form.resetFields();

    this.setState({
      disabled: false,
      isUploading: false,
      fileList: [],
      uploadedFileList: [],
      fieldsToMap: [],
      data: null,
      mappedFields: {},
      previousSellerSkuField: null,
      previousCostPriceField: null,
      previousSupplierField: null,
      previousPurchaseLinkField: null,
      optionsSelectedCount: 0
    });
  };

  hideDrawer = () => {
    this.clearData();

    const { closeImportDrawer } = this.props;
    closeImportDrawer();
  };

  uploadFile = (info) => {
    if (info.fileList.length === 1) {
      let fileList = [...info.fileList];
      
      this.setState({
        isUploading: true,
        fileList,
        uploadedFileList: fileList,
        disabled: true
      });

      this.populateFieldsFromFile(fileList[0]);
    } else if (info.fileList.length >= 1) {
      let fileList = [...info.fileList];

      this.setState({
        fileList,
        uploadedFileList: fileList,
        disabled: true,
        fieldsToMap: [],
        mappedFields: {}
      })
    } else {
      this.clearData();
    }
  }

  beforeUpload = (file) => {
    const { fileList } = this.state;
    if (fileList && fileList.length){
      notification.error({
        message: 'Upload File',
        description: 'Only single file upload allowed',
        top: 65
      });

      return false;
    } else {
      return false;
    }
  }

  populateFieldsFromFile = (file) => {
    const { name, originFileObj } = file;
    papa.parse(originFileObj, {
      header: true,
      trimHeaders: true,
      dynamicTyping: false,
      skipEmptyLines: 'greedy',
      complete: res => {
        if (res.errors && res.errors.length > 0) {
          message.error(`${name} file is not csv file !!`);
          this.clearData();
        } else {
          message.success(`${name} file uploaded successfully.`);
          this.setState({
            fieldsToMap: res.meta.fields,
            data: res.data,
            isUploading: false,
            disabled: false
          });
        }
      }
    });
  };

  mapSku = (val) => {
    let { mappedFields, previousSellerSkuField } = this.state;
    if (val) {
      if (mappedFields[previousSellerSkuField]) {
        delete mappedFields[previousSellerSkuField];
      }

      this.setState({
        mappedFields: { ...mappedFields, [val]: 'sellerSku' },
        previousSellerSkuField: val
       });
    } else {
      delete mappedFields[previousSellerSkuField];

      this.setState({
        mappedFields: { ...mappedFields },
        previousSellerSkuField: null
      });
    }
  };

  mapCostPrice = (val) => {
    let { mappedFields, previousCostPriceField, optionsSelectedCount } = this.state;
    if (val) {
      if (mappedFields[previousCostPriceField]) {
        delete mappedFields[previousCostPriceField];
      }

      this.setState({
        mappedFields: { ...mappedFields, [val]: 'costPrice' },
        previousCostPriceField: val,
        optionsSelectedCount: optionsSelectedCount + 1
       });
    } else {
      delete mappedFields[previousCostPriceField];

      this.setState({
        mappedFields: { ...mappedFields },
        previousCostPriceField: null,
        optionsSelectedCount: optionsSelectedCount - 1
      });
    }
  };

  mapSupplier = (val) => {
    let { mappedFields, previousSupplierField, optionsSelectedCount } = this.state;
    if (val) {
      if (mappedFields[previousSupplierField]) {
        delete mappedFields[previousSupplierField];
      }

      this.setState({
        mappedFields: { ...mappedFields, [val]: 'supplier' },
        previousSupplierField: val,
        optionsSelectedCount: optionsSelectedCount + 1
       });
    } else {
      delete mappedFields[previousSupplierField];

      this.setState({
        mappedFields: { ...mappedFields },
        previousSupplierField: null,
        optionsSelectedCount: optionsSelectedCount - 1
      });
    }
  };

  mapPurchaseLink = (val) => {
    let { mappedFields, previousPurchaseLinkField, optionsSelectedCount } = this.state;
    if (val) {
      if (mappedFields[previousPurchaseLinkField]) {
        delete mappedFields[previousPurchaseLinkField];
      }

      this.setState({
        mappedFields: { ...mappedFields, [val]: 'purchaseLink' },
        previousPurchaseLinkField: val,
        optionsSelectedCount: optionsSelectedCount + 1
       });
    } else {
      delete mappedFields[previousPurchaseLinkField];

      this.setState({
        mappedFields: { ...mappedFields },
        previousPurchaseLinkField: null,
        optionsSelectedCount: optionsSelectedCount - 1
      });
    }
  };

  buttonDisability = () => {
    const { uploadedFileList, optionsSelectedCount } = this.state;
    if (uploadedFileList && uploadedFileList.length && optionsSelectedCount >= 1) {
      return false;
    }
    return true;
  }

  validateFileProducts = (fileProducts) => {
    const { mappedFields } = this.state;
    const requiredProducts = [];
    
    fileProducts.forEach((product) => {
      const item = {};
      Object.keys(product).forEach((key) => {
        const newKey = mappedFields[key];
        if (newKey) {
          if (newKey === 'costPrice') {
            if (typeof(product[key]) === 'string' && product[key].includes('$')){
              item[newKey] = Number(product[key].split('$')[1].trim());
            } else {
              item[newKey] = Number(product[key]);
            }
          } else {
            item[newKey] = product[key];
          }
        }
      });
      requiredProducts.push(item);
    });
    return {
      requiredProducts
    };
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const { form } = this.props;
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        const { data } = this.state;
        const fileData = data;
        if (fileData.length !== 0){
          const { mappedFields } = this.state;
          if (!isEmpty(mappedFields)) {
            const { requiredProducts } = this.validateFileProducts(fileData);
            const costEntry = requiredProducts.find(element => parseFloat(element.costPrice) >= 0);
            const { onImportProducts } = this.props;
            onImportProducts(requiredProducts, costEntry ? true : false);
          }
        } else if (fileData && fileData.length===0){
          notification.error({
            top: 60,
            message: 'File Upload:',
            description: 'Imported file contains no Data !!',
            duration: 3
          });
          this.clearData();
        }
      }
    });
  };

  getFields() {
    const { fieldsToMap, mappedFields } = this.state;

    const selectOptions = [];
    fieldsToMap.forEach(field => {
      if (isEmpty(mappedFields) || (!isEmpty(mappedFields) && !mappedFields[field])) {
        selectOptions.push(
          <Select.Option key={field} value={field}>{field}</Select.Option>
        );
      }
    });

    const { getFieldDecorator } = this.props.form;
    const children = [];
    children.push(
      <Col style={{ textAlign: 'center' }} key={2}>
        <Form.Item label='Seller Sku'>
          {getFieldDecorator(`sellerSkuField`, {
            rules: [
              {
                required: true,
                message: 'Enter the correct Seller Sku Column',
                initialValue: ''
              },
            ],
          })(
            <Select ref={this.sellerSkuRef} allowClear={true} onChange={this.mapSku} style={{ width: 200 }}>
              {selectOptions}
            </Select>
          )}
        </Form.Item>
      </Col>,
      <Col style={{ textAlign: 'center' }} key={3}>
        <Form.Item label='Cost Price'>
          {getFieldDecorator(`costPriceField`, {
            rules: [
              {
                message: 'Enter the correct Cost Price Column',
                initialValue: ''
              },
            ],
          })(
            <Select ref={this.costPriceRef} allowClear={true} onChange={this.mapCostPrice} style={{ width: 200 }}>
              {selectOptions}
            </Select>
          )}
        </Form.Item>
      </Col>,
      <Col style={{ textAlign: 'center' }} key={4}>
        <Form.Item label='Supplier'>
          {getFieldDecorator(`supplierField`, {
            rules: [
              {
                message: 'Enter the correct Supplier Column',
                initialValue: ''
              },
            ],
          })(
            <Select ref={this.supplierRef} allowClear={true} onChange={this.mapSupplier} style={{ width: 200 }}>
              {selectOptions}
            </Select>
          )}
        </Form.Item>
      </Col>,
      <Col style={{ textAlign: 'center' }} key={6}>
      <Form.Item label='Purchase Link'>
        {getFieldDecorator(`purchaseLinkField`, {
          rules: [
            {
              message: 'Enter the correct Purchase Link Column',
              initialValue: ''
            },
          ],
        })(
          <Select ref={this.purchaseLinkRef} allowClear={true} onChange={this.mapPurchaseLink} style={{ width: 200 }}>
            {selectOptions}
          </Select>
        )}
      </Form.Item>
    </Col>,
      <Col style={{ textAlign: 'center', margin: '50px' }} key={5}>
        <Button loading={this.props.fetching} disabled={this.buttonDisability()} style={{ width: '70%' }} type="primary" htmlType="submit">
          Finish Uploading
        </Button>
      </Col>
    );
    return children;
  };

  showForm() {
    const { fieldsToMap, isUploading } = this.state;
    if (isUploading) {
      return (
        <Spin />
      );
    }

    if (!fieldsToMap || fieldsToMap.length === 0) {
      return null;
    }

    return (
      <Form onSubmit={this.handleSubmit} style={{ height: '100%' }}>
        {this.getFields()}
      </Form>
    );
  };

  componentDidUpdate(prevProps) {
    if (this.props && this.props.importInventory) {
      const { onResetImportProducts } = this.props;
      onResetImportProducts();

      this.hideDrawer();
    }
  };

  render() {
    const {
      visible
    } = this.props;
    const {
      disabled,
      fileList,
      uploadedFileList
    } = this.state;
    return (
      <Drawer
        title="Import Inventory"
        placement="right"
        closable={false}
        destroyOnClose={true}
        onClose={this.hideDrawer}
        visible={visible}
        getContainer={false}
        width={600}
        style={{ position: 'absolute', textAlign: 'center' }}
      >
        <Upload
          name='file'
          accept='.csv'
          action='https://www.mocky.io/v2/5cc8019d300000980a055e76'
          headers={{ authorization: 'authorization-text' }}
          disabled={disabled}
          beforeUpload={this.beforeUpload}
          onChange={this.uploadFile}
          showUploadList={uploadedFileList && uploadedFileList.length ? true : false}
          fileList={fileList}
        >
          <Button style={{ margin: '10px' }}>
            <Icon type="upload" /> Click to Upload
          </Button>
        </Upload>

        {this.showForm()}
      </Drawer>
    );
  };
};

const WrappedDrawer = Form.create({ name: 'import_selection_form' })(ImportInventoryDrawer);

export default WrappedDrawer;
