import React from 'react';
import { AgGridReact } from 'ag-grid-react';
import { connect } from 'react-redux';
import { find } from 'lodash';
import {
  Icon,
  Modal,
  Button
} from 'antd';

import { getChildUser, deleteChildUser, openUpdateRoleModal, sendInviteAgain } from '../../actions/users';
import './Grid.less';

const { confirm } = Modal;

const sideBarDef = {
  toolPanels: [{
    id: 'columns',
    labelDefault: 'Columns',
    labelKey: 'columns',
    iconKey: 'columns',
    toolPanel: 'agColumnsToolPanel',
    toolPanelParams: {
      suppressPivots: true,
      suppressPivotMode: true,
      suppressValues: true
    }
  }, {
    id: 'filters',
    labelDefault: 'Filters',
    labelKey: 'filters',
    iconKey: 'filter',
    toolPanel: 'agFiltersToolPanel'
  }]
};

let rowNodeToBeRemembered;

class ChildUserGrid extends React.Component {
  componentDidMount() {
    this.props.onRef(this);

    const {  getChildUser } = this.props;
    getChildUser();
  }

  gridReady = (params) => {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
  }

  componentDidUpdate(prevProps) {
    const { fetching, childUsers } = this.props.user;

    if (!fetching && this.gridApi) {
      if (childUsers && childUsers.length > 0) {
        // Update node of saved ChildUser
        if (rowNodeToBeRemembered) {
          const { email } = rowNodeToBeRemembered.data;
          const childUser = find(childUsers, { email });
          rowNodeToBeRemembered.data = childUser;
          this.gridApi.redrawRows({
            rowNodes: [rowNodeToBeRemembered]
          });

          rowNodeToBeRemembered = undefined;
        }
      }
    }
  }

  saveNode = (node) => {
    rowNodeToBeRemembered = node;
  }

  roleSetter = (params) => {
    this.props.openUpdateRoleModal(params);
  }

  handleDelete = (e, params) => {
    e.preventDefault();
    
    const { _id } = params.data;
    const instance = this;
    confirm({
      title: 'Delete User',
      content: `Do you really want to delete this User?`,
      okText: 'Yes',
      cancelText: 'No',
      onOk() {
        const { deleteChildUser } = instance.props;
        deleteChildUser({ _id });
      },
      onCancel() {
      },
    });
  }

  handleInviteAgain = (e, params) => {
    const { email } = params.data;
    rowNodeToBeRemembered = params.node;

    const { sendInviteAgain } = this.props;
    sendInviteAgain({ email });
  }

  getDistinctRoles = () => {
    const { distinctRoles } = this.props.user;
    if (distinctRoles) {
      return distinctRoles;
    }
    return null;
  }

  columnDefinitions = [{
    headerName: '',
    field: '',
    menuTabs: [],
    pinned: true,
    width: 40,
    checkboxSelection: true,
    headerCheckboxSelection: true,
    sortable: false,
  }, {
    headerName: 'Name',
    field: 'name',
    width: 150,
    resizable: true,
    sortable: true,
  }, {
    headerName: 'Email',
    field: 'email',
    width: 240,
    resizable: true,
    sortable: true,
  }, {
    headerName: 'Role',
    field: 'permission',
    width: 640,
    filter: false,
    cellRendererFramework: (params) => {
      const { role } = params.value[0];
      let stringToPrint = [];
      if (role) {
        for (let i = 0; i < role.length; i += 1) {
          stringToPrint = stringToPrint.concat(role[i])
          if (i !== (role.length - 1)) {
            stringToPrint = stringToPrint.concat(', ')
          }
        }
      }
      return (
        <div onClick={() => this.roleSetter(params)}>
          <Icon type='edit' style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '15px' }} />
          {stringToPrint}
        </div>
      );
    }
  }, {
    headerName: 'Actions',
    width: 250,
    pinned: 'right',
    cellRendererFramework: (params) => {
      const user = params.data;
      const passwordExpiresIn = new Date(user.resetPasswordExpires);
      const currentDate = new Date();

      return (
        <div style={{textAlign:'center'}}>
          <Button style={{ marginRight: '10px' }} size='small' onClick={(e) => this.handleDelete(e, params)} > Delete User </Button>
          {user && !user.password && currentDate > passwordExpiresIn &&
            <Button style={{ marginRight: '10px' }} size='small' onClick={(e) => this.handleInviteAgain(e, params)} > Invite Again </Button>
          }
        </div>
      );
    }
  }];

  render() {
    const { childUsers } = this.props.user;
    return (
      <div style={{ height: 'calc(100% - 52px)' }}>
        <div className='ag-theme-balham' style={{ height: 'calc(100% - 32px)', padding: 10 }}>
          <AgGridReact
            reactNext={true}
            onGridReady={this.gridReady}
            rowSelection='multiple'
            deltaRowDataMode={true}
            animateRows={true}
            columnDefs={this.columnDefinitions}
            rowData={childUsers}
            rowHeight={30}
            getRowNodeId={({ _id }) => _id}
            pagination={false}
            suppressRowClickSelection={true}
            suppressPaginationPanel={true}
            suppressScrollOnNewData={true}
            singleClickEdit={true}
            sideBar={sideBarDef}
            onSelectionChanged={this.handleSelectionChange}
          />
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ user }) => ({ user });
const mapDispatchToProps = dispatch => ({
  getChildUser: () => dispatch(getChildUser()),
  openUpdateRoleModal: (child) => dispatch(openUpdateRoleModal(child)),
  deleteChildUser: (id) => dispatch(deleteChildUser(id)),
  sendInviteAgain: (params) => dispatch(sendInviteAgain(params))
});

export default connect(mapStateToProps, mapDispatchToProps)(ChildUserGrid)
