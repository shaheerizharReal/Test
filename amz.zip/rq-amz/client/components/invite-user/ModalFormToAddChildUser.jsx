import React from 'react';
import {
  Input,
  Modal,
  Form,
  Button,
  Select
} from 'antd';
import { connect } from 'react-redux';

import { sendInvite, openSetInventoryReadAttributesModal, closeSetInventoryReadAttributesModal, setValidateFormFlag } from '../../actions/users';

const { Option } = Select;

const ModalFormToAddChildUser = Form.create({ name: 'form_in_modal' })(
  class extends React.Component {
    handleSubmit = (e) => {
      e.preventDefault();
      const { form } = this.props;

      form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          const { name, role } = values;
          const { sendInvite } = this.props;
          let { email } = values;
          email = email.toLowerCase();
          if (role.includes('New Inventory Read')) {
            let { attributes } = this.props.user;
            attributes = attributes.toString();
            sendInvite({ name, email, role, attributes });
          } else {
            sendInvite({ name, email, role });
          }
          const { onCancel } = this.props;
          form.resetFields();
          onCancel();
        }
      });
    }

    componentDidUpdate () {
      if (this.props.user && this.props.user.validateFormFlag && this.props.user.validateFormFlag === true) {
        const { form, setValidateFormFlag } = this.props;
        setValidateFormFlag(false);
        form.validateFieldsAndScroll(['role'], { force: true }, (err, values) => {});
      }
    }

    handleCancel = () => {
      const { form, onCancel, closeSetInventoryReadAttributesModal } = this.props;
      closeSetInventoryReadAttributesModal(null);
      form.resetFields();
      onCancel();
    }

    getOptions = () => {
      const { distinctRoles } = this.props.user;
      if (distinctRoles) {
        const options = distinctRoles.map(role => (
          <Option key={role} value={role}>{role}</Option>
        ));
        options.push(<Option key='New Inventory Read' value='New Inventory Read'>New Inventory Read</Option>);
        return options;
      }
      return null;
    }

    singleInventoryReadGrant = (rule, value, callback) => {
      let inventoryGrantCount = 0;
      if (value) {
        for (let i = 0; i < value.length; i += 1) {
          if (value[i].includes('Inventory') && value[i].includes('Read')) {
            inventoryGrantCount += 1;
          }
        }
        if (inventoryGrantCount > 1) {
          callback('Please Select Only One Read Inventory Role for User');
        }
      }
      callback();
    }

    checkNewInventoryReadGrant = (rule, value, callback) => {
      if (value && value.includes('New Inventory Read')) {
        if (this.props.user.attributes === null) {
          this.props.openSetInventoryReadAttributesModal();
        } else {
          callback();
        }
      }
      callback();
    }

    arrayInclusionCheck = (value) => {
      const inventoryFeatures = ['Can Export Inventory', 'Can Import Inventory', 'Can Set Cost Price', 'Can Set Purchase Link', 'Can Set Suppliers', 'Can Set Store Section', 'Can Set Notes Section'];
        for (let i = 0; i < inventoryFeatures.length; i += 1) {
          if (value.includes(inventoryFeatures[i])) {
            return true;
          };
        }
      return false;
    }

    checkReadInventoryExistsForInventoryFeature = (rule, value, callback) => {
      let inventoryGrantCount = 0;
      if (value) {
        if (this.arrayInclusionCheck(value)) {
          for (let i = 0; i < value.length; i += 1) {
            if (value[i].includes('Inventory') && value[i].includes('Read')) {
              inventoryGrantCount += 1;
            }
          }
          if (inventoryGrantCount === 0) {
            callback('Please Add Any Inventory Read Grant because Inventory Features does not work without it.');
          }
        }
      }
      callback();
    }

    checkNewInventoryReadGrantHasSelectedAttributes = (rule, value, callback) => {
      if (value && value.includes('New Inventory Read') && !this.props.user.attributes) {
        callback('Please Select Some Attributes For New Inventory Read Grant');
      }
      callback();
    }

    requiredCheckOnBasesOfAboveFields = (rule, value, callback) => {
      const { getFieldValue } = this.props.form;
      const name = getFieldValue('name');
      const email = getFieldValue('email');
      if ((!value || value && value.length === 0) && name && email) {
        callback('Please input the Role of User!');
      }
      callback();
    }

    render() {
      const { visible, form } = this.props;
      const { getFieldDecorator } = form;
      return (
        <Modal
          visible={visible}
          title="Want to Add Invite User"
          closable={false}
          footer={[
            <Button key="cancel" type="primary" onClick={this.handleCancel}>
              Cancel
            </Button>,
            <Button key="submit" type="primary"  onClick={this.handleSubmit}>
              Add User
            </Button>
          ]}
        >
          <Form layout="vertical" onSubmit={this.handleSubmit}>
            <Form.Item >
                {getFieldDecorator('name', {
                  rules: [{ required: true, message: 'Please input the Name of User!' }],
                })(<Input placeholder="Name"/>)}
            </Form.Item>

            <Form.Item >
                {getFieldDecorator('email', {
                  rules: [{
                    type: 'email', message: 'Please enter valid email!',
                  }, {
                    required: true, message: 'Please input an email!'
                  }],
                })(<Input type="email"  placeholder="Email" />)}
            </Form.Item>

            <Form.Item >
                {getFieldDecorator('role', {
                  rules: [{
                    validator: this.requiredCheckOnBasesOfAboveFields,
                  }, {
                    validator: this.singleInventoryReadGrant,
                  }, {
                    validator: this.checkNewInventoryReadGrant,
                  }, {
                    validator: this.checkReadInventoryExistsForInventoryFeature,
                  }, {
                    validator: this.checkNewInventoryReadGrantHasSelectedAttributes,
                  }],
                })(
                  <Select mode="multiple"  placeholder="Role">
                    {this.getOptions()}
                  </Select>
                )}
            </Form.Item>
          </Form>
        </Modal>
      );
    }
  }
);

const mapStateToProps = ({ user }) => ({ user });

const mapDispatchToProps = dispatch => ({
  sendInvite: (mailData) => dispatch(sendInvite(mailData)),
  openSetInventoryReadAttributesModal: () => dispatch(openSetInventoryReadAttributesModal()),
  closeSetInventoryReadAttributesModal: (attributes) => dispatch(closeSetInventoryReadAttributesModal(attributes)),
  setValidateFormFlag: (flag) => dispatch(setValidateFormFlag(flag))
});

export default connect(mapStateToProps, mapDispatchToProps)(ModalFormToAddChildUser);
