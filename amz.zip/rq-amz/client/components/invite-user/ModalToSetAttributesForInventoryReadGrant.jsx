import React from 'react';
import {
  Modal,
  Form,
  Button,
  Select
} from 'antd';
import { connect } from 'react-redux';

import { closeSetInventoryReadAttributesModal, setValidateFormFlag } from '../../actions/users';

const { Option } = Select;

const ModalForInventoryReadGrant = Form.create({ name: 'form_in_modal' })(
  class extends React.Component {
    handleSubmit = (e) => {
      e.preventDefault();
      const { form, setValidateFormFlag } = this.props;

      form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          const { attributes } = values;
          const { closeSetInventoryReadAttributesModal } = this.props;

          closeSetInventoryReadAttributesModal(attributes);
          setValidateFormFlag(true);
          form.resetFields();
        }
      });
    }

    onCancel = () => {
      const { closeSetInventoryReadAttributesModal } = this.props;
      closeSetInventoryReadAttributesModal(null);
    }

    allCheckAttributes = (rule, value, callback) => {
      const { setFields } = this.props.form;
      if (value && value.includes('*')) {
        setFields({
          attributes: {
            value: ['title', 'asin', 'asinShortcut', 'sellerSku', 'fnsku', 'fulfilmentType', 'condition', 'status', 'quantity', 'sales30days', 'sales60days', 'sales90days', 'prices', 'noOfSellers', 'fees', 'profits', 'supplier', 'salesRank', 'productGroup', 'storeSection', 'notesSection', 'purchaseLink', 'enrolledInSnL', 'openDate', 'isReplen'],
            errors: null
          },
        });
      }
      callback();
    }

    isReplenCheck = (rule, value, callback) => {
      if (value && value.includes('isReplen')) {
        if (!value.includes('sellerSku')) {
          callback('Please Add Seller Sku Attribute also because IsReplen Depends upon it.');
        }
      }
      callback();
    }

    render() {
      const { visible, form } = this.props;
      const { getFieldDecorator } = form;
      return (
        <Modal
          visible={visible}
          title='New Inventory Read Attributes For User'
          closable={false}
          footer={[
            <Button key='cancel' type='primary' onClick={this.onCancel}>
              Cancel
            </Button>,
            <Button key='submit' type='primary'  onClick={this.handleSubmit}>
              Confirm Inventory Read Attributes For User
            </Button>
          ]}
        >
          <Form layout='vertical' onSubmit={this.handleSubmit}>
            <Form.Item >
                {getFieldDecorator('attributes', {
                  rules: [{
                    required: true, message: 'Please Select any attributes!'
                  }, {
                    validator: this.allCheckAttributes,
                  }, {
                    validator: this.isReplenCheck,
                  }]
                })(
                  <Select mode='multiple'  placeholder='Read Inventory Attributes'>
                    <Option value='*'>All</Option>
                    <Option value='title'>Title</Option>
                    <Option value='asin'>Asin</Option>
                    <Option value='asinShortcut'>Custom Asin Shortcuts</Option>
                    <Option value='sellerSku'>Seller Sku</Option>
                    <Option value='fnsku'>Fnsku</Option>
                    <Option value='fulfilmentType'>Fulfilled By</Option>
                    <Option value='condition'>Condition</Option>
                    <Option value='status'>Status</Option>
                    <Option value='quantity'>Quantity</Option>
                    <Option value='sales30days'>Sales 30 Days</Option>
                    <Option value='sales60days'>Sales 60 Days</Option>
                    <Option value='sales90days'>Sales 90 Days</Option>
                    <Option value='prices'>Prices</Option>
                    <Option value='noOfSellers'>No of Sellers</Option>
                    <Option value='fees'>Fees</Option>
                    <Option value='profits'>Profit</Option>
                    <Option value='supplier'>Supplier</Option>
                    <Option value='salesRank'>Sales Rank</Option>
                    <Option value='productGroup'>Category</Option>
                    <Option value='storeSection'>Store Section</Option>
                    <Option value='notesSection'>Notes Section</Option>
                    <Option value='purchaseLink'>Purchase Link</Option>
                    <Option value='enrolledInSnL'>Enrolled in Snl</Option>
                    <Option value='openDate'>Date Added</Option>
                    <Option value='isReplen'>IsReplen</Option>
                  </Select>
                )}
            </Form.Item>
          </Form>
        </Modal>
      );
    }
  }
);

const mapStateToProps = ({ user }) => ({ user });

const mapDispatchToProps = dispatch => ({
  closeSetInventoryReadAttributesModal: (attributes) => dispatch(closeSetInventoryReadAttributesModal(attributes)),
  setValidateFormFlag: (flag) => dispatch(setValidateFormFlag(flag))
});

export default connect(mapStateToProps, mapDispatchToProps)(ModalForInventoryReadGrant);
