import React from 'react';
import {
  Modal,
  Form,
  Button,
  Select
} from 'antd';
import { connect } from 'react-redux';

import { updateChildRole, openSetInventoryReadAttributesModal, closeUpdateRoleModal, fetchAttributes, hideAttributeFieldOfUpdateRoleModal, setValidateFormFlag } from '../../actions/users';

const { Option } = Select;

const ModalUpdateRole = Form.create({ name: 'form_in_modal' })(
  class extends React.Component {
    state = {
      roleAttributesToBeFetched: null,
      fetchAttributeFlag: false,
      attributeFieldFlag: true
    };
    handleSubmit = (e) => {
      e.preventDefault();
      const { form } = this.props;

      form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          const { updateChildRole } = this.props;
          const { _id } = this.props.user.childToBeUpdated.data;
          const { role, attributes } = values;
                
          if (attributes) {
            let roleWithAttributes = null;
            role.map(rol => {
              if (rol.includes('Can Read Inventory')) {
                roleWithAttributes = rol;
              }
            });

            if (role.includes('New Inventory Read') || roleWithAttributes) {
              updateChildRole({ _id, role, attributes, roleWithAttributes });
            } else {
              updateChildRole({ _id, role });
            }
          } else {
            updateChildRole({ _id, role });
          }

          this.props.saveNode(this.props.user.childToBeUpdated.node);
          const { closeUpdateRoleModal } = this.props;
          this.setState({ fetchAttributeFlag: true, roleAttributesToBeFetched: null, attributeFieldFlag: true });
          closeUpdateRoleModal();
          form.resetFields();
        }
      });
    }

    componentDidUpdate () {
      if (!this.state.roleAttributesToBeFetched && this.props.user && this.props.user.childToBeUpdated && this.props.user.childToBeUpdated.data && this.props.user.childToBeUpdated.data.permission[0].role) {
        const { role } = this.props.user.childToBeUpdated.data.permission[0];
        role.map((rol) => {
          if (rol.includes('Can Read Inventory')) {
            this.setState({ roleAttributesToBeFetched: rol, fetchAttributeFlag: false })
          }
        });
      }
      
      if (this.state.roleAttributesToBeFetched && !this.state.fetchAttributeFlag && this.props.user && !this.props.user.attributes && !this.props.user.fetching) {
        this.props.fetchAttributes(this.state.roleAttributesToBeFetched);
        this.setState({ fetchAttributeFlag: true, roleAttributesToBeFetched: null });
      }

      if (this.props.user && this.props.user.validateFormFlag && this.props.user.validateFormFlag === true) {
        const { form, setValidateFormFlag } = this.props;
        setValidateFormFlag(false);
        form.validateFieldsAndScroll(['role'], { force: true }, (err, values) => {});
      }
    }

    handleCancel = () => {
      const { form, closeUpdateRoleModal } = this.props;
      this.setState({ fetchAttributeFlag: true, roleAttributesToBeFetched: null, attributeFieldFlag: true });
      closeUpdateRoleModal();
      form.resetFields();
    }

    getOptions = () => {
      const { distinctRoles } = this.props.user;
      if (distinctRoles) {
        const options = distinctRoles.map(role => (
          <Option key={role} value={role}>{role}</Option>
        ));
        options.push(<Option key='New Inventory Read' value='New Inventory Read'>New Inventory Read</Option>);
        return options;
      }
      return null;
    }

    checkNewInventoryReadGrant = (rule, value, callback) => {
      let inventoryGrantCount = 0;
      if (value) {
        for (let i = 0; i < value.length; i += 1) {
          if (value[i].includes('Inventory') && value[i].includes('Read')) {
            inventoryGrantCount += 1;
          }
        }
        if (inventoryGrantCount > 1) {
          callback('Please Select Only One Read Inventory Role for User');
        } else if (value && value.includes('New Inventory Read')) {
          this.setState({ fetchAttributeFlag: true, attributeFieldFlag: true });
          if (!this.props.user.attributes) {
            this.props.openSetInventoryReadAttributesModal();
          }
        }
      }
      callback();
    }

    checkNewInventoryReadGrantHasSelectedAttributes = (rule, value, callback) => {
      if (value && value.includes('New Inventory Read') && !this.props.user.attributes) {
        callback('Please Select Some Attributes For New Inventory Read Grant');
      }
      callback();
    }

    allCheckAttributes = (rule, value, callback) => {
      const { setFields } = this.props.form;
      if (value.includes('*')) {
        setFields({
          attributes: {
            value: ['title', 'asin', 'asinShortcut', 'sellerSku', 'fnsku', 'fulfilmentType', 'condition', 'status', 'quantity', 'sales30days', 'sales60days', 'sales90days', 'prices', 'noOfSellers', 'fees', 'profits', 'supplier', 'salesRank', 'productGroup', 'storeSection', 'notesSection', 'purchaseLink', 'enrolledInSnL', 'openDate', 'isReplen'],
            errors: null
          },
        });
      }
      callback();
    }

    arrayInclusionCheck = (value) => {
      const inventoryFeatures = ['Can Export Inventory', 'Can Import Inventory', 'Can Set Cost Price', 'Can Set Purchase Link', 'Can Set Suppliers', 'Can Set Store Section', 'Can Set Notes Section'];
        for (let i = 0; i < inventoryFeatures.length; i += 1) {
          if (value.includes(inventoryFeatures[i])) {
            return true;
          };
        }
      return false;
    }

    checkReadInventoryExistsForInventoryFeature = (rule, value, callback) => {
      let inventoryGrantCount = 0;
      if (value && this.arrayInclusionCheck(value)) {
        for (let i = 0; i < value.length; i += 1) {
          if (value[i].includes('Inventory') && value[i].includes('Read')) {
            inventoryGrantCount += 1;
          }
        }
        if (inventoryGrantCount === 0) {
          callback('Please Add Any Inventory Read Grant because Inventory Features doesnot work without it.');
        }
      }
      callback();
    }

    isReplenCheck = (rule, value, callback) => {
      if (value.includes('isReplen')) {
        if (!value.includes('sellerSku')) {
          callback('Please Add Seller Sku Attribute also because IsReplen Depends upon it.');
        }
      }
      callback();
    }

    attributeFieldValidator = (rule, value, callback) => {
      let inventoryGrantCount = 0;
      if (value) {
        for (let i = 0; i < value.length; i += 1) {
          if (value[i].includes('Inventory') && value[i].includes('Read')) {
            inventoryGrantCount += 1;
          }
        }
        if (inventoryGrantCount === 0) {
          const { hideAttributeFieldOfUpdateRoleModal } = this.props;
          this.setState({ fetchAttributeFlag: true, attributeFieldFlag: false });
          hideAttributeFieldOfUpdateRoleModal();
        }
      }
      callback();
    }

    render() {
      const { visible, form } = this.props;
      const { getFieldDecorator } = form;
      return (
        <Modal
          visible={visible}
          title='Want to Update User Role'
          closable={false}
          footer={[
            <Button key='cancel' type='primary' onClick={this.handleCancel}>
              Cancel
            </Button>,
            <Button key='submit' type='primary'  onClick={this.handleSubmit}>
              Update Roles
            </Button>
          ]}
        >
          <Form layout="vertical" onSubmit={this.handleSubmit}>
            <Form.Item>
                {getFieldDecorator('role', {
                  initialValue: (this.props.user && this.props.user.childToBeUpdated && this.props.user.childToBeUpdated.data && this.props.user.childToBeUpdated.data.permission[0].role)? this.props.user.childToBeUpdated.data.permission[0].role : null,
                  rules: [{
                    required: true, message: 'Please input the Role of User!'
                  }, {
                    validator: this.checkReadInventoryExistsForInventoryFeature,
                  }, {
                    validator: this.attributeFieldValidator,
                  }, {
                    validator: this.checkNewInventoryReadGrant,
                  }, {
                    validator: this.checkNewInventoryReadGrantHasSelectedAttributes,
                  }]
                })(
                  <Select mode='multiple'  placeholder='Roles'>
                    {this.getOptions()}
                  </Select>
                )}
            </Form.Item>
            {(this.props.user.attributes && this.state.attributeFieldFlag) ?
              <Form.Item>
                  {getFieldDecorator('attributes', {
                    rules: [{
                      required: true, message: 'Please input the Attributes of User!'
                    }, {
                      validator: this.allCheckAttributes,
                    }, {
                      validator: this.isReplenCheck,
                    }],
                    initialValue: this.props.user.attributes
                  })(
                    <Select mode='multiple'  placeholder='Attributes'>
                      <Option value='*'>All</Option>
                      <Option value='title'>Title</Option>
                      <Option value='asin'>Asin</Option>
                      <Option value='asinShortcut'>Custom Asin Shortcuts</Option>
                      <Option value='sellerSku'>Seller Sku</Option>
                      <Option value='fnsku'>Fnsku</Option>
                      <Option value='fulfilmentType'>Fulfilled By</Option>
                      <Option value='condition'>Condition</Option>
                      <Option value='status'>Status</Option>
                      <Option value='quantity'>Quantity</Option>
                      <Option value='sales30days'>Sales 30 Days</Option>
                      <Option value='sales60days'>Sales 60 Days</Option>
                      <Option value='sales90days'>Sales 90 Days</Option>
                      <Option value='prices'>Prices</Option>
                      <Option value='noOfSellers'>No of Sellers</Option>
                      <Option value='fees'>Fees</Option>
                      <Option value='profits'>Profit</Option>
                      <Option value='supplier'>Supplier</Option>
                      <Option value='salesRank'>Sales Rank</Option>
                      <Option value='productGroup'>Category</Option>
                      <Option value='storeSection'>Store Section</Option>
                      <Option value='notesSection'>Notes Section</Option>
                      <Option value='purchaseLink'>Purchase Link</Option>
                      <Option value='enrolledInSnL'>Enrolled in Snl</Option>
                      <Option value='openDate'>Date Added</Option>
                      <Option value='isReplen'>IsReplen</Option>
                    </Select>
                  )}
              </Form.Item> :
              null
            }
          </Form>
        </Modal>
      );
    }
  }
);

const mapStateToProps = ({ user }) => ({ user });

const mapDispatchToProps = dispatch => ({
  updateChildRole: (roleData) => dispatch(updateChildRole(roleData)),
  openSetInventoryReadAttributesModal: () => dispatch(openSetInventoryReadAttributesModal()),
  closeUpdateRoleModal: () => dispatch(closeUpdateRoleModal()),
  hideAttributeFieldOfUpdateRoleModal: () => dispatch(hideAttributeFieldOfUpdateRoleModal()),
  fetchAttributes: (roleToFetchAttribute) => dispatch(fetchAttributes(roleToFetchAttribute)),
  setValidateFormFlag: (flag) => dispatch(setValidateFormFlag(flag))
});

export default connect(mapStateToProps, mapDispatchToProps)(ModalUpdateRole);
