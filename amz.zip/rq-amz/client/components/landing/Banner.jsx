import React from 'react';
import { Icon } from 'antd';
import QueueAnim from 'rc-queue-anim';
import TweenOne from 'rc-tween-one';

class Banner extends React.PureComponent {
  render() {
    const { ...currentProps } = this.props;
    const { dataSource } = currentProps;
    delete currentProps.dataSource;
    delete currentProps.isMobile;
    return (
      <div {...currentProps} {...dataSource.wrapper}>
        <QueueAnim
          key="QueueAnim"
          type={['bottom', 'top']}
          delay={200}
          {...dataSource.textWrapper}
        >
          <div style={{width: '100%'}} key="title1" {...dataSource.title1}>
            { dataSource.title1.children }
          </div>
          {dataSource.title2 && 
          <div style={{width: '100%'}} key="title2" {...dataSource.title2}>
            { dataSource.title2.children }
          </div>
          }
          <div style={{ padding: '35px 0px 18px 0px' }} key="content" {...dataSource.content}>
            {dataSource.content.children}
          </div>
        </QueueAnim>
        <TweenOne
          animation={{
            y: '-=20',
            yoyo: true,
            repeat: -1,
            duration: 1000,
          }}
          className="banner0-icon"
          key="icon"
        >
          <Icon type="down" />
        </TweenOne>
      </div>
    );
  }
}
export default Banner;
