import React from 'react';
import { Link } from 'react-router-dom';
import { Row, Col } from 'antd';


const Footer = () => {
  

  return (
    <Row gutter={24} style={{ padding: '50px', color: 'grey', backgroundColor: '#ec7151'}}>
      
      <Col style={{ marginLeft: '150px' }} span={8}>
        <img style={{height: '150px', width: '350px'}} src={require('../../public/images/replen-dashboard_logo.svg')} alt='Not Showing'/>
      </Col>

      <Col style={{ marginLeft: '150px' }} span={8}>
        <Row>
          <h3>Our Policies</h3>
        </Row>
        <Row>
          <Link to='/privacy-policy'>
            <h5>Privacy Policy </h5>
          </Link>
        </Row>
        <Row>
          <Link to='/terms-and-condition-policy'>
            <h5>Terms and Conditions Policy </h5>
          </Link>
        </Row>
      </Col>

    </Row>
  );
}

export default Footer;
