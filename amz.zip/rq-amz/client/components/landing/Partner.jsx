import React from 'react';
import { Row, Col } from 'antd';

import { getChildrenToRender } from './utils';

class Partner extends React.PureComponent {
  render() {
    const { dataSource, isMobile, ...props } = this.props;
    const {
      wrapper,
      titleWrapper,
      page,
      childWrapper,
    } = dataSource;
    return (
      <div {...props} {...wrapper}>
        <div {...page}>
          <div {...titleWrapper}>
            {titleWrapper.children.map(getChildrenToRender)}
          </div>
          <Row type="flex" justify="center" align="middle">
            {childWrapper.children.map((block, i) => {
              const { children: item, ...blockProps } = block;
              return (
                <Col span={24} key={i.toString()} {...blockProps}>
                  <a href={item.children[1].href}>
                    <div {...item}>
                      {item.children.map(getChildrenToRender)}
                    </div>
                  </a>
                </Col>
              );
            })}
          </ Row>
        </div>
      </div>
    );
  }
}

export default Partner;
