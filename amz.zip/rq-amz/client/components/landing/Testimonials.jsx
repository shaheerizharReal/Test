import React from 'react';
import { Col, Row, Card } from 'antd';
 
const Testimonials = () => {
  return (
    <div style={{ padding: '50px', textAlign: 'center' }}>
      <h1 style={{ padding: '50px', fontSize: '34px', color:'rgba(0, 0, 0, 0.65)' }}> Testimonials </h1>
      <Row gutter={24} style={{ padding: '5px' }}>
        <Col span={6} />
        <Col span={12}>
          <Card style={{ boxShadow: '2px 2px 3px red' }}>
            <p>
              Replen Dashboard saves me so much time! I can create a shopping list in under 5 minutes now and that use to take me nearly an hour using Excel formulas. It's simple to use and drastically reduces the number of days we are out of stock.
            </p>
            <b style={{ color: 'red' }}>Stetzen F</b>
          </Card>
        </Col>
      </Row>
      <Row gutter={24} style={{ padding: '5px' }}>
        <Col span={6} />
        <Col span={12}>
          <Card style={{ boxShadow: '2px 2px 3px red' }}>
            <p>
              I just placed a $3500 order that usually takes me three hours to place.  It took me an hour.  I am extremely excited about this tool.  We do mainly replens, so I can't even imagine how much time and money this is going to save me. This is HUGE. Great job! 🙌🏻🙌🏻🙌🏻
            </p>
            <b style={{ color: 'red' }}>Samara Z</b>
          </Card>
        </Col>
      </Row>
      <Row gutter={24} style={{ padding: '5px' }}>
        <Col span={6} />
        <Col span={12}>
          <Card style={{ boxShadow: '2px 2px 3px red' }}>
            <p>
            Replen Dashboard is an amazing tool!! A must have for every Amazon seller, especially those who have a base of replens. This tool has saved me at least 75% of the time it used to take to get my replen shopping list together. I love being able to see at a glance which products are in need of replenishing. I would highly recommend this to any Amazon seller. <br/>Thank You!!
            </p>
            <b style={{ color: 'red' }}>Aaron P</b>
          </Card>
        </Col>
      </Row>
      <Row gutter={24} style={{ padding: '5px' }}>
        <Col span={6} />
        <Col span={12}>
          <Card style={{ boxShadow: '2px 2px 3px red' }}>
            <p>
            This is so amazing!! I love this already. I'm actually excited to make our replen list this week.
            </p>
            <b style={{ color: 'red' }}>Crystal A</b>
          </Card>
        </Col>
      </Row>
      <Row gutter={24} style={{ padding: '5px' }}>
        <Col span={6} />
        <Col span={12}>
          <Card style={{ boxShadow: '2px 2px 3px red' }}>
            <p>
            Finally, a restock software that works for those of us that have a combination of replens and non-replenishable items. I have tried several other software's and Replen Dashboard is by far, the most straightforward and easy to use. It has saved me hours of time as I am able to sort through my items quickly and stay in stock with ease!
            </p>
            <b style={{ color: 'red' }}>Paul S.</b>
          </Card>
        </Col>
      </Row>
      <Row gutter={24} style={{ padding: '5px' }}>
        <Col span={6} />
        <Col span={12}>
          <Card style={{ boxShadow: '2px 2px 3px red' }}>
            <p>
            This software is AMAZING! Super easy to use. The import, export, sort & drag capabilities are awesome. We dropped off a shipment at UPS yesterday afternoon, and the inbound shipment quantities are showing correctly in the replen software, but have not yet posted in Amazon- what?!!
            </p>
            <b style={{ color: 'red' }}>Mary Beth A.</b>
          </Card>
        </Col>
      </Row>
      <Row gutter={24} style={{ padding: '5px' }}>
        <Col span={6} />
        <Col span={12}>
          <Card style={{ boxShadow: '2px 2px 3px red' }}>
            <p>
            Jimmy, I have had the Replen software for a couple of days and to be honest my ego was in the camp of "I can do this better with my spreadsheets" but after two days I have decided this is a "no brainer".  Thanks to this software, I have culled /paused 28 replens due to low ROI and low profit dollars.  I was wasting too much time prepping many of these with little return.  Without this software I would not have been able to see this issue this quickly. For the record...I sold my first unit on 7/28/19 and I have approximately 200 SKU's  and I am averaging around $7500 ever 30 days.  This software increases my time I need to devote to sourcing and shipping. Thanks and I will be a customer.....
            </p>
            <b style={{ color: 'red' }}>Chris N.</b>
          </Card>
        </Col>
      </Row>
    </div>
  )
};

export default Testimonials;
