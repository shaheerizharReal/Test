import React from "react";
import { Icon, Row } from "antd";

const getDetails = (name) => {
  if(name === 'pro')
  return {amount: 29.97, title: 'Pro', activeSKUs: 'Up to 400', textColor: 'text-color'};
  else if (name === 'expert')
  return {amount: 49.97, title: 'Expert', activeSKUs: 'Up to 1000', textColor: 'text-color-expert'};
  else if (name === 'enterprise')
  return {amount: 79.97, title: 'Enterprise', activeSKUs: 'Over 1000', textColor: 'text-color-professional'};
};

const PlanCard = ({styleName, headerStyle, itemStyle, plan }) => {

  if (plan) {
    const planDetails = getDetails(plan.name);
    return (
      <div className={`${styleName}`}>
        <div className={`${headerStyle}`}>
          <h2 className="price"><i className="icon icon-halfstar"/>{planDetails.title}</h2>
          <h3 className="letter-spacing-base text-white- text-uppercase mb-0"><b>{planDetails.activeSKUs}</b>  Active SKUs</h3>
        </div>

        <div className={`${itemStyle}`}>
          <div>
            <h3 className="letter-spacing-base text-white text-uppercase mb-0">{`$ ${planDetails.amount} / month`}</h3>
            <h3 className={planDetails.textColor} style={{paddingTop: '5px'}}> OR </h3>
            <h3 className="letter-spacing-base text-white text-uppercase mb-0">{`$ ${planDetails.amount * 10}0   / year - 2 months free!`}</h3>
          </div>
          <ul style={{marginTop: '20px'}} className="package-items">
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Advanced Replenishment Stats</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Sales Rank Data</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Profit Data</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> FBA Fees Data</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Competition Pricing Data</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> ASIN Sales Data</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> OA Link Tracking</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Amazon Listing Link</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Picture of Each ASIN</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Alerts for Competition Under Your Current Price</span>
              </li>
            </Row>
            <Row> 
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> <p style={{textAlign: 'left'}}>Easily Upload Cost, Supplier Data and Download Reports As Needed</p></span>
              </li>
            </Row>
            <Row><li><span><Icon style={{paddingLeft: '30px'}} className={planDetails.textColor} type="arrow-right" /> Manage by Supplier</span></li></Row>
            <Row><li><span><Icon style={{paddingLeft: '30px'}} className={planDetails.textColor} type="arrow-right" /> Manage by Category</span></li></Row>
            <Row><li><span><Icon style={{paddingLeft: '30px'}} className={planDetails.textColor} type="arrow-right" /> Repurchase Amount</span></li></Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Insightful Account Dashboard</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Email Support Access</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> <p style={{textAlign: 'left'}}> Active SKUs are FBA SKUs that have active listings on Amazon as shown by your Inventory Report.</p></span>
              </li>
            </Row>
          </ul>
        </div>
      </div>
    )
  }
  return '__';
};

export default PlanCard;
