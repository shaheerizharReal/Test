import React from 'react';
import { Link } from 'react-router-dom';
import { Col, Row, Button } from 'antd';

import PlanCard from './PlanCard';
import './PricingTable.less';
 
const PricingTable = () => {
  return (
    <div className='price-tables pt-default'>
      <Row>
        <Col xl={8} lg={24} md={8} xs={24} style={{padding: '25px'}}>
          <PlanCard
            plan={{name: 'pro'}}
            styleName='package'
            headerStyle='package-header bg-primary text-white'
            itemStyle='package-body'
          />
        </Col>

        <Col xl={8} lg={24} md={8} xs={24} style={{padding: '25px'}}>
          <PlanCard
            plan={{name: 'expert'}}
            styleName='package-expert bg-primary-light highlight border-0'
            headerStyle='package-expert-header-expert bg-primary-expert text-white'
            itemStyle='package-expert-body-expert text-white'

          />
        </Col>

        <Col xl={8} lg={24} md={8} xs={24} style={{padding: '25px'}}>
          <PlanCard
            plan={{name: 'enterprise'}}
            styleName='package-professional bg-primary-light highlight border-0'
            headerStyle='package-professional-header-professional bg-primary-professional text-white'
            itemStyle='package-professional-body-professional text-white'
          />
        </Col>
      </Row>
      
      <div style={{textAlign: "center"}} className="package-footer">
        <Link to='/auth/register'>
          <Button size='large' type="primary" >Register for Your 30 Day Free Trial Now!</Button>
        </Link>
      </div>
    </div>
  )
};

export default PricingTable;
