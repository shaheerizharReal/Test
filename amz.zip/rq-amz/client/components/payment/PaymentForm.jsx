import React, { Component } from 'react';
import { CardElement, injectStripe } from 'react-stripe-elements';
import { Card,
  Button,
  notification,
  Statistic,
  Icon,
  Spin,
  Modal,
  Row,
  Col
} from 'antd';
import { find, round } from 'lodash';
import axios from 'axios';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';

const { confirm } = Modal;

import { resetSelectedPlan, setShowPaymentCard } from '../../actions/payment';

class PaymentForm extends Component {
  constructor(props) {
    super(props);
    this.submit = this.submit.bind(this);
    this.state = {
      loading: false,
      newAmount: null,
      coupon: null
    }
  }

  componentDidMount() {
    this.props.onRef(this);

    const { referralCode } = this.props.user;
    const { stripeCoupons } = this.props;
    if (referralCode && find(stripeCoupons, { _id: referralCode })) {
      this.validateCoupon(referralCode);
    }
  }

  createSubscription = ({ token, coupon, planId, planName, planAmount, tierNo, quantity }) => {
    let lmref;
    try {
      lmref = lmFinished();
    } catch (e) {
      console.log('e', e);
    }

    this.setState({ loading: true });
    const url = '/api/v1/users/create-subscription';
    const instance = this;

    confirm({
      title: 'Subscribe Plan',
      content: `Do you really want to Subscribe this Plan ?`,
      okText: 'Yes',
      cancelText: 'No',
      onOk() {
        axios.post(url, {
          token,
          coupon,
          planId,
          planName,
          planAmount,
          tierNo,
          quantity,
          lmref
        }).then(() => {
          notification['success']({
            message: 'Payment',
            description: 'Payment charged successfully !',
          });

          instance.props.fetchUser();
          instance.props.setShowPaymentCard( false );
          // instance.setState({ loading: false });
        }).catch((error) => {
          notification['error']({
            message: 'Payment',
            description: 'Subscription Failed!'
          });

          instance.setState({ loading: false });
        })
      },
      onCancel() {
        instance.setState({ loading: false });
      },
    });
  }

  validateCoupon = (coupon) => {
    const url = '/api/v1/users/validate-coupon';

    this.setState({ loading: true });

    axios.post(url, {
      couponId: coupon
    }).then(({ data }) => {
      const { coupon } = data;

      if (coupon) {
        const { selectedPlan, selectedTier } = this.props;
        
        let amountOff = 0;
        const { amount_off, percent_off } = coupon;
        if (amount_off) {
          amountOff = amount_off;
        } else if (percent_off) {
          amountOff = (((selectedPlan.tiers[selectedTier].flat_amount / 100) * percent_off) / 100);
        }
        
        const newAmount = round(((selectedPlan.tiers[selectedTier].flat_amount / 100) - amountOff), 2);

        this.setState({ newAmount, coupon: coupon.id });

        notification['success']({
          message: 'Apply Promo',
          description: 'Promo applied successfully !',
        });
      }

      this.setState({ loading: false });
    }).catch((error) => {
      notification['error']({
        message: 'Apply Promo',
        description: 'Promo Code Error',
      });

      this.setState({ loading: false });
    });
  }

  submit(e) {
    const { stripe, selectedPlan, selectedTier } = this.props;
    const { noOfActiveProducts } = this.props.user;

    const { coupon } = this.state;
    const planId = selectedPlan.id;
    const planName = selectedPlan.nickname;
    const tierNo = selectedTier;
    const planAmount = round(selectedPlan.tiers[tierNo].flat_amount / 100, 2);

    this.setState({ loading: true });
    stripe.createToken()
      .then((response) => {
        this.setState({ loading: false });
        const token = response.token.id;
        const quantity = noOfActiveProducts;
        this.createSubscription({ token, coupon, planId, planName, planAmount, tierNo, quantity });
      }).catch((err) => {
        notification['error']({
          message: 'Subscription',
          description: err.message,
        });
      })
  }

  getSuffix = (planTitle) => {
    if (planTitle === 'Yearly') {
      return '/ Year'
    } else {
      return '/ Month'
    }
  }
  
  removeCard = (e) => {
    const { resetSelectedPlan, setShowPaymentCard } = this.props;

    resetSelectedPlan();
    setShowPaymentCard(false);
  }

  render() {
    const { newAmount, loading } = this.state;
    const { selectedPlan, selectedTier } = this.props;

    return (
      <Spin tip="Loading..." spinning={loading} >
      <Row gutter={24}>
        <Col span={5}> </Col>
        <Col span={14}>
          <Card
            title="Subscription"
            description="Enter your credit card details to subscribe."
            style={{ width: 700 }}
            actions={[<Button type="primary" onClick={this.submit}>Activate</Button>,
              <Button type="primary" onClick={(e) => this.removeCard(e)}> Remove Card</Button>]}

            style={{ 'marginTop': '8%' }}
          >
            <Card.Grid style={{ 'width': '100%' }}>
              {newAmount
                ? (<div>
                      <strike>
                        <Statistic value={selectedPlan.tiers[selectedTier].flat_amount / 100} prefix={<Icon type="dollar" />} suffix={this.getSuffix(selectedPlan.nickname)} />
                      </strike>
                      <Statistic value={newAmount} prefix={<Icon type="dollar" />} suffix={this.getSuffix(selectedPlan.nickname)} />
                  </div>)
                : (<Statistic value={selectedPlan.tiers[selectedTier].flat_amount / 100} prefix={<Icon type="dollar" />} suffix={this.getSuffix(selectedPlan.nickname)} />) }
            </Card.Grid>

            <Card.Grid style={{ 'width': '100%' }}>
              <div className="checkout">
                <CardElement />
              </div>
            </Card.Grid>
          </Card>
        </Col>
        <Col span={5}> </Col>
      </Row> 
      </Spin>
    );
  }
}

const mapStateToProps = ({ payment }) => payment;

const mapDispatchToProps = (dispatch) => ({
  resetSelectedPlan: () => {
    dispatch(resetSelectedPlan());
  },
  setShowPaymentCard: (showPaymentCard) => {
    dispatch(setShowPaymentCard(showPaymentCard));
  }
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(withRouter(injectStripe(PaymentForm)))
