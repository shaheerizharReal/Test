import React from "react";
import { Button, Icon, Row } from "antd";

const getDetails = (amount) => {
  if(amount === 2997)
    return {amount: 29.97, title: 'Monthly Pro ', activeSKUs: 'Up to 400', textColor: 'text-color-expert', payable: '$ 29.97 / month'};
  else if (amount === 4997)
    return {amount: 49.97, title: 'Monthly Expert', activeSKUs: 'Up to 1000', textColor: 'text-color-expert', payable: '$ 49.97 / month'};
  else if (amount === 7997)
    return {amount: 79.97, title: 'Monthly Enterprise', activeSKUs: 'Over 1000', textColor: 'text-color-expert', payable: '$ 79.97 / month'};
  else if(amount === 29970)
    return {amount: 299.70, title: 'Yearly Pro', activeSKUs: 'Up to 400', textColor: 'text-color-professional', payable: '$ 299.70 / year - 2 months free!'};
  else if (amount === 49970)
    return {amount: 499.70, title: 'Yearly Expert', activeSKUs: 'Up to 1000', textColor: 'text-color-professional', payable: '$ 499.70 / year - 2 months free!'};
  else if (amount === 79970)
    return {amount: 799.70, title: 'Yearly Enterprise', activeSKUs: 'Over 1000', textColor: 'text-color-professional', payable: '$ 799.70 / year - 2 months free!'};
};

const getButtonText = (user, plan) => {
  if (user && user.payment && user.payment.planID && user.payment.planID === plan.id) {
    return 'Cancel Subscription';
  }
  
  return 'Subscribe Now';
};

const gotoPayment = (user, plan, tierNo, cancelSubscription, planSelected, setShowPaymentCard) => {
  if (user && user.payment && user.payment.planID && user.payment.planID === plan.id) {
    cancelSubscription(user.payment.subscriptionId, plan.nickname);
  } else {
    planSelected(plan, tierNo);
    setShowPaymentCard( true );
  }
}

const PlanCard = ({
  styleName,
  headerStyle,
  itemStyle,
  footerStyle,
  plan,
  user,
  planSelected,
  setShowPaymentCard,
  setShowUpdateCard,
  cancelSubscription,
  noOfActiveProducts
}) => {
  if (plan) {
    let tierNo = 0;
    for(let i = 0; i < plan.tiers.length; i += 1) {
      if ((noOfActiveProducts <= plan.tiers[i].up_to) || !plan.tiers[i].up_to) {
        tierNo = i;
        break;
      }
    }

    const planDetails = getDetails(plan.tiers[tierNo].flat_amount);

    return (
      <div className={`${styleName}`}>
        <div className={`${headerStyle}`}>
          <h2 className="price"><i className="icon icon-halfstar"/>{planDetails.title}</h2>
          <h3 className="letter-spacing-base text-white- text-uppercase mb-0"><b>{planDetails.activeSKUs}</b>  Active SKUs</h3>
        </div>

        <div className={`${itemStyle}`}>
          <div>
            <h3 className="letter-spacing-base text-white text-uppercase mb-0">{ planDetails.payable }</h3>
          </div>
          <ul style={{marginTop: '20px'}} className="package-items">
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Advanced Replenishment Stats</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Sales Rank Data</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Profit Data</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> FBA Fees Data</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Competition Pricing Data</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> ASIN Sales Data</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> OA Link Tracking</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Amazon Listing Link</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Picture of Each ASIN</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Alerts for Competition Under Your Current Price</span>
              </li>
            </Row>
            <Row> 
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> <p style={{textAlign: 'left'}}>Easily Upload Cost, Supplier Data and Download Reports As Needed</p></span>
              </li>
            </Row>
            <Row><li><span><Icon style={{paddingLeft: '30px'}} className={planDetails.textColor} type="arrow-right" /> Manage by Supplier</span></li></Row>
            <Row><li><span><Icon style={{paddingLeft: '30px'}} className={planDetails.textColor} type="arrow-right" /> Manage by Category</span></li></Row>
            <Row><li><span><Icon style={{paddingLeft: '30px'}} className={planDetails.textColor} type="arrow-right" /> Repurchase Amount</span></li></Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Insightful Account Dashboard</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> Email Support Access</span>
              </li>
            </Row>
            <Row>
              <li>
                <span><Icon className={planDetails.textColor} type="check" /> <p style={{textAlign: 'left'}}> Active SKUs are FBA SKUs that have active listings on Amazon as shown by your Inventory Report.</p></span>
              </li>
            </Row>
          </ul>
          <div className="package-footer">
            <Button type="primary" onClick={() => gotoPayment(user, plan, tierNo, cancelSubscription, planSelected, setShowPaymentCard)} className={`${footerStyle}`}>{getButtonText(user, plan)}</Button>
            {(user && user.payment && user.payment.planID && user.payment.planID === plan.id) ?
              <Button type="primary" marginleft="20px" onClick={(e) => setShowUpdateCard(true)} className={`${footerStyle}`}>Update Card</Button> :
              null
            }
          </div>
        </div>
      </div>
    )
  }
  return '__';
};

export default PlanCard;
