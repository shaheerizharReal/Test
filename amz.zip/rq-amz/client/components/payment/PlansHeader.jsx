import React from 'react';
import moment from 'moment';
import {
  Spin,
  Row,
  Col
} from 'antd';
import { connect } from 'react-redux';

import PlansCard from './PlanCard';
import { getStripeData } from '../../actions/payment';
import { getNoOfActiveProducts } from '../../actions/users';
import './PlansHeader.less';

class PlansHeader extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const { getStripeData, getNoOfActiveProducts } = this.props;
    getStripeData();
    getNoOfActiveProducts();
  };

  render() {
    const { fetching, stripePlans } = this.props.payment;
    const { noOfActiveProducts, payment } = this.props.user;
    const { nextInvoicedChargedAt, subscriptionEndDate } = payment || {};
    return (
      <div>
        <Spin tip="Loading..." spinning={fetching}>
          <div style={{ background: '#cdccce', padding: '30px' }}>
            {
              (nextInvoicedChargedAt || subscriptionEndDate) &&
              <div style={{ textAlign: 'center', marginBottom: '20px' }}>
                <h2 style={{ fontSize: '26px' }}>
                  {nextInvoicedChargedAt ? 'Next Invoice Date' : 'Last Date Till Usage'}
                </h2>
                <p style={{ fontSize: '22px' }}>
                  {moment.unix(nextInvoicedChargedAt ? nextInvoicedChargedAt : subscriptionEndDate).format('LL')}
                </p>
              </div>
            }
            <Row gutter={24}>
              <Col span={2} />
              <Col span={10} style={{ paddingLeft: '5px', paddingRight: '20px'}}>
                <PlansCard
                  user={this.props.user}
                  plan={stripePlans[1]}
                  noOfActiveProducts={noOfActiveProducts}
                  planSelected={this.props.planSelected}
                  setShowPaymentCard={this.props.setShowPaymentCard}
                  setShowUpdateCard={this.props.setShowUpdateCard}
                  cancelSubscription={this.props.cancelSubscription}
                  styleName='pkg-expert'
                  headerStyle='pkg-expert-header-expert bg-primary text-white'
                  itemStyle='pkg-expert-body-expert'
                  footerStyle='btn-bg-expert'
                />
              </Col>
              <Col span={10} style={{ paddingLeft: '20px', paddingRight: '5px'}}>
                <PlansCard
                  user={this.props.user}
                  plan={stripePlans[0]}
                  noOfActiveProducts={noOfActiveProducts}
                  planSelected={this.props.planSelected}
                  setShowPaymentCard={this.props.setShowPaymentCard}
                  setShowUpdateCard={this.props.setShowUpdateCard}
                  cancelSubscription={this.props.cancelSubscription}
                  styleName='pkg-professional'
                  headerStyle='pkg-professional-header-professional bg-primary text-white'
                  itemStyle='pkg-professional-body-professional'
                  footerStyle='btn-bg-professional'
                />
              </Col>
            </Row>
          </div>
        </Spin>
      </div>
    );
  };
};

const mapStateToProps = ({ payment }) => ({ payment });

const mapDispatchToProps = (dispatch) => ({
  getStripeData: () => {
    dispatch(getStripeData())
  },
  getNoOfActiveProducts: () => {
    dispatch(getNoOfActiveProducts());
  }
});
export default connect(mapStateToProps, mapDispatchToProps)(PlansHeader);
