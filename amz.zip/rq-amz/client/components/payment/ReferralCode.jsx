import React, { Component } from 'react';
import { Row, Col, Form, Button } from 'antd';
import { connect } from 'react-redux';

import { InputField } from '../../components/form/Components.jsx';
import { updateReferralCode } from '../../actions/users';

class ReferralCodeForm extends Component {

  handleSubmit = (e) => {
    e.preventDefault();
    const { form, updateReferralCode } = this.props;

    form.validateFields((err, values) => {
      if (!err) {
        let { referralCode } = values;
        referralCode = referralCode ? referralCode.trim() : '';
        updateReferralCode(referralCode);
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const { referralCode } = this.props;

    return (
      <div style={{ height: '20%' }}>
        <Form layout="horizontal" onSubmit={this.handleSubmit}>
          <Row gutter={24}>
            <Col span={8}> </Col>
            <Col span={8}>
              {InputField({
                getFieldDecorator,
                label: 'Referral Code',
                name: 'referralCode',
                initialValue: referralCode
              })}
            </Col>
          </Row>
          <Row>
            <Col span={8}> </Col>
            <Col span={8}>
              <Button type="primary" htmlType="submit" style={{ float: 'right' }}>Update Referral Code</Button>
            </Col>
          </Row>
        </Form>
      </div>
    );
  }
}

const ReferralCodeSettings = Form.create({ name: 'printer-form' })(ReferralCodeForm);

const mapStateToProps = ({ user }) => ({
  referralCode: (user.referralCode || '')
});

const mapDispatchToProps = (dispatch) => ({
  updateReferralCode: (updatedRC) => dispatch(updateReferralCode(updatedRC)),
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(ReferralCodeSettings)
