import React, { Component } from 'react';
import { CardElement, injectStripe } from 'react-stripe-elements';
import {
  Card,
  Button,
  notification,
  Spin,
  Modal,
  Row,
  Col
} from 'antd';
import axios from 'axios';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';

const { confirm } = Modal;

import { setShowUpdateCard } from '../../actions/payment';

class UpdateCardForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
    }
  }

  updateCard = ({ token }) => {
    this.setState({ loading: true });
    const url = '/api/v1/users/update-card';
    const instance = this;

    confirm({
      title: 'Update Card',
      content: `Do you really want to Update Your Card?`,
      okText: 'Yes',
      cancelText: 'No',
      onOk() {
        axios.post(url, {
          token,
        }).then(() => {
          notification['success']({
            message: 'Payment Card',
            description: 'Card Updated successfully !',
          });

          instance.props.setShowUpdateCard( false );
        }).catch((error) => {
          notification['error']({
            message: 'Payment Card',
            description: 'Card Update Failed!'
          });

          instance.setState({ loading: false });
        })
      },
      onCancel() {
        instance.setState({ loading: false });
      },
    });
  }

  submit(e) {
    const { stripe } = this.props;

    stripe.createToken()
      .then((response) => {
        const token = response.token.id;
        this.updateCard({ token });
      }).catch((err) => {
        notification['error']({
          message: 'Subscription',
          description: err.message,
        });
      })
  }
  
  render() {
    const { loading } = this.state;
    const { setShowUpdateCard } = this.props;

    return (
      <Spin tip="Loading..." spinning={loading} >
      <Row gutter={24}>
        <Col span={5}> </Col>
        <Col span={14}>
          <Card
            title="Card Updation"
            description="Enter your credit card details to update card."
            style={{ width: 700 }}
            actions={[<Button type="primary" onClick={(e) => this.submit(e)}>Update Card</Button>,
              <Button type="primary" onClick={(e) => setShowUpdateCard(false)}>Remove Card</Button>]}

            style={{ 'marginTop': '8%' }}
          >

            <Card.Grid style={{ 'width': '100%' }}>
              <div className="checkout">
                <CardElement />
              </div>
            </Card.Grid>
          </Card>
        </Col>
        <Col span={5}> </Col>
      </Row> 
      </Spin>
    );
  }
}

const mapStateToProps = ({ payment }) => payment;

const mapDispatchToProps = (dispatch) => ({
  setShowUpdateCard: (showUpdateCard) => {
    dispatch(setShowUpdateCard(showUpdateCard));
  }
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(withRouter(injectStripe(UpdateCardForm)))
