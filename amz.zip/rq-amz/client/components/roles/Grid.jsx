import React from 'react';
import { AgGridReact } from 'ag-grid-react';
import { connect } from 'react-redux';
import {
  Button,
  Modal
} from 'antd';

import { getRoles, deleteRole } from '../../actions/role';
import './Grid.less';

const { confirm } = Modal;

const sideBarDef = {
  toolPanels: [{
    id: 'columns',
    labelDefault: 'Columns',
    labelKey: 'columns',
    iconKey: 'columns',
    toolPanel: 'agColumnsToolPanel',
    toolPanelParams: {
      suppressPivots: true,
      suppressPivotMode: true,
      suppressValues: true
    }
  }, {
    id: 'filters',
    labelDefault: 'Filters',
    labelKey: 'filters',
    iconKey: 'filter',
    toolPanel: 'agFiltersToolPanel'
  }]
};

class RoleGrid extends React.Component {
  componentDidMount() {
    const {  getRoles } = this.props;
    getRoles();
  }

  handleDelete = (e, params) => {
    e.preventDefault();
    
    const { _id } = params.data;
    const instance = this;
    confirm({
      title: 'Change Status',
      content: `Do you really want to delete this Role?`,
      okText: 'Yes',
      cancelText: 'No',
      onOk() {
        const { deleteRole } = instance.props;
        deleteRole({ _id });
      },
      onCancel() {
      },
    });
  }

  gridReady = (params) => {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
  }

  columnDefinitions = [{
    headerName: '',
    field: '',
    menuTabs: [],
    pinned: true,
    width: 40,
    checkboxSelection: true,
    headerCheckboxSelection: true,
    sortable: false,
  }, {
    headerName: 'Role Name',
    field: 'role',
    width: 150,
    resizable: true,
    sortable: true,
  }, {
    headerName: 'Resource Permitted',
    field: 'resource',
    width: 240,
    resizable: true,
    sortable: true,
  }, {
    headerName: 'Permitted Actions',
    field: 'action',
    width: 240
  }, {
    headerName: 'Possession',
    field: 'possession',
    width: 240
  }, {
    headerName: 'Actions',
    width: 250,
    pinned: 'right',
    cellRendererFramework: (params) => {
      return (
        <div style={{textAlign:'center'}}>
          <Button style={{ marginRight: '10px' }} size='small' onClick={(e) => this.handleDelete(e, params)} > Delete User </Button>
        </div>
      );
    }
  }];

  render() {
    const { roles } = this.props.role;
    return (
      <div style={{ height: 'calc(100% - 52px)' }}>
        <div className='ag-theme-balham' style={{ height: 'calc(100% - 32px)', padding: 10 }}>
          <AgGridReact
            reactNext={true}
            onGridReady={this.gridReady}
            rowSelection='multiple'
            deltaRowDataMode={true}
            animateRows={true}
            columnDefs={this.columnDefinitions}
            rowData={roles}
            rowHeight={30}
            getRowNodeId={({ _id }) => _id}
            pagination={false}
            suppressRowClickSelection={true}
            suppressPaginationPanel={true}
            suppressScrollOnNewData={true}
            singleClickEdit={true}
            sideBar={sideBarDef}
          />
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ role }) => ({ role });
const mapDispatchToProps = dispatch => ({
  getRoles: () => dispatch(getRoles()),
  deleteRole: (id) => dispatch(deleteRole(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(RoleGrid)
