import React from 'react';
import {
  Input,
  Modal,
  Form,
  Button,
  Select
} from 'antd';
import { connect } from 'react-redux';

import { addRole } from '../../actions/role'

const { Option } = Select;

const ModalFormToAddAffilate = Form.create({ name: 'form_in_modal' })(
  class extends React.Component {

    handleSubmit = (e) => {
      e.preventDefault();
      let isReferrelCodeUnique = true;
      const { form } = this.props;
      const { roles } = this.props.role;

      form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          const { name, modules, grantType } = values;
          const { onCancel, addRole } = this.props;

          addRole({ name, modules, grantType });
          form.resetFields();
          onCancel();
        }
      });
    }

    render() {
      const { visible, onCancel, handleSubmit, form } = this.props;
      const { getFieldDecorator } = form;
      return (
        <Modal
          visible={visible}
          title="Want to Add Role"
          okText='Add Role'
          closable={false}
          footer={[
            <Button key="cancel" type="primary" onClick={onCancel}>
              Cancel
            </Button>,
            <Button key="submit" type="primary"  onClick={this.handleSubmit}>
              Ok
            </Button>
          ]}
        >
          <Form layout="vertical" onSubmit={handleSubmit}>
            <Form.Item >
                {getFieldDecorator('name', {
                rules: [{ required: true, message: 'Please input the Name of Role!' }],
                })(<Input placeholder="Name"/>)}
            </Form.Item>

            <Form.Item >
                {getFieldDecorator('modules', {
                rules: [{ required: true, message: 'Please select Modules' }],
                })(<Select mode="multiple"  placeholder="Modules">
                  <Option value="Dashboard">Dashboard</Option>
                  <Option value="Inventory">Inventory</Option>
                  <Option value="Payment">Payment</Option>
                  <Option value="MWS">MWS</Option>
                </Select>)}
            </Form.Item>

            <Form.Item>
                {getFieldDecorator('grantType', {
                rules: [{ required: true, message: 'Please select Grant type' }],
                })(<Select mode="multiple"  placeholder="Grants">
                  <Option value="read">Read</Option>
                  <Option value="update">Update</Option>
                </Select>)}
            </Form.Item>
          </Form>
        </Modal>
      );
    }
  }
);

const mapStateToProps = ({ users, role }) => ({
  users, role
});

const mapDispatchToProps = dispatch => ({
  addRole: (role) =>
    dispatch(addRole(role))
});

export default connect(mapStateToProps, mapDispatchToProps)(ModalFormToAddAffilate);
