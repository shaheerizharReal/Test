import React, { Component } from 'react';
import { Row, Col, Form, Button, Steps, Icon, Card, Select, Input, Divider } from 'antd';
import { connect } from 'react-redux';

import { InputField } from '../../components/form/Components.jsx';
import { resetUpdatedSuccessfully, updateMwsCredentials } from '../../actions/users';

const { Step } = Steps;
const { Option } = Select;
const { Group } = Input;
// const marketPlaces = [{
//   key: 'United States (US)',
//   value: 'ATVPDKIKX0DER'
// }, {
//   key: 'Canada (CA)',
//   value: 'A2EUQ1WTGCTBG2'
// }];

class MwsCredentialsForm extends Component {
  state = {
    visible: false,
    currentStep: 0
  };

  handleSubmit = (e) => {
    e.preventDefault();

    const { form, updateMwsCredentials, mws } = this.props;
    form.validateFields((err, values) => {
      if (!err) {
        const { authToken } = values;
        updateMwsCredentials({
          mws: {
            authToken,
            marketplaceId: 'ATVPDKIKX0DER',
            sellerId: (mws.sellerId || values.sellerId)
          }
        });
        this.setState({ currentStep: 0 });
      }
    });
  };

  showConnectedPrinterForm = () => {
    const { getFieldDecorator } = this.props.form;
    const { mws } = this.props;

    return (
      <Form layout="horizontal" onSubmit={this.handleSubmit}>
        <Row gutter={24}>
          <Col span={4}> </Col>
          <Col span={16}>
            {InputField({
              getFieldDecorator,
              label: 'Seller ID',
              name: 'sellerId',
              required: true,
              initialValue: mws.sellerId,
              disabled: !!mws.sellerId
            })}
          </Col>
        </Row>

        <Row gutter={24}>
          <Col span={4}> </Col>
          <Col span={16}>
            {InputField({
              getFieldDecorator,
              label: 'Auth Token',
              name: 'authToken',
              required: true,
              initialValue: mws.authToken,
              disabled: !!mws.sellerId
            })}
          </Col>
        </Row>

        {!mws.sellerId ? 
          <Row>
            <Col span={4}> </Col>
            <Col span={16}>
              <div style={{ textAlign: 'right', marginTop: '10px' }}>
                <Button type="primary" htmlType="submit">Sync MWS</Button>
              </div>
            </Col>
          </Row>
          : null
        }
      </Form>
    )
  }

  componentDidUpdate(prevProps) {
    if(this.props.updatedSuccessfully && !this.state.visible)
    {
      this.setState({
        visible: true
      });
    } else if (!this.props.updatedSuccessfully && this.state.visible) {
      this.setState({
        visible: false
      });
    }
  };

  getStepState = (stepNo) => {
    const { currentStep } = this.state;
    if(stepNo === currentStep) {
      return 'process'
    } else if (stepNo > currentStep) {
      return 'wait'
    } else if (stepNo < currentStep) {
      return 'finish'
    }
  }

  getStepBodyToShow = () => {
    const { currentStep } = this.state;
    if (currentStep === 0) {
      return (
        <div>
          <Row gutter={24}>
            <Col span={4}> </Col>
            <Col span={16}>
              <h3>Select Marketplace</h3>
              <p>Follow the steps in this simple setup guide to get started with our tools. It only takes 2 minutes and then it's done for good! Please note that only Amazon Professional Merchants can utilize email tools.</p>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={4}> </Col>
            <Col span={16}>
              <Select
                style={{ padding: '15px 0px', width: '120' }}
                defaultValue='amazonUS'
                disabled
              >
                <Option value='amazonUS'>Amazon US</Option>
              </Select>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col span={4}> </Col>
            <Col span={16}>
              <p>Now Click on the link below and sign in with your Seller Account then come back here and press Next Button.</p>
              <a target="_blank" href='https://sellercentral.amazon.com/gp/mws/registration/register.html?signInPageDisplayed=2&developerName=Replen%20Dashboard&devMWSAccountId=5406-0033-7133'>
                https://developer.amazonservices.com/gp/mws/registration/register.html
              </a>
            </Col>
          </Row>
        </div>
      );
    } else if (currentStep === 1) {
      return (
        <div>
          <Row gutter={24}>
            <Col span={4}> </Col>
            <Col span={16}>
              <p><b>1.</b> Click on the Next Button on the below View which opens up by clicking the link on the previous step. </p>
              <img
                src = {require('../../public/images/SellerCenterAccountGuide1.png')}
                alt = 'Seller Center Image 1'
                style = {{ padding: '15px 0px' }}
              />
              <Divider />
              <p><b>2.</b> Accept the license agreement then Click Next.</p>
              <img
                src = {require('../../public/images/SellerCenterAccountGuide2.png')}
                alt = 'Seller Center Image 1'
                style = {{ padding: '15px 0px' }}
              />
              <Divider />
              <p><b>3.</b> Enter the Seller ID and the MWS Auth Token in the appropriate fields.</p>
              <img
                src = {require('../../public/images/SellerCenterAccountGuide3.png')}
                alt = 'Seller Center Image 1'
                style = {{ padding: '15px 0px' }}
              />
            </Col>
          </Row>
        </div>
      );
    } else if (currentStep === 2) {
      return (
        <div>
          <Row gutter={24}>
            <Col span={4}> </Col>
            <Col span={16}>
              {this.showConnectedPrinterForm()}
            </Col>
          </Row>
        </div>
      );
    }
  }

  render() {
    const { currentStep } = this.state;
    return (
      <div style={{ height: 'calc(100% - 63px)' }}>
        <Card>
          <Steps>
              <Step status={this.getStepState(0)} title='MarketPlace' icon={<Icon type='shopping-cart' />} />
              <Step status={this.getStepState(1)} title='MWS Access' icon={<Icon type='lock' />} />
              <Step status={this.getStepState(2)} title='Register' icon={<Icon type='user-add' />} />
          </Steps>
        </Card>
        <Card
          bodyStyle={{ height: 'calc(100% - 166px)', overflow: 'auto' }}
        >
          {this.getStepBodyToShow()}
        </Card>
        <Card style={{ width: '100%' }} >
          <div style={{ float: 'right'}}>
            <Group compact>
              <Button
                icon = ''
                onClick = {() => this.setState({ currentStep: currentStep - 1 })}
                disabled = { currentStep === 0 ? true : false }
              >
                Previous
              </Button>
              <Button
                type='primary'
                onClick={() => this.setState({ currentStep: currentStep + 1 })}
                disabled = { currentStep === 2 ? true : false }
              >
                Next
              </Button>
            </Group>
          </div>
        </Card>
      </div>
    );
  }
}

const MwsCredentialsSettings = Form.create({ name: 'printer-form' })(MwsCredentialsForm);

const mapStateToProps = ({ user }) => ({
  mws: (user.mws || {}),
  fetching: user.fetching,
  updatedSuccessfully: user.updatedSuccessfully,
});

const mapDispatchToProps = (dispatch) => ({
  updateMwsCredentials: ({ mws }) => {
    dispatch(updateMwsCredentials({ mws }));
  },
  onResetUpdatedSuccessfully: () => dispatch(resetUpdatedSuccessfully()),
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(MwsCredentialsSettings)
