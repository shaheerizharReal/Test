import React, { Component } from 'react';
import { 
  Input,
  Row,
  Col,
  Button, 
  Spin, 
  Select,
  notification,
  Card,
  Alert
} from 'antd';
import { connect } from 'react-redux';

import { saveDefaultShippingRates, getDefaultShippingRate, saveCalculationChanges, getDefaultCalculationPrice } from '../../actions/users';

const { Option } = Select;

class UpdateShippingRate extends Component {
  state = {
    shippingRate: 0,
    shipBy: 'byItem',
    profitCalculatedBy: 'listPrice'
  }

  componentDidMount() {
    const {  getDefaultShippingRate, getDefaultCalculationPrice } = this.props;
    const { shipBy } = this.state;

    getDefaultShippingRate().then(({ payload }) => {
      const { fbaInboundShippingCost } = payload || {};
      const { shipBy, shippingRate } = fbaInboundShippingCost || {};
      if (fbaInboundShippingCost) {
        this.setState({
          shipBy,
          shippingRate
        });
      } else {
        this.setState({
          shipBy: 'byItem',
          shippingRate: 0
        });
      }
    });

    getDefaultCalculationPrice().then(({ payload }) => {
      const { profitCalculatedBy } = payload || {};
      if (profitCalculatedBy) {
        this.setState({
          profitCalculatedBy
        });
      }
    });
  }

  saveShippingRate = ({ target }) => {
    this.setState({ 
      shippingRate: target.value
    });
  }

  saveShippingData = ({ shipBy, shippingRate }) => {
    const { saveDefaultShippingRates } = this.props;
    const shippingRateValue = parseFloat(shippingRate);

    if (shippingRateValue > 0 ) {
      saveDefaultShippingRates({ shipBy, shippingRate: shippingRateValue });
    } else {
      notification.warning({
        message: 'INVALID SHIPPING RATE',
        description: 'Please enter a valid shipping rate !!'
      });
    }
  }

  saveCalculationData = ({ profitCalculatedBy }) => {
    const { saveCalculationChanges } = this.props;
    
    if (this.state.profitCalculatedBy === this.props.profitCalculatedBy) {
      notification.warning({
        message: 'Save Default Calculation Price',
        description: `You have already selected ${this.props.profitCalculatedBy} as default calculation price.`
      });
    } else {
      saveCalculationChanges({ profitCalculatedBy });
    }
  }

  render() {
    const { fetching } = this.props;
    const { shipBy, shippingRate, profitCalculatedBy } = this.state;
    return (
      <div style={{ marginTop: '20px' }}>
        <Spin tip='Loading...' spinning={fetching}>
          <Card>
            <Row>
              <Col span={12} offset={6}>
                <Select
                  value={shipBy}
                  style={{ width: '210px', marginBottom: '20px' }}
                  onChange={(value) => this.setState({ shipBy: value })}
                >
                  <Option key='1' value='byItem'>By Item Shipping Rate</Option>
                  <Option key='2' value='byWeight'>By Weight Shipping Rate</Option>
                </Select>
                <Input value={shippingRate} onChange={this.saveShippingRate} addonAfter={shipBy === 'byItem' ? 'Per Item' : (shipBy === 'byWeight' && 'Per Pound')}/>
              </Col>
            </Row>
            <Row>
              <Col style={{ textAlign: 'center', marginTop: '10px' }}>
                <Button onClick={() => this.saveShippingData({ shipBy, shippingRate })} type='primary'>Save</Button>
              </Col>
            </Row>
          </Card>

          <Card>
            <Row>
              <Col style={{ textAlign: 'center', marginTop: '10px' }}>
                <h3 style={{ marginBottom: '10px' }}>Choose Price to calculate Gross Profit, Net Profit, Profit Percentage and ROI percentage (By default its Sale Price)</h3>
                <Select
                  value={profitCalculatedBy}
                  style={{ width: '210px', marginBottom: '20px' }}
                  onChange={(value) => this.setState({ profitCalculatedBy: value })}
                >
                  <Option key='1' value='listPrice'>Sale Price</Option>
                  <Option key='2' value='buyBoxPrice'>Buybox Price</Option>
                  <Option key='3' value='lowestFBAOfferPrice'>Lowest FBA Offer Price</Option>
                  <Option key='4' value='lowestOfferPrice'>Lowest Offer Price</Option>
                </Select>
                <Button onClick={() => this.saveCalculationData({ profitCalculatedBy })} type='primary'>Update Calculations</Button>
              </Col>
            </Row>

            <Row>
              <Col span={12} offset={6}>
                <Alert
                  message='If you Choose any of Buybox Price, Lowest FBA Price or Lowest Offer Price (for Calculations of Gross Profit, Net Profit, Profit Percentage and ROI percentage) and your choosen price does not exists for product(s) then it is obvious that system will use sale price for calculations'
                  type='info'
                  showIcon
                />
              </Col>
            </Row>
          </Card>
        </Spin>
      </div>
    );
  }
}

const mapStateToProps = ({ user }) => user;

const mapDispatchToProps = (dispatch) => ({
  saveDefaultShippingRates: (shippingRateData) => {
    dispatch(saveDefaultShippingRates(shippingRateData));
  },
  saveCalculationChanges: (calculationData) => {
    dispatch(saveCalculationChanges(calculationData));
  },
  getDefaultShippingRate: () => dispatch(getDefaultShippingRate()),
  getDefaultCalculationPrice: () => dispatch(getDefaultCalculationPrice())
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(UpdateShippingRate);
