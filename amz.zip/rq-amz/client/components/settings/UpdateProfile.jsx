import React, { Component } from 'react';
import { Input, Row, Col, Form, Button } from 'antd';
import { connect } from 'react-redux';

import { updateUserPassword } from '../../actions/users';

class UpdateProfileForm extends Component {
  handleSubmit = e =>{
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        const {oldPassword, newPassword, repeatPassword} = values;
        const { updatePassword } = this.props;
        if (newPassword === repeatPassword){
          updatePassword(oldPassword, newPassword);
        }
      }
    });
  }

  hasErrors = (fieldsError) => {
    return Object.keys(fieldsError).some(field => fieldsError[field]);
  }
  compareToRepeatPassword = (rules, value, callback) => {
    const { form } = this.props;
    const { setFields, getFieldsError } = this.props.form;
    if (value && value !== form.getFieldValue('repeatPassword')) {
      callback('Two passwords that you enter are inconsistent!');
    } else {
      setFields({
        repeatPassword: {
          value: form.getFieldValue('repeatPassword'),
          errors: null
        },
      });
      callback();
    }
  }

  compareToNewPassword = (rules, value, callback) => {
    const { form } = this.props;
    const { setFields, getFieldsError } = this.props.form;
    if (value && value !== form.getFieldValue('newPassword')) {
      callback('Two passwords that you enter are inconsistent!');
    } else {
      setFields({
        newPassword: {
          value: form.getFieldValue('newPassword'),
          errors: null
        },
      });
      callback();
    }
  }

  render() {
    const { getFieldDecorator, getFieldsError } = this.props.form;
    return (
      <div>
        <Form onSubmit={this.handleSubmit}>
          <Row style={{ marginTop: 25 }} gutter={24}>
            
            <Col span={24}>
              <center>
                <Form.Item>
                  {getFieldDecorator('oldPassword', {
                    rules: [{ required: true, message: 'Please input your old password!' }],
                  })(
                    <Input
                      autoComplete='oldPassword'  
                      style={{ width: 500 }}
                      type="password"
                      placeholder="Old password"
                    />,
                  )}
                </Form.Item>
              </center>
            </Col>
            
          </Row>
          <Row style={{ marginTop: 25 }} gutter={24}>
            <Col span={24}>
              <center>
                <Form.Item>
                  {getFieldDecorator('newPassword', {
                    rules: [{ 
                      required: true, message: 'Please input your new password!' 
                    },{
                      validator: this.compareToRepeatPassword,
                    }],
                  })(
                    <Input
                      autoComplete='newPassword'
                      style={{ width: 500 }}
                      type="password"
                      placeholder="New password"
                    />,
                  )}
                </Form.Item>
              </center>
            </Col>
          </Row>
          <Row style={{ marginTop: 25 }} gutter={24}>
            <Col span={24}>
              <center>
                <Form.Item>
                  {getFieldDecorator('repeatPassword', {
                    rules: [{ 
                      required: true, message: 'Please repeat your new password!' 
                    },{
                      validator: this.compareToNewPassword,
                    }],
                  })(
                    <Input
                      autoComplete='repeatPassword'
                      style={{ width: 500 }}
                      type="password"
                      placeholder="Repeat password"
                    />,
                  )}
                </Form.Item>
              </center>
            </Col>
          </Row>

          <Row style={{ marginTop: 25 }} gutter={24}>
            <Col span={24}>
              <center>
                <Form.Item>
                  <Button type="primary" htmlType="submit" disabled={this.hasErrors(getFieldsError())}>
                    Update password
                  </Button>
                </Form.Item>
              </center>
            </Col>

          </Row>
        </Form>
      </div>
    );
  }
}

const WrappedResetPasswordForm = Form.create()(UpdateProfileForm);


const mapDispatchToProps = (dispatch) => ({
  updatePassword: (oldPassword, newPassword) => {
    dispatch(updateUserPassword(oldPassword, newPassword));
  },
});

export default connect(null, mapDispatchToProps, null, { forwardRef: true })(WrappedResetPasswordForm);
