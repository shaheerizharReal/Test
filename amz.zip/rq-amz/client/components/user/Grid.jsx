import React from 'react';
import moment from 'moment';
import {
  Button,
  Icon,
  Pagination,
  Modal,
  Spin
} from 'antd';
import { AgGridReact } from 'ag-grid-react';
import { connect } from 'react-redux';
import { find } from 'lodash';

const { confirm } = Modal;  

// import DatePicker from '../ag-grid/DatePicker.jsx';
import {
  resetUserFilters,
  getUsers,
  setPage,
  setPageSize,
  setFilters,
  setSortFilters,
  impersonate,
  setUserStatus,
  deleteUsers,
  setUserReferralCode,
  setUserSignedUpDate
} from '../../actions/users';
import { VALID_STATUS_OF_USER } from '../../../config/constants';
import './Grid.less';

const sideBarDef = {
  toolPanels: [{
    id: 'columns',
    labelDefault: 'Columns',
    labelKey: 'columns',
    iconKey: 'columns',
    toolPanel: 'agColumnsToolPanel',
    toolPanelParams: {
      suppressPivots: true,
      suppressPivotMode: true,
      suppressValues: true
    }
  }, {
    id: 'filters',
    labelDefault: 'Filters',
    labelKey: 'filters',
    iconKey: 'filter',
    toolPanel: 'agFiltersToolPanel'
  }]
};

let rowNodeToBeRemembered;

class UserGrid extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      referralCodesLength: 0,
    };
  }

  componentDidMount() {
    const { resetAllFilters, getUsers } = this.props;
    resetAllFilters();
    getUsers();
  }

  gridReady = (params) => {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;

    // Update ReferralCodes
    if (this.props.referralCodes && this.props.referralCodes.length > 0) {
      const { referralCodes } = this.props;
      const referralCodeFilterComp = this.gridApi.getFilterInstance('referralCode');
      referralCodeFilterComp.setFilterValues(referralCodes, false, false, []);
      this.state.referralCodesLength = referralCodes.length;
    }

    const statusFilterComp = this.gridApi.getFilterInstance("status");
    statusFilterComp.selectNothing();
    statusFilterComp.selectValue('Active');
    statusFilterComp.selectValue('Trial');
    statusFilterComp.selectValue('Trial Expire');
    statusFilterComp.selectValue('Free');
    statusFilterComp.onFilterChanged();
  }

  handleImpersonate = (e, userId) => {
    e.preventDefault();

    const { impersonate } = this.props;
    impersonate(userId);
  }

  handleDelete = (e, params) => {
    e.preventDefault();
    const { name, _id: userId, status } = params.data;

    const instance = this;
    confirm({
      title: 'Change Status',
      content: `Do you really want to delete User ${name}?`,
      okText: 'Yes',
      cancelText: 'No',
      onOk() {
        // save node
        rowNodeToBeRemembered = params.node;

        const { deleteUsers } = instance.props;
        deleteUsers({ userId, status });
      },
      onCancel() {
      },
    });
  }

  userStatusSetter = (params) => {
    const { _id, name } = params.data;
    let { newValue, oldValue } = params;
    if (newValue !== oldValue) {
      const instance = this;
      confirm({
        title: 'Change Status',
        content: `Do you really want to change ${name}'s status ?`,
        okText: 'Yes',
        cancelText: 'No',
        onOk() {
          // save node
          rowNodeToBeRemembered = params.node;

          const { setUserStatus } = instance.props;
          setUserStatus({ _id, status: newValue });
        },
        onCancel() {
        },
      });
    }
  }
  
  referralCodeSetter = (params) => {
    const { _id, name } = params.data;
    let { newValue, oldValue } = params;
    
    if (newValue !== oldValue) {
      const instance = this;
      confirm({
        title: 'Change Referral Code',
        content: `Do you really want to change ${name}'s Referral Code?`,
        okText: 'Yes',
        cancelText: 'No',
        onOk() {
          // save node
          rowNodeToBeRemembered = params.node;

          newValue = newValue ? newValue.trim() : '';
          const { setUserReferralCode } = instance.props;
          setUserReferralCode({ _id, referralCode: newValue });
        },
        onCancel() {
        },
      });
    };
  }
  
  signedUpDateSetter = (params) => {
    const { _id } = params.data;
    const { oldValue, newValue } = params;
    const newUpdatedDate = moment(newValue).format('LL');
    const oldDate = moment(oldValue).format('LL');

    if (newValue && newUpdatedDate !== oldDate) {
      // save node
      rowNodeToBeRemembered = params.node;

      const { setUserSignedUpDate } = this.props;
      setUserSignedUpDate({ _id, signedUp: newUpdatedDate });

      return true;
    } else if (oldValue && newValue && newUpdatedDate === oldDate) {
      const rowNode = params.node;
      this.gridApi.redrawRows({
        rowNodes: [rowNode]
      });

      return true;
    }

    return false;
  }

  componentDidUpdate(prevProps) {
    if (!this.props.fetching && this.gridApi) {
      if (this.props.users && this.props.users.length > 0) {
        // Update node of saved product
        if (rowNodeToBeRemembered) {
          const { email } = rowNodeToBeRemembered.data;
          const user = find(this.props.users, { email });
          rowNodeToBeRemembered.data = user;
          this.gridApi.redrawRows({
            rowNodes: [rowNodeToBeRemembered]
          });

          rowNodeToBeRemembered = undefined;
        }
      }
      
      // Update ReferralCodes
      if (this.props.referralCodes && this.props.referralCodes.length !== this.state.referralCodesLength) {
        const { referralCodes } = this.props;
        const referralCodeFilterComp = this.gridApi.getFilterInstance('referralCode');
        referralCodeFilterComp.setFilterValues(referralCodes, false, false, []);
        this.state.referralCodesLength = referralCodes.length;
      }
    }
  }

  columnDefinitions = [{
    headerName: '',
    field: '',
    menuTabs: [],
    pinned: true,
    width: 40,
    checkboxSelection: true,
    headerCheckboxSelection: true,
    sortable: false,
  }, {
    headerName: 'Name',
    field: 'name',
    width: 150,
    resizable: true,
    sortable: true,
  }, {
    headerName: 'Status',
    field: 'status',
    width: 130,
    filter: true,
    filterParams: {
      values: VALID_STATUS_OF_USER,
      cellHeight: 20,
      newRowsAction: 'keep'
    },
    editable: true,
    cellEditor: 'agRichSelectCellEditor',
    cellEditorParams: {
      values: VALID_STATUS_OF_USER
    },
    valueSetter: this.userStatusSetter,
    cellRendererFramework: ({ value }) => {
      return (
        <div>
          <Icon type='edit' style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '15px' }} />
          {value}
        </div>
      );
    }
  }, {
    headerName: 'Email',
    field: 'email',
    width: 240
  }, {
    headerName: 'Referral Code',
    field: 'referralCode',
    width: 150,
    filter: true,
    filterParams: {
      cellHeight: 20,
    },
    editable: true,
    valueSetter: this.referralCodeSetter,
    cellRendererFramework: ({ value }) => {
      return (
        <div>
          <Icon type='edit' style={{ float: 'left', fontSize: '16px', marginTop: '5px', paddingRight: '15px' }} />
          {value}
        </div>
      );
    }
  }, {
    headerName: 'Signed Up At',
    field: 'signedUp',
    width: 200,
    sortable: true,
    // editable: true,
    // cellRendererFramework: DatePicker,
    // valueSetter: this.signedUpDateSetter,
    cellRenderer: ({ value }) => {
      return moment(value).format('LL')
    }
  }, {
    headerName: 'Subscribed At',
    field: 'payment.subscribedAt',
    width: 150,
    sortable: true,
    cellRenderer: ({ value }) => {
      return moment(value).format('LL')
    }
  },{
    headerName: 'TierNo',
    field: 'payment.tierNo',
    width: 85,
    sortable: true,
    cellRenderer: ({ value }) => {
      return value || value === 0 ? value : 'N/A' 
    }
  },{
    headerName: 'No of Active Products',
    field: 'noOfActiveProducts',
    width: 170,
    sortable: true,
    cellRenderer: ({ value }) => {
      return value || value === 0 ? value : 'N/A' 
    }
  }, {
    headerName: 'MWS Synced',
    field: 'mwsSynced',
    hide: true,
    sortable: false,
    filter: true,
    filterParams: {
      values: ['Yes', 'No'],
      cellHeight: 20,
      newRowsAction: 'keep'
    },
  }, {
    headerName: 'Actions',
    width: 250,
    pinned: 'right',
    cellRendererFramework: (params) => {
      const { _id } = params.data;

      return (
        <div style={{textAlign:'center'}}>
          <Button style={{ marginRight: '10px' }} size='small' onClick={(e) => this.handleImpersonate(e, _id)} > Impersonate </Button>
          <Button style={{ marginRight: '10px' }} size='small' onClick={(e) => this.handleDelete(e, params)} > Delete User </Button>
        </div>
      );
    }
  }];

  getRowStyle = (params) => {
    const { noOfActiveProducts, payment } = params.data;
    if (payment && payment.tierNo === 0 && noOfActiveProducts > 400) {
      return { background: '#eabbbb' };
    } else if (payment && payment.tierNo === 1 && (!(noOfActiveProducts > 400 && noOfActiveProducts <= 1000))) {
      return { background: '#eabbbb' };
    } else if (payment && payment.tierNo === 2 && (!(noOfActiveProducts > 1000))) {
      return { background: '#eabbbb' };
    }
    return { background: 'white' };
  };

  render() {
    const { pagination, onPageChange, onPageSizeChange, total, users, setSortingFilter, handleFilterChanged, fetching } = this.props;
    return (
      <div style={{ height: 'calc(100% - 52px)' }}>
        <Spin tip='Loading...' spinning={fetching}>
          <div className='ag-theme-balham' style={{ height: 'calc(100% - 32px)', padding: 10 }}>
            <AgGridReact
              reactNext={true}
              onGridReady={this.gridReady}
              rowSelection='multiple'
              getRowStyle={this.getRowStyle}
              deltaRowDataMode={true}
              animateRows={true}
              columnDefs={this.columnDefinitions}
              rowData={users}
              rowHeight={30}
              getRowNodeId={({ _id }) => _id}
              pagination={false}
              suppressRowClickSelection={true}
              suppressPaginationPanel={true}
              suppressScrollOnNewData={true}
              onSortChanged={setSortingFilter}
              onFilterChanged={handleFilterChanged}
              singleClickEdit={true}
              sideBar={sideBarDef}
            />
          </div>
        </Spin>
        <div style={{ float: 'right' }}>
          <Pagination
            current={pagination.pageNumber}
            defaultPageSize={pagination.pageSize ? pagination.pageSize : 25}
            pageSizeOptions={['25', '50', '100']}
            showSizeChanger
            onShowSizeChange={onPageSizeChange}
            showQuickJumper
            defaultCurrent={1}
            total={total}
            onChange={onPageChange}
            showTotal={(total, range) => `${range[0]}-${range[1]} of ${total} items`}
          />
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ users }) => users;
const mapDispatchToProps = dispatch => ({
  getUsers: () => dispatch(getUsers()),
  onPageChange: (pageNumber) => {
    dispatch(setPage(pageNumber));
    dispatch(getUsers())
  },
  resetAllFilters: () => { dispatch(resetUserFilters()) },
  onPageSizeChange: (current, pageSize) => {
    dispatch(setPage(1));
    dispatch(setPageSize(pageSize));
    dispatch(getUsers());
  },
  setSortingFilter: (params) => {
    const sort = params.api.getSortModel();
    let sortOptions = {};
    if (sort.length > 0){
      sort.forEach(({ colId, sort }) => {
        sortOptions = {
          ...sortOptions,
          [colId]: sort
        }
      });
    }
    dispatch(setSortFilters(sortOptions));
    dispatch(getUsers());
  },
  handleFilterChanged: (params) => {
    const filter = params.api.getFilterModel();
    dispatch(setFilters(filter));
    dispatch(setPage(1));
    dispatch(getUsers());
  },
  setUserStatus: (user) => dispatch(setUserStatus(user)),
  setUserReferralCode: (data) => dispatch(setUserReferralCode(data)),
  setUserSignedUpDate: (user) => dispatch(setUserSignedUpDate(user)),
  impersonate: (userId) => {
    return dispatch(impersonate(userId));
  },
  deleteUsers: (params) => dispatch(deleteUsers(params))
});

export default connect(mapStateToProps, mapDispatchToProps)(UserGrid)
