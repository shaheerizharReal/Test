import React from 'react';
import { Layout, Menu, Icon } from 'antd';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { withRouter } from 'react-router'

import { logoutUser } from '../actions/users';
import '../public/images/replen-dashboard_logo.svg';

const { Content, Sider } = Layout;
const SubMenu = Menu.SubMenu;

class AdminLayout extends React.Component {
  state = {
    collapsed: false,
  };

  onCollapse = (collapsed) => {
    this.setState({ collapsed });
    localStorage.setItem('isSideBarCollapsed', collapsed);
  }

  logout = () => {
    const { logoutUser } = this.props;
    logoutUser();
    this.props.history.push('/auth/login');
  }

  getMenuKey = () => {
    const { location } = this.props.children.props;
    if (location.pathname === '/admin/users') {
      return '1';
    }
    else if (location.pathname === '/admin/jobs') {
      return '2';
    }
    else if (location.pathname === '/admin/affiliates') {
      return '3';
    }

    return '1';
  };

  render() {
    const { user, children } = this.props;

    return (
      <Layout style={{ height: '100vh' }}>
        <Sider
          collapsible
          collapsed={localStorage.getItem('isSideBarCollapsed') == "true"}
          onCollapse={this.onCollapse}
        >
          <div className="app-layout-logo" style={{ height: '64px', margin: '0px' }}>
            <img style={{ height: '100%', width: '100%' }} src="/images/replen-dashboard_logo.svg" />
          </div>
          <Menu theme="dark" selectedKeys={[this.getMenuKey()]} mode="inline">
            <SubMenu key="sub0" title={<span><Icon type="user" /><span>{user.name}</span></span>}>
              <Menu.Item key="0" onClick={this.logout}>Logout</Menu.Item>
            </SubMenu>
            <Menu.Item key="1">
              <Link to="/admin/users">
                <Icon type="table" />
                <span>Users</span>
              </Link>
            </Menu.Item>
            <Menu.Item key="2">
              <Link to="/admin/jobs">
                <Icon type="table" />
                <span>Agenda Jobs</span>
              </Link>
            </Menu.Item>
            <Menu.Item key="3">
              <Link to="/admin/affiliates">
                <Icon type="table" />
                <span>Affiliates</span>
              </Link>
            </Menu.Item>
          </Menu>
        </Sider>
        <Layout>
          <Content>
            { children }
          </Content>
        </Layout>
      </Layout>
    );
  }
}

const mapStateToProps = ({ user }) => ({ user });

const mapDispatchToProps = (dispatch) => ({
  logoutUser: () => {
    return dispatch(logoutUser());
  }
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(withRouter(AdminLayout));
