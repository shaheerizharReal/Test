import React from 'react';
import { Layout, Menu, Icon } from 'antd';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

import { logoutUser, resetUser } from '../actions/users';
import { resetStateOfInventory } from '../actions/inventory';
import { resetStateOfDashboard } from '../actions/dashboard';
import AccessControl from 'accesscontrol';

import '../public/images/replen-dashboard_logo.svg';
import './AppLayout.less';

const { Content, Sider } = Layout;
const SubMenu = Menu.SubMenu;

class AppLayout extends React.Component {
  state = {
    collapsed: false,
    openKey: []
  };

  componentDidMount = () => {
    if (this.isSubMenuItemClicked()) {
      this.setState({ openKey: ['sub1']});
    }
  }

  onCollapse = (collapsed) => {
    this.setState({ collapsed });
    localStorage.setItem('isSideBarCollapsed', collapsed);
  }

  logout = () => {
    const { logoutUser } = this.props;
    logoutUser();
  }

  openMail = () => {
    window.location.href = 'mailto:support@replendashboard.com?cc=ibrahim@qbatch.com,syed.bilal@qbatch.com,waqas.sarwar@qbatch.com';
  }

  endImpersonate = () => {
    const { resetUser } = this.props;
    resetUser();
  }

  subMenuOpenKeys = (openIt) => {
    this.setState({ openKey: [openIt]});
  }

  showMenu = (val) => {
    const { user } = this.props;

    const adminToken = localStorage.getItem('adminToken');
    const ac = new AccessControl(this.props.user.roles);
    const permissionControl = ac.can(this.props.user.permission.role).readAny('Inventory');
    const { attributes } = permissionControl;

    return <Menu theme="dark" selectedKeys={[this.getMenuKey()]} openKeys={this.state.openKey} mode="inline">
      <SubMenu key="sub0" onTitleClick={(e) => this.subMenuOpenKeys('sub0')} title={<span><Icon type="user" /><span>{user.name}</span></span>}>
        { adminToken
          ? (<Menu.Item key="10" onClick={this.endImpersonate}>End Impersonatation</Menu.Item>)
          : (<Menu.Item key="11" onClick={this.openMail}>Get Help!</Menu.Item>)
        }
        <Menu.Item key="0" onClick={this.logout}>Logout</Menu.Item>
      </SubMenu>
      { (ac.can(this.props.user.permission.role).readAny('Whats New').granted) ?
          <Menu.Item key="8" onClick={(e) => this.subMenuOpenKeys(null)}>
            <Link to="/whats-new">
              <Icon type="table" />
              <span>What's New</span>
            </Link>
          </Menu.Item> : null
        }
      { (ac.can(this.props.user.permission.role).readAny('Dashboard').granted) ?
          <Menu.Item key="1" onClick={(e) => this.subMenuOpenKeys(null)}>
            <Link to="/dashboard">
              <Icon type="dashboard" />
              <span>Dashboard</span>
            </Link>
          </Menu.Item> : null
        }
        { (permissionControl.granted) ?
          <Menu.Item key="2" onClick={(e) => this.subMenuOpenKeys(null)}>
            <Link to="/inventory">
              <Icon type="table" />
              <span>Inventory</span>
            </Link>
          </Menu.Item> : null
        }
        { (ac.can(this.props.user.permission.role).readAny('Payment').granted) ?
        <Menu.Item key="5" onClick={(e) => this.subMenuOpenKeys(null)}>
          <Link to="/payment">
            <Icon type="table" />
            <span>Payment</span>
          </Link>
        </Menu.Item> : null
      }
      { (ac.can(this.props.user.permission.role).readAny('Invite User').granted) ?
        <Menu.Item key="7" onClick={(e) => this.subMenuOpenKeys(null)}>
          <Link to="/invite-user">
            <Icon type="table" />
            <span>Invite User</span>
          </Link>
        </Menu.Item> : null
      }
      <SubMenu key="sub1" onTitleClick={(e) => this.subMenuOpenKeys('sub1')} title={<span><Icon type="setting" /><span>Settings</span></span>}>
        <Menu.Item key="3">
          <Link to="/settings/updateProfile">
            Account
          </Link>
        </Menu.Item>
        <Menu.Item key="12">
          <Link to="/settings/updateShippingRate">
            Profit
          </Link>
        </Menu.Item>
        { (ac.can(this.props.user.permission.role).readAny('MWS').granted) ?
          <Menu.Item key="4">
            <Link to="/settings/mws">
              MWS
            </Link>
          </Menu.Item> : null
        }
        { (permissionControl.granted && (attributes.includes('*') || attributes.includes('asinShortcut'))) ?
          <Menu.Item key="9">
            <Link to="/settings/custom-asin-shortcut">
              <span>Custom Asin Shortcut</span>
            </Link>
          </Menu.Item> : null
        }
      </SubMenu>
    </Menu>;
  };

  getMenuKey = () => {
    const { location } = this.props.children.props;
    if (location.pathname === '/') {
      return '1';
    } else if (location.pathname === '/inventory') {
      return '2';
    } else if (location.pathname === '/settings/updateProfile') {
      return '3';
    } else if (location.pathname === '/settings/mws') {
      return '4';
    } else if (location.pathname === '/payment') {
      return '5';
    } else if (location.pathname === '/role') {
      return '6';
    } else if (location.pathname === '/invite-user') {
      return '7';
    } else if (location.pathname === '/whats-new') {
      return '8';
    } else if (location.pathname === '/settings/custom-asin-shortcut') {
      return '9';
    } else if (location.pathname === '/settings/updateShippingRate') {
      return '12';
    }

    return '1';
  };

  isSubMenuItemClicked = () => {
    const { location } = this.props.children.props;
    if (location.pathname === '/settings/updateProfile' || location.pathname === '/settings/mws' || location.pathname === '/settings/custom-asin-shortcut' || location.pathname === '/settings/updateShippingRate') {
      return true
    }

    return false;
  };

  render() {
    const { children } = this.props;

    return (
      <Layout style={{ height: '100vh' }}>
        <Sider
          collapsible
          collapsed={localStorage.getItem('isSideBarCollapsed') == "true"}
          onCollapse={this.onCollapse}
        >
          <div className="app-layout-logo" style={{ height: '64px', margin: '0px' }}>
            <a href='https://replendashboard.com/'>
              <img style={{ height: '100%', width: '100%' }} src="/images/replen-dashboard_logo.svg" />
            </a>
          </div>
          {(this.props.user && this.props.user.permission) ? this.showMenu(this.isSubMenuItemClicked()) : null}
        </Sider>
        <Layout>
          <Content>
            { children }
          </Content>
        </Layout>
      </Layout>
    );
  }
}

const mapStateToProps = ({ user }) => ({ user });

const mapDispatchToProps = (dispatch) => ({
  logoutUser: () => {
    dispatch(resetStateOfDashboard());
    dispatch(resetStateOfInventory());
    return dispatch(logoutUser());
  },
  resetUser: () => {
    dispatch(resetStateOfDashboard());
    dispatch(resetStateOfInventory());
    return dispatch(resetUser());
  }
});

export default connect(mapStateToProps, mapDispatchToProps, null, { forwardRef: true })(AppLayout);
