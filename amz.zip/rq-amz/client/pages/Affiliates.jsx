import React from 'react';
import {
  PageHeader,
  Icon,
  Button,
  Modal,
  notification
} from 'antd';
import { connect } from 'react-redux';

import { getUsers, setPage, setFilters } from '../actions/users';
import { getExportDetails, deleteAffiliates } from '../actions/affiliate';

import AffiliateGrid from '../components/affiliates/Grid.jsx';
import ModalFormToAddAffilate from '../components/affiliates/ModalFormToAddAffilate.jsx';
import './Inventory.less';

const { confirm } = Modal;

class Affiliates extends React.Component {
  state = { 
    visible: false
  };

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  deleteSelectedAffiliates = e => {
    const { delAffiliates } = this.props.affiliate;
    const instance = this;

    if (delAffiliates.length > 0) {
      confirm({
        title: 'Delete Affiliates',
        content: `Do you really want to Delete these Affiliates ?`,
        okText: 'Yes',
        cancelText: 'No',
        onOk() {
          const { deleteAffiliates } = instance.props;

          deleteAffiliates({delAffiliates})
        },
        onCancel() {
        },
      });
    } else {
      notification.error({
        message: 'Delete Affiliates',
        description: 'Kindly Select Affiliates to Delete'
      });
    }
  };

  handleCancel = e => {
    this.setState({
      visible: false,
    });
  };


  render() {
    const { getExportDetails } = this.props;

    return (
      <div style={{ height: '100%' }}>
        <PageHeader
          title="Affiliates"
          extra={[
            <Icon key='1' type="user-add" onClick={this.showModal} style={{ fontSize: '30px', margin: '10px 30px 0 0' }} />,
            <Button key="2" onClick={() => getExportDetails()} style={{ width:80, margin: '5px 20px 0 0' }} size='small'>
              <Icon type="export" /> Export
            </Button>,
            // <Button key="3" onClick={() => this.deleteSelectedAffiliates()} style={{ width:80, margin: '5px 20px 0 0' }} size='small'>
            //   <Icon type="delete" />
            // </Button>
          ]}
        />
        
        <AffiliateGrid />

        <ModalFormToAddAffilate
          wrappedComponentRef={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
        />

      </div>
    );
  }
};

const mapStateToProps = ({ affiliate }) => ({ affiliate });

const mapDispatchToProps = (dispatch, getState) => ({
  getUsers: () => dispatch(getUsers()),
  getExportDetails: () => dispatch(getExportDetails()),
  deleteAffiliates: (data) => dispatch(deleteAffiliates(data)),
  onSearchFilterChange: (event) => {
    const keyword = event.target.value;

    const filter = {
      keyword: {
        value: keyword,
        filterType: 'text'
      }
    };

    dispatch(setFilters(filter))
    dispatch(setPage(1));;
    dispatch(getUsers());
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(Affiliates)
