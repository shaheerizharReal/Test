import React from 'react';
import {
  PageHeader,
  Icon
} from 'antd';

import ShortcutsGrid from '../components/custom-asin-shortcut/Grid.jsx';
import AddShortcutModal from '../components/custom-asin-shortcut/AddShortcutModal.jsx';

class CustomAsinShortcut extends React.Component {
  state = { 
    visible: false
  };

  showModal = () => {
    this.setState({
      visible: true
    });
  };

  handleCancel = e => {
    this.setState({
      visible: false
    });
  };

  render() {
    return (
      <div style={{ height: '100%' }}>
        <PageHeader
          title="Custom ASIN Shortcut"
          extra={[
            <Icon key='1' type="plus" onClick={() => this.showModal()} style={{ fontSize: '30px', margin: '10px 30px 0 0' }} />
          ]}
        />
        <ShortcutsGrid />

        <AddShortcutModal
          visible={this.state.visible}
          onCancel={this.handleCancel}
        />
      </div>
    );
  };
};

export default CustomAsinShortcut;
