import React from 'react';
import {
  PageHeader
} from 'antd';
import { connect } from 'react-redux';

import { getSales } from '../actions/dashboard';
import SalesHeader from '../components/dashboard/SalesHeader.jsx';

import './Dashboard.less';

class Dashboard extends React.Component {
  componentDidMount() {
    const { getSales } = this.props;
    getSales();
  };

  render() {
    return (
      <div style={{ height: '100%' }}>
        <PageHeader
          title="Dashboard"
        />
        <SalesHeader />
      </div>
    );
  };
};

const mapStateToProps = ({ dashboard }) => dashboard;

const mapDispatchToProps = dispatch => ({
  getSales: () => dispatch(getSales())
});

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
