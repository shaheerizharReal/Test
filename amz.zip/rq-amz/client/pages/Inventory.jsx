import React from 'react';
import { PageHeader, Input, Button, Icon, Modal, notification } from 'antd';
import { connect } from 'react-redux';
import AccessControl from 'accesscontrol';

import {
  getProducts,
  setPage,
  setFilters,
  importProducts,
  resetImportProducts,
  resetAllDecidedBuyQuantites,
  exportProducts,
  setToReplen
} from '../actions/inventory';
import { getColumnsWanted } from '../actions/users'
import ImportInventoryDrawer from '../components/inventory/ImportInventoryDrawer.jsx';
import ExportInventoryDrawer from '../components/inventory/ExportInventoryDrawer.jsx';
import InventoryGrid from '../components/inventory/Grid.jsx';

import './Inventory.less';

const { confirm } = Modal;  

let headerExtra = [];

class Inventory extends React.Component {
  state = {
    visibleImportDrawer: false,
    visibleExportDrawer: false
  };

  showImportDrawer = () => {
    this.setState({
      visibleImportDrawer: true
    });
  };

  closeImportDrawer = () => {
    this.setState({
      visibleImportDrawer: false
    });
  };
  
  showExportDrawer = () => {
    this.setState({
      visibleExportDrawer: true
    });
  };

  closeExportDrawer = isExport => {
    this.setState({
      visibleExportDrawer: false
    });

    if (isExport) {
      const { onGetColumnsWanted } = this.props;
      onGetColumnsWanted();
    }
  };

  componentDidMount() {
    if (this.props.user && this.props.user.roles) {
      const ac = new AccessControl(this.props.user.roles);

      if (ac.can(this.props.user.permission.role).updateAny('Import Inventory').granted) {
        headerExtra = headerExtra.concat([
          <Button key="3" onClick={() => this.showImportDrawer()} style={{ width:80, marginRight: '10px' }} size='small'>
            <Icon type="import" /> Import
          </Button>
        ]);
      }
      if (ac.can(this.props.user.permission.role).readAny('Export Inventory').granted) {
        headerExtra = headerExtra.concat([
          <Button key="2" onClick={() => this.showExportDrawer()} style={{ width:80, marginRight: '10px' }} size='small'>
            <Icon type="export" /> Export
          </Button>
        ]);
      }
    }
    headerExtra = headerExtra.concat([
      <Input key="1" onChange={this.props.onSearchFilterChange} placeholder="Search by Title/ASIN/SKU/FNSKU/UPC/EAN" style={{ width: 310, marginRight: 10 }}/>
    ]);
  }

  componentWillUnmount() {
    headerExtra = [];
  }

  handleIsReplenHelper = (isReplen) => {
    const { inventory, handleIsReplen } = this.props;
    let { selectedItems } = inventory;

    selectedItems = selectedItems.map(({ sellerSku }) => sellerSku );
    handleIsReplen({ skuList: selectedItems, isReplen });
  };

  resetColumnAndFilterState = () => {
    confirm({
      title: 'Set Filter and Column State to Default',
      content: 'Do you really want to reset Filter and Column state to default?',
      okText: 'Yes',
      cancelText: 'No',
      onOk() {
        if(localStorage) {
          localStorage.removeItem('inventoryPageColumnsState');
          localStorage.removeItem('inventoryPageFiltersState');
          notification.warning({
            message: 'Set Filter and Column State to Default',
            description: 'You need to Refresh this Page to see Default Changes.'
          });
        }
      },
      onCancel() {
      }
    });
  };

  resetDecidedBuyQuantities = () => {
    const { onResetAllDecidedBuyQuantites, getProducts } = this.props;
    confirm({
      title: 'Reset Decided Buy Quantities',
      content: 'Do you really want to reset all Decided Buy Quantities?',
      okText: 'Yes',
      cancelText: 'No',
      onOk() {
        onResetAllDecidedBuyQuantites();
        getProducts();
      },
      onCancel() {
      }
    });
  };

  render() {
    const {
      onImportProducts,
      onResetImportProducts,
      onExportProducts,
      inventory,
      user
    } = this.props;
    const { visibleImportDrawer, visibleExportDrawer } = this.state;

    let fetching;
    let userId;
    let selectedItems = [];
    let attributes = [];
    let importInventory;
    if (inventory) {
      ({ fetching, importInventory } = inventory);

      if (inventory.products && inventory.products.length > 0) {
        ({ userId } = inventory.products[0]);
      }

      if (inventory && inventory.selectedItems) {
        ({ selectedItems } = inventory);
      }
    }

    if (this.props.user && this.props.inventory && this.props.user.roles && this.props.inventory.selectedItems) {
      const ac = new AccessControl(this.props.user.roles);
      const permissionControl = ac.can(this.props.user.permission.role).readAny('Inventory');
      ({ attributes } = permissionControl);
    }

    let columnsWanted = [];
    if (user && user.columnsWanted) {
      ({ columnsWanted } = user);
    }

    return (
      <div style={{ height: '100%' }}>
        <PageHeader
          title="Inventory"
          extra={[
            localStorage && <Button key="6" onClick={() => this.resetColumnAndFilterState()} style={{ marginRight: '10px' }} size='small'>
              Reset
            </Button>,
            (attributes.includes('*') || attributes.includes('decidedBuyQuantity')) ? <Button key="7" onClick={() => this.resetDecidedBuyQuantities()} style={{ marginRight: '10px' }} size='small'>
             Reset Decided Buy Quantities
           </Button> : null,
            (attributes.includes('*') || attributes.includes('isReplen')) && selectedItems && selectedItems.length > 0 && <Button key="4" onClick={() => this.handleIsReplenHelper(true)} style={{ marginRight: '10px' }} size='small'>
              Add To Replen
            </Button>,
            (attributes.includes('*') || attributes.includes('isReplen')) && selectedItems && selectedItems.length > 0 && <Button key="5" onClick={() => this.handleIsReplenHelper(false)} style={{ marginRight: '10px' }} size='small'>
              Remove From Replen
            </Button>
          ].concat(headerExtra)}
        />
        <ImportInventoryDrawer
          fetching={fetching}
          closeImportDrawer={() => this.closeImportDrawer()}
          visible={visibleImportDrawer}
          onImportProducts={onImportProducts}
          onResetImportProducts={onResetImportProducts}
          importInventory={importInventory}
        />
        <ExportInventoryDrawer
          closeExportDrawer={(isExport) => this.closeExportDrawer(isExport)}
          visible={visibleExportDrawer}
          userId={userId}
          columnsWanted={columnsWanted}
          selectedItems={selectedItems}
          onExportProducts={onExportProducts}
          replenExportOption={(attributes.includes('*') || attributes.includes('isReplen'))}
        />
        <InventoryGrid />
      </div>
    );
  }
};

const mapStateToProps = ({ inventory, user }) => ({
  user,
  inventory
});

const mapDispatchToProps = dispatch => ({
  onSearchFilterChange: (event) => {
    const keyword = event.target.value;
    const filter = {
      keyword: {
        value: keyword,
        filterType: 'text'
      }
    };

    dispatch(setFilters(filter));
    dispatch(setPage(1));
    dispatch(getProducts());
  },
  getProducts: () => dispatch(getProducts()),
  onResetImportProducts: () => dispatch(resetImportProducts()),
  onGetColumnsWanted: () => dispatch(getColumnsWanted()),
  onResetAllDecidedBuyQuantites: () => dispatch(resetAllDecidedBuyQuantites()),
  onImportProducts: (products, costCheck) => dispatch(importProducts(products, costCheck)),
  onExportProducts: (userId, noOfselectedItems, selectedItems, columnsWanted, exportReplen) => dispatch(exportProducts(userId, noOfselectedItems, selectedItems, columnsWanted, exportReplen)),
  handleIsReplen: (product) => dispatch(setToReplen(product))
});

export default connect(mapStateToProps, mapDispatchToProps)(Inventory)
