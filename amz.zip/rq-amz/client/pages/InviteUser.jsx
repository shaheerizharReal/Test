import React from 'react';
import {
  PageHeader,
  Icon
} from 'antd';
import { connect } from 'react-redux';

import ModalFormToAddChildUser from '../components/invite-user/ModalFormToAddChildUser.jsx';
import ModalForInventoryReadGrant from '../components/invite-user/ModalToSetAttributesForInventoryReadGrant.jsx';
import ModalUpdateRole from '../components/invite-user/ModalToUpdateRole.jsx';
import ChildUserGrid from '../components/invite-user/Grid.jsx';
import { getDistinctRolesForDropdown } from '../actions/users';

class InviteUser extends React.Component {
  componentDidMount() {
    const {  getDistinctRolesForDropdown } = this.props;
    getDistinctRolesForDropdown();
  }

  state = {
    visible: false
  };

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleCancel = e => {
    this.setState({
      visible: false,
    });
  };

  saveNode = (node) => {
    if (this.InviteUsersGrid) {
      this.InviteUsersGrid.saveNode(node);
    }
  }

  render() {
    return (
      <div style={{ height: '100%' }}>
        <PageHeader
          title="Invite User"
          extra={[
            <Icon key='1' type="user-add" onClick={this.showModal} style={{ fontSize: '30px', margin: '10px 30px 0 0' }} />,
          ]}
        />

        <ModalFormToAddChildUser
          visible={this.state.visible}
          onCancel={this.handleCancel}
        />

        <ModalForInventoryReadGrant
          visible={this.props.user.setAttributesFlag}
        />

        <ModalUpdateRole
          saveNode={this.saveNode}
          visible={this.props.user.setRoleUpdateFlag}
        />
        { (this.props.user && this.props.user.distinctRoles) ?
          <ChildUserGrid
            onRef={ref => this.InviteUsersGrid = ref}
          /> :
          null
        }
      </div>
    );
  }
};
const mapStateToProps = ({ user }) => ({ user });

const mapDispatchToProps = (dispatch) => ({
  getDistinctRolesForDropdown: () => dispatch(getDistinctRolesForDropdown())
});

export default connect(mapStateToProps, mapDispatchToProps)(InviteUser);
