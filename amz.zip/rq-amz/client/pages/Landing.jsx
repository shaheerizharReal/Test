import React from 'react';

import Navbar from '../components/landing/Navbar.jsx';
import Banner from '../components/landing/Banner.jsx';
import Partner from '../components/landing/Partner.jsx';
import ReplenUse from '../components/landing/ReplenUse.jsx';
import Footer from '../components/landing/Footer.jsx';
import PricingTable from '../components/landing/pricing-table/PricingTable.jsx';
import Testimonials from '../components/landing/Testimonials.jsx';

import {
    NavbarDataSource,
    BannerDataSource,
    PartnerDataSource,
    ReplenUseDataSource,
    FooterDataSource,
} from '../../config/data.source';
import '../components/landing/Less/antMotionStyle.less';

const { location } = window;
 
class Landing extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        show: !location.port
        };
    }

    componentDidMount() {
        if (location.port) {
        setTimeout(() => {
            this.setState({
            show: true,
            });
        }, 500);
        }
    }

    render() {
        const children = [
        <Navbar
            id="Navbar"
            key="Navbar"
            dataSource={NavbarDataSource}
        />,
        <Banner
            id="Banner"
            key="Banner"
            dataSource={BannerDataSource}
        />,
        <PricingTable 
            id='Pricing_Table'
            key='Pricing_Table'
        />,
        <ReplenUse
            id="ReplenUse"
            key="ReplenUse"
            dataSource={ReplenUseDataSource}
        />,
        <Testimonials
            id="testimonials"
            key="testimonials"
        />,
        <Partner
            id="Partner"
            key="Partner"
            dataSource={PartnerDataSource}
        />,
        <Footer
            id="Footer"
            key="Footer"
            dataSource={FooterDataSource}
            history={this.props.history}
        />,
        ];
        return (
        <div
            className="templates-wrapper"
            ref={(d) => {
            this.dom = d;
            }}
        >
            {this.state.show && children}
        </div>
        );
    }
}

export default Landing;
