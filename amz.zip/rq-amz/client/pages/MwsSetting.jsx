import React from 'react';
import {
  PageHeader,
} from 'antd';

import MwsCredentialsSettings from '../components/settings/MwsCredentials.jsx';

const routes = [{
    breadcrumbName: 'Settings',
  }, {
    breadcrumbName: 'MWS Credentials',
  }];

class MwsSetting extends React.Component {
  render() {
    return (
      <div>
        <PageHeader
          breadcrumb={{routes}}
        />

        <MwsCredentialsSettings />
      </div>
    );
  }
};

export default MwsSetting;
