import React from 'react';
import {
  Empty,
  Icon
} from 'antd';

class PageNotFound extends React.Component {
  render() {
    return (
      <div>
        <Empty description="Page Not Found" image={(<Icon style={{ fontSize: '100px' }} type="warning" />)} />
      </div>
    );
  }
};

export default PageNotFound;
