import React, { Component } from 'react';
import { Elements, StripeProvider } from 'react-stripe-elements';
import { connect } from 'react-redux';
import { find } from 'lodash';
import axios from 'axios';
import {
  Notification,
  Modal,
  PageHeader
} from 'antd';

const { confirm } = Modal;

import PaymentForm from '../components/payment/PaymentForm.jsx';
import UpdateCardForm from '../components/payment/UpdateCardForm.jsx';
import PlansHeader from '../components/payment/PlansHeader.jsx';
import ReferralCodeSettings from '../components/payment/ReferralCode.jsx'
import { STRIPE_KEYS_LIVE, STRIPE_KEYS_TEST } from '../../config/settings.json'
import { getUser } from '../actions/users';
import { setShowPaymentCard, setShowUpdateCard } from '../actions/payment';
import { setSelectedPlan } from '../actions/payment';

let instance;

class Payment extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    instance = this;
  }

  planSelected = (plan, tierNo) => {
    const { referralCode } = this.props.user;
    const { stripeCoupons, selectedPlan } = this.props.payment;

    if (this.PaymentForm && selectedPlan && referralCode && find(stripeCoupons, { _id: referralCode })) {
      this.PaymentForm.validateCoupon(referralCode);
    }

    this.props.setSelectedPlan(plan, tierNo);
  }

  fetchUser = () => {
    this.props.getUser();
  }

  cancelSubscription (subscriptionId, planName) {
    const url = '/api/v1/users/cancel-subscription';

    confirm({
      title: 'Unsubscribe Plan',
      content: `Do you really want to Unsubscribe ${planName} Plan ?`,
      okText: 'Yes',
      cancelText: 'No',
      onOk() {
        axios.delete(url, {
          params: {subscriptionId}
        }).then(() => {
          instance.props.getUser();

          Notification['success']({
            message: 'Subscription',
            description: 'Subscription Canceled successfully !',
          });
        }).catch((error) => {
          Notification['error']({
            message: 'Payment',
            description: 'Subscription Cancelled Failed'
          });
        });
      },
      onCancel() {
      },
    });
    
  };

  render() {
    const { user, payment } = this.props;
    const { selectedPlan, showPaymentCard, showUpdateCard } = payment;

    const apiKey = process.env.NODE_ENV === 'production' ? STRIPE_KEYS_LIVE.publicKey : STRIPE_KEYS_TEST.publicKey;

    return (
      <StripeProvider apiKey={apiKey}>
        <div className="example">
          <PageHeader
            title="Payment"
          />
          {(selectedPlan && showPaymentCard)
            ? <Elements>
                <PaymentForm
                  user={user}
                  fetchUser={this.fetchUser}
                  onRef={ref => this.PaymentForm = ref }
                />
              </Elements>
            : null
          }

          {(!selectedPlan && showUpdateCard) ?
            <Elements>
              <UpdateCardForm
                user={user}
              />
            </Elements>
            : null
          }

          <ReferralCodeSettings />

          {(user.status !== 'Free') ?
            <PlansHeader
              user={user}
              planSelected={this.planSelected}
              cancelSubscription={this.cancelSubscription}
              setShowPaymentCard={this.props.setShowPaymentCard}
              setShowUpdateCard={this.props.setShowUpdateCard}
            /> : null
          }
        </div>
      </StripeProvider>
    );
  }
}
const mapStateToProps = ({ payment, user }) => ({ payment, user });

const mapDispatchToProps = (dispatch) => ({
  getUser: () => {
    dispatch(getUser());
  },
  setSelectedPlan: (selectedPlan, tierNo) => {
    dispatch(setSelectedPlan(selectedPlan, tierNo));
  },
  setShowPaymentCard: (showPaymentCard) => {
    dispatch(setShowPaymentCard(showPaymentCard));
  },
  setShowUpdateCard: (showUpdateCard) => {
    dispatch(setShowUpdateCard(showUpdateCard));
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(Payment);
