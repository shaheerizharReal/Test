import React from 'react';
import { Card, Row, Icon } from 'antd';
import QueueAnim from 'rc-queue-anim';

import { NavbarDataSource, FooterDataSource, PrivacyPolicyDataSource } from '../../config/data.source';
import Navbar from '../components/landing/Navbar.jsx';
import Footer from '../components/landing/Footer.jsx';

class PrivacyPolicy extends React.Component {
  render() {
    const dataSource = PrivacyPolicyDataSource;
    return (
      <div className='price-tables pt-default'>
        
        <div>
          <Navbar
              id="Nav0_0"
              key="Nav0_0"
              dataSource={NavbarDataSource}
          />
        </div>
        
        <div>
          <h1 style={{textAlign:'center', padding: '35px', color:'#fe3703', fontSize:'32', fontWeight:'bolder'}} > Privacy Policy</h1>

          <QueueAnim
            key="QueueAnim"
            type={['bottom', 'top']}
            delay={200}
            // {dataSource.textWrapper}
          >
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c1.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c1.content}<a href='http://www.replendashboard.com'>www.replendashboard.com</a>{dataSource.c1.content1}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c3.title }
              </Row>
              <Row style={{paddingLeft: '25px',paddingBottom: '10px'}} key="content1" {...dataSource.content}>
                <span> <Icon style={{fontSize:'20', fontWeight:'bolder'}} type="arrow-right" />{dataSource.c3.content1}</span>
              </Row>
              <Row style={{paddingLeft: '25px',paddingBottom: '10px'}} key="content2" {...dataSource.content}>
                <span> <Icon style={{fontSize:'20', fontWeight:'bolder'}} type="arrow-right" />{dataSource.c3.content2}</span>
              </Row>
              <Row style={{paddingLeft: '25px',paddingBottom: '10px'}} key="content3" {...dataSource.content}>
                <span> <Icon style={{fontSize:'20', fontWeight:'bolder'}} type="arrow-right" />{dataSource.c3.content3}</span>
              </Row>
              <Row style={{paddingLeft: '25px',paddingBottom: '10px'}} key="content4" {...dataSource.content}>
                <span> <Icon style={{fontSize:'20', fontWeight:'bolder'}} type="arrow-right" />{dataSource.c3.content4}</span>
              </Row>
              <Row style={{paddingLeft: '25px',paddingBottom: '10px'}} key="content5" {...dataSource.content}>
                <span> <Icon style={{fontSize:'20', fontWeight:'bolder'}} type="arrow-right" />{dataSource.c3.content5}</span>
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c4.title }
              </Row>
              <Row style={{paddingLeft: '25px'}}  key="content5" {...dataSource.content}>
                <span> <Icon style={{fontSize:'20', fontWeight:'bolder'}} type="arrow-right" />{dataSource.c4.content} </span>
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                <span> <Icon style={{fontSize:'20', fontWeight:'bolder'}} type="arrow-right" />{dataSource.c4.content1} </span>
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c5.title }
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c5.content1}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c6.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                <span> <Icon style={{fontSize:'20', fontWeight:'bolder'}} type="arrow-right" />{dataSource.c6.content1} </span>
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content2" {...dataSource.content}>
                <span> <Icon style={{fontSize:'20', fontWeight:'bolder'}} type="arrow-right" />{dataSource.c6.content2} </span>
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c7.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c7.content}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c8.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c8.content1}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c9.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c9.content}
              </Row>
            
              <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
                <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                  { dataSource.c10.title }
                </Row>
                <Row key="content1" {...dataSource.content}>
                  {dataSource.c10.content}
                </Row>
              </Card>
              
              <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
                <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                  { dataSource.c11.title }
                </Row>
                <Row key="content1" {...dataSource.content}>
                  {dataSource.c11.content}
                </Row>
                {/* <Row key="content2" {...dataSource.content}>
                  {dataSource.c11.content1}
                </Row> */}
              </Card>

              <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
                <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                  { dataSource.c12.title }
                </Row>
                <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                  {dataSource.c12.content1}
                </Row>
                <Row style={{paddingLeft: '25px'}} key="content2" {...dataSource.content}>
                  {dataSource.c12.content2}
                </Row>
                <ol  style={{ listStyleType: 'initial', paddingLeft: '65px' }}>
                  <li><a href={dataSource.c12Links.l1.address}>{dataSource.c12Links.l1.clickableText}</a>{dataSource.c12Links.l1.remainingText}</li>
                  <li><a href={dataSource.c12Links.l2.address}>{dataSource.c12Links.l2.clickableText}</a>{dataSource.c12Links.l2.remainingText}</li>
                  <li><a href={dataSource.c12Links.l3.address}>{dataSource.c12Links.l3.clickableText}</a>{dataSource.c12Links.l3.remainingText}</li>
                  <li><a href={dataSource.c12Links.l4.address}>{dataSource.c12Links.l4.clickableText}</a>{dataSource.c12Links.l4.remainingText}</li>
                  <li><a href={dataSource.c12Links.l5.address}>{dataSource.c12Links.l5.clickableText}</a>{dataSource.c12Links.l5.remainingText}</li>
                  <li><a href={dataSource.c12Links.l6.address}>{dataSource.c12Links.l6.clickableText}</a>{dataSource.c12Links.l6.remainingText}</li>
                  <li><a href={dataSource.c12Links.l7.address}>{dataSource.c12Links.l7.clickableText}</a>{dataSource.c12Links.l7.remainingText}</li>
                </ol>
              </Card>
            
              <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
                <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                  { dataSource.c13.title }
                </Row>
                <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                  {dataSource.c13.content1}
                </Row>
              </Card>
            
              <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
                <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                  { dataSource.c14.title }
                </Row>
                <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                  {dataSource.c14.content1}
                </Row>
              </Card>
            
              <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
                <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                  { dataSource.c15.title }
                </Row>
                <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                  {dataSource.c15.content1}
                </Row>
              </Card>

            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c16.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c16.content1}
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c17.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c17.content1}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content2" {...dataSource.content}>
                {dataSource.c17.content2}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content2" {...dataSource.content}>
                {dataSource.c17.content3} <b style={{ color: 'deepSkyBlue' }}>support@replendashboard.com</b>.
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c18.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c18.content1}
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c19.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c19.content1}
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c20.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c20.content1}
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c21.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c21.content1} <b style={{ color: 'deepSkyBlue' }}>support@replendashboard.com</b>.
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c22.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c22.content1}
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c23.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c23.content1}
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c24.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c24.content1}
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c25.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c25.content1}
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c26.title }
              </Row>
              <Row style={{paddingLeft: '25px'}} key="content1" {...dataSource.content}>
                {dataSource.c26.content1} <b style={{ color: 'deepSkyBlue' }}>support@replendashboard.com</b>.
              </Row>
            </Card>





            
          </QueueAnim>

        </div>

        <div>
          <Footer
            id="Footer1_0"
            key="Footer1_0"
            dataSource={FooterDataSource}
            history={this.props.history}
          />
        </div>

      </div>
    )
  }
};

export default PrivacyPolicy;
