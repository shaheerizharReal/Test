import React from 'react';
import {
  PageHeader,
  Icon,
} from 'antd';
import { connect } from 'react-redux';

import RoleGrid from '../components/roles/Grid.jsx';
import ModalFormToAddRole from '../components/roles/ModalFormToAddRole.jsx';
import './Inventory.less';

class Roles extends React.Component {
  state = {
    visible: false
  };

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleCancel = e => {
    this.setState({
      visible: false,
    });
  };


  render() {
    return (
      <div style={{ height: '100%' }}>
        <PageHeader
          title="Roles"
          extra={[
            <Icon key='1' type="plus" onClick={this.showModal} style={{ fontSize: '30px', margin: '10px 30px 0 0' }} />
          ]}
        />
        <RoleGrid />
        <ModalFormToAddRole
          visible={this.state.visible}
          onCancel={this.handleCancel}
        />
      </div>
    );
  }
};

const mapStateToProps = ({ role }) => ({ role });

const mapDispatchToProps = (dispatch, getState) => ({
  //getUsers: () => dispatch(getUsers()),
});

export default connect(mapStateToProps, mapDispatchToProps)(Roles)
