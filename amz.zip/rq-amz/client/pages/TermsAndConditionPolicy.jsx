import React from 'react';
import { Card, Row } from 'antd';
import QueueAnim from 'rc-queue-anim';

import { NavbarDataSource, FooterDataSource, TermAndConditionDataSource } from '../../config/data.source';
import Navbar from '../components/landing/Navbar.jsx';
import Footer from '../components/landing/Footer.jsx';

class TermsAndConditionPolicy extends React.Component {
  render() {
    const dataSource = TermAndConditionDataSource;

    return (
      <div>
        <div>
          <Navbar
              id="Nav0_0"
              key="Nav0_0"
              dataSource={NavbarDataSource}
          />
        </div>

        <div>
          <h1 style={{textAlign:'center', padding: '35px', color:'#fe3703', fontSize:'32', fontWeight:'bolder'}} > Terms And Conditions Policy</h1>

          <QueueAnim
            key="QueueAnim"
            type={['bottom', 'top']}
            delay={200}
          >
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row style={{width: '100%', color:'#fe3703' , padding: '35px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c.content2}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c.content3}
              </Row>
              <Row key="content4" {...dataSource.content}>
                {dataSource.c.content4}
              </Row>
              <Row key="content5" {...dataSource.content}>
                {dataSource.c.content5}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 1</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c1.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c1.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c1.content2}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c1.content3}
              </Row>
              <Row key="content4" {...dataSource.content}>
                {dataSource.c1.content4}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 2</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c2.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c2.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c2.content2}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c2.content3}
              </Row>
              <Row key="content4" {...dataSource.content}>
                {dataSource.c2.content4}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 3</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c3.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c3.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c3.content2}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 4</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c4.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c4.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c4.content2}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c4.content3}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 5</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c1.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c1.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c1.content1}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c1.content1}
              </Row>
              <Row key="content4" {...dataSource.content}>
                {dataSource.c1.content1}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 6</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c6.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c6.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c6.content2}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 7</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c7.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c7.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c7.content2}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c7.content3}
              </Row>
              <Row key="content4" {...dataSource.content}>
                {dataSource.c7.content4}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 8</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c8.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c8.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c8.content2}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c8.content3}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 9</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c9.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c9.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c9.content2}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c9.content3}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 10</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c10.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c10.content1}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 11</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c11.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c11.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c11.content2}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 12</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c12.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c12.content1}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentA" {...dataSource.content}>
                <b>(A) </b>  {dataSource.c12.contentA}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentB" {...dataSource.content}>
                <b>(B) </b>  {dataSource.c12.contentB}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentC" {...dataSource.content}>
                <b>(C) </b>  {dataSource.c12.contentC}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentD" {...dataSource.content}>
                <b>(D) </b>  {dataSource.c12.contentD}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentE" {...dataSource.content}>
                <b>(E) </b>  {dataSource.c12.contentE}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentF" {...dataSource.content}>
                <b>(F) </b>  {dataSource.c12.contentF}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentG" {...dataSource.content}>
                <b>(G) </b>  {dataSource.c12.contentG}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentH" {...dataSource.content}>
                <b>(H) </b>  {dataSource.c12.contentH}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentI" {...dataSource.content}>
                <b>(I) </b>  {dataSource.c12.contentI}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentJ" {...dataSource.content}>
                <b>(J) </b>  {dataSource.c12.contentJ}
              </Row>
              <Row style={{paddingLeft: '25px'}} key="contentK" {...dataSource.content}>
                <b>(K) </b>  {dataSource.c12.contentK}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 13</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c13.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c13.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c13.content2}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c13.content3}
              </Row>
              <Row key="content4" {...dataSource.content}>
                {dataSource.c13.content4}
              </Row>
              <Row key="content5" {...dataSource.content}>
                {dataSource.c13.content5}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 14</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c14.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c14.content1}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 15</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c15.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c15.content1}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 16</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c16.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c16.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c16.content2}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c16.content3}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 17</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c17.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c17.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c17.content2}
              </Row>
              <Row key="content3" {...dataSource.content}>
                {dataSource.c17.content3}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 18</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c18.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c18.content1}
              </Row>
            </Card>
            
            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 19</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c19.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c19.content1}
              </Row>
              <Row key="content2" {...dataSource.content}>
                {dataSource.c19.content2}
              </Row>
            </Card>

            <Card style={{margin: '10px 40px', padding: '0px 40px'}}>
              <Row key="section" {...dataSource.content}>
                <h2 style={{color:'#fe3703'}}>Section 20</h2>
              </Row>
              <Row style={{width: '100%', padding: '10px 0px 18px 0px', fontSize:'24', fontWeight:'bolder'}} key="title1">
                { dataSource.c20.title }
              </Row>
              <Row key="content1" {...dataSource.content}>
                {dataSource.c20.content1}
              </Row>
            </Card>
            
            
            
          </QueueAnim>

        </div>
        
        <div>
          <Footer
            id="Footer1_0"
            key="Footer1_0"
            dataSource={FooterDataSource}
            history={this.props.history}
          />
        </div>

      </div>
    )
  }
};

export default TermsAndConditionPolicy;
