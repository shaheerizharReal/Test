import React, { Component } from 'react';
import { PageHeader } from 'antd';

import ShippingRateSettings from '../components/settings/ShippingRateSettings.jsx';

const routes = [{
  breadcrumbName: 'Settings',
}, {
  breadcrumbName: 'Profit',
}];

class UpdateShippingRate extends Component {
  render() {
    return (
      <div>
        <PageHeader
          breadcrumb={{ routes }}
        />

        <ShippingRateSettings />
      </div>
    );
  }
}

export default UpdateShippingRate;
