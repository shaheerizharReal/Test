import React from 'react';
import {
  PageHeader,
  Input,
  Button,
  notification
} from 'antd';
import { connect } from 'react-redux';

import { 
  getUsers,
  setPage,
  setFilters,
  loadDemoUserData
} from '../actions/users';
import UserGrid from '../components/user/Grid.jsx';
import './Inventory.less';

class Users extends React.Component {
  state = {
    loadingForDemoAccountButton: false
  }

  handleLoadDemoAccountData = () => {
    this.setState({ loadingForDemoAccountButton: true });
    
    const { loadDemoAccountData } = this.props;
    loadDemoAccountData().then(() => {
      this.setState({
        loadingForDemoAccountButton: false
      });
    }).catch(() => {
      this.setState({
        loadingForDemoAccountButton: false
      });
    });
  }

  render() {
    const { onSearchFilterChange } = this.props;
    const { loadingForDemoAccountButton } = this.state;
    return (
      <div style={{ height: '100%' }}>
        <PageHeader
          title="Users"
          extra={[
            <Button 
              key="1"
              loading={loadingForDemoAccountButton}
              icon='save'
              type='primary' 
              onClick={this.handleLoadDemoAccountData}>
                Load Demo Account Data
            </Button>,
            <Input key="2" onChange={onSearchFilterChange} placeholder="Search by Username or email" style={{ width: 310, marginRight: 10 }} />
          ]}
        />
        <UserGrid />
      </div>
    );
  }
};

const mapStateToProps = ({ users }) => users;

const mapDispatchToProps = (dispatch, getState) => ({
  onSearchFilterChange: (event) => {
    const keyword = event.target.value;

    const filter = {
      keyword: {
        value: keyword,
        filterType: 'text'
      }
    };

    dispatch(setFilters(filter))
    dispatch(setPage(1));;
    dispatch(getUsers());
  },
  loadDemoAccountData: () => dispatch(loadDemoUserData())
});

export default connect(mapStateToProps, mapDispatchToProps)(Users)
