import React from 'react';
import { Timeline, TimelineItem }  from 'vertical-timeline-component-for-react';
import { 
  PageHeader
} from 'antd';

import './WhatsNew.less'

class WhatsNew extends React.Component {
  render() {
      return (
        <div style={{ height: '100%' }}>
          <PageHeader
            title="Whats' New"
          />
          <div>
            <Timeline lineColor={'#fe3703'}>
            <TimelineItem
                key="11"
                dateText="08 May 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Profit</h3>
                <p>
                  Now Users can chose how they want their profit to be shown to them in the settings tab.
                    <li><b>Sale Price</b></li>
                    <li><b>Buy Box Price</b></li>
                    <li><b>Lowest Price</b></li>
                    <li><b>Lowest FBA Price</b></li>
                  Our software will do calculations based on Sale Price if selected price does not exists for a Product. This will have an obvious effect in around 1 hour on Profit, ROI% and Profit%.
                </p>
              </TimelineItem>
              
              <TimelineItem
                key="10"
                dateText="08 May 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Shipping Costs</h3>
                <p>
                  Now Users can add their Shipping Costs(by one of these two methods) in the settings tab.
                    <li>On Basis of <b>Item</b> Eg:($1/item)</li>
                    <li>On Basis of <b>Weight</b> Eg:($0.25/pound)</li>
                  Our software has to do some extra calculations if user chooses it on basis of weight. This cost has an obvious effect on Profit and ROI/Profit.
                </p>
              </TimelineItem>

              <TimelineItem
                key="9"
                dateText="08 May 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Lowest FBA Price</h3>
                <p>
                  FBA lowest price of every product is present now. It will help you see what is the lowest price for FBA.
                </p>
              </TimelineItem>

              <TimelineItem
                key="8"
                dateText="08 May 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Pending Orders</h3>
                <p>
                  Pending Orders are also attached now with 30, 60 and 90 Days Data. These orders are now separated from reserved quantity(FC Transfers and FC Processing).
                </p>
              </TimelineItem>

              <TimelineItem
                key="7"
                dateText="08 May 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Buy Quantity</h3>
                <p>
                  Buy Quantity for 60 and 90 Days is also present now. A good news for new products of 30 Days older, Buy Quantity is calculated based on Sales Per Day now.
                </p>
              </TimelineItem>

              <TimelineItem
                key="6"
                dateText="21 January 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Roles and Permissions</h3>
                <p>
                  Most powerful feature is available now. All users can add Shoppers/VAs with custom permissions now.
                </p>
              </TimelineItem>

              <TimelineItem
                key="5"
                dateText="06 January 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Purchase Link</h3>
                <p>
                  Now you can perfectly import purchase link of every product by Importing File.
                </p>
              </TimelineItem>

              <TimelineItem
                key="4"
                dateText="06 January 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Sales Data</h3>
                <p>
                  Our latest release provides you more detailed information about the Sales history. In this release sales record of Last 60 Days and Last 90 Days has been add to Dashboard and Export Inventory Drawer. Moreover, you can check 60 and 90 days sales data of every product on Inventory Page.
                </p>
              </TimelineItem>

              <TimelineItem
                key="3"
                dateText="06 January 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Custom ASIN Shortcuts</h3>
                <p>
                  A new feature is added to the Inventory Page named as Create Custom ASIN. You can make a custom ASIN and query ASIN on the related Store.
                </p>
              </TimelineItem>

              <TimelineItem
                key="2"
                dateText="06 January 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Replen Products</h3>
                <p>
                  A new feature is added to the Inventory Page named as Replen Products. You can set products as replen product by just checking the checkbox in the column named Replen? pinned at Right. Futher you can also set and unset multiple product as Replen Product by just Checking the extreme left Checkbox Column. Moreover, you can export your replen products data on Export Inventory Drawer.
                </p>
              </TimelineItem>

              <TimelineItem
                key="1"
                dateText="06 January 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Store Section</h3>
                <p>
                Column for Users to enter in what section of the store the items are in. It is simple text column which is sortable.
                </p>
              </TimelineItem>

              <TimelineItem
                key="0"
                dateText="06 January 2020"
                dateInnerStyle={{ background: '#fe3703', color: '#fff' }}
                bodyContainerStyle={{
                  background: '#fff',
                  padding: '20px',
                  borderRadius: '8px',
                  boxShadow: '0.5rem 0.5rem 2rem 0 rgba(0, 0, 0, 0.2)',
                }}
              >
                <h3 style={{ color: '#fe3703' }}>Notes Section</h3>
                <p>
                  Column for Users to enter information about item. It is simple text column for user to remember things.
                </p>
              </TimelineItem>
            </Timeline>
          </div>
        </div>
      );
  }
}

export default WhatsNew;
