import React from 'react';
import {
  PageHeader,
  Input,
  Select
} from 'antd';
import { connect } from 'react-redux';

import { getAgendaJobs, setPage, setPageSize, setFilters } from '../actions/agendaJobs';
import { getAllUsersAgendaJobs } from '../actions/users';
import AgendaJobsGrid from '../components/agendaJobs/Grid.jsx';
import './AgendaJobs.less';

const Option = Select.Option;

class AgendaJobs extends React.Component {
  componentDidMount(){
    const { getAllUsersAgendaJobs } = this.props;
    getAllUsersAgendaJobs();
  }

  render() {
    const { users, onSelectionFilterChnage, onSearchFilterChnage } = this.props;
    return (
      <div style={{ height: '100%' }}>
        <PageHeader
          title="Agenda Jobs"
          extra={[
            <Select key="0" onChange={onSelectionFilterChnage} placeholder="Search by User" style={{ marginRight:10, width: 150 }} >
              <Option key={-1} value="all">All</Option>
              {users.map((user) => {
                return <Option key={user._id} value={user._id}>{user.name}</Option>;
              })}
            </Select>,
            <Input key="1" onChange={onSearchFilterChnage} placeholder="Search by Job name" style={{ width: 310, marginRight: 10 }} />
          ]}
        />
        <AgendaJobsGrid />
      </div>
    );
  }
};

const mapStateToProps = ({ agendaJobs, users }) => (agendaJobs, users);

const mapDispatchToProps = dispatch => ({
  getAllUsersAgendaJobs: () => dispatch(getAllUsersAgendaJobs()),
  getAgendaJobs: () => dispatch(getAgendaJobs()),
  onPageChange: (pageNumber) => {
    dispatch(setPage(pageNumber));
    dispatch(getAgendaJobs())
  },
  onPageSizeChange: (current, pageSize) => {
    dispatch(setPageSize(pageSize));
    dispatch(getAgendaJobs());
  },

  onSelectionFilterChnage: (selectedUser) => {
    const userId = selectedUser;
    const filter = (userId === 'all' ? {} : {
      userSelection: {
        value: userId,
        filterType: 'text'
      }
    });

    dispatch(setFilters(filter));
    dispatch(setPage(1));
    dispatch(getAgendaJobs());
  },

  onSearchFilterChnage: (event) => {
    const keyword = event.target ? event.target.value : event;
    const filter = {
      keyword: {
        value: keyword,
        filterType: 'text'
      }
    };

    dispatch(setFilters(filter));
    dispatch(setPage(1));
    dispatch(getAgendaJobs());
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(AgendaJobs)
