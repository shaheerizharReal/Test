import React from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import AccessControl from 'accesscontrol';

import MwsSetting from './MwsSetting.jsx';
import UpdateProfile from './updateProfile.jsx';
import CustomAsinShortcut from '../pages/CustomAsinShortcut.jsx';
import UpdateShippingRate from '../pages/UpdateShippingRate.jsx';

class Settings extends React.Component {
  render() {
    const { roles } = this.props.user;
    const ac = new AccessControl(roles);
    const permissionControl = ac.can(this.props.user.permission.role).readAny('Inventory');
    const { attributes } = permissionControl;
    return (
      <Switch>
        <Route exact path="/settings/updateProfile" component={UpdateProfile} />
        <Route exact path="/settings/updateShippingRate" component={UpdateShippingRate} />
        {
          (permissionControl.granted && (attributes.includes('*') || attributes.includes('asinShortcut'))) ?
          <Route exact path="/settings/custom-asin-shortcut" component={CustomAsinShortcut} /> :
          <Redirect from='*' to='/not-found' />
        }
        {
          (ac.can(this.props.user.permission.role).readAny('MWS').granted) ?
          <Route exact path="/settings/mws" component={MwsSetting} /> :
          <Redirect from='*' to='/not-found' />
        }
      </Switch>
    );
  }
};

const mapStateToProps = ({ user }) => ({ user });

const mapDispatchToProps = (dispatch) => ({
});

export default connect(mapStateToProps, mapDispatchToProps)(Settings)
