import React, { Component } from 'react';
import { PageHeader } from 'antd';

import UpdateProfileForm from '../components/settings/UpdateProfile.jsx';

const routes = [{
  breadcrumbName: 'Settings',
}, {
  breadcrumbName: 'Update Profile',
}];

class UpdateProfile extends Component {
  render() {
    return (
      <div>
        <PageHeader
          breadcrumb={{ routes }}
        />

        <UpdateProfileForm />
      </div>
    );
  }
}

export default UpdateProfile;
