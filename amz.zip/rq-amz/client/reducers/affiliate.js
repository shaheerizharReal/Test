import { findIndex, includes } from 'lodash';

const initialState = {
  fetching: false,
  affiliates: [],
  delAffiliates: [],
  noOfAffiliatedUsers: []
};

const affiliate = (state = initialState, action) => {
  switch (action.type) {
    case 'ADD_AFFILIATE_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'ADD_AFFILIATE_SUCCESS': {
      return {
        ...state,
        fetching: false,
        affiliates: action.payload
      };
    }
    case 'ADD_AFFILIATE_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'GET_AFFILIATES_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_AFFILIATES_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'SET_AFFILIATES_TO_DELETE': {
      return {
        ...state,
        ...action.payload
      };
    }
    case 'DELETE_AFFILIATES_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'DELETE_AFFILIATES_SUCCESS': {
      let tempAffiliates = [...state.affiliates];
      const tempDelAffiliates = [...state.delAffiliates];
      const ids = tempDelAffiliates.map(affi => affi._id);

      tempAffiliates = tempAffiliates.filter((affi) => {
        return !(includes(ids, affi._id));
      });

      return {
        ...state,
        fetching: false,
        affiliates: tempAffiliates,
        delAffiliates: []
      };
    }
    default: {
      return state;
    }
  }
};

export default affiliate;
