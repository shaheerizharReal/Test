const initialState = {
  fetching: false,
  agendaJobs: [],
  total: 0,
  filters: {},
  sort: {},
  selectedItems: [],
  pagination: {
    pageNumber: 1,
    pageSize: Number(localStorage.getItem('agendaJobsPerPage'))
  }
};

const agendaJobs = (state = initialState, action) => {
  switch (action.type) {
    case 'REQUEUE_AGENDA_JOB_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'AGENDA_JOB_REQUEUED_SUCCESSFULLY': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'REMOVE_AGENDA_JOB_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'AGENDA_JOB_REMOVED_SUCCESSFULLY': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'GET_AGENDA_JOBS_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_AGENDA_JOBS_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'SET_PAGE_AGENDA_JOBS': {
      return {
        ...state,
        pagination: {
          ...state.pagination,
          ...action.payload
        }
      };
    }
    case 'SET_FILTER_AGENDA_JOBS': {
      let { keyword, filters } = action.payload;
      if (keyword && keyword.value === '') {
        ({ keyword, ...filters } = state.filters);
        return {
          ...state,
          filters: {
            ...filters
          }
        };
      }

      if (keyword && !!keyword.value) {
        return {
          ...state,
          filters: {
            ...state.filters,
            keyword
          }
        };
      }

      ({ keyword, ...filters } = state.filters);

      return {
        ...state,
        filters: {
          keyword,
          ...action.payload
        }
      };
    }
    case 'RESET_FILTERS_AGENDA_JOBS': {
      return {
        ...state,
        filters: {}
      };
    }
    case 'SET_SORT_FILTERS_AGENDA_JOBS': {
      return {
        ...state,
        sort: {
          ...state.sort,
          ...action.payload
        }
      };
    }
    case 'SET_PAGE_SIZE_AGENDA_JOBS': {
      return {
        ...state,
        pagination: {
          ...state.pagination,
          ...action.payload
        }
      };
    }
    default: {
      return state;
    }
  }
};

export default agendaJobs;
