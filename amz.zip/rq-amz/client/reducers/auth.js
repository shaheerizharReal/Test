const initialState = {
  fetching: true,
  loggedIn: false,
  admin: false
};

const auth = (state = initialState, action) => {
  switch (action.type) {
    case 'SET_AUTH_LOADING': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'STOP_AUTH_LOADING': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'AUTH_LOGIN_SUCCESS': {
      return {
        loggedIn: true,
        fetching: false,
        ...action.payload
      };
    }
    case 'AUTH_LOGIN_FAILED': {
      return {
        loggedIn: false,
        fetching: false
      };
    }
    case 'AUTH_LOGOUT': {
      return {
        fetching: false,
        loggedIn: false,
        admin: false
      }
    }
    default: {
      return state;
    }
  }
};

export default auth;
