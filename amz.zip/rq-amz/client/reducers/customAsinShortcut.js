import { findIndex } from 'lodash';

const initialState = {
  fetching: false,
  shortcuts: []
};

const customAsinShortcut = (state = initialState, action) => {
  switch (action.type) {
    case 'ADD_SHORTCUT_REQUEST': case 'GET_SHORTCUTS_REQUEST': case 'EDIT_SHORTCUT_REQUEST': case 'DELETE_SHORTCUT_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'ADD_SHORTCUT_SUCCESS': case 'GET_SHORTCUTS_SUCCESS': case 'EDIT_SHORTCUT_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'ADD_SHORTCUT_FAILED': case 'GET_SHORTCUTS_FAILED': case 'EDIT_SHORTCUT_FAILED': case 'DELETE_SHORTCUT_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'UPDATE_SHORTCUT': {
      const { shortcuts } = state;
      const shortcut = action.payload;
      const { _id: shortcutId } = shortcut;

      const index = findIndex(shortcuts, { _id: shortcutId });
      if (index >= 0) {
        shortcuts[index] = shortcut;
      }

      return {
        ...state,
        shortcuts
      };
    }
    case 'DELETE_SHORTCUT_SUCCESS': {
      let tempShortcuts = [...state.shortcuts];
      const { shortcutId } = action.payload;

      tempShortcuts = tempShortcuts.filter(shortcut => !(shortcut._id === shortcutId));

      return {
        ...state,
        fetching: false,
        shortcuts: tempShortcuts
      };
    }
    default: {
      return state;
    }
  }
};

export default customAsinShortcut;
