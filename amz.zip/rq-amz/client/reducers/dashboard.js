const initialState = {
  fetching: false,
  sales: {}
};

const dashboard = (state = initialState, action) => {
  switch (action.type) {
    case 'GET_SALES_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_SALES_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'RESET_STATE_OF_DASHBOARD': {
      return initialState;
    }
    default: {
      return state;
    }
  }
};

export default dashboard;
