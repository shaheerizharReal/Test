import { combineReducers } from 'redux';

import dashboard from './dashboard';
import inventory from './inventory';
import users from './users';
import user from './user';
import agendaJobs from './agendaJobs';
import auth from './auth';
import payment from './payment';
import affiliate from './affiliate';
import role from './role';
import customAsinShortcut from './customAsinShortcut';

export default combineReducers({
  dashboard,
  inventory,
  users,
  user,
  agendaJobs,
  auth,
  payment,
  affiliate,
  role,
  customAsinShortcut
});
