import { findIndex } from 'lodash';

const initialState = {
  fetching: false,
  categories: [],
  suppliers: [],
  products: [],
  total: 0,
  filters: {},
  sort: {},
  selectedItems: [],
  pagination: {
    pageNumber: 1,
    pageSize: Number(localStorage.getItem('inventoryItemsPerPage'))
  },
  importInventory: false
};

const inventory = (state = initialState, action) => {
  switch (action.type) {
    case 'GET_PRODUCTS_REQUEST': case 'SET_COST_REQUEST': case 'SET_DECIDE_BUY_QUANTITY_RQUEST': case 'SET_SHIPPING_COST_REQUEST': case 'SET_SUPPLIER_REQUEST': case 'SET_PURCHASE_LINK_REQUEST': case 'SET_STORE_SECTION_REQUEST': case 'SET_NOTES_SECTION_REQUEST': case 'SET_TO_REPLEN_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_PRODUCTS_SUCCESS': case 'SET_COST_SUCCESS': case 'SET_DECIDE_BUY_QUANTITY_SUCCESS': case 'SET_SUPPLIER_SUCCESS': case 'SET_PURCHASE_LINK_SUCCESS': case 'SET_STORE_SECTION_SUCCESS': case 'SET_NOTES_SECTION_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'GET_PRODUCTS_FAIL': case 'SET_COST_FAIL': case 'SET_DECIDE_BUY_QUANTITY_FAIL': case 'SET_SHIPPING_COST_FAIL': case 'SET_SHIPPING_COST_SUCCESS': case 'SET_SUPPLIER_FAIL': case 'SET_PURCHASE_LINK_FAIL': case 'SET_STORE_SECTION_FAIL': case 'SET_NOTES_SECTION_FAIL': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'SET_PAGE_INVENTORY': {
      return {
        ...state,
        pagination: {
          ...state.pagination,
          ...action.payload
        }
      };
    }
    case 'SET_PAGE_SIZE_INVENTORY': {
      return {
        ...state,
        pagination: {
          ...state.pagination,
          ...action.payload
        }
      };
    }
    case 'SET_SORT_FILTERS': {
      return {
        ...state,
        sort: {
          ...action.payload
        }
      };
    }
    case 'SET_FILTER_INVENTORY': {
      let { keyword, filters } = action.payload;
      if (keyword && keyword.value === '') {
        ({ keyword, ...filters } = state.filters);
        return {
          ...state,
          filters: {
            ...filters
          }
        };
      }

      if (keyword && !!keyword.value) {
        return {
          ...state,
          filters: {
            ...state.filters,
            keyword
          }
        };
      }

      ({ keyword, ...filters } = state.filters);

      return {
        ...state,
        filters: {
          keyword,
          ...action.payload
        }
      };
    }
    case 'RESET_FILTERS_AND_SELECTIONS_INVENTORY': {
      return {
        ...state,
        filters: {},
        selectedItems: []
      };
    }
    case 'GET_CATEGORIES_AND_SUPPLIERS_SUCCESS': {
      return {
        ...state,
        ...action.payload
      };
    }
    case 'GET_CATEGORIES_AND_SUPPLIERS_FAIL': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'SET_SELECTED_ITEMS': {
      return {
        ...state,
        selectedItems: action.payload
      };
    }
    case 'UPDATE_PRODUCT': {
      const { products } = state;
      const product = action.payload;
      const { sellerSku } = product;

      const index = findIndex(products, { sellerSku });
      if (index >= 0) {
        products[index] = product;
      }

      return {
        ...state,
        products
      };
    }
    case 'IMPORT_INVENTORY_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'IMPORT_INVENTORY_SUCCESS': {
      return {
        ...state,
        fetching: false,
        importInventory: true
      };
    }
    case 'IMPORT_INVENTORY_FAIL': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'RESET_IMPORT_INVENTORY': {
      return {
        ...state,
        fetching: false,
        importInventory: false
      };
    }
    case 'RESET_STATE_OF_INVENTORY': {
      return initialState;
    }
    case 'SET_TO_REPLEN_SUCCESS': {
      const tempProducts = [...state.products];
      const products = action.payload;

      for (let i = 0; i < products.length; i += 1) {
        const { sellerSku } = products[i];
        const index = findIndex(tempProducts, { sellerSku });
        if (index >= 0) {
          tempProducts[index] = products[i];
        }
      }
      return {
        ...state,
        fetching: false,
        products: tempProducts
      };
    }
    case 'SET_TO_REPLEN_FAIL': {
      return {
        ...state,
        fetching: false
      };
    }
    default: {
      return state;
    }
  }
};

export default inventory;
