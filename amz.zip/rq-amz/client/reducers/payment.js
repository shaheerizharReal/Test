const initialState = {
  fetching: false,
  stripePlans: [],
  stripeCoupons: [],
  selectedPlan: null,
  selectedTier: null,
  showPaymentCard: false,
  showUpdateCard: false
};

const payment = (state = initialState, action) => {
  switch (action.type) {
    case 'GET_STRIPE_DATA_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_STRIPE_DATA_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'GET_STRIPE_DATA_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'SET_SELECTED_PLAN': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'RESET_SELECTED_PLAN': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'SET_SHOW_PAYMENT_CARD': {
      const { showPaymentCard } = action.payload;
      if (showPaymentCard) {
        return {
          ...state,
          showUpdateCard: false,
          showPaymentCard,
          fetching: false
        };
      }

      return {
        ...state,
        fetching: false,
        showPaymentCard
      };
    }
    case 'SET_SHOW_UPDATE_CARD': {
      const { showUpdateCard } = action.payload;
      if (showUpdateCard) {
        return {
          ...state,
          selectedPlan: null,
          selectedTier: null,
          showPaymentCard: false,
          showUpdateCard,
          fetching: false
        };
      }

      return {
        ...state,
        fetching: false,
        showUpdateCard
      };
    }
    default: {
      return state;
    }
  }
};

export default payment;
