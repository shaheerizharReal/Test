const initialState = {
  fetching: false,
  roles: []
};

const role = (state = initialState, action) => {
  switch (action.type) {
    case 'ADD_ROLE_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'ADD_ROLE_SUCCESS': {
      return {
        ...state,
        fetching: false,
        roles: action.payload
      };
    }
    case 'ADD_ROLE_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'GET_ROLE_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_ROLE_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'DELETE_ROLE_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'DELETE_ROLE_SUCCESS': {
      let tempRoles = [...state.roles];
      const { _id } = action.payload;

      tempRoles = tempRoles.filter(rol => !(rol._id === _id));

      return {
        ...state,
        fetching: false,
        roles: tempRoles
      };
    }
    default: {
      return state;
    }
  }
};

export default role;
