import { findIndex } from 'lodash';

const initialState = {
  fetching: false,
  name: null,
  email: null,
  status: null,
  admin: false,
  updatedSuccessfully: false,
  mws: {},
  columnsWanted: [],
  noOfActiveProducts: 0,
  childUsers: [],
  setAttributesFlag: false,
  validateFormFlag: false,
  attributes: null,
  setRoleUpdateFlag: false,
  childToBeUpdated: null,
  fbaInboundShippingCost: {
    shipBy: 'byItem',
    shippingRate: 0
  },
  profitCalculatedBy: 'listPrice'
};

const user = (state = initialState, action) => {
  switch (action.type) {
    case 'GET_DEFAULT_SHIPPING_RATE_SUCCESS': {
      const { fbaInboundShippingCost } = action.payload || {};
      const { shipBy, shippingRate } = fbaInboundShippingCost || {};
      return {
        ...state,
        fetching: false,
        fbaInboundShippingCost: {
          shipBy: shipBy || 'byItem',
          shippingRate: shippingRate || 0
        }
      };
    }
    case 'GET_DEFAULT_CALCULATION_PRICE_SUCCESS': {
      const { profitCalculatedBy } = action.payload || {};
      return {
        ...state,
        fetching: false,
        profitCalculatedBy
      };
    }
    case 'SAVE_DEFAULT_SHIPPING_RATE_REQUEST':
    case 'GET_DEFAULT_SHIPPING_RATE_REQUEST':
    case 'SAVE_DEFAULT_CALCULATION_PRICE_REQUEST':
    case 'GET_DEFAULT_CALCULATION_PRICE_REQUEST':
    case 'GET_MWS_CREDENTIALS_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_MWS_CREDENTIALS_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'UPDATE_MWS_CREDENTIALS_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'UPDATE_MWS_CREDENTIALS_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'SAVE_DEFAULT_SHIPPING_RATE_SUCCESS': {
      const { shipBy, shippingRate } = action.payload;
      return {
        ...state,
        fetching: false,
        fbaInboundShippingCost: {
          shipBy,
          shippingRate
        }
      };
    }
    case 'SAVE_DEFAULT_CALCULATION_PRICE_SUCCESS': {
      const { profitCalculatedBy } = action.payload;
      return {
        ...state,
        fetching: false,
        profitCalculatedBy
      };
    }
    case 'SAVE_DEFAULT_SHIPPING_RATE_FAILED':
    case 'GET_DEFAULT_SHIPPING_RATE_FAILED':
    case 'SAVE_DEFAULT_CALCULATION_PRICE_FAILED':
    case 'GET_DEFAULT_CALCULATION_PRICE_FAILED':
    case 'UPDATE_MWS_CREDENTIALS_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'REGISTER_USER_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'REGISTER_USER_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'REGISTER_USER_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'LOGIN_USER_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'LOGIN_USER_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'LOGIN_USER_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'GET_USER_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_USER_SUCCESS': {
      return {
        ...initialState,
        fetching: false,
        ...action.payload
      };
    }
    case 'GET_USER_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'UPDATE_USER_PASSWORD_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'UPDATE_USER_PASSWORD_SUCCESS': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'RESET_PASSWORD_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'RESET_PASSWORD_SUCCESS': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'RESET_PASSWORD_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'UPDATE_PASSWORD_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'UPDATE_PASSWORD_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'UPDATE_PASSWORD_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'IMPERSONATE_USER_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'IMPERSONATE_USER_SUCCESS': {
      return {
        ...initialState,
        fetching: false,
        ...action.payload
      };
    }
    case 'IMPERSONATE_USER_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'LOGOUT_USER_SUCCESS': {
      return {
        ...initialState
      };
    }
    case 'RESET_UPDATED_SUCCESSFULLY': {
      return {
        ...state,
        updatedSuccessfully: false
      };
    }
    case 'GET_COLUMNS_WANTED_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_COLUMNS_WANTED_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'GET_NO_OF_ACTIVE_PRODUCTS_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_NO_OF_ACTIVE_PRODUCTS_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'UPDATE_USER_REFERRAL_CODE_SUCCESS': {
      return {
        ...state,
        ...action.payload
      };
    }
    case 'GET_CHILD_USERS_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_CHILD_USERS_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'SEND_INVITE_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'SEND_INVITE_SUCCESS': {
      const tempChildUsers = [...state.childUsers];
      tempChildUsers.push(action.payload);
      return {
        ...state,
        fetching: false,
        childUsers: tempChildUsers
      };
    }
    case 'SEND_INVITE_AGAIN_SUCCESS': {
      const tempChildUsers = [...state.childUsers];
      const { _id } = action.payload;
      const index = findIndex(tempChildUsers, { _id });
      tempChildUsers[index] = action.payload;

      return {
        ...state,
        fetching: false,
        childUsers: tempChildUsers
      };
    }
    case 'SEND_INVITE_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'UPDATE_CHILD_USERS_ROLE_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'UPDATE_CHILD_USERS_ROLE_SUCCESS': {
      const tempChildUsers = [...state.childUsers];
      const { _id, role } = action.payload;
      const index = findIndex(tempChildUsers, { _id });
      tempChildUsers[index].permission[0].role = role;

      return {
        ...state,
        fetching: false,
        childUsers: tempChildUsers
      };
    }
    case 'UPDATE_CHILD_USERS_ROLE_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'GET_DISTINCT_ROLES_FOR_DROPDOWN_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_DISTINCT_ROLES_FOR_DROPDOWN_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'DELETE_CHILD_USER_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'DELETE_CHILD_USER_SUCCESS': {
      let tempChildUsers = [...state.childUsers];
      const { _id } = action.payload;

      tempChildUsers = tempChildUsers.filter(child => !(child._id === _id));

      return {
        ...state,
        fetching: false,
        childUsers: tempChildUsers
      };
    }
    case 'SET_INVENTORY_READ_ATTRIBUTES_FLAG': {
      return {
        ...state,
        ...action.payload
      };
    }
    case 'UNSET_INVENTORY_READ_ATTRIBUTES_FLAG': {
      return {
        ...state,
        ...action.payload
      };
    }
    case 'SET_ROLE_UPDATE_FLAG': case 'SET_VALIDATE_FORM_FLAG': {
      return {
        ...state,
        ...action.payload
      };
    }
    case 'FETCH_ATTRIBUTES_TO_UPDATE_CHILD_USERS_ROLE_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'FETCH_ATTRIBUTES_TO_UPDATE_CHILD_USERS_ROLE_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'FETCH_ATTRIBUTES_TO_UPDATE_CHILD_USERS_ROLE_FAILED': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    default: {
      return state;
    }
  }
};

export default user;
