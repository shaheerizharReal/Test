import { findIndex } from 'lodash';

const initialState = {
  fetching: false,
  users: [],
  total: 0,
  referralCodes: [],
  filters: {},
  sort: {},
  pagination: {
    pageNumber: 1,
    pageSize: Number(localStorage.getItem('usersPerPage'))
  }
};

const users = (state = initialState, action) => {
  switch (action.type) {
    case 'LOAD_DEMO_USER_DATA_REQUEST':
    case 'GET_ALL_USERS_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'GET_ALL_USERS_SUCCESS': {
      return {
        ...state,
        fetching: false,
        ...action.payload
      };
    }
    case 'SET_PAGE_USERS': {
      return {
        ...state,
        pagination: {
          ...state.pagination,
          ...action.payload
        }
      };
    }
    case 'RESET_FILTERS_USERS': {
      return {
        ...state,
        filters: {}
      };
    }
    case 'GET_REFERRAL_CODE_SUCCESS': {
      return {
        ...state,
        ...action.payload
      };
    }
    case 'SET_PAGE_SIZE_USERS': {
      return {
        ...state,
        pagination: {
          ...state.pagination,
          ...action.payload
        }
      };
    }
    case 'SET_FILTER_USERS': {
      let { keyword, filters } = action.payload;
      if (keyword && keyword.value === '') {
        ({ keyword, ...filters } = state.filters);
        return {
          ...state,
          filters: {
            ...filters
          }
        };
      }

      if (keyword && !!keyword.value) {
        return {
          ...state,
          filters: {
            ...state.filters,
            keyword
          }
        };
      }

      ({ keyword, ...filters } = state.filters);

      return {
        ...state,
        filters: {
          keyword,
          ...action.payload
        }
      };
    }
    case 'SET_SORT_FILTERS': {
      return {
        ...state,
        sort: {
          ...action.payload
        }
      };
    }
    case 'SET_USER_STATUS_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'SET_USER_STATUS_SUCCESS': {
      const tempUsers = [...state.users];
      const { _id, status } = action.payload;
      const index = findIndex(tempUsers, { _id });
      tempUsers[index].status = status;

      return {
        ...state,
        fetching: false,
        users: tempUsers
      };
    }
    case 'DELETE_USER_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'DELETE_USER_SUCCESS': {
      let tempUsers = [...state.users];
      const { userId } = action.payload;

      tempUsers = tempUsers.filter(user => !(user._id === userId));

      return {
        ...state,
        fetching: false,
        users: tempUsers
      };
    }
    case 'SET_REFERRAL_CODE_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'SET_REFERRAL_CODE_SUCCESS': {
      const tempUsers = [...state.users];
      const { _id, referralCode } = action.payload;
      const index = findIndex(tempUsers, { _id });
      tempUsers[index].referralCode = referralCode;

      return {
        ...state,
        fetching: false,
        users: tempUsers
      };
    }
    case 'SET_REFERRAL_CODE_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    case 'SET_SIGNED_UP_REQUEST': {
      return {
        ...state,
        fetching: true
      };
    }
    case 'SET_SIGNED_UP_SUCCESS': {
      const tempUsers = [...state.users];
      const { _id, signedUp } = action.payload;
      const index = findIndex(tempUsers, { _id });
      tempUsers[index].signedUp = signedUp;

      return {
        ...state,
        fetching: false,
        users: tempUsers
      };
    }
    case 'LOAD_DEMO_USER_DATA_FAILED':
    case 'LOAD_DEMO_USER_DATA_SUCCESS':
    case 'SET_SIGNED_UP_FAILED': {
      return {
        ...state,
        fetching: false
      };
    }
    default: {
      return state;
    }
  }
};

export default users;
