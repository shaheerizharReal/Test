import React from 'react';
import { connect } from 'react-redux';
import { Route, Switch, Redirect } from 'react-router-dom';
import { Spin } from 'antd';
import AccessControl from 'accesscontrol';

import AdminLayout from '../layouts/AdminLayout.jsx';

import Users from '../pages/Users.jsx';
import AgendaJobs from '../pages/agendaJobs.jsx';
import Affiliates from '../pages/Affiliates.jsx';
import Roles from '../pages/Roles.jsx';

import { getUser, stopAuthLoading } from '../actions/users';

const ContainerRoute = ({ component: Component, ...rest }) => (
  <Route {...rest} render={props => (
    <AdminLayout>
      <Component {...props} />
    </AdminLayout>
   )} />
);

class AdminRoute extends React.Component {
  componentDidMount() {
    const { getUser, stopAuthLoading } = this.props;
    const { loggedIn } = this.props.auth;

    const authToken = localStorage.getItem('loginToken');
    if (!loggedIn && authToken) {
      getUser();
    } else {
      stopAuthLoading();
    }
  }

  render() {
    const { loggedIn, fetching, admin } = this.props.auth;

    if (fetching) {
      return (<Spin tip="Loading..." spinning={true} style={{'marginTop': '20%'}}> </Spin>);
    }

    if (!loggedIn) {
      return (<Redirect to={{ pathname: "/auth/login", state: { from: this.props.location } }} />);
    }

    if (loggedIn && !admin) {
      const { roles } = this.props.user;
      if (roles) {
        const ac = new AccessControl(roles);
        if (ac.can(this.props.user.permission.role).readAny('Dashboard').granted) {
          return (<Redirect to={{ pathname: "/dashboard", state: { from: this.props.location } }} />);
        } else if (ac.can(this.props.user.permission.role).readAny('Inventory').granted) {
          return (<Redirect to={{ pathname: "/inventory", state: { from: this.props.location } }} />);
        }
      }
    }

    return (
      <Switch>
        <ContainerRoute exact path="/admin/" component={Users} />
        <ContainerRoute exact path="/admin/users" component={Users} />
        <ContainerRoute exact path="/admin/jobs" component={AgendaJobs} />
        <ContainerRoute exact path="/admin/affiliates" component={Affiliates} />
        <ContainerRoute exact path="/admin/roles" component={Roles} />
        <Redirect from='*' to='/not-found' />
      </Switch>
    );
  }
}

const mapStateToProps = ({ auth, user }) => ({ auth, user });

const mapDispatchToProps = (dispatch) => ({
  getUser: () => {
    return dispatch(getUser());
  },
  stopAuthLoading: () => {
    return dispatch(stopAuthLoading());
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminRoute)
