import React from 'react';
import { connect } from 'react-redux';
import { Route, Switch, Redirect } from 'react-router-dom';
import { Spin, notification } from 'antd';
import AccessControl from 'accesscontrol';

import AppLayout from '../layouts/AppLayout.jsx';

import Inventory from '../pages/Inventory.jsx';
import Dashboard from '../pages/Dashboard.jsx';
import Settings from '../pages/settings.jsx';
import Payment from '../pages/Payment.jsx';
import InviteUser from '../pages/InviteUser.jsx';
import WhatsNew from '../pages/WhatsNew.jsx';

import { getUser, stopAuthLoading } from '../actions/users';

const ContainerRoute = ({ component: Component, ...rest }) => (
  <Route {...rest} render={props => (
    <AppLayout>
      <Component {...props} />
    </AppLayout>
   )} />
);

class AppRoute extends React.Component {
  componentDidMount() {
    const { getUser, stopAuthLoading } = this.props;
    const { loggedIn } = this.props.auth;

    const authToken = localStorage.getItem('loginToken');
    if (!loggedIn && authToken) {
      getUser();
    } else {
      stopAuthLoading();
    }
  }

  render() {
    const { status, roles } = this.props.user;
    const { loggedIn, fetching, admin } = this.props.auth;
  
    if (fetching) {
      return (<Spin tip="Loading..." spinning={true} style={{'marginTop': '20%'}}> </Spin>);
    }

    if (!loggedIn) {
      return (<Redirect to={{ pathname: "/auth/login", state: { from: this.props.location } }} />);
    }

    if (loggedIn && admin) {
      return (<Redirect to={{ pathname: "/admin/users", state: { from: this.props.location } }} />);
    }
    
    if (roles) {
      const ac = new AccessControl(roles);
  
      if (status === 'Trial Expire' && this.props.location.pathname !== "/payment") {
        notification.warn({
          message: 'Trial Expires',
          description: 'Your Trial Duration is Finished. Kindly, Take a Plan which suits you the best.',
          style: {
            width: 350
          },
          duration: 5
        });
        return (<Redirect to={{ pathname: "/payment", state: { from: this.props.location } }} />);
      }
  
      return (
        <Switch>
          {
            (ac.can(this.props.user.permission.role).readAny('Dashboard').granted) ?
            <ContainerRoute exact path="/dashboard" component={Dashboard} /> :
              null
          }
          {
            (ac.can(this.props.user.permission.role).readAny('Inventory').granted) ?
            <ContainerRoute exact path="/inventory" component={Inventory} /> :
              null
          }
          <ContainerRoute path="/settings" component={Settings} />
          {
            (ac.can(this.props.user.permission.role).readAny('Payment').granted) ?
              <ContainerRoute exact path="/payment" component={Payment} /> :
              null
          }
          {
            (ac.can(this.props.user.permission.role).readAny('Invite User').granted) ? 
              <ContainerRoute exact path="/invite-user" component={InviteUser} /> :
              null
          }
          {
            (ac.can(this.props.user.permission.role).readAny('Whats New').granted) ? 
              <ContainerRoute exact path="/whats-new" component={WhatsNew} /> :
              null
          }
          <Redirect from='*' to='/not-found' />
        </Switch>
      );
    } else {
      return null;
    }
  }
}

const mapStateToProps = ({ auth, user }) => ({ auth, user });

const mapDispatchToProps = (dispatch) => ({
  getUser: () => {
    return dispatch(getUser());
  },
  stopAuthLoading: () => {
    return dispatch(stopAuthLoading());
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(AppRoute)
