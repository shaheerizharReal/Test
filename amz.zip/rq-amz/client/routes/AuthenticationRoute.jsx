import React from 'react';
import { connect } from 'react-redux';
import { Route, Switch, Redirect } from 'react-router-dom';
import { Spin } from 'antd';
import AccessControl from 'accesscontrol';

import EmptyLayout from '../layouts/EmptyLayout.jsx';

import Register from '../components/authentication/Register.jsx';
import Login from '../components/authentication/Login.jsx';
import ForgotPassword from '../components/authentication/ForgotPassword.jsx';
import ResetPassword from '../components/authentication/ResetPassword.jsx';

import { getUser, stopAuthLoading } from '../actions/users';

const ContainerRoute = ({ component: Component, ...rest }) => (
  <Route {...rest} render={props => (
    <EmptyLayout>
      <Component {...props} />
    </EmptyLayout>
   )} />
);

class AuthenticationRoute extends React.Component {
  componentDidMount() {
    const { getUser, stopAuthLoading } = this.props;
    const { loggedIn } = this.props.auth;

    const authToken = localStorage.getItem('loginToken');
    if (!loggedIn && authToken) {
      getUser();
    } else {
      stopAuthLoading();
    }
  }

  render() {
    const { loggedIn, fetching, admin } = this.props.auth;

    if (fetching) {
      return (<Spin tip="Loading..." spinning={true} style={{'marginTop': '20%'}}> </Spin>);
    }

    if (loggedIn) {
      if (admin) {
        return (<Redirect to={{ pathname: "/admin", state: { from: this.props.location } }} />);
      }
      const { roles } = this.props.user;
      if (roles) {
        const ac = new AccessControl(roles);
        if (ac.can(this.props.user.permission.role).readAny('Dashboard').granted) {
          return (<Redirect to={{ pathname: "/dashboard", state: { from: this.props.location } }} />);
        } else if (ac.can(this.props.user.permission.role).readAny('Inventory').granted) {
          return (<Redirect to={{ pathname: "/inventory", state: { from: this.props.location } }} />);
        }
      }
    }

    return (
      <Switch>
        <ContainerRoute exact path="/auth/login" component={Login} />
        <ContainerRoute exact path="/auth/register" component={Register} />
        <ContainerRoute exact path="/auth/forgot-password" component={ForgotPassword} />
        <ContainerRoute exact path="/auth/reset/:resetPasswordToken" component={ResetPassword} />
        <Redirect from='*' to='/not-found' />
      </Switch>
    );
  }
}

const mapStateToProps = ({ auth, user }) => ({ auth, user });

const mapDispatchToProps = (dispatch) => ({
  getUser: () => {
    return dispatch(getUser());
  },
  stopAuthLoading: () => {
    return dispatch(stopAuthLoading());
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(AuthenticationRoute)
