import { applyMiddleware, createStore } from 'redux';
import thunk from 'redux-thunk';
import { createLogger } from 'redux-logger';
import { createBrowserHistory } from 'history';

import reducers from './reducers';

export const history = createBrowserHistory();

const store = createStore(
  reducers,
  applyMiddleware(thunk, createLogger())
);

export default store;
