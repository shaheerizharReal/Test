const ChooseDefaultCalculationPrice = ({
  profitCalculatedBy,
  listPrice,
  buyBoxPrice,
  lowestOfferPrice,
  lowestFBAOfferPrice
}) => {
  if (profitCalculatedBy === 'buyBoxPrice') return buyBoxPrice || listPrice;
  if (profitCalculatedBy === 'lowestOfferPrice') return lowestOfferPrice || listPrice;
  if (profitCalculatedBy === 'lowestFBAOfferPrice') return lowestFBAOfferPrice || listPrice;
  return listPrice;
};

export default ChooseDefaultCalculationPrice;
