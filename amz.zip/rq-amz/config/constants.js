export const CONDITION_TYPE = {
  NEW: {
    label: 'New',
    value: 11,
    amazon: 'NewItem'
  },
  USED_LIKE_NEW: {
    label: 'Used Like New',
    value: 1,
    amazon: 'UsedLikeNew'
  },
  USED_VERY_GOOD: {
    label: 'Used Very Good',
    value: 2,
    amazon: 'UsedVeryGood'
  },
  USED_GOOD: {
    label: 'Used Good',
    value: 3,
    amazon: 'UsedGood'
  },
  USED_ACCEPTABLE: {
    label: 'Used Acceptable',
    value: 4,
    amazon: 'UsedAcceptable'
  },
  COLLECTIBLE_LIKE_NEW: {
    label: 'Collectible Like New',
    value: 5,
    amazon: 'CollectibleLikeNew'
  },
  COLLECTIBLE_VERY_GOOD: {
    label: 'Collectible Very Good',
    value: 6,
    amazon: 'CollectibleVeryGood'
  },
  COLLECTIBLE_GOOD: {
    label: 'Collectible Good',
    value: 7,
    amazon: 'CollectibleGood'
  },
  COLLECTIBLE_ACCEPTABLE: {
    label: 'Collectible Acceptible',
    value: 8,
    amazon: 'CollectibleAcceptible'
  },
  UNACCEPTABLE: {
    label: 'Unacceptable',
    value: 9,
    amazon: 'Unacceptable'
  },
  REFURBISHED: {
    label: 'Refurbished',
    value: 10,
    amazon: 'Refurbished'
  }
};

export const IGNORE_FIELDS = [
  'asin',
  'asin1',
  'asin2',
  'asin3',
  'sellersku',
  'sku',
  'productid',
  'fnsku',
  'fulfillmentnetworksku',
  'merchantorderid',
  'amazonorderid',
  'generatedreportid',
  'reportrequestid',
  'feedsubmissionid',
  'postalcode',
  'idvalue'
];

export const FULLFILMENT_TYPE = {
  AMAZON: 'AFN',
  MERCHANT: 'MFN',
  EBAY: 'EBAY'
};

export const JOB_STATES = {
  STARTED: '_STARTED_',
  IN_PROGRESS: '_IN_PROGRESS_',
  SAVING: '_SAVING_',
  COMPLETED: '_COMPLETED_',
  FAILED: '_FAILED_',
  NEXT: '_NEXT_'
};

export const PRODUCT_ID_TYPE = {
  ASIN: 1,
  ISBN: 2,
  UPC: 3,
  EAN: 4
};

export const RETRYABLE_ERRORS = [
  'getaddrinfo ENOTFOUND',
  'connect ETIMEDOUT',
  'ECONNRESET',
  'EPIPE',
  'internal error',
  'throttl',
  'quota will reset',
  'Service temporarily unavailable',
  'Internal service error',
  'empty response',
  'Unexpected close tag',
  'Unclosed root tag',
  'no message',
  'socket hang up',
  '502 Bad Gateway',
  'Service Unavailable',
  'errors/mws.amazonservices.com/500.html'
];

export const MONTHLY_STORAGE_FEE = {
  STANDARD: {
    JAN_SEP: 0.75,
    OCT_DEC: 2.40
  },
  OVERSIZE: {
    JAN_SEP: 0.48,
    OCT_DEC: 1.20
  },
  JAN_SEP: [1, 2, 3, 4, 5, 6, 7, 8, 9],
  OCT_DEC: [10, 11, 12]
};

export const VALID_STATUS_OF_USER = ['Active', 'Trial', 'Trial Expire', 'Free', 'Child User'];
