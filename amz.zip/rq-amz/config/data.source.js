import React from 'react';

export const NavbarDataSource = {
  wrapper: { className: 'header0 home-page-wrapper' },
  page: { className: 'home-page' },
  logo: {
    className: 'header0-logo',
    children: '../client/public/images/replen-dashboard_logo.svg',
  },
  Menu: {
    className: 'header0-menu',
    children: [
      // {
      //   name: 'item0',
      //   className: 'header0-item',
      //   children: {
      //     href: '/',
      //     children: [{ children: 'Pricing & Plans', name: 'text' }],
      //   },
      // },
      // {
      //   name: 'item1',
      //   className: 'Privacy Policy',
      //   children: {
      //     href: '/privacy-policy',
      //     children: [{ children: 'Privacy Policy', name: 'text' }],
      //   },
      // },
      // {
      //   name: 'item2',
      //   className: 'header0-item',
      //   children: {
      //     href: '/terms-and-condition-policy',
      //     children: [{ children: 'Terms and Condition Policy', name: 'text' }],
      //   },
      // },
      {
        name: 'item3',
        className: 'header0-item',
        children: {
          href: '/auth/login',
          children: [{ children: 'Login', name: 'text' }],
        },
      },
      {
        name: 'item4',
        className: 'header0-item',
        children: {
          href: '/auth/register',
          children: [{ children: 'Register', name: 'text' }],
        },
      },
    ],
  },
  mobileMenu: { className: 'header0-mobile-menu' },
};

export const BannerDataSource = {
  wrapper: { className: 'banner0' },
  textWrapper: { className: 'banner0-text-wrapper' },
  title1: {
    className: 'banner0-title-1',
    children: 'Restocking Software Designed for Amazon Arbitrage and Wholesale Sellers',
    // children: 'https://zos.alipayobjects.com/rmsportal/HqnZZjBjWRbjyMr.png',
  },
  // title2: {
  //   className: 'banner0-title-2',
  //   children: 'Designed for Amazon Arbitrage Sellers and Wholesale Sellers',
  //   // children: 'https://zos.alipayobjects.com/rmsportal/HqnZZjBjWRbjyMr.png',
  // },
  content: {
    className: 'banner0-content',
    children: ' Replen Dashboard was designed to help Amazon sellers know when to replenish their inventory, how many to purchase based on their sales data, and see real time inventory data for sales rank, profit, FBA fees, costs, and competitor pricing.',
  },
  button: { className: 'banner0-button', children: 'Learn More' },
};

export const PartnerDataSource = {
  wrapper: { className: 'home-page-wrapper content0-wrapper' },
  page: { className: 'home-page content0' },
  OverPack: { playScale: 0.3, className: '' },
  titleWrapper: {
    className: 'title-wrapper',
    children: [{ name: 'title', children: 'Partners' }],
  },
  childWrapper: {
    className: 'content0-block-wrapper',
    children: [
      {
        name: 'block0',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://d1aettbyeyfilo.cloudfront.net/ryanreger/3966007_1555097977292Legends_Logo_New_800_pixels.png',
            },
            {
              name: 'title',
              className: 'content0-block-title',
              // children: 'Amazon Legends',
              children: '',
              href:'https://ko296.isrefer.com/go/lgnd/jdsbls0410/'
            },
            // { name: 'content', children: 'J' },
          ],
        },
      },
      // {
      //   name: 'block1',
      //   className: 'content0-block',
      //   md: 8,
      //   xs: 24,
      //   children: {
      //     className: 'content0-block-item',
      //     children: [
      //       {
      //         name: 'image',
      //         className: 'content0-block-icon',
      //         children:
      //           'https://cdn.drawception.com/images/panels/2012/4-4/kTr3qedQxg-2.png',
      //       },
      //       {
      //         name: 'title',
      //         className: 'content0-block-title',
      //         children: '',
      //       },
      //       // {
      //       //   name: 'content',
      //       //   children: 'L',
      //       // },
      //     ],
      //   },
      // },
      {
        name: 'block2',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://www.fbainsiders.co/wp-content/uploads/2019/06/FBA-Insiders-Logo-500px.png',
            },
            {
              name: 'title',
              className: 'content0-block-title',
              // children: 'FBA Insiders',
              children: '',
              href: 'https://www.fbainsiders.co/retail-arbitrage-made-easy/?ref=17'
            },
            // {
            //   name: 'content',
            //   children: 'N',
            // },
          ],
        },
      },
    ],
  },
};

export const ReplenUseDataSource = {
  wrapper: { className: 'home-page-wrapper content3-wrapper' },
  page: { className: 'home-page content3' },
  OverPack: { playScale: 0.3 },
  titleWrapper: {
    className: 'title-wrapper',
    children: [
      {
        name: 'title',
        children: 'Why Should I Use Replen Dashboard?',
        className: 'title-h1',
      },
      // {
      //   name: 'content',
      //   className: 'title-content',
      //   children: 'R',
      // },
    ],
  },
  block: {
    className: 'content3-block-wrapper',
    children: [
      {
        name: 'block0',
        className: 'content3-block',
        md: 4,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children: ''
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: '' },
          content: {
            className: 'content3-content',
            children: ''
          },
        },
      },
      {
        name: 'block1',
        className: 'content3-block',
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children:
              'https://zos.alipayobjects.com/rmsportal/ScHBSdwpTkAHZkJ.png',
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: " Don't Lose Money by Running Out of Stock" },
          content: {
            className: 'content3-content',
            children:
              "The worst thing for your business is to run out of stock of popular products and never realizing that you were close to being out of stock. Replen Dashboard helps to eliminate this problem by showing you how many sales you've had in the past 30 days and how many products you need to send in based on that data.",
          },
        },
      },
      {
        name: 'block2',
        className: 'content3-block',
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children:
              'https://zos.alipayobjects.com/rmsportal/NKBELAOuuKbofDD.png',
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: "Make Fast and Accurate Buying Decisions" },
          content: {
            className: 'content3-content',
            children:
              "It's easy to get lost inside multiple software programs or Amazon reports. We've aggregated all of the important information you need such as Sales Data, Competitor Pricing, Profit and ROI amounts, Buy Quantities, and so much more for you to be able to make a fully informed rebuying decision.",
          },
        },
      },
      {
        name: 'block3',
        className: 'content3-block',
        md: 4,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children: ''
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: '' },
          content: {
            className: 'content3-content',
            children: ''
          },
        },
      },
      {
        name: 'block4',
        className: 'content3-block',
        md: 4,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children: ''
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: '' },
          content: {
            className: 'content3-content',
            children: ''
          },
        },
      },
      {
        name: 'block5',
        className: 'content3-block',
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children:
              'https://zos.alipayobjects.com/rmsportal/MNdlBNhmDBLuzqp.png',
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: 'Customize Replen Dashboard to Your Needs' },
          content: {
            className: 'content3-content',
            children:
            "Our dashboard is fully customizable so that you can see exactly the data you need in front of you. Additionally, our easy-to-export reports allow you to select the information you want downloaded from the inventory you selected.",
          },
        },
      },
      {
        name: 'block6',
        className: 'content3-block',
        md: 8,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children:
              'https://zos.alipayobjects.com/rmsportal/UsUmoBRyLvkIQeO.png',
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: 'Manage Your Online Arbitrage Products' },
          content: {
            className: 'content3-content',
            children:
              " We know it can be stressful when you need to buy more OA products and don't have a good system for finding it again. We've included the ability to input your OA links so that you can quickly repurchase without the hassle of searching for the product again.",
          },
        },
      },
      {
        name: 'block7',
        className: 'content3-block',
        md: 4,
        xs: 24,
        children: {
          icon: {
            className: 'content3-icon',
            children: ''
          },
          textWrapper: { className: 'content3-text' },
          title: { className: 'content3-title', children: '' },
          content: {
            className: 'content3-content',
            children: ''
          },
        },
      },
    ],
  },
};

export const FooterDataSource = {
  wrapper: { className: 'home-page-wrapper footer1-wrapper' },
  OverPack: { className: 'footer1', playScale: 0.2 },
  block: {
    className: 'home-page',
    gutter: 0,
    children: [
      {
        name: 'block0',
        xs: 24,
        md: 6,
        className: 'block',
        title: {
          className: 'logo',
          children:
            '../client/public/images/replen-dashboard_logo.svg',
        },
        childWrapper: {
          className: 'slogan',
          children: [
            {
              name: 'content0',
              children: '', // We help Ecom Sellers.
            },
          ],
        },
      },
      {
        name: 'block1',
        xs: 24,
        md: 6,
        className: 'block',
        title: { children: 'Our Policies' },
        childWrapper: {
          children: [
            { name: 'link0', href: '/privacy-policy', children: 'Privacy Policy' },
            { name: 'link1', href: '/term-and-condition-policy', children: 'Terms and Condition Policy' },
          ],
        },
      },
      // {
      //   name: 'block2',
      //   xs: 24,
      //   md: 6,
      //   className: 'block',
      //   title: { children: 'E1' },
      //   childWrapper: {
      //     children: [
      //       { href: '#', name: 'link0', children: 'FAQ' },
      //       { href: '#', name: 'link1', children: 'F1' },
      //     ],
      //   },
      // },
      {
        name: 'block3',
        xs: 24,
        md: 6,
        className: 'block',
        title: { children: 'Contact us' },
        childWrapper: {
          children: [
            { name: 'link0', children: '+971 358 1234567' },
            { href: '#', name: 'link1', children: 'admin@replendashboard.com' },
          ],
        },
      },
    ],
  },
  copyrightWrapper: { className: 'copyright-wrapper' },
  copyrightPage: { className: 'home-page' },
  copyright: {
    className: 'copyright',
    children: (
      <>
        <span>
          ©2019 by <a target="_blank" href="https://www.qbatch.com">Qbatch</a> All Rights
          Reserved
        </span>
      </>
    ),
  },
};

export const PrivacyPolicyDataSource = {
  wrapper: { className: 'PrivacyPolicy' },
  textWrapper: { className: 'banner0-text-wrapper' },
  c1: {
    title: 'KJS E-Commerce Solutions LLC Privacy Policy',
    content: "This Privacy Policy describes KJS eCommerce Solutions' and its subsidiaries (collectively 'KJS eCommerce Solutions'), practices regarding the collection, and the use and disclosure of the information we collect from and about you when you use KJS eCommerce Solutions' web-based and mobile applications(the 'Service'), which includes the use of this Site - ",
    content1: " and it’s included domains/subdomains. We take our obligations regarding your privacy seriously and have made every effort to draft this Privacy Policy in a manner that is clear and easy for you to understand. By accessing or using the Service, you agree to this Privacy Policy and Terms of Service.",
    // children: 'https://zos.alipayobjects.com/rmsportal/HqnZZjBjWRbjyMr.png',
  },
  c2: {
    title: 'PERSONAL INFORMATION WE COLLECT',
    content: ' When you visit the Site, we automatically collect certain information about your device, including information about your web browser, IP address, time zone, and some of the cookies that are installed on your device. Additionally, as you browse the Site, we collect information about the individual web pages or products that you view, what websites or search terms referred you to the Site, and information about how you interact with the Site. We refer to this automatically-collected information as "Device Information."',
  },
  c3: {
    title: 'Our Collection and Use of Information You Provide to Us',
    content1: 'In order to set up a user account for use of the Service, we collect personal information, such as your name, address, phone number, email address, payment information, and Amazon account data when you register for an account on the Service. You may also provide us with optional information such as a photograph, your user name, and any optional profile information that you elect to associate with your account is referred to herein as your "Profile Information." KJS eCommerce Solutions maintains this information indefinitely for record purposes.',
    content2: 'If you are a user of our paid Service, we will utilize a third party credit card payment processing company to collect payment information, including your credit card number, billing address, and phone number. We will share this payment information with the third party processing company as detailed below in "How We Share Your Information: With Trusted Service Providers And Business Partners." We do not store your payment information.',
    content3: 'We may use your email address to send you Service-related notices (including any notices required by law, in lieu of communication by postal mail). We may also use your email address to send you announcements and information about other products or services (including third-party services) that you may be interested in (together, the "Marketing Messages"). You may opt-out of receiving Marketing Messages at any time by following the instructions provided in the Marketing Message. Through your account interface, you may also opt-out of receiving categories of Service-related notices that are not deemed by KJS eCommerce Solutions to be integral to your use of the Service.',
    content4: 'Even if you are not a registered user of our Service, if you email us we may retain a record of such email communication, including your email address, the content of your email, and our response indefinitely.',
    content5: "If you choose to use our invitation service to invite a friend to the Service, we will ask you for that person's contact information, which may include their email address or their social network identity, and automatically send an invitation. KJS eCommerce Solutions stores the information you provide to send the invitation, to register your friend if your invitation is accepted, and to track the success of our invitation service.",
  },
  c4: {
    title: 'Your Content',
    content: ' Your use of the Service will involve you uploading or inputting various content into the Service; including but not limited to: tasks, attachments, project names, team names, and conversations (together, the "Content").',
    content1: ' You control how your Content is shared with others via your settings on the Service. KJS eCommerce Solutions may view your Content only as necessary (i) to maintain, provide and improve the Service; (ii) to resolve a support request from you; (iii) if we have a good faith belief, or have received a complaint alleging, that such Content is in violation of our Acceptable Use Guidelines; (iv) as reasonably necessary to allow KJS eCommerce Solutions to comply with or avoid the violation of applicable law or regulation; or (v) to comply with a valid legal subpoena or request that meets the requirements of our Law Enforcement Guidelines. We may also analyze the Content in aggregate and on an anonymized basis, in order to better understand the manner in which our Service is being used.',
    // content2: ' Screen our orders for potential risk or fraud',
    // content3: ' When in line with the preferences you have shared with us, provide you with information or advertising relating to our products or services.',
    // content4: ' We use the Device Information that we collect to help us screen for potential risk and fraud (in particular, your IP address), and more generally to improve and optimize our Site (for example, by generating analytics about how our customers browse and interact with the Site, and to assess the success of our marketing and advertising campaigns).',
    // content5: ' We may also use this information in our advertising efforts to better focus on our target customer.',
  },
  c5: {
    title: 'Information We Collect Automatically',
    content1: ' We use technologies like cookies and pixel tags to provide, monitor, analyze, promote, and improve the Service. For example, a cookie is used to remember your user name when you return to the Service and to improve our understanding of how you interact with the Service. You can block cookies on your web browser; however, please be aware that some features of the Service may not function properly if the ability to accept cookies is disabled. While we collect this information automatically, at no time is your personal information ever used to make automated decisions for the Service provided or the Company as a whole.',
    // content2: ' Finally, we may also share your Personal Information to comply with applicable laws and regulations, to respond to a subpoena, search warrant or other lawful request for information we receive, or to otherwise protect our rights.',
  },
  c6: {
    title: 'Embedded Content',
    content1: " This site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.",
    content2: ' These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracing your interaction with the embedded content if you have an account and are logged in to that website.',
    // FB Google Bing
    // content3: " Additionally, you can opt out of some of these services by visiting the Digital Advertising Alliance's opt-out portal at:  http://optout.aboutads.info/.",
  },
  c7: {
    title: 'Log Files',
    content: " When you use the Service, our servers automatically record certain information in server logs. These server logs may include information such as your web request, Internet Protocol ('IP') address, browser type, referring/exit pages and URLs, number of clicks and how you interact with links on the Service, domain names, landing pages, pages viewed, mobile carrier, and other such information. Log files help us to monitor, analyze, improve, and maintain the Service and to diagnose and fix any Service-related issues.",
  },
  c8: {
    title: 'Device Identifiers',
    content1: " When you access the Service using a mobile device, we collect specific device information contained in your mobile device's 'device identifier.' This device identifier includes information such as the type of device you are using, its operating system, and mobile network information, which may include your mobile phone number. We may associate this device identifier with your Service account and will use data associated with your device identifier to customize our Services to your device and to analyze any device-related issues.",
    // content2: ' Additionally, if you are a European resident we note that we are processing your information in order to fulfill contracts we might have with you (for example if you make an order through the Site), or otherwise to pursue our legitimate business interests listed above.  Additionally, please note that your information will be transferred outside of Europe, including to Canada and the United States.',
  },
  c9: {
    title: ' How We Share Your Information',
    content: ' We may share the information we collect from you with third parties as detailed below.'
  },
  c10: {
    title: ' As Directed By You',
    content: ' We will display your Profile information on your profile page and elsewhere on the Service in accordance with the preferences you set in your account. You can review and revise your Profile information at any time.'
  },
  c11: {
    title: ' We Will Display Your Content Within The Service As Directed By You',
    content: ' If you elect to give access to a third-party application, then we may share or disclose your account and Profile information and your Content with that third-party application as directed by you. Please remember that we are not responsible for the privacy practices of such third parties, so you should make sure you trust the application and that it has a privacy policy acceptable to you.',
    // content1: '1302 W Lark Industrial Dr. Fenton, MO 63026',
  },
  c12: {
    title: 'With Trusted Service Providers and Business Partners',
    content1: " We may utilize trusted third party service providers to assist us in delivering our Service. For example, we may use third parties to help host our Service, send out email updates, or process payments. These service providers may have access to your information for the limited purpose of providing the service we have contracted with them to provide. They are required to have a privacy policy and security standards in place that are at least as protective of your information as is this Privacy Policy. We may also store personal information in locations outside the direct control of KJS eCommerce Solutions (for instance, on servers or databases co-located with hosting providers).",
    content2: ' The US-based third-party service providers utilized by KJS eCommerce Solutions are as follows:'
  },
  c12Links: {
    l1: {
      address: 'https://aws.amazon.com/compliance/data-privacy-faq/',
      clickableText: 'Amazon Web Services',
      remainingText: ' - cloud services provider'
    },
    l2: {
      address: 'http://www.stripe.com',
      clickableText: 'Stripe',
      remainingText: ' - payment Processing Services'
    },
    l3: {
      address: 'https://www.zendesk.com/company/customers-partners/privacy-policy/',
      clickableText: 'Zendesk',
      remainingText: ' - help desk software'
    },
    l4: {
      address: 'http://www.mailchimp.com',
      clickableText: 'Mailchimp',
      remainingText: ' - email newsletter service'
    },
    l5: {
      address: 'https://policies.google.com/privacy?hl=en&gl=us',
      clickableText: 'Google Analytics',
      remainingText: ' - web analytics service'
    },
    l6: {
      address: 'https://basecamp.com/about/policies/privacy',
      clickableText: 'Basecamp',
      remainingText: ' - project management software'
    },
    l7: {
      address: 'https://www.atlassian.com/legal/privacy-policy',
      clickableText: 'Atlassian/Jira',
      remainingText: ' - bug reporting and tracking software'
    },
  },
  c13: {
    title: 'With Law Enforcement or In Order to Protect Our Rights',
    content1: " We may disclose your information (including your personally identifiable information) if required to do so by law or subpoena and if the relevant request meets our Law Enforcement Guidelines. We may also disclose your information to our legal counsel, governmental authorities, or law enforcement if we believe that it is reasonably necessary to do so in order to comply with a law or regulation; to protect the safety of any person; to address fraud, security or technical issues; or to protect KJS eCommerce Solutions's rights or property.",
  },
  c14: {
    title: 'In an Aggregate and Non-Personally Identifiable Manner',
    content1: " We may disclose aggregate non-personally identifiable information (such as aggregate and anonymous usage data, platform types, etc.) about the overall use of our Service publicly or with interested third parties to help them understand, or to help us improve, the Service.",
  },
  c15: {
    title: 'In Connection With a Sale or Change of Control',
    content1: " If the ownership of all or substantially all of our business changes, we may transfer your information to the new owner so that the Service can continue to operate. In such case, your information would remain subject to the promises and commitments contained in this Privacy Policy until such time as this Privacy Policy is updated or amended by the acquiring party upon notice to you.",
  },
  c16: {
    title: 'Specific Sensitive Information',
    content1: " KJS eCommerce Solutions does not collect or process the following sensitive personal information at any time for any reason: Social Security number, gender, race or ethnic origin, political opinions, religious or philosophical beliefs, trade union memberships, genetic or biometric data, health or mortality, sex life or sexual orientation.",
  },
  c17: {
    title: 'How We Protect Your Information',
    content1: " The security of your information is important to us. When you enter sensitive information (such as a credit card number) as part of our service, we encrypt the transmission of that information using industry-standard encryption.",
    content2: ' KJS eCommerce Solutions uses commercially reasonable and industry-standard physical, managerial, and technical safeguards to preserve the integrity and security of your information. For example, we continuously and regularly back up your data to help prevent data loss and aid in data recovery. We also guard against common web attack vectors.',
    content3: ' If you have any questions about security on our Service, you can contact us at '
  },
  c18: {
    title: 'Risks Inherent in Sharing Information',
    content1: " Although we allow you control over where you share your Content and what information is included in your Profile and take reasonable steps to maintain the security of the information associated with your account, please be aware that no security measures are perfect or impenetrable. We cannot control the actions of other users with whom you share your Content and we are not responsible for third party circumvention of any privacy settings or security measures on the Service.",
  },
  c19: {
    title: 'Your Choices About Your Information',
    content1: " You may, of course, decline to submit personally identifiable information through the Service, in which case KJS eCommerce Solutions may not be able to provide certain services to you. You may update or correct your account information at any time by logging in to your account.",
  },
  c20: {
    title: 'KJS eCommerce Solutions Blogs/Facebook Page',
    content1: " Information you provide in comments to our blogs/Facebook Page are public and may be read, collected, and used by others who view those sites. Your posts will remain even after you cancel your Service account. KJS eCommerce Solutions is not liable for any messages kept on personal social media pages either by the customer or any KJS eCommerce Solutions employee.",
  },
  c21: {
    title: "Children's Privacy",
    content1: " Our Service is not directed to persons under 18. KJS eCommerce Solutions does not knowingly collect or solicit personal information from anyone under the age of 18 or knowingly allow such persons to register for an account on the Service. If we become aware that we have collected personal information from a child under age 18 without verification of parental consent, we take steps to remove that information. If you believe that we might have any information from or about a child under 18, please contact us at ",
  },
  c22: {
    title: 'International Data Transfer',
    content1: " We may transfer information that we collect about you, including personally identifiable information, to affiliated entities, or to other third parties (as provided herein) across borders and from your country or jurisdiction to other countries or jurisdictions around the world for customer service and support activities. If you are located in the European Union or other regions with laws governing data collection and use that may differ from U.S. law, please note that you are transferring information, including personal information, to a country and jurisdiction that does not have the same data protection laws as your jurisdiction, and you consent to the transfer of information to the U.S. and the use and disclosure of information about you, including personal information, as described in this Privacy Policy.",
  },
  c23: {
    title: 'Links to Other Websites',
    content1: " We are not responsible for the practices employed by websites linked to from within the Service, nor the information or content contained therein. Please remember that when you use a link to go from the Service to another website, our Privacy Policy is no longer in effect and your activities on that third party website is subject to such third party website's own rules and policies.",
  },
  c24: {
    title: 'Do Not Track Signals',
    content1: `Some browsers have a "do not track" feature that lets you tell websites that you do not want to have your online activities tracked. We currently do not respond to "do not track" signals.`,
  },
  c25: {
    title: 'Changes to Our Privacy Policy',
    content1: " If we change our Privacy Policy, we will post those changes on this page to keep you aware of what information we collect, how we use it, and under what circumstances we may disclose it. Changes to this Privacy Policy are effective when they are posted on this page.",
  },
  c26: {
    title: 'Contact Us',
    content1: " For questions about these or any KJS eCommerce Solutions terms or policies, email us at ",
  },
  button: { className: 'banner0-button', children: 'Learn More' },
};

export const TermAndConditionDataSource = {
  wrapper: { className: 'TermAndCondition' },
  textWrapper: { className: 'banner0-text-wrapper' },
  c: {
    title: ' OVERVIEW',
    content1: ' This website is operated by KJS eCommerce Solutions LLC. Throughout the site, the terms "we", "us" and "our" refer to KJS eCommerce Solutions LLC. KJS eCommerce Solutions LLC offers this website, including all information, tools and services available from this site to you, the user, conditioned upon your acceptance of all terms, conditions, policies and notices stated here.',
    content2: ' By visiting our site (www.replendashboard.com and all pages associated with it) and/ or purchasing something from us, you engage in our "Service" and agree to be bound by the following terms and conditions ("Terms of Service", "Terms"), including those additional terms and conditions and policies referenced herein and/or available by hyperlink. These Terms of Service apply  to all users of the site, including without limitation users who are browsers, vendors, customers, merchants, and/ or contributors of content.',
    content3: ' Please read these Terms of Service carefully before accessing or using our website. By accessing or using any part of the site, you agree to be bound by these Terms of Service. If you do not agree to all the terms and conditions of this agreement, then you may not access the website or use any services. If these Terms of Service are considered an offer, acceptance is expressly limited to these Terms of Service.',
    content4: ' Any new features or tools which are added to the current store shall also be subject to the Terms of Service. You can review the most current version of the Terms of Service at any time on this page. We reserve the right to update, change or replace any part of these Terms of Service by posting updates and/or changes to our website. It is your responsibility to check this page periodically for changes. Your continued use of or access to the website following the posting of any changes constitutes acceptance of those changes.',
    content5: ' Our store is hosted on Amazon MWS. They provide us with the online platform that allows us to sell our products and services to you.',
  },
  c1: {
    title: ' ONLINE STORE TERMS',
    content1: ' By agreeing to these Terms of Service, you represent that you are at least the age of majority in your state or province of residence, or that you are the age of majority in your state or province of residence and you have given us your consent to allow any of your minor dependents to use this site.',
    content2: ' You may not use our products for any illegal or unauthorized purpose nor may you, in the use of the Service, violate any laws in your jurisdiction (including but not limited to copyright laws).',
    content3: ' You must not transmit any worms or viruses or any code of a destructive nature.',
    content4: ' A breach or violation of any of the Terms will result in an immediate termination of your Services.',
  },
  c2: {
    title: ' GENERAL CONDITIONS',
    content1: ' We reserve the right to refuse service to anyone for any reason at any time.',
    content2: ' You understand that your content (not including credit card information), may be transferred unencrypted and involve (a) transmissions over various networks; and (b) changes to conform and adapt to technical requirements of connecting networks or devices. Credit card information is always encrypted during transfer over networks.',
    content3: ' You agree not to reproduce, duplicate, copy, sell, resell or exploit any portion of the Service, use of the Service, or access to the Service or any contact on the website through which the service is provided, without express written permission by us.',
    content4: ' The headings used in this agreement are included for convenience only and will not limit or otherwise affect these Terms.',
  },
  c3: {
    title: ' ACCURACY, COMPLETENESS AND TIMELINESS OF INFORMATION',
    content1: ' We are not responsible if information made available on this site is not accurate, complete or current. The material on this site is provided for general information only and should not be relied upon or used as the sole basis for making decisions without consulting primary, more accurate, more complete or more timely sources of information. Any reliance on the material on this site is at your own risk.',
    content2: ' This site may contain certain historical information. Historical information, necessarily, is not current and is provided for your reference only. We reserve the right to modify the contents of this site at any time, but we have no obligation to update any information on our site. You agree that it is your responsibility to monitor changes to our site.',
  },
  c4: {
    title: ' MODIFICATIONS TO THE SERVICE AND PRICES',
    content1: ' Prices for our products are subject to change without notice.',
    content2: ' We reserve the right at any time to modify or discontinue the Service (or any part or content thereof) without notice at any time.',
    content3: ' We shall not be liable to you or to any third-party for any modification, price change, suspension or discontinuance of the Service.',
  },
  c5: {
    title: ' PRODUCTS OR SERVICES (if applicable)',
    content1: ' Certain products or services may be available exclusively online through the website. These products or services may have limited quantities and are subject to return or exchange only according to our Return Policy.',
    content2: " We have made every effort to display as accurately as possible the colors and images of our products that appear at the store. We cannot guarantee that your computer monitor's display of any color will be accurate.",
    content3: ' We reserve the right, but are not obligated, to limit the sales of our products or Services to any person, geographic region or jurisdiction. We may exercise this right on a case-by-case basis. We reserve the right to limit the quantities of any products or services that we offer. All descriptions of products or product pricing are subject to change at anytime without notice, at the sole discretion of us. We reserve the right to discontinue any product at any time. Any offer for any product or service made on this site is void where prohibited.',
    content4: ' We do not warrant that the quality of any products, services, information, or other material purchased or obtained by you will meet your expectations, or that any errors in the Service will be corrected.',
  },
  c6: {
    title: ' ACCURACY OF BILLING AND ACCOUNT INFORMATION',
    content1: ' We reserve the right to refuse any order you place with us. We may, in our sole discretion, limit or cancel quantities purchased per person, per household or per order. These restrictions may include orders placed by or under the same customer account, the same credit card, and/or orders that use the same billing and/or shipping address. In the event that we make a change to or cancel an order, we may attempt to notify you by contacting the e-mail and/or billing address/phone number provided at the time the order was made. We reserve the right to limit or prohibit orders that, in our sole judgment, appear to be placed by dealers, resellers or distributors.',
    content2: ' You agree to provide current, complete and accurate purchase and account information for all purchases made at our store. You agree to promptly update your account and other information, including your email address and credit card numbers and expiration dates, so that we can complete your transactions and contact you as needed.',
  },
  c7: {
    title: ' OPTIONAL TOOLS',
    content1: ' We may provide you with access to third-party tools over which we neither monitor nor have any control nor input.',
    content2: ' You acknowledge and agree that we provide access to such tools "as is" and "as available" without any warranties, representations or conditions of any kind and without any endorsement. We shall have no liability whatsoever arising from or relating to your use of optional third-party tools.',
    content3: ' discretion and you should ensure that you are familiar with and approve of the terms on which tools are provided by the relevant third-party provider(s).',
    content4: ' We may also, in the future, offer new services and/or features through the website (including, the release of new tools and resources). Such new features and/or services shall also be subject to these Terms of Service.',
  },
  c8: {
    title: ' THIRD-PARTY LINKS',
    content1: ' Certain content, products and services available via our Service may include materials from third-parties.',
    content2: ' Third-party links on this site may direct you to third-party websites that are not affiliated with us. We are not responsible for examining or evaluating the content or accuracy and we do not warrant and will not have any liability or responsibility for any third-party materials or websites, or for any other materials, products, or services of third-parties.',
    content3: " We are not liable for any harm or damages related to the purchase or use of goods, services, resources, content, or any other transactions made in connection with any third-party websites. Please review carefully the third-party's policies and practices and make sure you understand them before you engage in any transaction. Complaints, claims, concerns, or questions regarding third-party products should be directed to the third-party.",
  },
  c9: {
    title: ' USER COMMENTS, FEEDBACK AND OTHER SUBMISSIONS',
    content1: " If, at our request, you send certain specific submissions (for example contest entries) or without a request from us you send creative ideas, suggestions, proposals, plans, or other materials, whether online, by email, by postal mail, or otherwise (collectively, 'comments'), you agree that we may, at any time, without restriction, edit, copy, publish, distribute, translate and otherwise use in any medium any comments that you forward to us. We are and shall be under no obligation (1) to maintain any comments in confidence; (2) to pay compensation for any comments; or (3) to respond to any comments.",
    content2: " We may, but have no obligation to, monitor, edit or remove content that we determine in our sole discretion are unlawful, offensive, threatening, libelous, defamatory, pornographic, obscene or otherwise objectionable or violates any party's intellectual property or these Terms of Service.",
    content3: ' You agree that your comments will not violate any right of any third-party, including copyright, trademark, privacy, personality or other personal or proprietary right. You further agree that your comments will not contain libelous or otherwise unlawful, abusive or obscene material, or contain any computer virus or other malware that could in any way affect the operation of the Service or any related website. You may not use a false e-mail address, pretend to be someone other than yourself, or otherwise mislead us or third-parties as to the origin of any comments. You are solely responsible for any comments you make and their accuracy. We take no responsibility and assume no liability for any comments posted by you or any third-party.',
  },
  c10: {
    title: ' PERSONAL INFORMATION',
    content1: ' Your submission of personal information through the store is governed by our Privacy Policy. To view our Privacy Policy.',
  },
  c11: {
    title: ' ERRORS, INACCURACIES AND OMISSIONS',
    content1: ' Occasionally there may be information on our site or in the Service that contains typographical errors, inaccuracies or omissions that may relate to product descriptions, pricing, promotions, offers, product shipping charges, transit times and availability. We reserve the right to correct any errors, inaccuracies or omissions, and to change or update information or cancel orders if any information in the Service or on any related website is inaccurate at any time without prior notice (including after you have submitted your order).',
    content2: ' We undertake no obligation to update, amend or clarify information in the Service or on any related website, including without limitation, pricing information, except as required by law. No specified update or refresh date applied in the Service or on any related website, should be taken to indicate that all information in the Service or on any related website has been modified or updated.',
  },
  c12: {
    title: ' PROHIBITED USES',
    content1: ' In addition to other prohibitions as set forth in the Terms of Service, you are prohibited from using the site or its content:',
    contentA: ' for any unlawful purpose',
    contentB: ' to solicit others to perform or participate in any unlawful acts',
    contentC: ' to violate any international, federal, provincial or state regulations, rules, laws, or local ordinances',
    contentD: ' to infringe upon or violate our intellectual property rights or the intellectual property rights of others',
    contentE: ' to harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate based on gender, sexual orientation, religion, ethnicity, race, age, national origin, or disability',
    contentF: ' to submit false or misleading information',
    contentG: ' to upload or transmit viruses or any other type of malicious code that will or may be used in any way that will affect the functionality or operation of the Service or of any related website, other websites, or the Internet',
    contentH: ' to collect or track the personal information of others',
    contentI: ' to spam, phish, pharm, pretext, spider, crawl, or scrape',
    contentJ: ' for any obscene or immoral purpose',
    contentK: ' to interfere with or circumvent the security features of the Service or any related website, other websites, or the Internet. We reserve the right to terminate your use of the Service or any related website for violating any of the prohibited uses.',
  },
  c13: {
    title: ' DISCLAIMER OF WARRANTIES; LIMITATION OF LIABILITY',
    content1: ' We do not guarantee, represent or warrant that your use of our service will be uninterrupted, timely, secure or error-free.',
    content2: ' We do not warrant that the results that may be obtained from the use of the service will be accurate or reliable.',
    content3: ' You agree that from time to time we may remove the service for indefinite periods of time or cancel the service at any time, without notice to you.',
    content4: " You expressly agree that your use of, or inability to use, the service is at your sole risk. The service and all products and services delivered to you through the service are (except as expressly stated by us) provided 'as is' and 'as available' for your use, without any representation, warranties or conditions of any kind, either express or implied, including all implied warranties or conditions of merchantability, merchantable quality, fitness for a particular purpose, durability, title, and non-infringement.",
    content5: ' In no case shall KJS eCommerce Solutions LLC, our directors, officers, employees, affiliates, agents, contractors, interns, suppliers, service providers or licensors be liable for any injury, loss, claim, or any direct, indirect, incidental, punitive, special, or consequential damages of any kind, including, without limitation lost profits, lost revenue, lost savings, loss of data, replacement costs, or any similar damages, whether based in contract, tort (including negligence), strict liability or otherwise, arising from your use of any of the service or any products procured using the service, or for any other claim related in any way to your use of the service or any product, including, but not limited to, any errors or omissions in any content, or any loss or damage of any kind incurred as a result of the use of the service or any content (or product) posted, transmitted, or otherwise made available via the service, even if advised of their possibility. Because some states or jurisdictions do not allow the exclusion or the limitation of liability for consequential or incidental damages, in such states or jurisdictions, our liability shall be limited to the maximum extent permitted by law.',
  },
  c14: {
    title: ' INDEMNIFICATION',
    content1: " You agree to indemnify, defend and hold harmless KJS eCommerce Solutions LLC and our parent, subsidiaries, affiliates, partners, officers, directors, agents, contractors, licensors, service providers, subcontractors, suppliers, interns and employees, harmless from any claim or demand, including reasonable attorneys' fees, made by any third-party due to or arising out of your breach of these Terms of Service or the documents they incorporate by reference, or your violation of any law or the rights of a third-party.",
  },
  c15: {
    title: ' SEVERABILITY',
    content1: ' In the event that any provision of these Terms of Service is determined to be unlawful, void or unenforceable, such provision shall nonetheless be enforceable to the fullest extent permitted by applicable law, and the unenforceable portion shall be deemed to be severed from these Terms of Service, such determination shall not affect the validity and enforceability of any other remaining provisions.',
  },
  c16: {
    title: ' TERMINATION',
    content1: ' The obligations and liabilities of the parties incurred prior to the termination date shall survive the termination of this agreement for all purposes.',
    content2: ' These Terms of Service are effective unless and until terminated by either you or us. You may terminate these Terms of Service at any time by notifying us that you no longer wish to use our Services, or when you cease using our site.',
    content3: ' If in our sole judgment you fail, or we suspect that you have failed, to comply with any term or provision of these Terms of Service, we also may terminate this agreement at any time without notice and you will remain liable for all amounts due up to and including the date of termination; and/or accordingly may deny you access to our Services (or any part thereof).',
  },
  c17: {
    title: ' ENTIRE AGREEMENT',
    content1: ' The failure of us to exercise or enforce any right or provision of these Terms of Service shall not constitute a waiver of such right or provision.',
    content2: ' These Terms of Service and any policies or operating rules posted by us on this site or in respect to The Service constitutes the entire agreement and understanding between you and us and govern your use of the Service, superseding any prior or contemporaneous agreements, communications and proposals, whether oral or written, between you and us (including, but not limited to, any prior versions of the Terms of Service).',
    content3: ' Any ambiguities in the interpretation of these Terms of Service shall not be construed against the drafting party.',
  },
  c18: {
    title: ' GOVERNING LAW',
    content1: ' These Terms of Service and any separate agreements whereby we provide you Services shall be governed by and construed in accordance with the laws of 1302 W. Lark Industrial Dr., Fenton, MO, 63026, United States.',
  },
  c19: {
    title: ' CHANGES TO TERMS OF SERVICE',
    content1: ' You can review the most current version of the Terms of Service at any time at this page.',
    content2: ' We reserve the right, at our sole discretion, to update, change or replace any part of these Terms of Service by posting updates and changes to our website. It is your responsibility to check our website periodically for changes. Your continued use of or access to our website or the Service following the posting of any changes to these Terms of Service constitutes acceptance of those changes.',
  },
  c20: {
    title: ' CONTACT INFORMATION',
    content1: ' Questions about the Terms of Service should be sent to us at support@replendashboard.com.',
  },
  
}
