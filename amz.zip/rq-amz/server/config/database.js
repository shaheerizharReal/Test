import mongoose from 'mongoose';
import { LOCAL_MONGO_URL, PRODUCTION_MONGO_URL } from '../../config/settings';
import Fixture from './fixture';

const options = {
  useNewUrlParser: true,
  useCreateIndex: true
};
mongoose.set('useNewUrlParser', true);
mongoose.set('useCreateIndex', true);

const MONGO_URL = (process.env.NODE_ENV === 'development') ? LOCAL_MONGO_URL : PRODUCTION_MONGO_URL;

mongoose.connect(MONGO_URL)
  .then(async (db) => {
    console.log('MongoDB Connected');

    await Fixture();
  })
  .catch(err => console.log('MongoDB::', err));
