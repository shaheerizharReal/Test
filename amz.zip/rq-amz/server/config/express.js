import express from 'express';
import agenda from '../controllers/agenda';

import Users from '../models/users';
import AgendaJobs from '../models/agenda-jobs';
import '../controllers/agenda/definitions';

const app = express();
app.use(express.json());

app.listen({ port: process.env.PORT }, async () => {
  console.log(`app listening on port ${process.env.PORT}!`);
  await agenda._ready;
  agenda.start();

  const [user] = await Users.find({ admin: true });
  if (user) {
    const { _id: userId } = user;
    const [checkingTrialJob] = await AgendaJobs.find({
      'data.userId': userId,
      name: 'checking-trial'
    });
    if (!checkingTrialJob) {
      agenda.create('checking-trial', { userId })
        .unique({ 'data.userId': userId })
        .repeatEvery('24 hours')
        .save();
    }
  }
});

export default app;
