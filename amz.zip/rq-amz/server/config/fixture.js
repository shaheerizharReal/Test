import bcrypt from 'bcrypt';
import Users from '../models/users';

const Fixture = async () => {
  const adminUser = await Users.findOne({ email: 'admin@replen.com' });
  if (!adminUser) {
    const hashedPassword = await bcrypt.hash('superadmin', 12);

    await Users.updateOne({ email: 'admin@replen.com' }, {
      $set: {
        name: 'Admin',
        password: hashedPassword,
        status: 'Active',
        admin: true
      }
    }, {
      upsert: true
    });
  }
};

export default Fixture;
