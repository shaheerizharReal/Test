import Raven from 'raven';
import { SentryKey } from '../../config/settings';

Raven.config(['production', 'staging', 'development'].includes(process.env.NODE_ENV) && `https://${SentryKey}@sentry.io/281786`, {
  debug: true,
  sendTimeout: 5,
  tags: {
    project: 'replen'
  }
}).install();

export const captureException = ({ error, extraParams }) => {
  Raven.captureException(error, {
    extra: {
      ...extraParams,
    }
  });
};
