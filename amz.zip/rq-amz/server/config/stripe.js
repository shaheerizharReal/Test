import Stripe from 'stripe';
import { STRIPE_KEYS_LIVE, STRIPE_KEYS_TEST } from '../../config/settings.json';

const secretKey = process.env.NODE_ENV === 'production' ? STRIPE_KEYS_LIVE.secretKey : STRIPE_KEYS_TEST.secretKey;
const stripe = new Stripe(secretKey);
export default stripe;
