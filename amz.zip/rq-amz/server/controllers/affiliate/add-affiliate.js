
import Affiliates from '../../models/affiliates';
import { CreateCoupon, SaveCoupon } from '../stripe';

const AddAffiliate = async ({
  name,
  email,
  referralCode,
  couponOffPercent,
  duration
}) => {
  if (couponOffPercent > 0.01) {
    await CreateCoupon(referralCode, couponOffPercent, duration);

    await SaveCoupon();
  }

  await Affiliates.create({
    name,
    email,
    referralCode,
    couponOffPercent,
    duration
  });

  const affiliates = await Affiliates.find();
  return affiliates;
};

export default AddAffiliate;
