import Affiliates from '../../models/affiliates';

const deleteAffiliates = async ({ delAffiliates }) => {
  for (let i = 0; i < delAffiliates.length; i += 1) {
    const obj = JSON.parse(delAffiliates[i]);

    await Affiliates.deleteOne({ _id: obj._id });
  }
};

export default deleteAffiliates;
