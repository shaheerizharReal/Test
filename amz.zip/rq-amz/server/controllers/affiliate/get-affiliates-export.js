import moment from 'moment';
import { startCase, isEmpty } from 'lodash';
import Excel from 'exceljs';
import { Writable } from 'stream';

import Affiliates from '../../models/affiliates';
import Users from '../../models/users';

const GetAffiliatesExport = async (req, res) => {
  const headers = {
    'Content-type': 'application/vnd.ms-excel',
    'Transfer-Encoding': 'chunked',
    'Content-Disposition': `attachment; filename="Affilator's At ${moment().format('LLLL')}.xlsx"`
  };
  res.writeHead(200, headers);

  const stream = new Writable({
    write(chunk) {
      res.write(chunk);
    }
  });

  const options = {
    stream: res,
    useStyles: false,
    useSharedStrings: false
  };
  const workbook = new Excel.stream.xlsx.WorkbookWriter(options);

  const sheet = workbook.addWorksheet("Affilator's Report");

  const allAffiliates = await Affiliates.find({});

  let isHeadersPopulated = false;
  for (let i = 0; i < allAffiliates.length; i += 1) {
    const { referralCode } = allAffiliates[i];
    const users = await Users.find({ referralCode }, {
        name: 1,
        email: 1,
        signedUp: 1,
        status: 1,
        payment: 1
    });

    const arrayToBeSaved = users.map((user) => {
      const {
        name: userName,
        email: userEmail,
        signedUp: signedUpAt,
        status,
        payment
      } = user;

      return {
        userName,
        userEmail,
        signedUpAt,
        status,
        planName: payment.planName || '',
        amount: payment.planAmount ? `$${payment.planAmount}` : '',
        affiliatorName: allAffiliates[i].name,
        affiliatorEmail: allAffiliates[i].email,
        referralCode,
        offPercent: allAffiliates[i].couponOffPercent,
        duration: allAffiliates[i].duration
      };
    });

    if (arrayToBeSaved.length > 0) {
      if (!isHeadersPopulated) {
        const [header] = arrayToBeSaved;
        if (!isEmpty(header)) {
          isHeadersPopulated = true;

          sheet.columns = Object.getOwnPropertyNames(header).map(key => ({
            key,
            header: startCase(key),
            width: 25
          }));
        }
      }

      arrayToBeSaved.forEach((item) => {
        sheet.addRow(item).commit();
      });
    }
  }

  sheet.commit();

  workbook.commit()
    .then(async () => {
      res.send();
    }).catch((err) => {
      res.send(err);
    });
};

export default GetAffiliatesExport;
