import Affiliates from '../../models/affiliates';
import Users from '../../models/users';

const getNoOfAffiliatedUsers = async () => {
  const affiliates = await Affiliates.find().select({ referralCode: 1 });
  const noOfUsers = [];

  for (let i = 0; i < affiliates.length; i += 1) {
    const usersCount = await Users.find({ referralCode: affiliates[i].referralCode }).countDocuments();
    noOfUsers.push({
      _id: affiliates[i]._id,
      noOfUsers: usersCount
    });
  }
  return noOfUsers;
};

const GetAffiliates = async () => {
  const affiliates = await Affiliates.find();
  const noOfAffiliatedUsers = await getNoOfAffiliatedUsers();
  return { affiliates, noOfAffiliatedUsers };
};

export default GetAffiliates;
