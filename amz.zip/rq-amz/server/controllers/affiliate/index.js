export AddAffiliate from './add-affiliate';
export GetAffiliates from './get-affiliates';
export GetAffiliatesExport from './get-affiliates-export';
export DeleteAffiliates from  './delete-affiliate';
