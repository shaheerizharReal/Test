import moment from 'moment';

import agenda from '..';
import Users from '../../../models/users';
import EmailData from '../../../models/email-data';
import AgendaJobs from '../../../models/agenda-jobs';

import { JOB_STATES } from '../../../../config/constants';
import { captureException } from '../../../config/raven';
import { sendMail } from '../../utils/index';

agenda.define('checking-trial', { concurrency: 1 }, async (job, done) => {
  console.log('*********************************************************');
  console.log('*************    Checking  User  Trial    ***************');
  console.log('*********************************************************');

  job.attrs.state = JOB_STATES.STARTED;
  job.attrs.progress = 0;
  job.save();

  try {
    const paymentPageLink = (process.env.NODE_ENV === 'development') ? 'http://localhost:5200/payment' : 'http://app.replendashboard.com/payment';
    const usersWithTrial = await Users.find({ status: 'Trial', mws: { $exists: true } });
    console.log('\n\n', 'usersWithTrial', usersWithTrial.length);
    for (let i = 0; i < usersWithTrial.length; i += 1) {
      if (moment(usersWithTrial[i].signedUp).add(30, 'days').toDate() < moment().toDate()) {
        // Expire Trial
        const emailDataEntry = await EmailData.findOne({
          userId: usersWithTrial[i]._id
        });
        if (!emailDataEntry || (emailDataEntry && !emailDataEntry.trialExpired)) {
          await Users.updateOne({
            _id: usersWithTrial[i]._id
          }, {
            $set: {
              status: 'Trial Expire'
            }
          });

          await sendMail({
            toEmail: usersWithTrial[i].email,
            subject: 'Your Trial with Replen Dashboard Has Expired',
            body: `<div>
              <p>Hi ${usersWithTrial[i].name},</p>
              <p>Wanted to let you know that your free 30-day trial has expired. We sincerely appreciate you testing this tool for your business.</p>
              <p>To prevent any disruption of service, please <a href=${paymentPageLink}>click here</a> to select the subscription that will serve your needs the best. If there is anything specific preventing you from continuing, please let us know.</p>
              <p>Best wishes!</p>
              <p>Replen Dashboard Support Team</p>
            </div>`
          });

          await EmailData.updateOne({
            userId: usersWithTrial[i]._id
          }, {
            $setOnInsert: {
              createdAt: new Date
            },
            $set: {
              trialExpired: true,
              updatedAt: new Date
            }
          }, {
            upsert: true
          });
        }
      } else if (moment(usersWithTrial[i].signedUp).add(25, 'days').toDate() < moment().toDate()) {
        // Generate Email only Once
        const emailDataEntry = await EmailData.findOne({
          userId: usersWithTrial[i]._id
        });
        if (!emailDataEntry || (emailDataEntry && !emailDataEntry.trialWillExpire)) {
          await sendMail({
            toEmail: usersWithTrial[i].email,
            subject: 'Your Trial with Replen Dashboard Will Expire Soon',
            body: `<div>
              <p>Hi ${usersWithTrial[i].name},</p>
              <p>Wanted to give you a heads up that your free 30-day trial will expire soon. We sincerely appreciate you testing this tool for your business.</p>
              <p>To prevent any disruption of service, please <a href=${paymentPageLink}>click here</a> to select the subscription that will serve your needs the best. If there is anything specific preventing you from continuing, please let us know.</p>
              <p>Best wishes!</p>
              <p>Replen Dashboard Support Team</p>
            </div>`
          });

          await EmailData.updateOne({
            userId: usersWithTrial[i]._id
          }, {
            $setOnInsert: {
              createdAt: new Date
            },
            $set: {
              trialWillExpire: true,
              updatedAt: new Date
            }
          }, {
            upsert: true
          });
        }
      }
    }

    job.attrs.state = JOB_STATES.IN_PROGRESS;
    job.attrs.progress = 50;
    job.save();

    const usersWithTrialExpired = await Users.find({ status: 'Trial Expire', mws: { $exists: true } });
    console.log('\n\n', 'usersWithTrialExpired', usersWithTrialExpired.length);
    for (let i = 0; i < usersWithTrialExpired.length; i += 1) {
      if (moment(usersWithTrialExpired[i].signedUp).add(44, 'days').toDate() < moment().toDate()) {
        // Remove Jobs
        const jobAvailable = await AgendaJobs.findOne({
          'data.userId': usersWithTrialExpired[i]._id
        });
        if (jobAvailable) {
          await AgendaJobs.deleteMany({
            'data.userId': usersWithTrialExpired[i]._id
          });
        }
      } else if (moment(usersWithTrialExpired[i].signedUp).add(37, 'days').toDate() < moment().toDate()) {
        // Deactivate Account
        const emailDataEntry = await EmailData.findOne({
          userId: usersWithTrialExpired[i]._id
        });
        if (!emailDataEntry || (emailDataEntry && !emailDataEntry.isDeactivated)) {
          await sendMail({
            toEmail: usersWithTrialExpired[i].email,
            subject: 'Last Chance - Your Account with Replen Dashboard',
            body: `<div>
              <p>Hi ${usersWithTrialExpired[i].name},</p>
              <p>We again thank you for your time in testing Replen Dashboard for your business. I know life gets chaotic and we often forget things, so I wanted to remind you that your free 30-day trial had expired. We don’t want to be a pest, so we’ll let this emailserve as the “Last Chance” before your account gets deactivated and then deleted.</p>
              <p>To prevent any disruption of service, please <a href=${paymentPageLink}>click here</a> to select the subscription that will serve your needs the best. If there is anything specific preventing you from continuing, please let us know.</p>
              <p>Best wishes!</p>
              <p>Replen Dashboard Support Team</p>
            </div>`
          });

          await EmailData.updateOne({
            userId: usersWithTrialExpired[i]._id
          }, {
            $setOnInsert: {
              createdAt: new Date
            },
            $set: {
              isDeactivated: true,
              updatedAt: new Date
            }
          }, {
            upsert: true
          });
        }
      } else if (moment(usersWithTrialExpired[i].signedUp).add(30, 'days').toDate() < moment().toDate()) {
        // Generate Email only Once
        const emailDataEntry = await EmailData.findOne({
          userId: usersWithTrialExpired[i]._id
        });
        if (!emailDataEntry || (emailDataEntry && !emailDataEntry.isInGracePeriod)) {
          await sendMail({
            toEmail: usersWithTrialExpired[i].email,
            subject: 'Your Account with Replen Dashboard',
            body: `<div>
              <p>Hi ${usersWithTrialExpired[i].name},</p>
              <p>We again thank you for your time in testing Replen Dashboard for your business. I know life gets chaotic and we often forget things, so I wanted to remind you that your free 30-day trial had expired. As a courtesy, we give users 7 days before their account gets deactivated and eventually deleted so that our available resources canbest serve the active users.</p>
              <p>To prevent any disruption of service, please <a href=${paymentPageLink}>click here</a> to select the subscription that will serve your needs the best. If there is anything specific preventing you from continuing, please let us know.</p>
              <p>Best wishes!</p>
              <p>Replen Dashboard Support Team</p>
            </div>`
          });

          await EmailData.updateOne({
            userId: usersWithTrialExpired[i]._id
          }, {
            $setOnInsert: {
              createdAt: new Date
            },
            $set: {
              isInGracePeriod: true,
              updatedAt: new Date
            }
          }, {
            upsert: true
          });
        }
      }
    }

    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;
    job.save();

    console.log('*****************************************************************');
    console.log('****************   Checking  User  Trial COMPLETED   ****************');
    console.log('*****************************************************************');
  } catch (error) {
    console.log('*****************************************************************');
    console.log('******************   Checking  User  Trial RETRY   ******************');
    console.log('*****************************************************************');
    console.log(error.message);
    console.log('*****************************************************************');

    const { userId } = job.attrs.data;
    captureException({
      error,
      extraParams: {
        userId,
        jobId: job.attrs._id,
        jobName: job.attrs.name
      }
    });

    job.attrs.state = JOB_STATES.FAILED;
    job.attrs.failedAt = new Date();
    job.attrs.failReason = error.message;

    job.save();
  }

  done();
});
