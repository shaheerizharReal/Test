import moment from 'moment';

import agenda from '..';

import GetMyFeeEstimate from '../helpers/inventory/get-my-fee-estimate';
import SaveInventoryFees from '../helpers/inventory/save-fees';

import AgendaJobs from '../../../models/agenda-jobs';
import Products from '../../../models/products';
import Users from '../../../models/users';

import { ThrottlingException } from '../../utils/custom-exceptions';
import { sleep } from './utils';
import { JOB_STATES, FULLFILMENT_TYPE } from '../../../../config/constants';
import { captureException } from '../../../config/raven';

agenda.define('inventory:fees', { concurrency: 4 }, async (job, done) => {
  const { userId } = job.attrs.data;
  let skip = job.attrs.data.skip ? job.attrs.data.skip : 0;
  let productCountInThisIteration = 0;

  const user = await Users.findOne({ _id: userId });

  console.log('*******************************************************************');
  console.log('***********************  Sync Inventory FEES  *********************');
  console.log('*******************************************************************');
  console.log(`Company: ${user.name} (${userId})}`);
  console.log('*******************************************************************');

  job.attrs.state = JOB_STATES.STARTED;
  job.save();

  try {
    while (true) {
      const products = await Products.find({
        userId,
        listPrice: { $gt: 0 },
      }, null, {
        limit: 20,
        skip
      }).select({
        asin: 1,
        fulfilmentType: 1,
        listPrice: 1,
        fee: 1,
        sizeTier: 1,
        cubitFeet: 1
      });

      if (products.length <= 0 || productCountInThisIteration === 2000) {
        job.attrs.data.skip = (products.length === 0) ? 0 : skip;
        job.attrs.state = JOB_STATES.COMPLETED;
        job.attrs.progress = 100;
        job.save();
        break;
      }

      const feeRequestList = [];
      products.forEach(({
        asin,
        fulfilmentType,
        listPrice,
        fee
      }) => {
        if (!fee || !fee.feePercentage) {
          feeRequestList.push({
            idType: 'ASIN',
            idValue: asin,
            isAmazonFulfilled: fulfilmentType === FULLFILMENT_TYPE.AMAZON,
            listingPrice: {
              currencyCode: 'USD',
              amount: listPrice
            }
          });
        }
      });

      while (true) {
        try {
          let feeEstimateList = [];
          if (feeRequestList.length) {
            feeEstimateList = await GetMyFeeEstimate({
              userId,
              feeRequestList
            });
          }

          await SaveInventoryFees({
            userId,
            feeEstimateList,
            products
          });

          await sleep(2000);
          break;
        } catch (error) {
          if (error instanceof ThrottlingException) {
            const { nextAvailableAt } = error;

            const waitTime = moment(nextAvailableAt).diff(moment(), 'millisecond');
            if (waitTime > 0) await sleep(waitTime);
          } else {
            throw error;
          }
        }
      }

      skip += 20;
      productCountInThisIteration += 20;

      job.attrs.lockedAt = new Date();
      job.save();
    }
  } catch (e) {
    captureException({
      e,
      extraParams: {
        userId,
        jobId: job.attrs._id,
        jobName: job.attrs.name
      }
    });

    job.attrs.state = JOB_STATES.FAILED;
    job.attrs.failedAt = new Date();
    job.attrs.failReason = e.message;
    job.save();
  }

  console.log('*****************************************************************');
  console.log('****************  Sync Inventory FEES Completed  ****************');
  console.log('*****************************************************************');
  console.log(`Company: ${user.name} (${userId})}`);
  console.log('*****************************************************************');

  await AgendaJobs.deleteOne({
    'data.userId': userId,
    name: 'profit:calculations'
  });

  agenda.create('profit:calculations', { userId })
    .unique({ 'data.userId': userId })
    .save();

  done();
});
