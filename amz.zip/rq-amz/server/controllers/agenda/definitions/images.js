import moment from 'moment';
import { uniq } from 'lodash';

import agenda from '..';
import GetMatchingProductForIds from '../helpers/inventory/get-matching-products-for-ids';
import SaveProductImages from '../helpers/inventory/save-images';

import Products from '../../../models/products';
import Users from '../../../models/users';

import { ThrottlingException } from '../../utils/custom-exceptions';
import { sleep } from './utils';
import { JOB_STATES } from '../../../../config/constants';
import { captureException } from '../../../config/raven';

agenda.define('inventory:images', { concurrency: 3 }, async (job, done) => {
  const { userId } = job.attrs.data;

  const user = await Users.findOne({ _id: userId });

  console.log('*******************************************************************');
  console.log('**********************  Sync Inventory Images  ********************');
  console.log('*******************************************************************');
  console.log(`Company: ${user.name} (${userId})}`);
  console.log('*******************************************************************');

  let process = 5000;
  let skip = 0;
  let isFailed = false;

  job.attrs.state = JOB_STATES.STARTED;
  job.attrs.totalChunks = 200;
  job.attrs.completedChunks = 0;
  job.save();

  while (process > 0) {
    try {
      let products = await Products.find({
        userId,
        $or: [
          { imageUrl: { $exists: false } },
          { sizeTier: { $exists: false } }
        ]
      }, null, {
        limit: 5,
        skip,
        sort: {
          status: 1
        },
      }).select({
        asin: 1
      });

      let asinList = products.map(product => product.asin);
      asinList = uniq(asinList);
      if (asinList && asinList.length > 0) {
        products = await GetMatchingProductForIds({
          userId,
          idType: 'ASIN',
          idList: asinList
        });

        const sentCount = asinList.length;
        const receivedCount = products.length;

        const withDimension = await SaveProductImages({
          userId,
          products
        });

        skip += (sentCount - receivedCount + (receivedCount - withDimension));

        await sleep(1000);

        job.attrs.state = JOB_STATES.IN_PROGRESS;
        job.attrs.completedChunks += 1;
        if (job.attrs.completedChunks !== job.attrs.totalChunks) {
          job.attrs.lockedAt = new Date();
        }
        job.save();
      } else {
        process = 0;
      }

      process -= 5;
    } catch (error) {
      console.log('*****************************************************************');
      console.log('**************   Sync Inventory Images RETRY   ******************');
      console.log('*****************************************************************');
      console.log(error.message);
      console.log('*****************************************************************');

      if (error instanceof ThrottlingException) {
        const { nextAvailableAt } = error;

        const waitTime = moment(nextAvailableAt).diff(moment(), 'millisecond');

        if (waitTime > 0) await sleep(waitTime);
      } else {
        captureException({
          error,
          extraParams: {
            userId,
            jobId: job.attrs._id,
            jobName: job.attrs.name
          }
        });

        job.attrs.state = JOB_STATES.FAILED;
        job.attrs.failedAt = new Date();
        job.attrs.failReason = error.message;
        job.save();

        isFailed = true;
        process = 0;
      }
    }
  }

  if (!isFailed) {
    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;
    job.attrs.totalChunks = 100;
    job.attrs.completedChunks = 100;
    job.save();
  }

  job.save();

  console.log('*****************************************************************');
  console.log('**************  Sync Inventory Images Completed  ****************');
  console.log('*****************************************************************');
  console.log(`Company: ${user.name} (${userId})}`);
  console.log('*****************************************************************');

  agenda.create('fee:monthly-storage', { userId })
    .unique({ 'data.userId': userId })
    .save();

  done();
});
