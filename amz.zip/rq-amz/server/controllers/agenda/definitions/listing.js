import agenda from '..';

import GenerateReport from '../helpers/reports/generate';
import SaveInventoryListing from '../helpers/inventory/save-listing';

import Products from '../../../models/products';
import LastUpdateTracker from '../../../models/last-update-tracker';

import { GenerateReportException } from '../../utils/custom-exceptions';
import { JOB_STATES } from '../../../../config/constants';
import { captureException } from '../../../config/raven';
import { handleGenerateReportException } from './utils';

const UpdateTracker = async ({ userId }) => {
  await LastUpdateTracker.updateOne({ userId, name: 'Inventory' }, {
    $set: {
      lastUpdatedAt: new Date()
    }
  }, { upsert: true });
};

agenda.define('inventory:listing', { concurrency: 5 }, async (job, done) => {
  console.log('*********************************************************');
  console.log('*************   Sync Inventory Listing    ***************');
  console.log('*********************************************************');

  const {
    userId,
    reportRequestId,
    reportRequestStatus,
    reportId,
    retries
  } = job.attrs.data;

  try {
    const inventory = await GenerateReport({
      userId,
      reportType: '_GET_MERCHANT_LISTINGS_ALL_DATA_',
      reportOptions: null,
      reportRequestId,
      reportRequestStatus,
      reportId,
      retries
    });

    job.attrs.state = JOB_STATES.SAVING;
    job.attrs.progress = 50;
    job.save();

    const lastUpdatedDate = new Date();
    await SaveInventoryListing({
      userId,
      report: inventory
    });

    // Remove Products that are not Updated today(now) because they does not exists on Amazon
    await Products.deleteMany({
      userId,
      updatedAt: { $lt: lastUpdatedDate }
    });

    // Update Last Tracker
    await UpdateTracker({ userId });

    agenda.create('profit:estimations', { userId })
      .unique({ 'data.userId': userId })
      .save();

    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;
    job.attrs.data = { userId };
    job.save();

    console.log('*****************************************************************');
    console.log('****************   Inventory Listing COMPLETED   ****************');
    console.log('*****************************************************************');
    console.log(`User Id: ${userId}`);
    console.log('*****************************************************************');
  } catch (error) {
    console.log('*****************************************************************');
    console.log('******************   Inventory Listing RETRY   ******************');
    console.log('*****************************************************************');
    console.log(error.message);
    console.log('*****************************************************************');

    if (error instanceof GenerateReportException) {
      job = handleGenerateReportException(job, error);
    } else {
      captureException({
        error,
        extraParams: {
          userId,
          jobId: job.attrs._id,
          jobName: job.attrs.name
        }
      });

      job.attrs.state = JOB_STATES.FAILED;
      job.attrs.failedAt = new Date();
      job.attrs.failReason = error.message;
    }

    job.save();
  }

  done();
});
