import { round } from 'lodash';

import agenda from '..';

import AgendaJobs from '../../../models/agenda-jobs';
import Products from '../../../models/products';

import { JOB_STATES, FULLFILMENT_TYPE, MONTHLY_STORAGE_FEE } from '../../../../config/constants';
import { captureException } from '../../../config/raven';

agenda.define('fee:monthly-storage', { concurrency: 3 }, async (job, done) => {
  console.log('*********************************************************');
  console.log('******************   Monthly Storage Fee   **************');
  console.log('*********************************************************');

  const { userId } = job.attrs.data;

  try {
    job.attrs.state = JOB_STATES.IN_PROGRESS;
    job.save();

    const products = await Products.find({
      userId,
      sizeTier: { $exists: true },
      fulfilmentType: FULLFILMENT_TYPE.AMAZON
    }).select({
      sellerSku: 1,
      sizeTier: 1,
      cubitFeet: 1
    });

    const writeData = [];
    for (let i = 0; i < products.length; i += 1) {
      const {
        sellerSku,
        sizeTier,
        cubitFeet
      } = products[i];
      let monthlyStorageFeeJan = null;
      let monthlyStorageFeeOct = null;

      if (sizeTier.toLowerCase().includes('oversize')) {
        monthlyStorageFeeJan = (cubitFeet * MONTHLY_STORAGE_FEE.OVERSIZE.JAN_SEP);
        monthlyStorageFeeOct = (cubitFeet * MONTHLY_STORAGE_FEE.OVERSIZE.OCT_DEC);
      } else {
        monthlyStorageFeeJan = (cubitFeet * MONTHLY_STORAGE_FEE.STANDARD.JAN_SEP);
        monthlyStorageFeeOct = (cubitFeet * MONTHLY_STORAGE_FEE.STANDARD.OCT_DEC);
      }

      writeData.push({
        updateOne: {
          filter: {
            userId,
            sellerSku
          },
          update: {
            $set: {
              'fee.monthlyStorageFeeJan': round(monthlyStorageFeeJan, 4),
              'fee.monthlyStorageFeeOct': round(monthlyStorageFeeOct, 4),
              profit: null,
              profitPercentage: null,
              roiPercentage: null
            }
          }
        }
      });
    }

    if (writeData.length > 0) {
      await Products.bulkWrite(writeData);
    }

    job.attrs.lockedAt = new Date();
    job.save();

    await AgendaJobs.deleteOne({
      'data.userId': userId,
      name: 'profit:calculations'
    });
    agenda.create('profit:calculations', { userId })
      .unique({ 'data.userId': userId })
      .save();

    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;
    job.save();
    done();

    job.remove();

    console.log('*****************************************************************');
    console.log('*****************   Monthly Storage Fee COMPLETED   *************');
    console.log('*****************************************************************');
    console.log(`User Id: ${userId}`);
    console.log('*****************************************************************');
  } catch (error) {
    console.log('*****************************************************************');
    console.log('*******************   Monthly Storage Fee RETRY   ***************');
    console.log('*****************************************************************');
    console.log(error.message);
    console.log('*****************************************************************');

    captureException({
      error,
      extraParams: {
        userId,
        jobId: job.attrs._id,
        jobName: job.attrs.name
      }
    });

    job.attrs.state = JOB_STATES.FAILED;
    job.attrs.failedAt = new Date();
    job.attrs.failReason = error.message;
    job.save();

    done();
  }
});
