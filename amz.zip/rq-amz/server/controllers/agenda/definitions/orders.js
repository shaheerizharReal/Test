import moment from 'moment';

import agenda from '..';

import GenerateReport from '../helpers/reports/generate';
import SaveOrders from '../helpers/orders';

import LastUpdateTracker from '../../../models/last-update-tracker';

import { MWSErrorException, GenerateReportException } from '../../utils/custom-exceptions';
import { JOB_STATES } from '../../../../config/constants';
import { captureException } from '../../../config/raven';
import { handleGenerateReportException } from './utils';

const UpdateTracker = async ({ userId, endDate }) => {
  await LastUpdateTracker.updateOne({ userId, name: 'Orders' }, {
    $set: {
      lastUpdatedAt: endDate
    }
  }, { upsert: true });
};

agenda.define('orders', { concurrency: 3 }, async (job, done) => {
  console.log('*****************************************************************');
  console.log('*********************   Sync Orders Daily   ********************');
  console.log('*****************************************************************');

  const {
    userId,
    reportRequestId,
    reportRequestStatus,
    reportId,
    retries
  } = job.attrs.data;
  let { startDate, endDate } = job.attrs.data;
  if (!startDate && !endDate) {
    const tracker = await LastUpdateTracker.findOne({
      userId,
      name: 'Orders'
    });

    if (tracker) {
      startDate = moment(tracker.lastUpdatedAt).toISOString();
      endDate = moment().subtract(3, 'minutes').endOf('minute').toISOString();

      if ((moment(endDate).diff(moment(startDate), 'days') + 1) > 30) {
        endDate = moment(tracker.lastUpdatedAt).add(30, 'days').toISOString();
      }
    } else {
      startDate = moment().subtract(90, 'days').toISOString();
      endDate = moment().subtract(60, 'days').toISOString();
    }

    job.attrs.data.startDate = startDate;
    job.attrs.data.endDate = endDate;
    job.save();
  }

  job.attrs.state = JOB_STATES.STARTED;
  job.attrs.progress = 0;
  job.save();

  try {
    const inventory = await GenerateReport({
      userId,
      reportType: '_GET_FLAT_FILE_ALL_ORDERS_DATA_BY_LAST_UPDATE_',
      reportRequestId,
      reportRequestStatus,
      reportId,
      startDate,
      endDate,
      retries
    });

    job.attrs.state = JOB_STATES.SAVING;
    job.attrs.progress = 50;
    job.save();

    await SaveOrders({
      userId,
      date: endDate,
      report: inventory
    });

    // Update Last Tracker
    await UpdateTracker({ userId, endDate });

    job.attrs.data = { userId };
    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;
    job.save();

    console.log('SyncOrdersDaily::JOB COMPLETED');
  } catch (error) {
    console.log('*****************************************************************');
    console.log('********************   ORDERS Daily RETRY   ********************');
    console.log('*****************************************************************');
    console.log(error.message);
    console.log('*****************************************************************');

    if (error instanceof GenerateReportException) {
      job = handleGenerateReportException(job, error);
    } else if (error instanceof MWSErrorException) {
      captureException({
        error,
        extraParams: {
          userId,
          jobId: job.attrs._id,
          jobName: job.attrs.name
        }
      });

      job.attrs.state = JOB_STATES.FAILED;
      job.attrs.failedAt = new Date();
      job.attrs.failReason = error.message;
    }

    job.save();
  }

  done();
});
