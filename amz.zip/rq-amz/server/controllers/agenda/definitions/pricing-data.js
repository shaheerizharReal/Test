import moment from 'moment';
import { uniq, find, chunk } from 'lodash';

import agenda from '..';
import GetCompetitivePricingForASIN from '../helpers/inventory/get-competitive-pricing-for-asin';
import GetLowestOfferListingsForASIN from '../helpers/inventory/get-lowest-offer-listings-for-asin';

import Products from '../../../models/products';
import { JOB_STATES } from '../../../../config/constants';
import { sleep } from './utils';
import { MWSErrorException, ThrottlingException } from '../../utils/custom-exceptions';
import { captureException } from '../../../config/raven';
import { SaveDataBuyBox, SaveDataLowest } from '../helpers/inventory/save-pricing-data';

const limit = 1000;
const CHUNK = 10;

const getAmazonCondition = (condition) => {
  let amazonCondition = null;
  if (condition === 11) {
    amazonCondition = 'New';
  } else if ([1, 2, 3, 4].includes(condition)) {
    amazonCondition = 'Used';
  } else if ([5, 6, 7, 8].includes(condition)) {
    amazonCondition = 'Collectible';
  } else if (condition === 10) {
    amazonCondition = 'Refurbished';
  }
  return amazonCondition;
};

const GetCompetitivePricingForASINHelper = async ({ userId, asinList }) => {
  let data;
  while (true) {
    try {
      data = await GetCompetitivePricingForASIN({
        userId,
        asinList,
      });

      break;
    } catch (error) {
      if (error instanceof ThrottlingException) {
        const { nextAvailableAt } = error;
        const waitTime = moment(nextAvailableAt).diff(moment(), 'millisecond');
        if (waitTime > 0) await sleep(waitTime);
      } else if (error instanceof MWSErrorException) {
        throw new MWSErrorException({
          message: error.message,
          endpoint: 'GetCompetitivePricingForASIN',
          userId
        });
      }
    }
  }

  return data;
};

const GetLowestOfferListingsForASINHelper = async ({ userId, asinList, condition }) => {
  let data;
  while (true) {
    try {
      data = await GetLowestOfferListingsForASIN({
        userId,
        asinList,
        condition
      });

      break;
    } catch (error) {
      if (error instanceof ThrottlingException) {
        const { nextAvailableAt } = error;
        const waitTime = moment(nextAvailableAt).diff(moment(), 'millisecond');
        if (waitTime > 0) await sleep(waitTime);
      } else if (error instanceof MWSErrorException) {
        throw new MWSErrorException({
          message: error.message,
          endpoint: 'GetLowestOfferListingsForASIN',
          userId
        });
      }
    }
  }

  return data;
};

agenda.define('pricing-data-api', { concurrency: 3 }, async (job, done) => {
  console.log('*****************************************************************');
  console.log('***************   Sync Pricing(Buy & Low) Data    ***************');
  console.log('*****************************************************************');

  const { userId, skip } = job.attrs.data;

  job.attrs.state = JOB_STATES.STARTED;
  job.attrs.progress = 0;
  job.save();

  try {
    const products = await Products.find({
      userId
    }, null, {
      limit,
      skip
    }).select({
      asin: 1,
      condition: 1
    });

    let completeASINLIST = products.map(product => product.asin);
    completeASINLIST = uniq(completeASINLIST);

    job.attrs.state = JOB_STATES.IN_PROGRESS;
    job.attrs.progress = 50;
    job.attrs.totalChunks = completeASINLIST.length;
    job.attrs.completedChunks = 0;
    job.save();

    const chunkASINList = chunk(completeASINLIST, CHUNK);
    let i = 0;
    while (i < chunkASINList.length) {
      const asinList = chunkASINList[i];

      // Get Response from API
      const responseCompetitivePricing = await GetCompetitivePricingForASINHelper({
        userId,
        asinList
      });

      // If Response Exists Then Save Buy Box Data for Every Product
      if (responseCompetitivePricing) {
        for (let j = 0; j < asinList.length; j += 1) {
          const asin = asinList[j];

          const product = find(products, { asin });
          const { condition } = product;

          await SaveDataBuyBox({
            userId,
            asin,
            condition: getAmazonCondition(parseInt(condition, 10)),
            response: find(responseCompetitivePricing, { asin })
          });

          job.attrs.lockedAt = new Date();
          job.save();
        }
      }

      // Get Response from API
      const responseLowestOfferListings = await GetLowestOfferListingsForASINHelper({
        userId,
        asinList
      });

      // If Response Exists Then Save Buy Box Data for Every Product
      if (responseLowestOfferListings) {
        for (let j = 0; j < asinList.length; j += 1) {
          const asin = asinList[j];

          const product = find(products, { asin });
          const { condition } = product;

          await SaveDataLowest({
            userId,
            asin,
            condition: getAmazonCondition(parseInt(condition, 10)),
            response: find(responseLowestOfferListings, { asin })
          });

          job.attrs.lockedAt = new Date();
          job.save();
        }
      }

      i += 1;
      job.attrs.completedChunks += asinList.length;
      job.save();
    }

    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;

    if (products && products.length !== limit) {
      job.attrs.data = { userId, skip: 0 };
    } else {
      job.attrs.data = { userId, skip: (skip + limit) };
    }

    job.save();
    done();

    console.log('*****************************************************************');
    console.log('*************   Pricing(Buy & Low) Data Completed    ************');
    console.log('*****************************************************************');
  } catch (error) {
    console.log('*****************************************************************');
    console.log('************   Sync Pricing(Buy & Low) Data Retry    ************');
    console.log('*****************************************************************');
    console.log(error.message);
    console.log('*****************************************************************');

    if (error instanceof ThrottlingException) {
      const { nextAvailableAt } = error;
      job.attrs.nextRunAt = nextAvailableAt;
    } else {
      captureException({
        error,
        extraParams: {
          userId,
          jobId: job.attrs._id,
          jobName: job.attrs.name
        }
      });

      job.attrs.state = JOB_STATES.FAILED;
      job.attrs.failedAt = new Date();
      job.attrs.failReason = error.message;
    }

    job.save();
    done();
  }
});
