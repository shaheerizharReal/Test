import { isEmpty } from 'lodash';

import agenda from '..';

import Products from '../../../models/products';

import GetProfitEstimations from '../helpers/inventory/get-profit-estimations';
import GetDefaultCalculationPrice from '../../users/get-default-calculation-price';
import { ChooseDefaultCalculationPrice } from './utils';

import { JOB_STATES } from '../../../../config/constants';
import { captureException } from '../../../config/raven';

agenda.define('profit-recalculation:shipping-rate', { concurrency: 3 }, async (job, done) => {
  console.log('**********************************************************************************');
  console.log('***************   Sync Profit Recalculation Caused by Shipping Rate   ************');
  console.log('**********************************************************************************');

  const { userId } = job.attrs.data;

  try {
    job.attrs.state = JOB_STATES.IN_PROGRESS;
    job.save();
    const { profitCalculatedBy } = await GetDefaultCalculationPrice({ userId });

    while (true) {
      const products = await Products.find({
        userId,
        profit: null,
        shipBy: { $exists: true }
      }, null, {
        limit: 100
      }).select({
        sellerSku: 1,
        costPrice: 1,
        listPrice: 1,
        buyBoxPrice: 1,
        lowestOfferPrice: 1,
        lowestFBAOfferPrice: 1,
        fee: 1,
        fulfilmentType: 1,
        shipBy: 1,
        shippingRate: 1,
        packageDimensions: 1
      });
      console.log('\n\n', 'products', products.length);
      if (products.length <= 0) {
        break;
      }

      const writeData = [];
      for (let i = 0; i < products.length; i += 1) {
        const {
          sellerSku,
          costPrice,
          listPrice,
          buyBoxPrice,
          lowestOfferPrice,
          lowestFBAOfferPrice,
          fee,
          fulfilmentType,
          shipBy,
          shippingRate,
          packageDimensions
        } = products[i];
        const weight = (!isEmpty(packageDimensions) && (packageDimensions.weight))
          ? packageDimensions.weight : 0;
        const defaultPrice = ChooseDefaultCalculationPrice({
          profitCalculatedBy,
          listPrice,
          buyBoxPrice,
          lowestOfferPrice,
          lowestFBAOfferPrice
        });
        const {
          profit,
          profitPercentage,
          roiPercentage
        } = await GetProfitEstimations({
          costPrice,
          defaultPrice,
          fee,
          fulfilmentType,
          shipBy,
          shippingRate,
          weight
        });

        writeData.push({
          updateOne: {
            filter: {
              userId,
              sellerSku
            },
            update: {
              $set: {
                profit,
                profitPercentage,
                roiPercentage
              }
            }
          }
        });
      }

      console.log('\n\n', 'writeData', writeData.length);
      if (writeData.length > 0) {
        await Products.bulkWrite(writeData);
      }

      job.attrs.lockedAt = new Date();
      job.save();
    }

    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;
    job.save();
    done();

    job.remove();

    console.log('*************************************************************************************************');
    console.log('*****************   Profit Profit Recalculation Caused by Shipping Rate COMPLETED   *************');
    console.log('*************************************************************************************************');
    console.log(`User Id: ${userId}`);
    console.log('*****************************************************************');
  } catch (error) {
    console.log('*************************************************************************************************');
    console.log('*******************   Profit Profit Recalculation Caused by Shipping Rate RETRY   ***************');
    console.log('*************************************************************************************************');
    console.log(error.message);
    console.log('*************************************************************************************************');

    captureException({
      error,
      extraParams: {
        userId,
        jobId: job.attrs._id,
        jobName: job.attrs.name
      }
    });

    job.attrs.state = JOB_STATES.FAILED;
    job.attrs.failedAt = new Date();
    job.attrs.failReason = error.message;
    job.save();

    done();
    job.remove();
  }
});
