import moment from 'moment';

import agenda from '..';

import GenerateReport from '../helpers/reports/generate';
import SaveInventoryQuantity from '../helpers/inventory/save-quantity';

import MwsAPI from '../../mws';

import { GenerateReportException } from '../../utils/custom-exceptions';
import { JOB_STATES } from '../../../../config/constants';
import { captureException } from '../../../config/raven';
import { handleGenerateReportException } from './utils';

const reportType = '_GET_FBA_MYI_ALL_INVENTORY_DATA_';

const getRecentReport = async ({ userId, startDate }) => {
  const existingReportRequestList = await MwsAPI({
    endpoint: 'GetReportRequestList',
    params: {
      userId,
      reportProcessingStatusList: ['_DONE_'],
      reportTypeList: [reportType]
    }
  });

  let existingReportFound = false;
  for (let i = 0; i < existingReportRequestList.length; i += 1) {
    const existingReportRequest = existingReportRequestList[i];
    if (startDate && existingReportRequest.completedDate) {
      if (moment(startDate).diff(moment(existingReportRequest.completedDate), 'minutes') < 30) {
        if ((i + 1) < existingReportRequestList.length) {
          const previousReport = existingReportRequestList[i + 1];

          if (moment(existingReportRequest.completedDate).diff(moment(previousReport.completedDate), 'minutes') < 30) {
            existingReportFound = previousReport;
          }
          existingReportFound = true;
        }
      }
    } else {
      existingReportFound = true;
    }

    if (existingReportFound) {
      return {
        existingReportFound,
        reportRequestId: existingReportRequest.reportRequestId,
        reportRequestStatus: existingReportRequest.reportProcessingStatus,
        reportId: existingReportRequest.generatedReportId
      };
    }
  }

  return {
    existingReportFound
  };
};

agenda.define('inventory:quantity', { concurrency: 5 }, async (job, done) => {
  console.log('*********************************************************');
  console.log('************   Sync Inventory Quantity    ***************');
  console.log('*********************************************************');

  const {
    userId,
    retries
  } = job.attrs.data;

  let {
    reportRequestId,
    reportRequestStatus,
    reportId
  } = job.attrs.data;

  try {
    const response = await getRecentReport({
      userId,
      startDate: moment().toISOString()
    });

    if (response.existingReportFound) {
      ({
        reportRequestId,
        reportRequestStatus,
        reportId
      } = response);
    }

    const inventory = await GenerateReport({
      userId,
      reportType,
      reportRequestId,
      reportRequestStatus,
      reportId,
      retries
    });

    job.attrs.state = JOB_STATES.SAVING;
    job.attrs.progress = 50;
    job.save();

    await SaveInventoryQuantity({
      userId,
      report: inventory
    });

    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;
    job.attrs.data = { userId };
    job.save();

    console.log('*****************************************************************');
    console.log('****************   Inventory Quantity COMPLETED   ***************');
    console.log('*****************************************************************');
    console.log(`User Id: ${userId}`);
    console.log('*****************************************************************');
  } catch (error) {
    console.log('*********************************************************');
    console.log('************   Inventory Quantity RETRY   ***************');
    console.log('*********************************************************');
    console.log(error.message);
    console.log('*********************************************************');

    if (error instanceof GenerateReportException) {
      job = handleGenerateReportException(job, error);
    } else {
      captureException({
        error,
        extraParams: {
          userId,
          jobId: job.attrs._id,
          jobName: job.attrs.name
        }
      });

      job.attrs.state = JOB_STATES.FAILED;
      job.attrs.failedAt = new Date();
      job.attrs.failReason = error.message;
    }

    job.save();
  }

  done();
});
