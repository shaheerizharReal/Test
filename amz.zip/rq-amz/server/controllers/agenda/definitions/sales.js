import agenda from '..';

import SaveSales from '../helpers/inventory/save-sales';

import { JOB_STATES } from '../../../../config/constants';
import { captureException } from '../../../config/raven';

agenda.define('inventory:sales', { concurrency: 5 }, async (job, done) => {
  console.log('*********************************************************');
  console.log('***************   Sync Inventory Sales    ***************');
  console.log('*********************************************************');

  const { userId } = job.attrs.data;

  job.attrs.state = JOB_STATES.IN_PROGRESS;
  job.attrs.progress = 0;
  job.save();

  try {
    await SaveSales({
      userId: userId.toString(),
      job
    });

    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;
    job.attrs.data = { userId };
    job.save();

    done();

    job.remove();

    console.log('*****************************************************************');
    console.log('*****************   Inventory Sales COMPLETED   *****************');
    console.log('*****************************************************************');
    console.log(`User Id: ${userId}`);
    console.log('*****************************************************************');
  } catch (error) {
    console.log('*****************************************************************');
    console.log('*******************   Inventory Sales RETRY   *******************');
    console.log('*****************************************************************');
    console.log(error.message);
    console.log('*****************************************************************');

    captureException({
      error,
      extraParams: {
        userId,
        jobId: job.attrs._id,
        jobName: job.attrs.name
      }
    });

    job.attrs.state = JOB_STATES.FAILED;
    job.attrs.failedAt = new Date();
    job.attrs.failReason = error.message;
    job.save();

    done();
  }
});
