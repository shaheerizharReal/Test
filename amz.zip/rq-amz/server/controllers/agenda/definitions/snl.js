import agenda from '..';

import GenerateReport from '../helpers/reports/generate';
import SaveInventorySNL from '../helpers/inventory/save-snl';

import { GenerateReportException } from '../../utils/custom-exceptions';
import { JOB_STATES } from '../../../../config/constants';
import { captureException } from '../../../config/raven';
import { handleGenerateReportException } from './utils';

agenda.define('inventory:snl', { concurrency: 4 }, async (job, done) => {
  console.log('*********************************************************');
  console.log('****************   Sync Inventory SNL    ****************');
  console.log('*********************************************************');

  const {
    userId,
    reportRequestId,
    reportRequestStatus,
    reportId,
    retries
  } = job.attrs.data;

  try {
    const inventory = await GenerateReport({
      userId,
      reportType: '_GET_FBA_UNO_INVENTORY_DATA_',
      reportOptions: null,
      reportRequestId,
      reportRequestStatus,
      reportId,
      retries
    });

    job.attrs.state = JOB_STATES.SAVING;
    job.attrs.progress = 50;
    job.save();

    await SaveInventorySNL({
      userId,
      report: inventory
    });

    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;
    job.attrs.data = { userId };
    job.save();

    console.log('*****************************************************************');
    console.log('******************   Inventory SNL COMPLETED   ******************');
    console.log('*****************************************************************');
    console.log(`User Id: ${userId}`);
    console.log('*****************************************************************');
  } catch (error) {
    console.log('*****************************************************************');
    console.log('********************   Inventory SNL RETRY   ********************');
    console.log('*****************************************************************');
    console.log(error.message);
    console.log('*****************************************************************');

    if (error instanceof GenerateReportException) {
      job = handleGenerateReportException(job, error);
    } else {
      captureException({
        error,
        extraParams: {
          userId,
          jobId: job.attrs._id,
          jobName: job.attrs.name
        }
      });

      job.attrs.state = JOB_STATES.FAILED;
      job.attrs.failedAt = new Date();
      job.attrs.failReason = error.message;
    }

    job.save();
  }

  done();
});
