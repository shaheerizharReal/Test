import moment from 'moment';
import { round } from 'lodash';

import agenda from '..';

import { JOB_STATES } from '../../../../config/constants';

import Orders from '../../../models/orders';
import SalesDailyHistory from '../../../models/sales-daily-history';

agenda.define('summary.by.orders', { concurrency: 3 }, async (job, done) => {
  console.log('*****************************************************************');
  console.log('*********************   Summary By Orders   *********************');
  console.log('*****************************************************************');

  const { userId } = job.attrs.data;

  job.attrs.state = JOB_STATES.IN_PROGRESS;
  job.save();

  try {
    // Step1 => Fetch Orders and Extract IDs
    const ordersData = await Orders.find({
      userId,
      orderReconcileStatus: { $in: ['Pending', 'InProgress'] }
    }, null, {
      limit: 2500,
      sort: { purchaseDate: 1 }
    }).select({
      sellerSku: 1
    });
    console.log('\n\n', 'ordersData', ordersData.length);

    // Extract id
    const orderIds = [];
    ordersData.forEach((order) => {
      const { _id } = order;

      orderIds.push(_id);
    });
    console.log('\n\n', 'orderIds', orderIds.length);

    // Step2 => Reconcile InProgress
    await Orders.updateMany({
      _id: { $in: orderIds }
    }, {
      $set: {
        orderReconcileStatus: 'InProgress'
      }
    }).exec();

    job.attrs.lockedAt = new Date();
    job.save();

    // Step3 => Group Per Day Per sellerSku Data & Get Products
    const salesDataArr = await Orders.aggregate([
      {
        $match: {
          _id: { $in: orderIds }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: { date: '$purchaseDate', timezone: 'America/Los_Angeles' } },
            month: { $month: { date: '$purchaseDate', timezone: 'America/Los_Angeles' } },
            day: { $dayOfMonth: { date: '$purchaseDate', timezone: 'America/Los_Angeles' } },
            sellerSku: '$sellerSku'
          },
          units: { $sum: '$quantity' },
          price: { $sum: '$itemPrice' }
        }
      },
      {
        $sort: {
          _id: 1
        }
      }
    ]);
    console.log('\n\n', 'salesDataArr', salesDataArr.length);

    job.attrs.lockedAt = new Date();
    job.save();

    // Step4 => Process & Save Per Product Per Day Data
    const salesData = [];
    for (let i = 0; i < salesDataArr.length; i += 1) {
      const { _id } = salesDataArr[i];
      const {
        day,
        month,
        year,
        sellerSku
      } = _id;
      const timestamp = moment.tz({ day, month: month - 1, year }, 'America/Los_Angeles').toDate();

      const startDate = moment.tz({ day, month: month - 1, year }, 'America/Los_Angeles').startOf('day').toDate();
      const endDate = moment.tz({ day, month: month - 1, year }, 'America/Los_Angeles').endOf('day').toDate();

      const [sales] = await Orders.aggregate([
        {
          $match: {
            userId: userId.toString(),
            purchaseDate: { $gte: startDate, $lte: endDate },
            sellerSku
          }
        },
        {
          $group: {
            _id: null,
            orders: { $sum: 1 },
            unitsSold: { $sum: '$quantity' },
            saleAmount: { $sum: '$itemPrice' },
            itemPromotionDiscount: { $sum: '$itemPromotionDiscount' },
            shipPromotionDiscount: { $sum: '$shipPromotionDiscount' }
          }
        }
      ]);

      if (sales) {
        const {
          orders,
          unitsSold,
          saleAmount,
          itemPromotionDiscount,
          shipPromotionDiscount
        } = sales;
        const promotionDiscount = itemPromotionDiscount + shipPromotionDiscount;

        const pendingOrders = await Orders.find({
          userId: userId.toString(),
          purchaseDate: { $gte: startDate, $lte: endDate },
          sellerSku,
          orderStatus: 'Pending'
        });
        salesData.push({
          updateOne: {
            filter: {
              userId,
              timestamp,
              sellerSku
            },
            update: {
              $setOnInsert: {
                createdAt: new Date()
              },
              $set: {
                orders,
                pendingOrders: pendingOrders.length,
                unitsSold,
                saleAmount: round(saleAmount, 2),
                promos: round(promotionDiscount, 2),
                updatedAt: new Date()
              }
            },
            upsert: true
          }
        });
      }

      job.attrs.lockedAt = new Date();
      job.save();
    }

    console.log('\n\n', 'salesData', salesData.length);
    if (salesData.length > 0) {
      await SalesDailyHistory.bulkWrite(salesData);
    }

    // Step5 => Reconcile Status Done & Save Snapshots
    Orders.updateMany({
      _id: { $in: orderIds },
      orderReconcileStatus: 'InProgress'
    }, {
      $set: {
        orderReconcileStatus: 'Done'
      }
    }).exec();

    job.attrs.state = JOB_STATES.COMPLETED;
    job.attrs.progress = 100;
    job.attrs.data = { userId };
    job.save();
    done();

    agenda.create('inventory:sales', { userId })
      .unique({ 'data.userId': userId })
      .save();

    console.log('*****************************************************************');
    console.log('****************   Summary By Orders Completed   ****************');
    console.log('*****************************************************************');
    console.log(`User Id: ${userId}`);
    console.log('*****************************************************************');
  } catch (error) {
    console.log('*****************************************************************');
    console.log('******************   Summary By Orders Retry   ******************');
    console.log('*****************************************************************');
    console.log(error.message);
    console.log('*****************************************************************');

    job.attrs.state = JOB_STATES.FAILED;
    job.attrs.failedAt = new Date();
    job.attrs.failReason = error.message;

    job.save();
    done();
  }
});
