export const handleGenerateReportException = (job, error) => {
  const { nextAvailableAt, reportRequestId, reportRequestStatus, reportId, retries } = error;
  job.attrs.state = reportRequestStatus;

  const { data } = job.attrs;
  job.attrs.data = {
    ...data,
    reportId,
    reportRequestId,
    reportRequestStatus,
    retries
  };

  job.attrs.nextRunAt = nextAvailableAt;
  return job;
};

export const sleep = ms => (new Promise(resolve => setTimeout(resolve, ms)));

export const ChooseDefaultCalculationPrice = ({
  profitCalculatedBy,
  listPrice,
  buyBoxPrice,
  lowestOfferPrice,
  lowestFBAOfferPrice
}) => {
  if (profitCalculatedBy === 'buyBoxPrice') return buyBoxPrice || listPrice;
  if (profitCalculatedBy === 'lowestOfferPrice') return lowestOfferPrice || listPrice;
  if (profitCalculatedBy === 'lowestFBAOfferPrice') return lowestFBAOfferPrice || listPrice;
  return listPrice;
};
