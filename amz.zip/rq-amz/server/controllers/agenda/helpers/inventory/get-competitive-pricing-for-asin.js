import MwsAPI from '../../../mws';

const GetCompetitivePricingForASIN = async ({
  userId,
  marketplaceId,
  asinList
}) => {
  try {
    const results = MwsAPI({
      endpoint: 'GetCompetitivePricingForASIN',
      params: {
        userId,
        marketplaceId,
        asinList
      }
    });
    return Promise.resolve(results);
  } catch (e) {
    throw e;
  }
};

export default GetCompetitivePricingForASIN;
