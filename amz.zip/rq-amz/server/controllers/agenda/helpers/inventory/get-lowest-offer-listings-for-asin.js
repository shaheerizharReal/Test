import MwsAPI from '../../../mws';

const GetLowestOfferListingsForASIN = async ({
  userId,
  marketplaceId,
  asinList,
  condition
}) => {
  try {
    const results = MwsAPI({
      endpoint: 'GetLowestOfferListingsForASIN',
      params: {
        userId,
        marketplaceId,
        asinList,
        condition
      }
    });
    return Promise.resolve(results);
  } catch (e) {
    throw e;
  }
};

export default GetLowestOfferListingsForASIN;
