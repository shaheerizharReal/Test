import MwsAPI from '../../../mws';

const GetMatchingProduct = async ({ userId, asinList }) => {
  try {
    const matchingProducts = await MwsAPI({
      endpoint: 'GetMatchingProduct',
      params: {
        userId,
        asinList
      }
    });

    return matchingProducts;
  } catch (e) {
    throw e;
  }
};

export default GetMatchingProduct;
