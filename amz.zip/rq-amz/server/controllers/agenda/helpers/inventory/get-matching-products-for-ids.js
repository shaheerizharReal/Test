import MwsAPI from '../../../mws';

const GetMatchingProductForIds = async ({ userId, idType, idList, marketplaceId }) => {
  try {
    const matchingProducts = await MwsAPI({
      endpoint: 'GetMatchingProductForId',
      params: {
        userId,
        idType,
        idList,
        marketplaceId
      }
    });

    return matchingProducts;
  } catch (e) {
    throw e;
  }
};

export default GetMatchingProductForIds;
