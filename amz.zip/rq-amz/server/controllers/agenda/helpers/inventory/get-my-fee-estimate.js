import MwsAPI from '../../../mws';

const GetMyFeeEstimate = async ({ userId, feeRequestList }) => {
  try {
    const feesEstimate = await MwsAPI({
      endpoint: 'GetMyFeesEstimate',
      params: {
        userId,
        feeRequestList
      }
    });

    return feesEstimate;
  } catch (e) {
    throw e;
  }
};

export default GetMyFeeEstimate;
