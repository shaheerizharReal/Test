import moment from 'moment';
import { round } from 'lodash';

import { FULLFILMENT_TYPE } from '../../../../../config/constants';

const GetProfitEstimations = ({
  costPrice,
  defaultPrice,
  fee,
  fulfilmentType,
  shipBy,
  shippingRate,
  weight
}) => {
  let feeses = 0;
  if (fee) {
    if (defaultPrice > 0 && fee.feePercentage) {
      feeses += round(defaultPrice * (fee.feePercentage / 100), 2);
    }

    if (fee.otherFees) {
      feeses += round(fee.otherFees, 2);
    }

    if (fulfilmentType === FULLFILMENT_TYPE.AMAZON) {
      if ([9, 10, 11].includes(moment().month())) {
        if (fee.monthlyStorageFeeOct) {
          feeses += round(fee.monthlyStorageFeeOct, 2);
        }
      } else if (fee.monthlyStorageFeeJan) {
        feeses += round(fee.monthlyStorageFeeJan, 2);
      }
    }
  }

  let totalCosts = 0;
  if (costPrice > 0) {
    totalCosts += costPrice;
  }
  if (shipBy === 'byItem') {
    totalCosts += shippingRate;
  } else if (shipBy === 'byWeight') {
    totalCosts += (shippingRate * weight);
  }

  const calculation = defaultPrice - feeses - totalCosts;
  const profit = round(calculation, 2);
  const profitPercentage = defaultPrice > 0 ? round(((profit / defaultPrice) * 100), 2) : undefined;
  const roiPercentage = costPrice > 0 ? round(((profit / costPrice) * 100), 2) : undefined;
  return {
    profit,
    profitPercentage,
    roiPercentage
  };
};

export default GetProfitEstimations;
