import {
  extend,
  find,
  round,
  isEmpty
} from 'lodash';

import Products from '../../../../models/products';

const SaveInventoryFees = async ({ userId, feeEstimateList, products }) => {
  const reportData = [];
  products.forEach((product) => {
    const setObj = {};

    const {
      asin,
      fulfilmentType
    } = product;

    const feeEstimate = find(feeEstimateList, { feesEstimateIdentifier: { idValue: asin } });
    if (feeEstimate) {
      const { feeDetailList, feesEstimateIdentifier } = feeEstimate;

      const { priceToEstimateFees } = feesEstimateIdentifier;

      let otherFees = 0;
      let feePercentage = 0;
      feeDetailList.forEach(({ finalFee, feeType }) => {
        const { amount } = finalFee;

        if (feeType === 'ReferralFee') {
          const listPrice = priceToEstimateFees.listingPrice.amount;
          feePercentage = (amount / listPrice) * 100;
        } else {
          otherFees += amount;
        }
      });

      extend(setObj, {
        'fee.feePercentage': Math.round(feePercentage),
        'fee.otherFees': round(otherFees, 2)
      });
    }

    if (!isEmpty(setObj)) {
      reportData.push({
        updateMany: {
          filter: {
            userId,
            asin,
            fulfilmentType
          },
          update: {
            $set: {
              ...setObj,
              profit: null,
              profitPercentage: null,
              roiPercentage: null
            }
          }
        }
      });
    }
  });

  if (reportData.length > 0) {
    await Products.bulkWrite(reportData);
  }
};

export default SaveInventoryFees;
