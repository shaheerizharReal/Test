import {
  isArray,
  extend,
  round
} from 'lodash';

import Products from '../../../../models/products';

const getProductSizeTier = ({
  length,
  width,
  height,
  weight
}) => {
  let productSizeTier = 'N/A';

  const [shortestSide, medianSide, longestSide] = [length, width, height].sort((a, b) => (a - b));

  const girth = ((shortestSide + medianSide) * 2);
  const lengthPlusGirth = longestSide + girth;

  if (weight <= 0.75 && longestSide <= 15 && medianSide <= 12 && shortestSide <= 0.75) {
    productSizeTier = 'Small Standard Size';
  } else if (weight <= 20 && longestSide <= 18 && medianSide <= 14 && shortestSide <= 8) {
    productSizeTier = 'Large Standard Size';
  } else if (weight <= 70 && longestSide <= 60 && medianSide <= 30 && lengthPlusGirth <= 130) {
    productSizeTier = 'Small Oversize';
  } else if (weight <= 150 && longestSide <= 108) {
    if (lengthPlusGirth <= 130) {
      productSizeTier = 'Medium Oversize';
    } else if (lengthPlusGirth <= 165) {
      productSizeTier = 'Large Oversize';
    }
  } else if (weight > 150 && longestSide > 108 && lengthPlusGirth > 165) {
    productSizeTier = 'Special Oversize';
  }
  return productSizeTier;
};

const SaveProductImages = async ({
  userId,
  products
}) => {
  const reportData = [];
  let withDimension = 0;
  products.forEach((row) => {
    if (row && row.products && isArray(row.products) && row.products.length > 0) {
      const {
        asin,
        imageUrl,
        packageDimensions
      } = row.products[0];
      const setSelector = { imageUrl };
      if (packageDimensions) {
        const {
          height,
          length,
          width,
          weight
        } = packageDimensions;

        if (height && height.value
              && length && length.value
                && width && width.value
                  && weight && weight.value) {
          const cubitFeet = (height.value * width.value * length.value) / 1728;

          const sizeTier = getProductSizeTier({
            length: length.value,
            width: width.value,
            height: height.value,
            weight: weight.value
          });

          withDimension += 1;

          extend(setSelector, {
            packageDimensions: {
              length: round(length.value, 4),
              width: round(width.value, 4),
              height: round(height.value, 4),
              weight: round(weight.value, 4)
            },
            cubitFeet: round(cubitFeet, 4),
            sizeTier
          });
        }
      }

      reportData.push({
        updateMany: {
          filter: {
            userId,
            asin
          },
          update: {
            $set: setSelector
          }
        }
      });
    }
  });

  if (reportData.length > 0) {
    await Products.bulkWrite(reportData);
  }
  return withDimension;
};

export default SaveProductImages;
