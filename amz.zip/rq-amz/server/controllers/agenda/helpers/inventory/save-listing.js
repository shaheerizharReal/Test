import { extend } from 'lodash';

import Products from '../../../../models/products';

import { FULLFILMENT_TYPE } from '../../../../../config/constants';

const SaveInventoryListing = async ({ userId, report }) => {
  const reportData = [];
  for (let i = 0; i < report.length; i += 1) {
    const {
      sellerSku,
      itemName,
      itemCondition,
      itemDescription,
      fulfillmentChannel,
      asin1,
      price,
      quantity,
      openDate,
      status,
      productTaxCode
    } = report[i];

    const listPrice1 = price || 0;
    const fulfilmentType = fulfillmentChannel === 'DEFAULT' ? FULLFILMENT_TYPE.MERCHANT : FULLFILMENT_TYPE.AMAZON;
    const setSelector = {
      sellerSku,
      userId,
      status,
      taxCode: productTaxCode,
      asin: asin1,
      title: itemName,
      listPrice1,
      description: itemDescription,
      condition: itemCondition,
      fulfilmentType,
      updatedAt: new Date()
    };

    if (fulfillmentChannel === 'DEFAULT') {
      extend(setSelector, { sellableQuantity: quantity || 0 });
    }

    if (openDate) {
      extend(setSelector, { openDate: new Date(openDate) });
    }

    reportData.push({
      updateOne: {
        filter: {
          userId,
          sellerSku
        },
        update: {
          $set: setSelector,
          $setOnInsert: {
            createdAt: new Date()
          }
        },
        upsert: true
      }
    });
  }

  console.log('\n\n', 'Products', reportData.length);
  if (reportData.length > 0) {
    return Products.bulkWrite(reportData);
  }
  return Promise.resolve();
};

export default SaveInventoryListing;
