import {
  sortBy,
  isEmpty,
  isNumber,
  find,
  isArray,
  extend
} from 'lodash';

import Products from '../../../../models/products';

export const SaveDataBuyBox = async ({
  userId,
  asin,
  condition,
  response
}) => {
  const setSelector = {};
  const unsetSelector = {};

  let noOfSellers = null;
  if (response && response.numberOfOfferListings && response.numberOfOfferListings.length > 0) {
    const newOfferListingObj = find(response.numberOfOfferListings, { condition });
    noOfSellers = (newOfferListingObj && newOfferListingObj.value) || null;

    setSelector.noOfSellers = noOfSellers;
  }

  if (response && response.competitivePrices && response.competitivePrices.length > 0) {
    const competitivePrice = find(response.competitivePrices, { condition });
    if (competitivePrice) {
      const { belongsToRequester, price } = competitivePrice;

      // Extract Buy Box Winner
      const isBuyBoxWinner = belongsToRequester;

      // Extract Buy Box Price
      const buyBoxPrice = price.landedPrice.amount;

      // Update BuyBoxPrice & BuyBoxWinner
      setSelector.buyBoxPrice = buyBoxPrice;
      setSelector.isBuyBoxWinner = isBuyBoxWinner;
    } else {
      unsetSelector.buyBoxPrice = 1;
      unsetSelector.isBuyBoxWinner = 1;
    }
  } else {
    unsetSelector.buyBoxPrice = 1;
    unsetSelector.isBuyBoxWinner = 1;
  }

  if (response && response.salesRankings) {
    const salesRankings = !isArray(response.salesRankings) ? [response.salesRankings] : response.salesRankings;
    if (salesRankings.length > 0) {
      let category = salesRankings[0].productCategoryId;
      const salesRank = salesRankings[0].rank;

      if (!isNumber(category)) {
        category = category.substring(0, category.indexOf('_display_on_website'));
        const productGroup = category.replace(/_/g, ' ').replace(/(?: |\b)(\w)/g, (key) => key.toUpperCase());

        setSelector.productGroup = productGroup;
      }

      if (salesRank) {
        setSelector.salesRank = salesRank;
      }
    }
  }

  const updateSelector = {};
  if (!isEmpty(setSelector)) updateSelector.$set = setSelector;
  if (!isEmpty(unsetSelector)) updateSelector.$unset = unsetSelector;

  if (!isEmpty(updateSelector)) {
    Products.updateMany({
      userId,
      asin
    }, {
      ...updateSelector
    }).exec();
  }

  return Promise.resolve();
};

export const SaveDataLowest = async ({
  userId,
  asin,
  response,
  condition
}) => {
  if (response && response.lowestOfferListings && response.lowestOfferListings.length > 0) {
    let { lowestOfferListings } = response;
    lowestOfferListings = lowestOfferListings.filter(listing => (
      ((listing.itemCondition === condition) && listing.price.landedPrice)
    ));

    if (lowestOfferListings.length > 0) {
      lowestOfferListings = sortBy(lowestOfferListings, ['price.landedPrice.amount']);
      const setObj = {
        lowestOfferPrice: lowestOfferListings[0].price.landedPrice.amount
      };
      const lowestFBAOffer = lowestOfferListings.find(({ fulfillmentChannel }) => fulfillmentChannel === 'Amazon');
      if (lowestFBAOffer) {
        extend(setObj, { lowestFBAOfferPrice: lowestFBAOffer.price.landedPrice.amount });
      } else {
        // Update LowestFBAOfferPrice
        Products.updateMany({
          userId,
          asin
        }, {
          $unset: { lowestFBAOfferPrice: 1 }
        }).exec();
      }

      // Update LowestOfferPrice & lowestFBAOfferPrice
      Products.updateMany({
        userId,
        asin
      }, {
        $set: setObj
      }).exec();

      return Promise.resolve();
    }
  }

  // Update LowestOfferPrice
  Products.updateMany({
    userId,
    asin
  }, {
    $unset: { lowestOfferPrice: 1 }
  }).exec();

  return Promise.resolve();
};
