import Products from '../../../../models/products';

const SaveInventoryQuantity = async ({ userId, report }) => {
  const reportData = report.map(({
    sku,
    fnsku,
    afnWarehouseQuantity,
    afnTotalQuantity,
    afnFulfillableQuantity,
    afnUnsellableQuantity,
    afnInboundReceivingQuantity,
    afnInboundShippedQuantity,
    afnInboundWorkingQuantity,
    afnReservedQuantity
  }) => ({
    updateOne: {
      filter: {
        userId,
        sellerSku: sku
      },
      update: {
        $set: {
          fnsku,
          afnWarehouseQuantity,
          afnTotalQuantity,
          sellableQuantity: afnFulfillableQuantity,
          afnUnsellableQuantity,
          afnInboundReceivingQuantity,
          afnInboundShippedQuantity,
          afnInboundWorkingQuantity,
          afnInboundQuantity: ((afnInboundReceivingQuantity || 0) + (afnInboundShippedQuantity || 0) + (afnInboundWorkingQuantity || 0)),
          afnReservedQuantity
        }
      }
    }
  }));

  if (reportData.length > 0) {
    return Products.bulkWrite(reportData);
  }
  return Promise.resolve();
};

export default SaveInventoryQuantity;
