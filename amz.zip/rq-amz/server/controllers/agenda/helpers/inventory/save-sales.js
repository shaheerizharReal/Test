import moment from 'moment';
import { find, round, isEmpty } from 'lodash';

import Products from '../../../../models/products';
import SalesDailyHistory from '../../../../models/sales-daily-history';
import SalesData from '../../../../models/sales-data';

import GetDefaultCalculationPrice from '../../../users/get-default-calculation-price';
import { ChooseDefaultCalculationPrice } from '../../definitions/utils';

import { FULLFILMENT_TYPE } from '../../../../../config/constants';

const CalculateSalesHistory = async ({
  userId,
  name,
  startDate,
  endDate,
  job
}) => {
  console.log('\n\n', 'name', name);

  // Get SellerSku List
  const sellerSkuList = await SalesDailyHistory.distinct('sellerSku', {
    userId,
    timestamp: { $gte: new Date(startDate), $lte: new Date(endDate) }
  });
  console.log('\n\n', 'sellerSkuList', sellerSkuList.length);

  const { profitCalculatedBy } = await GetDefaultCalculationPrice({ userId });
  const products = await Products.find({
    userId,
    sellerSku: { $in: sellerSkuList }
  }).select({
    sellerSku: 1,
    costPrice: 1,
    listPrice: 1,
    buyBoxPrice: 1,
    lowestOfferPrice: 1,
    lowestFBAOfferPrice: 1,
    shipBy: 1,
    shippingRate: 1,
    packageDimensions: 1,
    fee: 1,
    fulfilmentType: 1,
    sellableQuantity: 1,
    afnInboundShippedQuantity: 1,
    afnReservedQuantity: 1,
    openDate: 1
  });
  console.log('\n\n', 'products', products.length);

  // Get Sales Data
  const salesDataArr = await SalesDailyHistory.aggregate([
    {
      $match: {
        userId,
        timestamp: { $gte: new Date(startDate), $lte: new Date(endDate) }
      }
    },
    {
      $group: {
        _id: '$sellerSku',
        sellerSku: { $first: '$sellerSku' },
        orders: { $sum: '$orders' },
        pendingOrders: { $sum: '$pendingOrders' },
        unitsSold: { $sum: '$unitsSold' },
        saleAmount: { $sum: '$saleAmount' },
        promotionDiscount: { $sum: '$promotionDiscount' }
      }
    }
  ]);
  console.log('\n\n', 'salesDataArr', salesDataArr.length);

  const productSalesDataArr = [];

  // Make Data To Be Inserted In Collection
  let totalOrders = 0;
  let totalUnitsSold = 0;
  let totalSaleAmount = 0.0;
  let totalPromotionDiscount = 0.0;
  let totalUnitsInStock = 0;
  let totalFees = 0;
  let totalGrossProfit = 0.0;
  let totalNetProfit = 0.0;
  let totalProfitPercentage = 0.0;
  let totalRoiPercentage = 0.0;
  for (let i = 0; i < salesDataArr.length; i += 1) {
    const sale = salesDataArr[i];

    const {
      sellerSku,
      orders,
      pendingOrders,
      unitsSold,
      saleAmount,
      promotionDiscount
    } = sale;

    const product = find(products, { sellerSku });
    const { openDate } = product || {};
    const productsAge = moment().diff(moment(new Date(openDate)), 'days');

    if (!isEmpty(product)) {
      if (name === 'Today') {
        let feeses = 0;
        const {
          costPrice,
          listPrice,
          buyBoxPrice,
          lowestOfferPrice,
          lowestFBAOfferPrice,
          fee,
          fulfilmentType,
          shipBy,
          shippingRate,
          packageDimensions
        } = product;
        const defaultPrice = ChooseDefaultCalculationPrice({
          profitCalculatedBy,
          listPrice,
          buyBoxPrice,
          lowestOfferPrice,
          lowestFBAOfferPrice
        });

        if (fee) {
          if (defaultPrice > 0 && fee.feePercentage) {
            feeses += round(defaultPrice * (fee.feePercentage / 100), 2);
          }

          if (fee.otherFees) {
            feeses += round(fee.otherFees, 2);
          }

          if (fulfilmentType === FULLFILMENT_TYPE.AMAZON) {
            if ([9, 10, 11].includes(moment().month())) {
              if (fee.monthlyStorageFeeOct) {
                feeses += round(fee.monthlyStorageFeeOct, 2);
              }
            } else if (fee.monthlyStorageFeeJan) {
              feeses += round(fee.monthlyStorageFeeJan, 2);
            }
          }
        }

        let totalCosts = 0;
        if (costPrice > 0) {
          totalCosts += costPrice;
        }
        if (shipBy === 'byItem' && shippingRate > 0) {
          totalCosts += shippingRate;
        } else if (shipBy === 'byWeight' && packageDimensions && !isEmpty(packageDimensions)) {
          const { weight } = packageDimensions;
          if (weight > 0) {
            totalCosts += (shippingRate * weight);
          }
        }

        const calculation = defaultPrice - feeses - totalCosts;
        const profit = round(calculation, 2);
        const profitPercentage = defaultPrice > 0 ? round(((profit / defaultPrice) * 100), 2) : undefined;
        const roiPercentage = costPrice > 0 ? round(((profit / costPrice) * 100), 2) : undefined;

        productSalesDataArr.push({
          updateOne: {
            filter: {
              userId,
              sellerSku
            },
            update: {
              $set: {
                profit,
                profitPercentage,
                roiPercentage,
                updatedAt: new Date()
              }
            }
          }
        });
      } else if (name === '30 Days') {
        let unitsPer30Days = 0;
        let suggestedBuyQuantity30Days = 0;
        unitsPer30Days = round(unitsSold / 30);
        if (unitsSold > 0 && product) {
          if (product.fulfilmentType === FULLFILMENT_TYPE.AMAZON) {
            const {
              sellableQuantity,
              afnInboundShippedQuantity,
              afnReservedQuantity
            } = product;
            if (productsAge <= 30) {
              if (unitsPer30Days === 0) {
                suggestedBuyQuantity30Days = (unitsSold + pendingOrders) - (
                  (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                    (afnReservedQuantity || 0) - pendingOrders
                  )
                );
              } else {
                suggestedBuyQuantity30Days = ((30 * unitsPer30Days) + pendingOrders) - (
                  (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                    (afnReservedQuantity || 0) - pendingOrders
                  )
                );
              }
            } else {
              suggestedBuyQuantity30Days = (unitsSold || 0) + pendingOrders - (
                (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                  (afnReservedQuantity || 0) - pendingOrders
                )
              );
            }
          } else {
            const { sellableQuantity } = product;

            if (productsAge <= 30) {
              if (unitsPer30Days === 0) {
                suggestedBuyQuantity30Days = unitsSold + pendingOrders - (sellableQuantity || 0);
              } else {
                suggestedBuyQuantity30Days = ((30 * unitsPer30Days) + pendingOrders) - (
                  sellableQuantity || 0
                );
              }
            } else {
              suggestedBuyQuantity30Days = (
                (unitsSold || 0) + pendingOrders
              ) - (sellableQuantity || 0);
            }
          }

          if (suggestedBuyQuantity30Days < 0) {
            suggestedBuyQuantity30Days = 0;
          }
        }

        productSalesDataArr.push({
          updateOne: {
            filter: {
              userId,
              sellerSku
            },
            update: {
              $set: {
                suggestedBuyQuantity30Days,
                unitsPer30Days,
                salesLast30Days: unitsSold,
                salesAmountLast30Days: round(saleAmount, 2),
                totalOrdersLast30Days: orders,
                totalPendingOrdersLast30Days: pendingOrders,
                updatedAt: new Date()
              }
            }
          }
        });
      } else if (name === '60 Days') {
        let unitsPer60Days = 0;
        let suggestedBuyQuantity60Days = 0;

        unitsPer60Days = round(unitsSold / 60);
        if (unitsSold > 0 && product) {
          if (product.fulfilmentType === FULLFILMENT_TYPE.AMAZON) {
            const {
              sellableQuantity,
              afnInboundShippedQuantity,
              afnReservedQuantity
            } = product;
            if (productsAge <= 30) {
              if (unitsPer60Days === 0) {
                suggestedBuyQuantity60Days = 2 * ((unitsSold + pendingOrders) - (
                  (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                    (afnReservedQuantity || 0) - pendingOrders
                  )
                ));
              } else {
                suggestedBuyQuantity60Days = ((60 * unitsPer60Days) + pendingOrders) - (
                  (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                    (afnReservedQuantity || 0) - pendingOrders
                  )
                );
              }
            } else {
              suggestedBuyQuantity60Days = (unitsSold || 0) + pendingOrders - (
                (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                  (afnReservedQuantity || 0) - pendingOrders
                )
              );
            }
          } else {
            const { sellableQuantity } = product;
            if (productsAge <= 30) {
              if (unitsPer60Days === 0) {
                suggestedBuyQuantity60Days = 2 * (
                  unitsSold + pendingOrders - (sellableQuantity || 0)
                );
              } else {
                suggestedBuyQuantity60Days = ((60 * unitsPer60Days) + pendingOrders) - (
                  sellableQuantity || 0
                );
              }
            } else {
              suggestedBuyQuantity60Days = (
                (unitsSold || 0) + pendingOrders
              ) - (sellableQuantity || 0);
            }
          }

          if (suggestedBuyQuantity60Days < 0) {
            suggestedBuyQuantity60Days = 0;
          }
        }

        productSalesDataArr.push({
          updateOne: {
            filter: {
              userId,
              sellerSku
            },
            update: {
              $set: {
                suggestedBuyQuantity60Days,
                unitsPer60Days,
                salesLast60Days: unitsSold,
                salesAmountLast60Days: round(saleAmount, 2),
                totalOrdersLast60Days: orders,
                totalPendingOrdersLast60Days: pendingOrders,
                updatedAt: new Date()
              }
            }
          }
        });
      } else if (name === '90 Days') {
        let unitsPer90Days = 0;
        let suggestedBuyQuantity90Days = 0;

        unitsPer90Days = round(unitsSold / 90);
        if (unitsSold > 0 && product) {
          if (product.fulfilmentType === FULLFILMENT_TYPE.AMAZON) {
            const {
              sellableQuantity,
              afnInboundShippedQuantity,
              afnReservedQuantity
            } = product;
            if (productsAge <= 30) {
              if (unitsPer90Days === 0) {
                suggestedBuyQuantity90Days = 3 * ((unitsSold + pendingOrders) - (
                  (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                    (afnReservedQuantity || 0) - pendingOrders
                  )
                ));
              } else {
                suggestedBuyQuantity90Days = ((90 * unitsPer90Days) + pendingOrders) - (
                  (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                    (afnReservedQuantity || 0) - pendingOrders
                  )
                );
              }
            } else {
              suggestedBuyQuantity90Days = (unitsSold || 0) + pendingOrders - (
                (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                  (afnReservedQuantity || 0) - pendingOrders
                )
              );
            }
          } else {
            const { sellableQuantity } = product;
            if (productsAge <= 30) {
              if (unitsPer90Days === 0) {
                suggestedBuyQuantity90Days = 3 * (
                  unitsSold + pendingOrders - (sellableQuantity || 0)
                );
              } else {
                suggestedBuyQuantity90Days = ((90 * unitsPer90Days) + pendingOrders) - (
                  sellableQuantity || 0
                );
              }
            } else {
              suggestedBuyQuantity90Days = (
                (unitsSold || 0) + pendingOrders
              ) - (sellableQuantity || 0);
            }
          }

          if (suggestedBuyQuantity90Days < 0) {
            suggestedBuyQuantity90Days = 0;
          }
        }

        productSalesDataArr.push({
          updateOne: {
            filter: {
              userId,
              sellerSku
            },
            update: {
              $set: {
                suggestedBuyQuantity90Days,
                unitsPer90Days,
                salesLast90Days: unitsSold,
                salesAmountLast90Days: round(saleAmount, 2),
                totalOrdersLast90Days: orders,
                totalPendingOrdersLast90Days: pendingOrders,
                updatedAt: new Date()
              }
            }
          }
        });
      }
    }

    let unitsInStock = 0;
    let costPrice = 0.0;
    let fees = 0.0;
    if (product) {
      if (product.costPrice) {
        ({ costPrice } = product);
        costPrice *= unitsSold;
      }

      const {
        fee,
        fulfilmentType,
        sellableQuantity
      } = product;
      if (fee) {
        if (fee.feePercentage) {
          fees += round(saleAmount * (fee.feePercentage / 100), 2);
        }

        if (fee.otherFees) {
          fees += round((fee.otherFees * unitsSold), 2);
        }
      }

      if (fulfilmentType === FULLFILMENT_TYPE.AMAZON) {
        if (sellableQuantity) {
          unitsInStock = sellableQuantity;
        }

        if (fee) {
          if ([9, 10, 11].includes(moment().month()) && fee.monthlyStorageFeeOct) {
            fees += round((fee.monthlyStorageFeeOct * unitsSold), 2);
          } else if (fee.monthlyStorageFeeJan) {
            fees += round((fee.monthlyStorageFeeJan * unitsSold), 2);
          }
        }
      } else if (sellableQuantity) {
        unitsInStock = sellableQuantity;
      }
    }

    const grossProfit = (
      saleAmount - costPrice
    );

    const netProfit = (
      grossProfit - fees
    );

    const profit = round(netProfit, 2);
    const profitPercentage = saleAmount > 0 ? round(((profit / saleAmount) * 100), 2) : 0;
    const roiPercentage = costPrice > 0 ? round(((profit / costPrice) * 100), 2) : 0;

    totalOrders += orders;
    totalUnitsSold += unitsSold;
    totalSaleAmount += saleAmount;
    totalPromotionDiscount += promotionDiscount;
    totalUnitsInStock += unitsInStock;
    totalFees += fees;
    totalGrossProfit += grossProfit;
    totalNetProfit += netProfit;
    totalProfitPercentage += profitPercentage;
    totalRoiPercentage += roiPercentage;

    if (i % 3 === 0) {
      job.attrs.lockedAt = new Date();
      job.save();
    }
  }

  if (salesDataArr.length > 0) {
    totalProfitPercentage = round((totalProfitPercentage / salesDataArr.length), 2);
    totalRoiPercentage = round((totalRoiPercentage / salesDataArr.length), 2);
  }

  console.log('\n\n', 'productSalesDataArr', productSalesDataArr.length);
  if (productSalesDataArr.length > 0) {
    await Products.bulkWrite(productSalesDataArr);
  }

  return {
    totalOrders,
    totalUnitsSold,
    totalSaleAmount: round(totalSaleAmount, 2),
    totalPromotionDiscount: round(totalPromotionDiscount, 2),
    totalUnitsInStock,
    totalFees: round(totalFees, 2),
    totalGrossProfit: round(totalGrossProfit, 2),
    totalNetProfit: round(totalNetProfit, 2),
    totalProfitPercentage: round(totalProfitPercentage, 2),
    totalRoiPercentage: round(totalRoiPercentage, 2)
  };
};

const SaveSalesData = async ({ userId, job }) => {
  const salesDataArr = [];

  const durations = [
    { period: 0, unit: 'today', name: 'Today' },
    { period: 0, unit: 'yesterday', name: 'Yesterday' },
    { period: 15, unit: 'days', name: '15 Days' },
    { period: 30, unit: 'days', name: '30 Days' },
    { period: 60, unit: 'days', name: '60 Days' },
    { period: 90, unit: 'days', name: '90 Days' }
  ];

  await Products.updateMany({
    userId
  }, {
    $set: {
      updatedAt: new Date()
    },
    $unset: {
      suggestedBuyQuantity30Days: 1,
      unitsPer30Days: 1,
      salesLast30Days: 1,
      salesAmountLast30Days: 1,
      totalOrdersLast30Days: 1,
      totalPendingOrdersLast30Days: 1,
      suggestedBuyQuantity60Days: 1,
      unitsPer60Days: 1,
      salesLast60Days: 1,
      salesAmountLast60Days: 1,
      totalOrdersLast60Days: 1,
      totalPendingOrdersLast60Days: 1,
      suggestedBuyQuantity90Days: 1,
      unitsPer90Days: 1,
      salesLast90Days: 1,
      salesAmountLast90Days: 1,
      totalOrdersLast90Days: 1,
      totalPendingOrdersLast90Days: 1
    }
  });

  for (let i = 0; i < durations.length; i += 1) {
    const { period, unit, name } = durations[i];

    let startDate = null;
    let endDate = moment.tz('America/Los_Angeles')
      .utc()
      .format();
    if (unit === 'today') {
      startDate = moment.tz('America/Los_Angeles').startOf('day')
        .utc()
        .format();
    } else if (unit === 'yesterday') {
      startDate = moment.tz('America/Los_Angeles').subtract(1, 'days').startOf('day')
        .utc()
        .format();
      endDate = moment.tz('America/Los_Angeles').subtract(1, 'days').endOf('day')
        .utc()
        .format();
    } else if (unit === 'days') {
      startDate = moment.tz('America/Los_Angeles').subtract(period - 1, 'days').startOf('day')
        .utc()
        .format();
    }
    const {
      totalOrders,
      totalUnitsSold,
      totalSaleAmount,
      totalPromotionDiscount,
      totalUnitsInStock,
      totalFees,
      totalGrossProfit,
      totalNetProfit,
      totalProfitPercentage,
      totalRoiPercentage
    } = await CalculateSalesHistory({
      userId,
      name,
      startDate,
      endDate,
      job
    });

    salesDataArr.push({
      updateOne: {
        filter: {
          userId,
          period: period > 0 ? `${period}-${unit}` : unit
        },
        update: {
          $set: {
            name,
            totalOrders,
            totalUnitsSold,
            totalSaleAmount,
            totalPromotionDiscount,
            totalUnitsInStock,
            totalFees,
            totalGrossProfit,
            totalNetProfit,
            totalProfitPercentage,
            totalRoiPercentage,
            updatedAt: new Date()
          },
          $setOnInsert: {
            createdAt: new Date()
          }
        },
        upsert: true
      }
    });
  }

  if (salesDataArr.length > 0) {
    await SalesData.bulkWrite(salesDataArr);
  }
  return Promise.resolve();
};

export default SaveSalesData;
