import Products from '../../../../models/products';

const SaveSNLData = async ({ userId, report }) => {
  const skuList = report.filter(row => row.enrolledInSnL).map(row => row.sku);

  Products.updateMany({
    userId,
    sellerSku: { $in: skuList }
  }, {
    $set: {
      enrolledInSnL: true
    }
  }).exec();

  Products.updateMany({
    userId,
    sellerSku: { $nin: skuList }
  }, {
    $set: {
      enrolledInSnL: false
    }
  }).exec();

  return Promise.resolve();
};

export default SaveSNLData;
