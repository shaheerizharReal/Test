import moment from 'moment';
import { groupBy, map } from 'lodash';

import Orders from '../../../../models/orders';
import SalesDailyHistory from '../../../../models/sales-daily-history';

const mergeColumn = (row, columnName) => parseFloat(
  (row.reduce((feild, next) => (feild + (next[columnName] || 0)), 0)).toFixed(2)
);

const SaveOrdersReport = async ({ userId, date, report }) => {
  const groupedReport = groupBy(report, row => [row.sku, row.amazonOrderId]);
  const orders = map(groupedReport, (row) => {
    const {
      amazonOrderId,
      merchantOrderId,
      sku,
      purchaseDate,
      fulfillmentChannel,
      salesChannel,
      productName,
      asin,
      orderStatus,
      itemStatus,
      currency,
      isBusinessOrder,
      isReplacementOrder,
      originalOrderId,
      lastUpdatedDate
    } = row[0];

    return {
      amazonOrderId,
      sellerOrderId: merchantOrderId,
      sellerSku: sku,
      purchaseDate: moment(purchaseDate).toDate(),
      lastUpdatedDate: moment(lastUpdatedDate).toDate(),
      orderStatus,
      fulfillmentChannel,
      salesChannel,
      title: productName,
      asin,
      itemStatus,
      currency,
      isBusinessOrder,
      isReplacementOrder,
      originalOrderId,
      quantity: parseInt(mergeColumn(row, 'quantity'), 10),
      itemTax: mergeColumn(row, 'itemTax'),
      itemPrice: mergeColumn(row, 'itemPrice'),
      shippingPrice: mergeColumn(row, 'shippingPrice'),
      shippingTax: mergeColumn(row, 'shippingTax'),
      giftWrapPrice: mergeColumn(row, 'giftWrapPrice'),
      giftWrapTax: mergeColumn(row, 'giftWrapTax'),
      shipPromotionDiscount: mergeColumn(row, 'shipPromotionDiscount'),
      itemPromotionDiscount: mergeColumn(row, 'itemPromotionDiscount')
    };
  });

  let writeData = orders.filter(({ amazonOrderId }) => amazonOrderId.indexOf('S') !== 0);
  writeData = writeData.map((row) => {
    const { amazonOrderId, sellerSku } = row;

    return {
      updateOne: {
        filter: {
          userId, amazonOrderId, sellerSku
        },
        update: {
          $set: {
            ...row,
            orderReconcileStatus: 'Pending',
            updatedAt: new Date()
          },
          $setOnInsert: {
            createdAt: new Date()
          }
        },
        upsert: true
      }
    };
  });

  console.log('\n\n', 'Orders', writeData.length);
  if (writeData.length > 0) {
    await Orders.bulkWrite(writeData);
  }

  await Orders.deleteMany({
    userId,
    purchaseDate: { $lt: moment(date).subtract(90, 'days').startOf('day').toDate() }
  });

  await SalesDailyHistory.deleteMany({
    userId,
    timestamp: { $lt: moment(date).subtract(90, 'days').startOf('day').toDate() }
  });

  return Promise.resolve();
};

export default SaveOrdersReport;
