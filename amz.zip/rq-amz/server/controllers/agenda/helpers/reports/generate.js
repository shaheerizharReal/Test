import moment from 'moment';

import MwsAPI from '../../../mws';
import { ThrottlingException, MWSErrorException, GenerateReportException } from '../../../utils/custom-exceptions';
import Users from '../../../../models/users';

const DEFAULT_RETRIES = 25;
const DEFAULT_STATUS = '_BEFORE_REQUEST_';

const GenerateReport = async ({
  userId,
  reportType,
  reportOptions,
  reportRequestId,
  reportRequestStatus,
  startDate,
  endDate,
  reportId,
  retries
}) => {
  const user = await Users.findOne({ _id: userId });
  try {
    retries = retries || DEFAULT_RETRIES;
    reportRequestStatus = reportRequestStatus || DEFAULT_STATUS;

    if (retries > 0) {
      console.log(`*****************************************************************`);
      console.log(`Company:${user.name} (${userId})`);
      console.log(`ReportType: ${reportType}`);
      console.log(`StartDate: ${moment(startDate).format('DD/MM/YY LTS')}\tEndDate: ${moment(endDate).format('DD/MM/YY LTS')}`);
      console.log(`Retries: ${retries}`);
      console.log(`*****************************************************************`);

      switch (reportRequestStatus) {
        case '_BEFORE_REQUEST_': case '_CANCEL_NOT_FOUND_':
          const req = await MwsAPI({
            endpoint: 'RequestReport',
            params: { userId, reportType, reportOptions, startDate, endDate }
          });

          reportRequestId = req.reportRequestId;
          reportRequestStatus = req.reportProcessingStatus;

          const nextAvailableAt = moment().add((30 * 1000), 'milliseconds').toDate();
          throw new ThrottlingException({
            message: 'Delay',
            endpoint: 'GenerateReport',
            nextAvailableAt,
            userId
          });

        case '_IN_PROGRESS_': case '_SUBMITTED_':
          const [reportRequest] = await MwsAPI({
            endpoint: 'GetReportRequestList',
            params: {
              userId,
              reportRequestIdList: [reportRequestId],
              reportTypeList: [reportType],
              maxCount: 1
            }
          });

          reportRequestStatus = reportRequest.reportProcessingStatus;
          retries -= 1;

          if (reportRequestStatus === '_IN_PROGRESS_' || reportRequestStatus === '_SUBMITTED_') {
            const nextAvailableAt = moment().add((180 * 1000), 'milliseconds').toDate();
            throw new ThrottlingException({
              message: 'Delay',
              endpoint: 'GenerateReport',
              nextAvailableAt,
              userId
            });
          }

          return GenerateReport({
            userId,
            reportType,
            reportRequestId,
            reportRequestStatus: reportRequest.reportProcessingStatus,
            startDate,
            endDate,
            reportId: reportRequest.generatedReportId,
            retries
          });


        /* _CANCELLED_ */
        case '_CANCELLED_':
          const existingReportRequestList = await MwsAPI({
            endpoint: 'GetReportRequestList',
            params: {
              userId,
              reportProcessingStatusList: ['_DONE_', '_DONE_NO_DATA_'],
              reportTypeList: [reportType]
            }
          });

          let existingReportFound = false;
          for (let i = 0; i < existingReportRequestList.length; i += 1) {
            const existingReportRequest = existingReportRequestList[i];

            if (startDate && endDate) {
              if (moment(startDate).milliseconds(0).isSame(moment(existingReportRequest.startDate)) &&
                    moment(endDate).milliseconds(0).isSame(moment(existingReportRequest.endDate))) {
                existingReportFound = true;
              }
            } else {
              existingReportFound = true;
            }

            if (existingReportFound) {
              return GenerateReport({
                userId,
                reportType,
                reportRequestId,
                reportRequestStatus: existingReportRequest.reportProcessingStatus,
                startDate,
                endDate,
                reportId: existingReportRequest.generatedReportId,
                retries
              });
            }
          }

          reportRequestStatus = '_CANCEL_NOT_FOUND_';
          retries = 25;

          const nextRunAt = moment().add(1, 'days').startOf('day').toDate();
          throw new ThrottlingException({
            message: 'Existing Report Not Found',
            endpoint: 'GenerateReport',
            nextAvailableAt: nextRunAt,
            userId
          });


        case '_DONE_':
          const report = await MwsAPI({
            endpoint: 'GetReport',
            params: { userId, reportId }
          });
          return Promise.resolve(report);



        case '_DONE_NO_DATA_':
          return Promise.resolve([]);

        default:
          console.log('Default case in Generate Report');
      }
    }

    throw new MWSErrorException({
      message: 'Retries Finished',
      endpoint: 'GenerateReport',
      userId
    });
  } catch (error) {
    console.log('\n\n\n');
    console.log('*****************************************************************');
    console.log('********************   GenerateReport ERROR   *******************');
    console.log('*****************************************************************');
    console.log(`Company:${user.name} (${userId})`);
    console.log(`ReportType: ${reportType}`);
    console.log(`StartDate: ${moment(startDate).format('DD/MM/YY LTS')}\tEndDate: ${moment(endDate).format('DD/MM/YY LTS')}`);
    console.log('*****************************************************************');

    if (error instanceof ThrottlingException) {
      throw new GenerateReportException({
        message: error.message,
        nextAvailableAt: error.nextAvailableAt,
        reportId,
        reportRequestId,
        reportRequestStatus,
        retries
      });
    } else if (error instanceof MWSErrorException) {
      throw error;
    }

    throw new MWSErrorException({
      message: error.message,
      endpoint: 'GenerateReport',
      userId
    });
  }
};

export default GenerateReport;
