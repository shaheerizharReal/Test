import Agenda from 'agenda';
import { LOCAL_MONGO_URL, PRODUCTION_MONGO_URL } from '../../../config/settings';

const MONGO_URL = (process.env.NODE_ENV === 'development') ? LOCAL_MONGO_URL : PRODUCTION_MONGO_URL;

const agenda = new Agenda({
  db: {
    address: MONGO_URL,
    collection: 'agendaJobs'
  },
  defaultConcurrency: 15,
  maxConcurrency: 200,
  defaultLockLifetime: 20 * 60000
});

export default agenda;
