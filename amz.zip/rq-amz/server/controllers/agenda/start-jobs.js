import agenda from './index';
import AgendaJobs from '../../models/agenda-jobs';

const runSignUpJobs = async (userId) => {
  const [listingJob] = await AgendaJobs.find({
    'data.userId': userId,
    name: 'inventory:listing'
  });
  if (listingJob) {
    return;
  }

  agenda.create('inventory:listing', { userId })
    .unique({ 'data.userId': userId })
    .repeatEvery('30 minutes')
    .save();

  agenda.create('inventory:quantity', { userId })
    .unique({ 'data.userId': userId })
    .repeatEvery('30 minutes')
    .schedule('in 10 minutes')
    .save();

  agenda.create('inventory:images', { userId })
    .unique({ 'data.userId': userId })
    .repeatEvery('6 hours')
    .schedule('in 10 minutes')
    .save();

  agenda.create('pricing-data-api', { userId, skip: 0 })
    .unique({ 'data.userId': userId })
    .repeatEvery('1 hour')
    .schedule('in 15 minutes')
    .save();

  agenda.create('inventory:fees', { userId, skip: 0 })
    .unique({ 'data.userId': userId })
    .repeatEvery('4 hours')
    .schedule('in 2 hours')
    .save();

  agenda.create('orders', { userId })
    .unique({ 'data.userId': userId })
    .repeatEvery('3 hours')
    .save();

  agenda.create('summary.by.orders', { userId })
    .unique({ 'data.userId': userId })
    .repeatEvery('60 minutes')
    .schedule('in 1 hour')
    .save();

  agenda.create('inventory:snl', { userId })
    .unique({ 'data.userId': userId })
    .repeatEvery('24 hours')
    .schedule('in 15 minutes')
    .save();
};

export default runSignUpJobs;
