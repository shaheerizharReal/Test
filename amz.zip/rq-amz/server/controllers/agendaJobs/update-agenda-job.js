import { extend } from 'lodash';
import moment from 'moment';
import mongoose from 'mongoose';
import Users from '../../models/users';
import AgendaJobs from '../../models/agenda-jobs';


const RequeueAgendaJob = async ({ _id, filters }) => {
  const selector = {};
  const usersList = [];

  await AgendaJobs.updateOne({ _id }, {
    $set: {
      lockedAt: null,
      nextRunAt: moment().add(10, 's').toDate()
    }
  });

  Object.keys(filters).forEach((key) => {
    const filter = filters[key];
    switch (key) {
      case 'keyword':
        extend(selector, {
          $or: [
            { name: { $regex: `.*${filter.value}.*`, $options: 'i' } }
          ]
        });
        break;

      case 'userSelection':
        const userId = mongoose.Types.ObjectId(filter.value);
        extend(selector, { 'data.userId': userId });
        break;

      default:
        break;
    }
  });

  const allAgendaJobs = await AgendaJobs.find(selector);
  allAgendaJobs.forEach(({ data }) => {
    usersList.push(data.userId);
  });
  const users = await Users.find({ _id: { $in: usersList } });
  const agendaJobs = allAgendaJobs.map(({ data, ...rest }) => {
    const { userId } = data;
    const user = users.find(user => user._id.toString() === userId.toString());

    if (user) {
      const { name } = user;
      const { _doc } = rest;
      return {
        ..._doc,
        userName: name
      };
    }
    const { _doc } = rest;
    return {
      ..._doc
    };
  });
  return { agendaJobs };
};
export default RequeueAgendaJob;
