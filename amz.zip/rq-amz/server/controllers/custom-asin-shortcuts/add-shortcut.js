
import AsinShortcuts from '../../models/custom-asin-shortcuts';

const AddShortcut = async ({
  userId,
  url,
  displayName,
  iconText,
  visibility
}) => {
  await AsinShortcuts.create({
    userId,
    url,
    displayName,
    iconText,
    visibility
  });

  const asinShortcuts = await AsinShortcuts.find({
    userId
  });
  return asinShortcuts;
};

export default AddShortcut;
