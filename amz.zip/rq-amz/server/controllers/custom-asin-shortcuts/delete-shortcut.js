import AsinShortcuts from '../../models/custom-asin-shortcuts';

const DeleteShortcut = async ({ shortcutId }) => {
  await AsinShortcuts.deleteOne({ _id: shortcutId });
};

export default DeleteShortcut;
