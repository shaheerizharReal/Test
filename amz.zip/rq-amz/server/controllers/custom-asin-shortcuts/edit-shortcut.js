import AsinShortcuts from '../../models/custom-asin-shortcuts';

const EditShortcut = async ({
  userId,
  shortcutId,
  setObj
}) => {
  await AsinShortcuts.updateOne({
    _id: shortcutId.toString()
  }, {
    $set: setObj
  });

  return AsinShortcuts.findOne({
    _id: shortcutId
  });
};

export default EditShortcut;
