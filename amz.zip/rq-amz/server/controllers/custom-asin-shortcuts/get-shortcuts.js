import AsinShortcuts from '../../models/custom-asin-shortcuts';

const GetShortcuts = async ({ userId }) => {
  const shortcuts = await AsinShortcuts.find({ userId });

  return shortcuts;
};

export default GetShortcuts;
