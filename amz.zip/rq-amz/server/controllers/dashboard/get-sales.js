import SalesData from '../../models/sales-data';

const GetSales = async ({
  userId
}) => {
  let salesData = await SalesData.find({
    userId
  });

  salesData = salesData.map(({
    period,
    name,
    totalOrders,
    totalUnitsSold,
    totalSaleAmount,
    totalPromotionDiscount,
    totalUnitsInStock,
    totalFees,
    totalGrossProfit,
    totalNetProfit,
    totalProfitPercentage,
    totalRoiPercentage
  }) => ({
    period,
    name,
    totalOrders,
    totalUnitsSold,
    totalSaleAmount,
    totalPromotionDiscount,
    totalUnitsInStock,
    totalFees,
    totalGrossProfit,
    totalNetProfit,
    totalProfitPercentage,
    totalRoiPercentage
  }));

  const sales = {};
  for (let i = 0; i < salesData.length; i += 1) {
    sales[salesData[i].period] = salesData[i];
  }

  return { sales };
};
export default GetSales;
