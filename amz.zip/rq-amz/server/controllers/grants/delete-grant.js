import Grants from '../../models/grants';

const DeleteRole = async ({ _id }) => {
  await Grants.deleteOne({ _id });
};

export default DeleteRole;
