import Grants from '../../models/grants';

const GetDistinctRoles = async ({ userId }) => {
  const distinctRolesGlobal = await Grants.distinct('role', { userId: { $exists: false } });
  let distinctRoles = await Grants.distinct('role', { userId });

  distinctRoles = distinctRolesGlobal.concat(distinctRoles);
  return distinctRoles;
};

export default GetDistinctRoles;
