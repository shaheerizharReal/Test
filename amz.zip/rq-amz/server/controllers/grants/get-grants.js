import Grants from '../../models/grants';

const GetGrants = async () => {
  const total = await Grants.find();
  const grants = await Grants.find();

  return { grants, total };
};

export default GetGrants;
