import Grants from '../../models/grants';

const InventoryReadGrant = async ({
  userId, attributes, roleName
}) => {
  let role = null;

  if (roleName) {
    role = roleName;
  } else {
    const userGrants = await Grants.find({ resource: 'Inventory', userId });
    role = `Child${userGrants.length + 1} Can Read Inventory`;
  }

  await Grants.updateOne({
    role,
    userId
  }, {
    $set: {
      resource: 'Inventory',
      action: 'read',
      possession: 'any',
      attributes
    }
  }, {
    upsert: true
  });

  return role;
};

export default InventoryReadGrant;
