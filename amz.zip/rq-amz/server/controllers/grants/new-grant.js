import Grants from '../../models/grants';

const NewGrant = async ({
  name, modules, grantType, userId
}) => {
  const grants = [];
  modules.forEach((modle) => {
    const grant = {};
    grant.role = name;
    grant.resource = modle;
    grantType.forEach((type) => {
      grant.action = type;
      grant.possession = 'any';
      grant.userId = userId;
      grants.push({ ...grant });
    });
  });

  await Grants.insertMany(grants);
  const roles = await Grants.find({ userId });

  return { roles };
};

export default NewGrant;
