import ExportProducts from '../../models/export-products';

const SaveExportProductsParams = async ({
  userId,
  skuList,
  columnsWanted
}) => {
  await ExportProducts.updateOne({
    _id: userId
  }, {
    $set: {
      skuList,
      columnsWanted
    }
  }, {
    upsert: true
  });

  return true;
};

export default SaveExportProductsParams;
