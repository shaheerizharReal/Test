import moment from 'moment';
import url from 'url';
import { startCase, round, extend } from 'lodash';
import Excel from 'exceljs';
import { Writable } from 'stream';

import ExportProductsParams from '../../models/export-products';
import Products from '../../models/products';
import Users from '../../models/users';

import { CONDITION_TYPE, FULLFILMENT_TYPE } from '../../../config/constants';

const refactorProductsData = (products, columnsWanted) => products.map(({
  sellerSku,
  asin,
  fnsku,
  title,
  fulfilmentType,
  condition,
  status,
  afnInboundShippedQuantity,
  afnReservedQuantity,
  decidedBuyQuantity,
  sellableQuantity,
  afnUnsellableQuantity,
  afnTotalQuantity,
  suggestedBuyQuantity30Days,
  suggestedBuyQuantity60Days,
  suggestedBuyQuantity90Days,
  totalOrdersLast30Days,
  salesLast30Days,
  salesAmountLast30Days,
  totalOrdersLast60Days,
  salesLast60Days,
  salesAmountLast60Days,
  totalOrdersLast90Days,
  salesLast90Days,
  salesAmountLast90Days,
  listPrice,
  buyBoxPrice,
  lowestOfferPrice,
  lowestFBAOfferPrice,
  costPrice,
  noOfSellers,
  fee,
  profit,
  profitPercentage,
  roiPercentage,
  supplier,
  salesRank,
  productGroup,
  purchaseLink,
  storeSection,
  notesSection,
  enrolledInSnL,
  openDate
}) => {
  fulfilmentType = fulfilmentType === FULLFILMENT_TYPE.AMAZON ? 'Amazon' : 'Merchant';
  condition = Object.values(CONDITION_TYPE).find(
    conditionType => conditionType.value === Number(condition)
  );

  let referralFee;
  if (listPrice > 0 && fee && fee.feePercentage) {
    referralFee = round(listPrice * (fee.feePercentage / 100), 2);
  }

  let fbaFee;
  if (fee && fee.otherFees) {
    fbaFee = fee.otherFees;
  }

  let storageFee;
  if (fulfilmentType === 'Amazon' && fee) {
    if ([9, 10, 11].includes(moment().month())) {
      if (fee.monthlyStorageFeeOct) {
        storageFee = round(fee.monthlyStorageFeeOct, 2);
      }
    } else if (fee.monthlyStorageFeeJan) {
      storageFee = round(fee.monthlyStorageFeeJan, 2);
    }
  }

  const newProduct = {};
  if (columnsWanted.includes('title')) {
    extend(newProduct, { title });
  }
  if (columnsWanted.includes('asin')) {
    extend(newProduct, { asin });
  }
  if (columnsWanted.includes('sellerSku')) {
    extend(newProduct, { sellerSku });
  }
  if (columnsWanted.includes('fnsku')) {
    extend(newProduct, { fnsku });
  }
  if (columnsWanted.includes('fulfilmentType')) {
    extend(newProduct, { fulfilledBy: fulfilmentType });
  }
  if (columnsWanted.includes('condition')) {
    extend(newProduct, { condition: !!condition && condition.label });
  }
  if (columnsWanted.includes('status')) {
    extend(newProduct, { status });
  }
  if (columnsWanted.includes('afnInboundQuantity')) {
    extend(newProduct, { inboundQuantity: afnInboundShippedQuantity || 0 });
  }
  if (columnsWanted.includes('afnReservedQuantity')) {
    extend(newProduct, { reservedQuantity: afnReservedQuantity || 0 });
  }
  if (columnsWanted.includes('decidedBuyQuantity')) {
    extend(newProduct, { decidedBuyQuantity: decidedBuyQuantity || 0 });
  }
  if (columnsWanted.includes('sellableQuantity')) {
    extend(newProduct, { sellableQuantity });
  }
  if (columnsWanted.includes('afnUnsellableQuantity')) {
    extend(newProduct, { unsellableQuantity: afnUnsellableQuantity || 0 });
  }
  if (columnsWanted.includes('afnTotalQuantity')) {
    extend(newProduct, { totalQuantity: afnTotalQuantity || 0 });
  }
  if (columnsWanted.includes('suggestedBuyQuantity30Days')) {
    extend(newProduct, { suggestedBuyQuantity30Days: suggestedBuyQuantity30Days || 0 });
  }
  if (columnsWanted.includes('suggestedBuyQuantity60Days')) {
    extend(newProduct, { suggestedBuyQuantity60Days: suggestedBuyQuantity60Days || 0 });
  }
  if (columnsWanted.includes('suggestedBuyQuantity90Days')) {
    extend(newProduct, { suggestedBuyQuantity90Days: suggestedBuyQuantity90Days || 0 });
  }
  if (columnsWanted.includes('ordersLast30Days')) {
    extend(newProduct, { ordersLast30Days: totalOrdersLast30Days || 0 });
  }
  if (columnsWanted.includes('salesLast30Days')) {
    extend(newProduct, { salesLast30Days: salesLast30Days || 0 });
  }
  if (columnsWanted.includes('salesAmountLast30Days')) {
    extend(newProduct, { salesAmountLast30Days: salesAmountLast30Days || 0 });
  }
  if (columnsWanted.includes('ordersLast60Days')) {
    extend(newProduct, { ordersLast60Days: totalOrdersLast60Days || 0 });
  }
  if (columnsWanted.includes('salesLast60Days')) {
    extend(newProduct, { salesLast60Days: salesLast60Days || 0 });
  }
  if (columnsWanted.includes('salesAmountLast60Days')) {
    extend(newProduct, { salesAmountLast60Days: salesAmountLast60Days || 0 });
  }
  if (columnsWanted.includes('ordersLast90Days')) {
    extend(newProduct, { ordersLast90Days: totalOrdersLast90Days || 0 });
  }
  if (columnsWanted.includes('salesLast90Days')) {
    extend(newProduct, { salesLast90Days: salesLast90Days || 0 });
  }
  if (columnsWanted.includes('salesAmountLast90Days')) {
    extend(newProduct, { salesAmountLast90Days: salesAmountLast90Days || 0 });
  }
  if (columnsWanted.includes('listPrice')) {
    extend(newProduct, { salePrice: round(listPrice, 2) });
  }
  if (columnsWanted.includes('buyBoxPrice')) {
    extend(newProduct, { buyBoxPrice: buyBoxPrice > 0 ? round(buyBoxPrice, 2) : 'N/A' });
  }
  if (columnsWanted.includes('lowestOfferPrice')) {
    extend(newProduct, { lowestOfferPrice: lowestOfferPrice > 0 ? round(lowestOfferPrice, 2) : 'N/A' });
  }
  if (columnsWanted.includes('lowestFBAOfferPrice')) {
    extend(newProduct, { lowestFBAOfferPrice: lowestFBAOfferPrice > 0 ? round(lowestFBAOfferPrice, 2) : 'N/A' });
  }
  if (columnsWanted.includes('costPrice')) {
    extend(newProduct, { costPrice: costPrice > 0 ? round(costPrice, 2) : 'N/A' });
  }
  if (columnsWanted.includes('noOfSellers')) {
    extend(newProduct, { noOfSellers: noOfSellers || 0 });
  }
  if (columnsWanted.includes('referralFee')) {
    extend(newProduct, { referralFee: referralFee || 'N/A' });
  }
  if (columnsWanted.includes('fbaFee')) {
    extend(newProduct, { fbaFee: fbaFee || 'N/A' });
  }
  if (columnsWanted.includes('storageFee')) {
    extend(newProduct, { storageFee: storageFee || 'N/A' });
  }
  if (columnsWanted.includes('profit')) {
    extend(newProduct, { profit: profit || 'N/A' });
  }
  if (columnsWanted.includes('profitPercentage')) {
    extend(newProduct, { profitPercentage: profitPercentage || 'N/A' });
  }
  if (columnsWanted.includes('roiPercentage')) {
    extend(newProduct, { roiPercentage: roiPercentage || 'N/A' });
  }
  if (columnsWanted.includes('supplier')) {
    extend(newProduct, { supplier: supplier || 'N/A' });
  }
  if (columnsWanted.includes('salesRank')) {
    extend(newProduct, { salesRank: salesRank || 'N/A' });
  }
  if (columnsWanted.includes('productGroup')) {
    extend(newProduct, { category: productGroup || 'N/A' });
  }
  if (columnsWanted.includes('purchaseLink')) {
    extend(newProduct, { purchaseLink: purchaseLink || 'N/A' });
  }
  if (columnsWanted.includes('storeSection')) {
    extend(newProduct, { storeSection: storeSection || 'N/A' });
  }
  if (columnsWanted.includes('notesSection')) {
    extend(newProduct, { notesSection: notesSection || 'N/A' });
  }
  if (columnsWanted.includes('enrolledInSnL')) {
    extend(newProduct, { enrolledInSnl: enrolledInSnL ? 'Yes' : 'No' });
  }
  if (columnsWanted.includes('openDate')) {
    extend(newProduct, { dateAdded: openDate ? moment(openDate).format('LL') : 'N/A' });
  }

  return newProduct;
});

const ExportProducts = async (req, res) => {
  const { query } = url.parse(req.url, true);
  const params = query;
  const { _id: userId, selectAll, isReplen } = params;
  let skuList = [];
  let columnsWanted = [];
  const exportProductsParams = await ExportProductsParams.findOne({
    _id: userId
  });
  if (exportProductsParams) {
    ({ skuList, columnsWanted } = exportProductsParams);
  }

  const headers = {
    'Content-type': 'application/vnd.ms-excel',
    'Transfer-Encoding': 'chunked',
    'Content-Disposition': `attachment; filename="Inventory At ${moment().format('LLLL')}.xlsx"`
  };
  res.writeHead(200, headers);

  const stream = new Writable({
    write(chunk) {
      res.write(chunk);
    }
  });

  const options = {
    stream: res,
    useStyles: false,
    useSharedStrings: false
  };
  const workbook = new Excel.stream.xlsx.WorkbookWriter(options);

  const sheet = workbook.addWorksheet('buy list');

  const selectorForProducts = { userId };
  if (selectAll !== 'All') {
    extend(selectorForProducts, { sellerSku: { $in: skuList } });
  }
  if (isReplen === 'true') {
    extend(selectorForProducts, { isReplen: true });
  }

  const productsCount = await Products.find(selectorForProducts).countDocuments();

  let dSkip = 0;
  const dLimit = productsCount > 100 ? 100 : productsCount;

  for (let i = 0; i < productsCount; i += dLimit) {
    let products = await Products.find(selectorForProducts).skip(dSkip).limit(dLimit);
    dSkip += products.length;
    products = refactorProductsData(products, columnsWanted);

    const [header] = products;
    if (i === 0) {
      sheet.columns = Object.getOwnPropertyNames(header).map(key => ({
        key,
        header: startCase(key),
        width: 25
      }));
    }

    products.forEach((item) => {
      sheet.addRow(item).commit();
    });
  }

  sheet.commit();

  workbook.commit()
    .then(async () => {
      await Users.updateOne({
        _id: userId
      }, {
        $set: {
          columnsWanted
        }
      });

      await ExportProductsParams.deleteOne({
        _id: userId
      });

      res.send();
    }).catch((err) => {
      res.send(err);
    });
};

export default ExportProducts;
