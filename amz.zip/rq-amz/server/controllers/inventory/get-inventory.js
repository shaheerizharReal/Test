import { extend } from 'lodash';
import AccessControl from 'accesscontrol';

import Products from '../../models/products';

import { FULLFILMENT_TYPE } from '../../../config/constants';

const setSortingObject = (sort) => {
  let sortObj = sort;
  const sortKey = Object.keys(sort);
  if (sortKey[0] === 'fba') {
    sortObj = { 'fee.otherFees': sort[sortKey[0]] };
  }
  return sortObj;
};

const GetInventory = async ({
  userId,
  roles,
  permission,
  filters,
  skip,
  limit,
  sort
}) => {
  const sortObj = setSortingObject(sort);
  const selector = { userId };

  const filterKeys = Object.keys(filters);
  let i = 0;
  while (i < filterKeys.length) {
    const key = filterKeys[i];
    const filter = filters[key];
    switch (key) {
      case 'fulfilmentType': {
        const values = [];
        for (let j = 0; j < filter.values.length; j += 1) {
          if (filter.values[j] === 'Amazon') values.push(FULLFILMENT_TYPE.AMAZON);
          else values.push(FULLFILMENT_TYPE.MERCHANT);
        }
        extend(selector, { fulfilmentType: { $in: values } });
        break;
      }

      case 'condition':
        extend(selector, { condition: { $in: filter.values.map(condition => Number(condition)) } });
        break;

      case 'status':
        extend(selector, { status: { $in: filter.values } });
        break;

      case 'supplier': {
        if (filter.values.length > 0) {
          let notAttached = false;
          if (filter.values.includes('N/A')) {
            notAttached = true;
          }
          const suppliers = filter.values.filter(sup => sup !== 'N/A');
          if (suppliers.length > 0 && notAttached) {
            extend(selector, {
              $or: [
                { supplier: { $exists: false } },
                { supplier: { $in: suppliers } }
              ]
            });
          } else if (suppliers.length > 0) {
            extend(selector, { supplier: { $in: suppliers } });
          } else {
            extend(selector, { supplier: { $exists: false } });
          }
        } else {
          extend(selector, { supplier: { $in: filter.values } });
        }
        break;
      }

      case 'productGroup': {
        if (filter.values.length > 0) {
          let notAttached = false;
          if (filter.values.includes('N/A')) {
            notAttached = true;
          }
          const categories = filter.values.filter(cat => cat !== 'N/A');
          if (categories.length > 0 && notAttached) {
            extend(selector, {
              $or: [
                { productGroup: { $exists: false } },
                { productGroup: { $in: categories } }
              ]
            });
          } else if (categories.length > 0) {
            extend(selector, { productGroup: { $in: categories } });
          } else {
            extend(selector, { productGroup: { $exists: false } });
          }
        } else {
          extend(selector, { productGroup: { $in: filter.values } });
        }
        break;
      }

      case 'enrolledInSnL': {
        if (filter.values.length > 0) {
          if (filter.values[0] === 'Yes') {
            extend(selector, { enrolledInSnL: true });
          } else {
            extend(selector, {
              $or: [
                { enrolledInSnL: { $exists: false } },
                { enrolledInSnL: false }
              ]
            });
          }
        } else {
          extend(selector, { enrolledInSnL: { $in: filter.values } });
        }
        break;
      }

      case 'isReplen': {
        if (filter.values.length > 0) {
          if (filter.values[0] === 'Yes') {
            extend(selector, { isReplen: true });
          } else {
            extend(selector, {
              $or: [
                { isReplen: { $exists: false } },
                { isReplen: false }
              ]
            });
          }
        } else {
          extend(selector, { isReplen: { $in: filter.values } });
        }
        break;
      }

      default:
        break;
    }

    i += 1;
  }

  if (filters && filters.keyword) {
    const { value } = filters.keyword;
    if (value.includes(' ')) {
      const regex = new RegExp(value.replace(/(\S+)/g, s => "\\b" + s + ".*").replace(/\s+/g, ''));
      extend(selector, {
        $or: [
          { title: { $regex: regex, $options: 'i' } },
          { sellerSku: { $regex: `.*${value}.*`, $options: 'i' } }
        ]
      });
    } else {
      extend(selector, {
        $or: [
          { title: { $regex: `.*${value}.*`, $options: 'i' } },
          { asin: { $regex: `.*${value}.*`, $options: 'i' } },
          { sellerSku: { $regex: `.*${value}.*`, $options: 'i' } },
          { fnsku: { $regex: `.*${value}.*`, $options: 'i' } }
        ]
      });
    }
  }

  const total = await Products.find(selector).countDocuments();
  const ac = new AccessControl(roles);
  const permissionControl = ac.can(permission.role).readAny('Inventory');
  const { attributes } = permissionControl;

  let products = await Products
    .find(selector)
    .sort(sortObj)
    .skip(skip)
    .limit(limit);

  products = products.map(({
    title,
    sellerSku,
    asin,
    imageUrl,
    fnsku,
    fulfilmentType,
    condition,
    status,
    afnInboundShippedQuantity,
    afnReservedQuantity,
    decidedBuyQuantity,
    sellableQuantity,
    afnUnsellableQuantity,
    afnTotalQuantity,
    suggestedBuyQuantity30Days,
    suggestedBuyQuantity60Days,
    suggestedBuyQuantity90Days,
    totalOrdersLast30Days,
    totalPendingOrdersLast30Days,
    salesLast30Days,
    salesAmountLast30Days,
    totalOrdersLast60Days,
    totalPendingOrdersLast60Days,
    salesLast60Days,
    salesAmountLast60Days,
    totalOrdersLast90Days,
    totalPendingOrdersLast90Days,
    salesLast90Days,
    salesAmountLast90Days,
    listPrice,
    buyBoxPrice,
    lowestOfferPrice,
    lowestFBAOfferPrice,
    costPrice,
    shipBy,
    shippingRate,
    noOfSellers,
    fee,
    profit,
    profitPercentage,
    roiPercentage,
    supplier,
    salesRank,
    productGroup,
    purchaseLink,
    storeSection,
    notesSection,
    enrolledInSnL,
    isReplen,
    openDate
  }) => {
    const rtnObj = { userId };

    if (attributes.includes('*') || attributes.includes('title')) {
      extend(rtnObj, { title, imageUrl });
    }
    if (attributes.includes('*') || attributes.includes('asin')) {
      extend(rtnObj, { asin });
    }
    if (attributes.includes('*') || attributes.includes('sellerSku')) {
      extend(rtnObj, { sellerSku });
    }
    if (attributes.includes('*') || attributes.includes('fnsku')) {
      extend(rtnObj, { fnsku });
    }
    if (attributes.includes('*') || attributes.includes('fulfilmentType')) {
      extend(rtnObj, { fulfilmentType: fulfilmentType === FULLFILMENT_TYPE.AMAZON ? 'Amazon' : 'Merchant' });
    }
    if (attributes.includes('*') || attributes.includes('condition')) {
      extend(rtnObj, { condition });
    }
    if (attributes.includes('*') || attributes.includes('status')) {
      extend(rtnObj, { status });
    }
    if (attributes.includes('*') || attributes.includes('quantity')) {
      extend(rtnObj, {
        afnInboundShippedQuantity,
        afnReservedQuantity,
        sellableQuantity,
        afnUnsellableQuantity,
        afnTotalQuantity,
        suggestedBuyQuantity30Days,
        suggestedBuyQuantity60Days,
        suggestedBuyQuantity90Days,
        decidedBuyQuantity
      });
    }
    if (attributes.includes('*') || attributes.includes('sales30days')) {
      extend(rtnObj, {
        totalOrdersLast30Days,
        totalPendingOrdersLast30Days,
        salesLast30Days,
        salesAmountLast30Days
      });
    }
    if (attributes.includes('*') || attributes.includes('sales60days')) {
      extend(rtnObj, {
        totalOrdersLast60Days,
        totalPendingOrdersLast60Days,
        salesLast60Days,
        salesAmountLast60Days
      });
    }
    if (attributes.includes('*') || attributes.includes('sales90days')) {
      extend(rtnObj, {
        totalOrdersLast90Days,
        totalPendingOrdersLast90Days,
        salesLast90Days,
        salesAmountLast90Days
      });
    }
    if (attributes.includes('*') || attributes.includes('prices')) {
      extend(rtnObj, {
        listPrice,
        buyBoxPrice,
        lowestOfferPrice,
        lowestFBAOfferPrice,
        costPrice,
        shipBy,
        shippingRate
      });
    }
    if (attributes.includes('*') || attributes.includes('noOfSellers')) {
      extend(rtnObj, { noOfSellers });
    }
    if (attributes.includes('*') || attributes.includes('fees')) {
      extend(rtnObj, { fee });
    }
    if (attributes.includes('*') || attributes.includes('profits')) {
      extend(rtnObj, {
        profit,
        profitPercentage,
        roiPercentage
      });
    }
    if (attributes.includes('*') || attributes.includes('supplier')) {
      extend(rtnObj, { supplier: supplier || 'N/A' });
    }
    if (attributes.includes('*') || attributes.includes('salesRank')) {
      extend(rtnObj, { salesRank });
    }
    if (attributes.includes('*') || attributes.includes('productGroup')) {
      extend(rtnObj, { productGroup: productGroup || 'N/A' });
    }
    if (attributes.includes('*') || attributes.includes('purchaseLink')) {
      extend(rtnObj, { purchaseLink });
    }
    if (attributes.includes('*') || attributes.includes('storeSection')) {
      extend(rtnObj, { storeSection });
    }
    if (attributes.includes('*') || attributes.includes('notesSection')) {
      extend(rtnObj, { notesSection });
    }
    if (attributes.includes('*') || attributes.includes('enrolledInSnL')) {
      extend(rtnObj, { enrolledInSnL: enrolledInSnL ? 'Yes' : 'No' });
    }
    if (attributes.includes('*') || attributes.includes('isReplen')) {
      extend(rtnObj, { isReplen: isReplen ? 'Yes' : 'No' });
    }
    if (attributes.includes('*') || attributes.includes('openDate')) {
      extend(rtnObj, { openDate });
    }

    return rtnObj;
  });
  return { products, total };
};
export default GetInventory;
