import Products from '../../models/products';

const GetCategoriesAndSuppliers = async ({
  userId
}) => {
  const categories = await Products.distinct('productGroup', { userId });
  categories.push('N/A');
  const suppliers = await Products.distinct('supplier', { userId });
  suppliers.push('N/A');

  return { categories, suppliers };
};
export default GetCategoriesAndSuppliers;
