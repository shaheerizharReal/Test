import { extend } from 'lodash';

import agenda from '../agenda';

import AgendaJobs from '../../models/agenda-jobs';
import Products from '../../models/products';

const ImportProducts = async ({
  userId,
  products,
  costCheck
}) => {
  if (costCheck) {
    const importInventoryJob = await AgendaJobs.findOne({
      'data.userId': userId,
      name: 'import:inventory'
    });

    if (importInventoryJob) {
      return false;
    }
  }

  const importedAt = new Date();
  const writeData = products.map(({
    sellerSku,
    costPrice,
    supplier,
    purchaseLink
  }) => {
    const setObj = {};

    if (costPrice >= 0) {
      extend(setObj, {
        costPrice,
        profit: null,
        profitPercentage: null,
        roiPercentage: null
      });
    }

    if (supplier) {
      extend(setObj, { supplier });
    }

    if (purchaseLink) {
      extend(setObj, { purchaseLink });
    }

    extend(setObj, { importedAt });

    return {
      updateOne: {
        filter: {
          userId,
          sellerSku
        },
        update: {
          $set: {
            ...setObj
          }
        }
      }
    };
  });

  console.log('\n\n', 'writeData', writeData.length);
  if (writeData.length > 0) {
    await Products.bulkWrite(writeData);
    if (costCheck) {
      agenda.create('import:inventory', { userId })
        .unique({ 'data.userId': userId })
        .save();
    }
  }

  return true;
};

export default ImportProducts;
