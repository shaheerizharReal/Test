import Products from '../../models/products';

const ResetDecidedQuantities = async ({ userId }) => {
  Products.updateMany({
    userId
  }, {
    $unset: {
      decidedBuyQuantity: 1
    }
  }).exec();

  return Promise.resolve();
};

export default ResetDecidedQuantities;
