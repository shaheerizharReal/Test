import Products from '../../models/products';

import { FULLFILMENT_TYPE } from '../../../config/constants';

const SetNotesSection = async ({
  userId,
  sellerSku,
  notesSection
}) => {
  await Products.updateOne({
    userId,
    sellerSku
  }, {
    $set: {
      notesSection
    }
  });

  const product = await Products.findOne({
    userId,
    sellerSku
  });

  return {
    userId,
    title: product.title,
    sellerSku,
    asin: product.asin,
    imageUrl: product.imageUrl,
    fnsku: product.fnsku,
    fulfilmentType: product.fulfilmentType === FULLFILMENT_TYPE.AMAZON ? 'Amazon' : 'Merchant',
    condition: product.condition,
    status: product.status,
    afnInboundQuantity: product.afnInboundShippedQuantity,
    afnReservedQuantity: product.afnReservedQuantity,
    sellableQuantity: product.sellableQuantity,
    afnUnsellableQuantity: product.afnUnsellableQuantity,
    afnTotalQuantity: product.afnTotalQuantity,
    suggestedBuyQuantity30Days: product.suggestedBuyQuantity30Days,
    suggestedBuyQuantity60Days: product.suggestedBuyQuantity60Days,
    suggestedBuyQuantity90Days: product.suggestedBuyQuantity90Days,
    totalOrdersLast30Days: product.totalOrdersLast30Days,
    salesLast30Days: product.salesLast30Days,
    salesAmountLast30Days: product.salesAmountLast30Days,
    totalOrdersLast60Days: product.totalOrdersLast60Days,
    salesLast60Days: product.salesLast60Days,
    salesAmountLast60Days: product.salesAmountLast60Days,
    totalOrdersLast90Days: product.totalOrdersLast90Days,
    salesLast90Days: product.salesLast90Days,
    salesAmountLast90Days: product.salesAmountLast90Days,
    listPrice: product.listPrice,
    buyBoxPrice: product.buyBoxPrice,
    lowestOfferPrice: product.lowestOfferPrice,
    lowestFBAOfferPrice: product.lowestFBAOfferPrice,
    costPrice: product.costPrice,
    noOfSellers: product.noOfSellers,
    fee: product.fee,
    profit: product.profit,
    profitPercentage: product.profitPercentage,
    roiPercentage: product.roiPercentage,
    supplier: product.supplier || 'N/A',
    salesRank: product.salesRank,
    productGroup: product.productGroup || 'N/A',
    purchaseLink: product.purchaseLink,
    storeSection: product.storeSection,
    notesSection: product.notesSection,
    enrolledInSnL: product.enrolledInSnL ? 'Yes' : 'No',
    isReplen: product.isReplen ? 'Yes' : 'No',
    openDate: product.openDate
  };
};
export default SetNotesSection;
