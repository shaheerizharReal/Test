import { isEmpty } from 'lodash';

import Products from '../../models/products';

import GetProfitEstimations from '../agenda/helpers/inventory/get-profit-estimations';
import GetDefaultCalculationPrice from '../users/get-default-calculation-price';
import { ChooseDefaultCalculationPrice } from '../agenda/definitions/utils';

import { FULLFILMENT_TYPE } from '../../../config/constants';

const SetShippingCost = async ({
  userId,
  sellerSku,
  shipBy,
  shippingRate
}) => {
  let product = await Products.findOne({
    userId,
    sellerSku
  });
  const { profitCalculatedBy } = await GetDefaultCalculationPrice({ userId });

  const {
    costPrice,
    listPrice,
    buyBoxPrice,
    lowestOfferPrice,
    lowestFBAOfferPrice,
    fee,
    fulfilmentType,
    packageDimensions
  } = product;
  const weight = (!isEmpty(packageDimensions) && (packageDimensions.weight))
    ? packageDimensions.weight : 0;
  const defaultPrice = ChooseDefaultCalculationPrice({
    profitCalculatedBy,
    listPrice,
    buyBoxPrice,
    lowestOfferPrice,
    lowestFBAOfferPrice
  });
  const {
    profit,
    profitPercentage,
    roiPercentage
  } = await GetProfitEstimations({
    costPrice,
    defaultPrice,
    fee,
    fulfilmentType,
    shipBy,
    shippingRate,
    weight
  });

  await Products.updateOne({
    userId,
    sellerSku
  }, {
    $set: {
      costPrice,
      shipBy,
      shippingRate,
      profit,
      profitPercentage,
      roiPercentage
    }
  });

  product = await Products.findOne({
    userId,
    sellerSku
  });

  return {
    userId,
    title: product.title,
    sellerSku,
    asin: product.asin,
    imageUrl: product.imageUrl,
    fnsku: product.fnsku,
    fulfilmentType: product.fulfilmentType === FULLFILMENT_TYPE.AMAZON ? 'Amazon' : 'Merchant',
    condition: product.condition,
    status: product.status,
    afnInboundQuantity: product.afnInboundShippedQuantity,
    afnReservedQuantity: product.afnReservedQuantity,
    sellableQuantity: product.sellableQuantity,
    afnUnsellableQuantity: product.afnUnsellableQuantity,
    afnTotalQuantity: product.afnTotalQuantity,
    suggestedBuyQuantity30Days: product.suggestedBuyQuantity30Days,
    suggestedBuyQuantity60Days: product.suggestedBuyQuantity60Days,
    suggestedBuyQuantity90Days: product.suggestedBuyQuantity90Days,
    totalOrdersLast30Days: product.totalOrdersLast30Days,
    salesLast30Days: product.salesLast30Days,
    salesAmountLast30Days: product.salesAmountLast30Days,
    totalOrdersLast60Days: product.totalOrdersLast60Days,
    salesLast60Days: product.salesLast60Days,
    salesAmountLast60Days: product.salesAmountLast60Days,
    totalOrdersLast90Days: product.totalOrdersLast90Days,
    salesLast90Days: product.salesLast90Days,
    salesAmountLast90Days: product.salesAmountLast90Days,
    listPrice: product.listPrice,
    buyBoxPrice: product.buyBoxPrice,
    lowestOfferPrice: product.lowestOfferPrice,
    lowestFBAOfferPrice: product.lowestFBAOfferPrice,
    costPrice: product.costPrice,
    shipBy: product.shipBy,
    shippingRate: product.shippingRate,
    noOfSellers: product.noOfSellers,
    fee: product.fee,
    profit: product.profit,
    profitPercentage: product.profitPercentage,
    roiPercentage: product.roiPercentage,
    supplier: product.supplier || 'N/A',
    salesRank: product.salesRank,
    productGroup: product.productGroup || 'N/A',
    purchaseLink: product.purchaseLink,
    storeSection: product.storeSection,
    notesSection: product.notesSection,
    enrolledInSnL: product.enrolledInSnL ? 'Yes' : 'No',
    isReplen: product.isReplen ? 'Yes' : 'No',
    openDate: product.openDate
  };
};
export default SetShippingCost;
