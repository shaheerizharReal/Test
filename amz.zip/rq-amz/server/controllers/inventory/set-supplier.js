import Products from '../../models/products';

const SetSupplier = async ({
  userId,
  sellerSku,
  supplier
}) => {
  await Products.updateOne({
    userId,
    sellerSku
  }, {
    $set: {
      supplier
    }
  });

  const suppliers = await Products.distinct('supplier', { userId });
  suppliers.push('N/A');

  return { suppliers };
};
export default SetSupplier;
