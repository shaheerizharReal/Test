import Products from '../../models/products';
import { FULLFILMENT_TYPE } from '../../../config/constants';

const SetAllToReplenProduct = async ({
  userId,
  skuList,
  isReplen
}) => {
  await Products.updateMany({
    userId,
    sellerSku: { $in: skuList }
  }, {
    $set: {
      isReplen
    }
  });

  let products = await Products.find({
    userId,
    sellerSku: { $in: skuList }
  });

  products = products.map(({
    title,
    sellerSku,
    asin,
    imageUrl,
    fnsku,
    fulfilmentType,
    condition,
    status,
    afnInboundShippedQuantity,
    afnReservedQuantity,
    sellableQuantity,
    afnUnsellableQuantity,
    afnTotalQuantity,
    suggestedBuyQuantity30Days,
    suggestedBuyQuantity60Days,
    suggestedBuyQuantity90Days,
    totalOrdersLast30Days,
    salesLast30Days,
    salesAmountLast30Days,
    totalOrdersLast60Days,
    salesLast60Days,
    salesAmountLast60Days,
    totalOrdersLast90Days,
    salesLast90Days,
    salesAmountLast90Days,
    listPrice,
    buyBoxPrice,
    lowestOfferPrice,
    lowestFBAOfferPrice,
    costPrice,
    noOfSellers,
    fee,
    profit,
    profitPercentage,
    roiPercentage,
    supplier,
    salesRank,
    productGroup,
    purchaseLink,
    storeSection,
    notesSection,
    enrolledInSnL,
    isReplen,
    openDate
  }) => ({
    userId,
    title,
    sellerSku,
    asin,
    imageUrl,
    fnsku,
    fulfilmentType: fulfilmentType === FULLFILMENT_TYPE.AMAZON ? 'Amazon' : 'Merchant',
    condition,
    status,
    afnInboundQuantity: afnInboundShippedQuantity,
    afnReservedQuantity,
    sellableQuantity,
    afnUnsellableQuantity,
    afnTotalQuantity,
    suggestedBuyQuantity30Days,
    suggestedBuyQuantity60Days,
    suggestedBuyQuantity90Days,
    totalOrdersLast30Days,
    salesLast30Days,
    salesAmountLast30Days,
    totalOrdersLast60Days,
    salesLast60Days,
    salesAmountLast60Days,
    totalOrdersLast90Days,
    salesLast90Days,
    salesAmountLast90Days,
    listPrice,
    buyBoxPrice,
    lowestOfferPrice,
    lowestFBAOfferPrice,
    costPrice,
    noOfSellers,
    fee,
    profit,
    profitPercentage,
    roiPercentage,
    supplier: supplier || 'N/A',
    salesRank,
    productGroup: productGroup || 'N/A',
    purchaseLink,
    storeSection,
    notesSection,
    enrolledInSnL: enrolledInSnL ? 'Yes' : 'No',
    isReplen: isReplen ? 'Yes' : 'No',
    openDate
  }));
  return products;
};
export default SetAllToReplenProduct;
