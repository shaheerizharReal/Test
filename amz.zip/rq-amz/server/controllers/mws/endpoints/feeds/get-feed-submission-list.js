import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { parseDate, toArray } from '../utils/utils';

const GetFeedSubmissionList = async ({
  sellerId,
  authToken,
  feedSubmissionIdList,
  feedTypeList,
  feedProcessingStatusList,
  maxCount,
  submittedFromDate,
  submittedToDate
}) => {
  const request = new MWS.Feeds.requests.GetFeedSubmissionList();

  if (feedSubmissionIdList.length > 0) request.set('FeedSubmissionIds', feedSubmissionIdList);
  if (feedTypeList) request.set('FeedTypes', feedTypeList);
  if (feedProcessingStatusList) request.set('FeedProcessingStatuses', feedProcessingStatusList);
  if (maxCount) request.set('MaxCount', maxCount);
  if (submittedFromDate) request.set('SubmittedFrom', parseDate('submittedFromDate', submittedFromDate));
  if (submittedToDate) request.set('SubmittedTo', parseDate('submittedToDate', submittedToDate));

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getFeedSubmissionListResult.feedSubmissionInfo;
  const feedRequests = toArray(result);

  return feedRequests;
};

export default GetFeedSubmissionList;
