import MWS from '@minmaxindustries/mws-sdk';
import { isEmpty } from 'lodash';
import { mapFlatFileResponse, mapXMLResponse } from './utils';

import Settings from '../../../../../config/settings';

const GetFeedSubmissionResult = async ({
  sellerId,
  authToken,
  feedSubmissionId
}) => {
  const request = new MWS.Feeds.requests.GetFeedSubmissionResult();

  if (feedSubmissionId) request.set('FeedSubmissionId', feedSubmissionId);

  const client = new MWS.Client(Settings.MWS.accessKeyId,
    Settings.MWS.secretKey, sellerId, { authToken });

  let response = await client.invoke(request);

  if (isEmpty(response)) {
    throw new Error('empty response');
  }

  if (response.slice(0, 5) === '<?xml') {
    response = mapXMLResponse(response);
  } else {
    response = await mapFlatFileResponse(response);
  }

  return response;
};

export default GetFeedSubmissionResult;
