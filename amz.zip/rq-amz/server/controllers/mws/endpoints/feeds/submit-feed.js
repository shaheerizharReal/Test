import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';

const SubmitFeed = async ({ sellerId, authToken, feedType, feedContent, marketplaceIds }) => {
  const request = new MWS.Feeds.requests.SubmitFeed();
  request.set('FeedType', feedType);
  request.set('FeedContents', feedContent);
  if (marketplaceIds) request.set('MarketplaceIds', marketplaceIds);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.submitFeedResult.feedSubmissionInfo;
  return result;
};

export default SubmitFeed;
