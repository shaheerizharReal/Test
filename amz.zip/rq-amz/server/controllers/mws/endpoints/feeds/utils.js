import { isArray } from 'lodash';

import { parseXML, parseTSV } from '../utils/parse';

export const mapXMLResponse = (response) => {
  let totalRecords = 0;
  let successfulRecords = 0;
  let unSuccessfulRecords = 0;
  let warningRecords = 0;
  let errorList = [];

  response = parseXML(response);

  const { message } = response;
  if (message) {
    const { processingReport } = message;
    if (processingReport) {
      const { processingSummary, result } = processingReport;
      if (processingSummary) {
        ({
          messagesProcessed: totalRecords,
          messagesSuccessful: successfulRecords,
          messagesWithError: unSuccessfulRecords,
          messagesWithWarning: warningRecords
        } = processingSummary);
      }

      if (result) {
        if (isArray(result)) {
          errorList = result;
        } else {
          errorList.push({
            type: 'Error',
            ...result
          });
        }
      }
    }
  }

  return {
    totalRecords,
    successfulRecords,
    unSuccessfulRecords,
    warningRecords,
    errorList
  };
};

export const mapFlatFileResponse = async (response) => {
  let [processingSummary, tsvResponse] = response.split('\n\n');

  let [totalRecords, successfulRecords] = processingSummary.replace('Feed Processing Summary:\n\t', '').split('\n\t');
  totalRecords = parseInt(totalRecords.split('Number of records processed\t\t')[1], 10);
  successfulRecords = parseInt(successfulRecords.split('Number of records successful\t\t')[1], 10);

  tsvResponse = await parseTSV(tsvResponse);

  return {
    totalRecords,
    successfulRecords,
    errorList: tsvResponse
  };
};
