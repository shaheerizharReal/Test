import MWS from '@minmaxindustries/mws-sdk';

import invokeRequest from '../utils/invoke-request';
import { printLogs } from '../utils/logs';
import { sleep } from '../utils/utils';
import { mergeFinancialEvents, filterFinancialEvents } from './utils';

const ListFinancialEventsByNextToken = async ({ sellerId, authToken, nextToken, financialEventType }) => {
  printLogs({
    endpoint: 'ListFinancialEventsByNextToken',
    params: {
      sellerId,
      nextToken
    }
  });

  const opts = {
    name: 'Finances',
    group: 'Finances',
    path: '/Finances/2015-05-01',
    version: '2015-05-01',
    legacy: false,
    action: 'ListFinancialEventsByNextToken',
    params: {
      NextToken: { name: 'NextToken', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('NextToken', nextToken);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listFinancialEventsByNextTokenResult;
  let financialEvents = result.financialEvents;

  financialEvents = filterFinancialEvents(financialEvents, financialEventType);

  if (result.nextToken) {
    await sleep(2000);
    const nextFinancialEvents = await ListFinancialEventsByNextToken({
      sellerId,
      authToken,
      nextToken: result.nextToken,
      financialEventType
    });
    financialEvents = mergeFinancialEvents(financialEvents, nextFinancialEvents, financialEventType);
  }
  return financialEvents;
};

export default ListFinancialEventsByNextToken;
