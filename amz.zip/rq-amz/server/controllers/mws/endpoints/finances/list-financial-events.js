import MWS from '@minmaxindustries/mws-sdk';

import ListFinancialEventsByNextToken from './list-financial-events-by-next-token';
import invokeRequest from '../utils/invoke-request';
import { parseDateToISO } from '../utils/utils';
import { mergeFinancialEvents, filterFinancialEvents } from './utils';

const ListFinancialEvents = async ({ sellerId, authToken, postedAfter, postedBefore, amazonOrderId, financialEventType }) => {
  const opts = {
    name: 'Finances',
    group: 'Finances',
    path: '/Finances/2015-05-01',
    version: '2015-05-01',
    legacy: false,
    action: 'ListFinancialEvents',
    params: {
      PostedAfter: { name: 'PostedAfter', required: true },
      PostedBefore: { name: 'PostedBefore', required: true },
      AmazonOrderId: { name: 'AmazonOrderId', required: true }
    }
  };

  const request = new MWS.Request(opts);
  if (postedAfter) request.set('PostedAfter', parseDateToISO('postedAfter', postedAfter));
  if (postedBefore) request.set('PostedBefore', parseDateToISO('postedBefore', postedBefore));
  if (amazonOrderId) request.set('AmazonOrderId', amazonOrderId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listFinancialEventsResult;
  let financialEvents = result.financialEvents;

  financialEvents = filterFinancialEvents(financialEvents, financialEventType);

  if (result.nextToken) {
    const nextFinancialEvents = await ListFinancialEventsByNextToken({
      sellerId,
      authToken,
      nextToken: result.nextToken,
      financialEventType
    });
    financialEvents = mergeFinancialEvents(financialEvents, nextFinancialEvents, financialEventType);
  }

  return financialEvents;
};

export default ListFinancialEvents;
