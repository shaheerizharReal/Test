import { concat } from 'lodash';
import { toArray } from '../utils/utils';

export const filterFinancialEvents = (f, financialEventType) => {
  const finances = {};
  if (financialEventType) {
    switch (financialEventType) {
      case 'retrochargeEventList':
        finances[financialEventType] = toArray(f[financialEventType].retrochargeEvent || []);
        break;

      case 'serviceFeeEventList':
        finances[financialEventType] = toArray(f[financialEventType].serviceFeeEvent || []);
        break;

      case 'adjustmentEventList':
        finances[financialEventType] = toArray(f[financialEventType].adjustmentEvent || []);
        break;

      case 'productAdsPaymentEventList':
        finances[financialEventType] = toArray(f[financialEventType].productAdsPaymentEvent || []);
        break;

      default:
        finances[financialEventType] = toArray(f[financialEventType].shipmentEvent || []);
        break;
    }
  } else {
    const { refundEventList,
      shipmentEventList,
      retrochargeEventList,
      serviceFeeEventList,
      adjustmentEventList,
      productAdsPaymentEventList } = f;

    finances.shipmentEventList = toArray(shipmentEventList.shipmentEvent || []);
    finances.refundEventList = toArray(refundEventList.shipmentEvent || []);
    finances.retrochargeEventList = toArray(retrochargeEventList.retrochargeEvent || []);
    finances.serviceFeeEventList = toArray(serviceFeeEventList.serviceFeeEvent || []);
    finances.adjustmentEventList = toArray(adjustmentEventList.adjustmentEvent || []);
    finances.productAdsPaymentEventList = toArray(productAdsPaymentEventList.productAdsPaymentEvent || []);
  }

  return finances;
};

export const mergeFinancialEvents = (prevfinances, nextFinances, financialEventType) => {
  const finances = {};

  if (financialEventType) {
    finances[financialEventType] = concat((prevfinances[financialEventType] || []),
      (nextFinances[financialEventType] || []));
  } else {
    finances.refundEventList = concat((prevfinances.refundEventList || []),
      (nextFinances.refundEventList || []));

    finances.shipmentEventList = concat((prevfinances.shipmentEventList || []),
      (nextFinances.shipmentEventList || []));

    finances.retrochargeEventList = concat((prevfinances.retrochargeEventList || []),
      (nextFinances.retrochargeEventList || []));

    finances.adjustmentEventList = concat((prevfinances.adjustmentEventList || []),
      (nextFinances.adjustmentEventList || []));

    finances.serviceFeeEventList = concat((prevfinances.serviceFeeEventList || []),
      (nextFinances.serviceFeeEventList || []));

    finances.productAdsPaymentEventList = concat((prevfinances.productAdsPaymentEventList || []),
      (nextFinances.productAdsPaymentEventList || []));
  }

  return finances;
};
