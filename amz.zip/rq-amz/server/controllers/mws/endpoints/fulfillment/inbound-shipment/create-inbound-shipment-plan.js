import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';
import { mapCreateInboundShipmentPlans } from './utils';

const CreateInboundShipmentPlan = async ({ sellerId, authToken, labelPrepPreference, shipFromAddress, shipmentItems }) => {
  const request = new MWS.Fbs.requests.inbound.CreateInboundShipmentPlan();
  request.set('LabelPrepPreference', labelPrepPreference);
  request.set('ShipFromName', shipFromAddress.name);
  request.set('ShipFromAddressLine1', shipFromAddress.addressLine1);
  if (shipFromAddress.addressLine2) request.set('ShipFromAddressLine2', shipFromAddress.addressLine2);
  request.set('ShipFromCity', shipFromAddress.city);
  request.set('ShipFromStateOrProvince', shipFromAddress.stateOrProvinceCode);
  request.set('ShipFromPostalCode', shipFromAddress.postalCode);
  request.set('ShipFromCountryCode', shipFromAddress.countryCode);
  const requestItems = new MWS.Fbs.complex.InboundShipmentPlanRequestItems();

  shipmentItems.forEach((item) => {
    requestItems.add(
      item.sellerSku,
      (item.asin || null),
      item.quantity,
      (item.quantityInCase || 0),
      (item.condition || null),
      (item.prepDetailsList || [])
    );
  });

  request.set('InboundShipmentPlanRequestItems', requestItems);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  return mapCreateInboundShipmentPlans(response.createInboundShipmentPlanResult);
};

export default CreateInboundShipmentPlan;
