import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';

/**
 * Creates an Inbound shipment from the Inbound Shipment Plans returned by CreateInboundShipmentPlan
 * @param {Object} shipment shipment details
 * {
 *  id:
 *  name:
 *  status:
 *  destinationFulfillmentCenterId:
 *  labelPrepPreference:
 *  areCasesRequired:
 *  intendedBoxContentsSource:
 *  shipFromAddress: {
 *    name:
 *    addressLine1:
 *    addressLine2:
 *    city:
 *    districtOrCounty:
 *    stateOrProvinceCode:
 *    countryCode:
 *    postalCode:
 *  }
 * }
 * @param {Array} items  Shipment Items
 * {
 *  sellerSku:
 *  quantity:
 * }
 * */

const CreateInboundShipment = async ({ sellerId, authToken, shipment, items }) => {
  const request = new MWS.Fbs.requests.inbound.CreateInboundShipment();

  if (shipment.id) request.set('ShipmentId', shipment.id);
  if (shipment.name) request.set('Shipmentname', shipment.name);
  if (shipment.labelPrepPreference) request.set('LabelPrepPreference', shipment.labelPrepPreference);
  if (shipment.shipFromAddress.name) request.set('ShipFromName', shipment.shipFromAddress.name);
  if (shipment.shipFromAddress.addressLine1) request.set('ShipFromAddressLine1', shipment.shipFromAddress.addressLine1);
  if (shipment.shipFromAddress.addressLine2) request.set('ShipFromAddressLine2', shipment.shipFromAddress.addressLine2);
  if (shipment.shipFromAddress.city) request.set('ShipFromAddressCity', shipment.shipFromAddress.city);
  if (shipment.shipFromAddress.countryCode) request.set('ShipFromDistrictOrCounty', shipment.shipFromAddress.countryCode);
  if (shipment.shipFromAddress.stateOrProvinceCode) request.set('ShipFromStateOrProvince', shipment.shipFromAddress.stateOrProvinceCode);
  if (shipment.shipFromAddress.postalCode) request.set('ShipFromPostalCode', shipment.shipFromAddress.postalCode);
  if (shipment.shipFromAddress.countryCode) request.set('ShipFromCountryCode', shipment.shipFromAddress.countryCode);
  if (shipment.destinationFulfillmentCenterId) request.set('DestinationFulfillmentCenterId', shipment.destinationFulfillmentCenterId);
  if (shipment.intendedBoxContentsSource) request.set('IntendedBoxContentsSource', shipment.intendedBoxContentsSource);
  if (shipment.areCasesRequired) request.set('AreCasesRequired', shipment.areCasesRequired);

  request.set('ShipmentStatus', shipment.status ? shipment.status : 'WORKING');

  const requestItems = new MWS.Fbs.complex.InboundShipmentItems();
  items.forEach((item) => {
    if (item.quantity && item.sellerSku) {
      requestItems.add(item.quantity, (item.quantityInCase || 0), item.sellerSku, item.prepDetailsList || []);
    }
  });

  request.set('InboundShipmentItems', requestItems);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  return response.createInboundShipmentResult;
};

export default CreateInboundShipment;
