import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';

const EstimateTransportRequest = async ({ sellerId, authToken, shipmentId }) => {
  const opts = {
    name: 'Fulfillment',
    group: 'Inbound Shipments',
    path: '/FulfillmentInboundShipment/2010-10-01',
    version: '2010-10-01',
    legacy: false,
    action: 'EstimateTransportRequest',
    params: {
      ShipmentId: { name: 'ShipmentId', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('ShipmentId', shipmentId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.estimateTransportRequestResult.transportResult;

  return result;
};

export default EstimateTransportRequest;
