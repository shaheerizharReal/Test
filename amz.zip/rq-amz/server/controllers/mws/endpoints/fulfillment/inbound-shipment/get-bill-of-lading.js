import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';

const GetBillOfLading = async ({ sellerId, authToken, shipmentId }) => {
  const opts = {
    name: 'Fulfillment',
    group: 'Inbound Shipments',
    path: '/FulfillmentInboundShipment/2010-10-01',
    version: '2010-10-01',
    legacy: false,
    action: 'GetBillOfLading',
    params: {
      ShipmentId: { name: 'ShipmentId', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('ShipmentId', shipmentId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getBillOfLadingResult.transportDocument.pdfDocument;

  return result;
};

export default GetBillOfLading;
