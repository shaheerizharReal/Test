import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';

const GetInboundGuidanceForASIN = async ({ sellerId, authToken, asinList, marketplaceId }) => {
  // let prepInstructionsList = [];
  // if (asinList && asinList.length > 50) {
  //   const otherPrepInstructionsList = await GetInboundGuidanceForASIN({
  //     sellerId,
  //     authToken,
  //     asinList: asinList.splice(50),
  //     marketplaceId
  //   });
  //   prepInstructionsList = prepInstructionsList.concat(mapPrepInstructions(otherPrepInstructionsList));
  //   await sleep(500);
  // }
  //
  // printLogs({
  //   endpoint: 'GetInboundGuidanceForASIN',
  //   params: {
  //     sellerId,
  //     asinList,
  //     marketplaceId
  //   }
  // });

  const opts = {
    name: 'Fulfillment',
    group: 'Inbound Shipments',
    path: '/FulfillmentInboundShipment/2010-10-01',
    version: '2010-10-01',
    legacy: false,
    action: 'GetInboundGuidanceForASIN',
    params: {
      ASINList: { name: 'ASINList.Id', list: true, required: true },
      MarketplaceId: { name: 'MarketplaceId', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('ASINList', asinList);
  request.set('MarketplaceId', marketplaceId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getInboundGuidanceForAsinResult.asinInboundGuidanceList.asinInboundGuidance;
  // prepInstructionsList = prepInstructionsList.concat(mapPrepInstructions(result));

  return result;
};

export default GetInboundGuidanceForASIN;
