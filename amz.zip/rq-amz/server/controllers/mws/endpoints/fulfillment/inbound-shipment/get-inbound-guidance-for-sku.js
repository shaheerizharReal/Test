import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';

const GetInboundGuidanceForSKU = async ({ sellerId, authToken, asinList, marketplaceId }) => {
  // let prepInstructionsList = [];
  // if (asinList && asinList.length > 50) {
  // const otherPrepInstructionsList = await GetInboundGuidanceForSKU({
  //   sellerId,
  //   authToken,
  //   asinList: asinList.splice(50),
  //   marketplaceId
  // });
  //   prepInstructionsList = prepInstructionsList.concat(mapPrepInstructions(otherPrepInstructionsList));
  //   await sleep(500);
  // }
  //
  // printLogs({
  //   endpoint: 'GetInboundGuidanceForSKU',
  //   params: {
  //     sellerId,
  //     asinList,
  //     marketplaceId
  //   }
  // });

  const opts = {
    name: 'Fulfillment',
    group: 'Inbound Shipments',
    path: '/FulfillmentInboundShipment/2010-10-01',
    version: '2010-10-01',
    legacy: false,
    action: 'GetInboundGuidanceForSKU',
    params: {
      ASINList: { name: 'AsinList.Id', list: true, required: true },
      MarketplaceId: { name: 'MarketplaceId', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('ASINList', asinList);
  request.set('MarketplaceId', marketplaceId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  // const result = response.getPrepInstructionsForAsinResult.asinPrepInstructionsList.asinPrepInstructions;
  // prepInstructionsList = prepInstructionsList.concat(mapPrepInstructions(result));

  return response;
};

export default GetInboundGuidanceForSKU;
