import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';

const GetPackageLabels = async ({ sellerId, authToken, shipmentId, pageType, noOfPackages }) => {
  const opts = {
    name: 'Fulfillment',
    group: 'Inbound Shipments',
    path: '/FulfillmentInboundShipment/2010-10-01',
    version: '2010-10-01',
    legacy: false,
    action: 'GetPackageLabels',
    params: {
      ShipmentId: { name: 'ShipmentId', required: true },
      PageType: { name: 'PageType', required: true },
      NumberOfPackages: { name: 'NumberOfPackages', required: false }
    }
  };

  const request = new MWS.Request(opts);
  request.set('ShipmentId', shipmentId);
  request.set('PageType', !!pageType ? pageType : 'PackageLabel_Letter_2');

  if (noOfPackages) {
    request.set('NumberOfPackages', noOfPackages);
  }

  const response = await invokeRequest({ sellerId, authToken, request });

  if(response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getPackageLabelsResult.transportDocument.pdfDocument;

  return result;
};

export default GetPackageLabels;
