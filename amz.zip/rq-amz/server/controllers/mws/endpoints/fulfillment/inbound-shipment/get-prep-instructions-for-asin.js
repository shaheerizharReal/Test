import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';
import { printLogs } from '../../utils/logs';
import { sleep } from '../../utils/utils';
import { mapPrepInstructions } from './utils';

const GetPrepInstructionsForASIN = async ({ sellerId, authToken, asinList, shipToCountryCode }) => {
  let prepInstructionsList = [];
  if (asinList && asinList.length > 50) {
    const otherPrepInstructionsList = await GetPrepInstructionsForASIN({
      sellerId,
      authToken,
      asinList: asinList.splice(50),
      shipToCountryCode
    });

    prepInstructionsList = prepInstructionsList.concat(otherPrepInstructionsList);
    await sleep(500);
  }

  const opts = {
    name: 'Fulfillment',
    group: 'Inbound Shipments',
    path: '/FulfillmentInboundShipment/2010-10-01',
    version: '2010-10-01',
    legacy: false,
    action: 'GetPrepInstructionsForASIN',
    params: {
      ASINList: { name: 'AsinList.Id', list: true, required: true },
      ShipToCountryCode: { name: 'ShipToCountryCode', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('ASINList', asinList);
  request.set('ShipToCountryCode', shipToCountryCode || 'US');

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getPrepInstructionsForAsinResult.asinPrepInstructionsList.asinPrepInstructions;
  prepInstructionsList = prepInstructionsList.concat(mapPrepInstructions(result));

  return prepInstructionsList;
};

export default GetPrepInstructionsForASIN;
