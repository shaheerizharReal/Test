import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';
import { printLogs } from '../../utils/logs';
import { sleep } from '../../utils/utils';
import { mapPrepInstructions } from './utils';

const GetPrepInstructionsForSKU = async ({ sellerId, authToken, skuList, shipToCountryCode }) => {
  let prepInstructionsList = [];

  if (skuList && skuList.length > 50) {
    const otherPrepInstructionsList = await GetPrepInstructionsForSKU({
      sellerId,
      authToken,
      skuList: skuList.splice(50),
      shipToCountryCode
    });
    prepInstructionsList = prepInstructionsList.concat(otherPrepInstructionsList);
    await sleep(500);
  }

  printLogs({
    endpoint: 'GetPrepInstructionsForSKU',
    params: {
      sellerId,
      skuList,
      shipToCountryCode
    }
  });

  const opts = {
    name: 'Fulfillment',
    group: 'Inbound Shipments',
    path: '/FulfillmentInboundShipment/2010-10-01',
    version: '2010-10-01',
    legacy: false,
    action: 'GetPrepInstructionsForSKU',
    params: {
      SellerSKU: { name: 'SellerSKUList.Id', list: true, required: true },
      ShipToCountryCode: { name: 'ShipToCountryCode', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('SellerSKU', skuList);
  request.set('ShipToCountryCode', shipToCountryCode || 'US');

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getPrepInstructionsForSkuResult.skuPrepInstructionsList.skuPrepInstructions;
  prepInstructionsList = prepInstructionsList.concat(mapPrepInstructions(result));

  return prepInstructionsList;
};

export default GetPrepInstructionsForSKU;
