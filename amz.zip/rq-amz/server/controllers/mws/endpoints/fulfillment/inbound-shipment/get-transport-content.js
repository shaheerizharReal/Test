import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';
import { mapTransportContentResponse } from './utils';

const GetTransportContent = async ({ sellerId, authToken, shipmentId }) => {
  const opts = {
    name: 'Fulfillment',
    group: 'Inbound Shipments',
    path: '/FulfillmentInboundShipment/2010-10-01',
    version: '2010-10-01',
    legacy: false,
    action: 'GetTransportContent',
    params: {
      ShipmentId: { name: 'ShipmentId', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('ShipmentId', shipmentId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  let transportContent = response.getTransportContentResult.transportContent;
  transportContent = mapTransportContentResponse(transportContent);

  return transportContent;
};

export default GetTransportContent;
