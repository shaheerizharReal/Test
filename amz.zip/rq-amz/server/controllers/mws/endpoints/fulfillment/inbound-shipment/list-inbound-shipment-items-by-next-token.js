import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';
import { printLogs } from '../../utils/logs';
import { sleep, toArray } from '../../utils/utils';

const ListInboundShipmentItemsByNextToken = async ({ sellerId, authToken, nextToken }) => {
  printLogs({
    endpoint: 'ListInboundShipmentItemsByNextToken',
    params: {
      sellerId,
      nextToken
    }
  });

  const request = new MWS.Fbs.requests.inbound.ListInboundShipmentItemsByNextToken();
  request.set('NextToken', nextToken);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listInboundShipmentItemsByNextTokenResult;
  let shipmentItems = toArray(result.itemData.member);

  if (result.nextToken) {
    await sleep(500);
    const nextShipmentItems = await ListInboundShipmentItemsByNextToken({
      sellerId,
      authToken,
      nextToken: result.nextToken
    });
    shipmentItems = shipmentItems.concat(nextShipmentItems);
  }

  return shipmentItems;
};

export default ListInboundShipmentItemsByNextToken;
