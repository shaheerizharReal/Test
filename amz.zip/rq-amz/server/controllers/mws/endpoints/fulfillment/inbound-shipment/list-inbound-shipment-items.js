import MWS from '@minmaxindustries/mws-sdk';
import ListInboundShipmentItemsByNextToken from './list-inbound-shipment-items-by-next-token';
import invokeRequest from '../../utils/invoke-request';
import { toArray } from '../../utils/utils';
import { mapPrepDetails } from './utils';

const ListInboundShipmentItems = async ({ sellerId, authToken, shipmentId }) => {
  const request = new MWS.Fbs.requests.inbound.ListInboundShipmentItems();
  request.set('ShipmentId', shipmentId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listInboundShipmentItemsResult;
  let shipmentItems = toArray(result.itemData.member);

  shipmentItems = mapPrepDetails(shipmentItems);
  if (result.nextToken) {
    const nextShipmentItems = await ListInboundShipmentItemsByNextToken({
      sellerId,
      authToken,
      nextToken: result.nextToken
    });
    shipmentItems = shipmentItems.concat(nextShipmentItems);
  }
  return shipmentItems;
};

export default ListInboundShipmentItems;
