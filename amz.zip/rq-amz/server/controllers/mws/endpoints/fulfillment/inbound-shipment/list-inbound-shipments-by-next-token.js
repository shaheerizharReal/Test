import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';
import { printLogs } from '../../utils/logs';
import { sleep, toArray } from '../../utils/utils';

const ListInboundShipmentsByNextToken = async ({ sellerId, authToken, nextToken }) => {
  printLogs({
    endpoint: 'ListInboundShipmentsByNextToken',
    params: {
      sellerId,
      nextToken
    }
  });

  const request = new MWS.Fbs.requests.inbound.ListInboundShipmentsByNextToken();
  request.set('NextToken', nextToken);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listInboundShipmentsByNextTokenResult;

  let shipments = toArray(result.shipmentData.member);
  if (result.nextToken) {
    await sleep(500);
    const nextShipments = await ListInboundShipmentsByNextToken({
      sellerId,
      authToken,
      nextToken: result.nextToken
    });
    shipments = shipments.concat(nextShipments);
  }

  return shipments;
};

export default ListInboundShipmentsByNextToken;
