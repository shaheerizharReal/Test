import MWS from '@minmaxindustries/mws-sdk';
import ListInboundShipmentsByNextToken from './list-inbound-shipments-by-next-token';
import invokeRequest from '../../utils/invoke-request';
import { parseDate, toArray } from '../../utils/utils';

const ListInboundShipments = async ({ sellerId, authToken,
  shipmentStatusList,
  shipmentIdList,
  lastUpdatedAfter,
  lastUpdatedBefore
}) => {
  const request = new MWS.Fbs.requests.inbound.ListInboundShipments();
  if (shipmentStatusList) request.set('ShipmentStatuses', shipmentStatusList);
  if (shipmentIdList) request.set('ShipmentIds', shipmentIdList);
  if (lastUpdatedAfter) request.set('LastUpdatedAfter', parseDate('lastUpdatedAfter', lastUpdatedAfter));
  if (lastUpdatedAfter) request.set('LastUpdatedBefore', parseDate('lastUpdatedBefore', lastUpdatedBefore));

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listInboundShipmentsResult;
  let shipments = toArray(result.shipmentData.member);

  if (result.nextToken) {
    const nextShipments = await ListInboundShipmentsByNextToken({
      sellerId,
      authToken,
      nextToken: result.nextToken
    });
    shipments = shipments.concat(nextShipments);
  }

  return shipments;
};

export default ListInboundShipments;
