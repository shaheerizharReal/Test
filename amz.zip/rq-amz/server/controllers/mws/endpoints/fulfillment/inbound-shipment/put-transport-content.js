import { isEmpty } from 'lodash';

import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';

const PutTransportContent = async ({
  sellerId,
  authToken,
  shipmentId,
  isPartnered,
  shipmentType,
  partneredSmallParcelData,
  nonPartneredSmallParcelData,
  partneredLtlData,
  nonPartneredLtlData
}) => {
  const request = new MWS.Fbs.requests.inbound.PutTransportContent();

  request.set('ShipmentId', shipmentId);
  request.set('IsPartnered', isPartnered);
  request.set('ShipmentType', shipmentType);

  if (isPartnered && shipmentType === 'SP') {
    const { carrierName, packageList } = partneredSmallParcelData;

    const partneredSPData = new MWS.Fbs.complex.PartneredSmallParcelData(
      carrierName,
      packageList
    );

    request.set('PartneredSmallParcelData', partneredSPData);
  } else if (!isPartnered && shipmentType === 'SP') {
    const { carrierName, packageList } = nonPartneredSmallParcelData;

    const nonPartneredSPData = new MWS.Fbs.complex.NonPartneredSmallParcelData(
      carrierName,
      packageList
    );

    request.set('NonPartneredSmallParcelData', nonPartneredSPData);
  } else if (isPartnered && (shipmentType === 'LTL' || shipmentType === 'TL')) {
    const {
      contact,
      boxCount,
      sellerFreightClass,
      freightReadyDate,
      palletList,
      totalWeight,
      sellerDeclaredValue
    } = partneredLtlData;

    const pLtlData = new MWS.Fbs.complex.PartneredLtlData(
      contact,
      boxCount,
      sellerFreightClass,
      freightReadyDate,
      palletList,
      totalWeight,
      sellerDeclaredValue
    );

    request.set('NonPartneredSmallParcelData', pLtlData);
  } else if (!isPartnered && (shipmentType === 'LTL' || shipmentType === 'TL')) {
    const { carrierName, proNumber } = nonPartneredLtlData;

    const nonPLtlData = new MWS.Fbs.complex.NonPartneredLtlData(
      carrierName,
      proNumber
    );

    request.set('NonPartneredLtlData', nonPLtlData);
  }

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.putTransportContentResult.transportResult;

  return result;
};

export default PutTransportContent;
