import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';

const UpdateInboundShipment = async ({ sellerId, authToken, shipment, shipmentItems }) => {
  const request = new MWS.Fbs.requests.inbound.UpdateInboundShipment();
  request.set('ShipmentId', shipment.shipmentId);
  if (shipment.shipmentName) {
    request.set('ShipmentName', shipment.shipmentName);
  }
  if (shipment.shipFromAddress) {
    if (shipment.shipFromAddress.name) {
      request.set('ShipFromName', shipment.shipFromAddress.name);
    }
    if (shipment.shipFromAddress.addressLine1) {
      request.set('ShipFromAddressLine1', shipment.shipFromAddress.addressLine1);
    }
    if (shipment.shipFromAddress.city) {
      request.set('ShipFromAddressCity', shipment.shipFromAddress.city);
    }
    if (shipment.shipFromAddress.countryCode) {
      request.set('ShipFromDistrictOrCounty', shipment.shipFromAddress.countryCode);
    }
    if (shipment.shipFromAddress.stateOrProvinceCode) {
      request.set('ShipFromStateOrProvince', shipment.shipFromAddress.stateOrProvinceCode);
    }
    if (shipment.shipFromAddress.postalCode) {
      request.set('ShipFromPostalCode', shipment.shipFromAddress.postalCode);
    }
    if (shipment.shipFromAddress.countryCode) {
      request.set('ShipFromCountryCode', shipment.shipFromAddress.countryCode);
    }
  }
  if (shipment.destinationFulfillmentCenterId) {
    request.set('DestinationFulfillmentCenterId', shipment.destinationFulfillmentCenterId);
  }
  if (shipment.intendedBoxContentsSource) {
    request.set('IntendedBoxContentsSource', shipment.intendedBoxContentsSource);
  }
  if (shipment.areCasesRequired) {
    request.set('AreCasesRequired', shipment.areCasesRequired);
  }
  if (shipment.shipmentStatus) {
    request.set('ShipmentStatus', shipment.shipmentStatus);
  }
  if (shipment.labelPrepType) {
    request.set('LabelPrepPreference', shipment.labelPrepType);
  }

  if (shipmentItems) {
    const requestItems = new MWS.Fbs.complex.InboundShipmentItems();
    shipmentItems.forEach(item => requestItems.add(item.quantity, item.quantityInCase || 0, item.sellerSku, item.prepDetailsList || []));
    request.set('InboundShipmentItems', requestItems);
  }

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  return response.updateInboundShipmentResult;
};

export default UpdateInboundShipment;
