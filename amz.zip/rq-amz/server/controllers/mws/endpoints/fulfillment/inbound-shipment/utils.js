import { isArray, compact, isEmpty, omit } from 'lodash';

export const mapPrepInstructions = (items) => {
  items = items || [];
  items = isArray(items) ? items : [items];

  return items.map((item) => {
    let prepInstructions = [];
    if (item.prepInstructionList && item.prepInstructionList.prepInstruction) {
      prepInstructions = item.prepInstructionList.prepInstruction;
      if (!isArray(prepInstructions)) {
        prepInstructions = [prepInstructions];
      }
    }

    let amazonPrepFeesDetails = [];
    if (item.amazonPrepFeesDetailsList && item.amazonPrepFeesDetailsList.amazonPrepFeesDetails) {
      amazonPrepFeesDetails = item.amazonPrepFeesDetailsList.amazonPrepFeesDetails;
      if (!isArray(amazonPrepFeesDetails)) {
        amazonPrepFeesDetails = [amazonPrepFeesDetails];
      }
    }

    return {
      ...omit(item, 'prepInstructionList', 'amazonPrepFeesDetailsList'),
      prepInstructions,
      amazonPrepFeesDetails
    };
  });
};

export const mapCreateInboundShipmentPlans = (result) => {
  let plans = result.inboundShipmentPlans.member;
  const shipmentPlans = [];
  if (plans) {
    plans = isArray(plans) ? plans : [plans];

    plans.forEach((plan) => {
      let items = plan.items.member;
      items = isArray(items) ? items : [items];

      items = items.map((item) => {
        let prepDetailsList = [];
        if (!isEmpty(item.prepDetailsList)) {
          prepDetailsList = item.prepDetailsList.prepDetails;
          prepDetailsList = isArray(prepDetailsList) ? prepDetailsList : [prepDetailsList];
        }

        return {
          ...item,
          prepDetailsList
        };
      });

      shipmentPlans.push({
        ...plan,
        items: isArray(items) ? items : [items]
      });
    });
  }
  return shipmentPlans;
};

export const mapPrepDetails = (items) => {
  let shipmentItems = items;
  if (shipmentItems.length > 0) {
    shipmentItems = shipmentItems.map((item) => {
      let prepDetailsList = [];
      if (item.prepDetailsList && item.prepDetailsList.prepDetails) {
        if (isArray(item.prepDetailsList.prepDetails)) {
          prepDetailsList = compact(item.prepDetailsList.prepDetails);
        } else {
          if (!isEmpty(item.prepDetailsList.prepDetails)) {
            prepDetailsList.push(item.prepDetailsList.prepDetails);
          }
        }
      }
      return {
        ...omit(item, 'prepDetailsList'),
        prepDetailsList
      };
    });
  }
  return shipmentItems;
};

export const mapTransportContentResponse = (transportContent) => {
  const { transportDetails, transportHeader, transportResult } = transportContent;

  const { isPartnered, shipmentId, shipmentType } = transportHeader;
  const { transportStatus } = transportResult;
  let {
    partneredSmallParcelData,
    nonPartneredSmallParcelData,
    partneredLtlData
  } = transportDetails;

  const { nonPartneredLtlData } = transportDetails;

  if (isPartnered && shipmentType === 'SP') {
    let { packageList } = partneredSmallParcelData;
    packageList = packageList.member;

    if (!isArray(packageList)) packageList = [packageList];

    partneredSmallParcelData = {
      ...partneredSmallParcelData,
      packageList
    };
  } else if (!isPartnered && shipmentType === 'SP') {
    let { packageList } = nonPartneredSmallParcelData;
    packageList = packageList.member;

    if (!isArray(packageList)) packageList = [packageList];

    nonPartneredSmallParcelData = {
      ...nonPartneredSmallParcelData,
      packageList
    };
  } else if (isPartnered && (shipmentType === 'LTL' || shipmentType === 'TL')) {
    let { palletList } = partneredLtlData;
    palletList = palletList.member;

    if (!isArray(palletList)) palletList = [palletList];

    partneredLtlData = {
      ...partneredLtlData,
      palletList
    };
  }

  return {
    shipmentId,
    isPartnered,
    shipmentType,
    transportStatus,
    partneredSmallParcelData,
    nonPartneredSmallParcelData,
    partneredLtlData,
    nonPartneredLtlData
  };
};
