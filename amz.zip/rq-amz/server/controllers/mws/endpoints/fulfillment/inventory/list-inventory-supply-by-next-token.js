import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';
import { printLogs } from '../../utils/logs';
import { sleep } from '../../utils/utils';

const ListInventorySupplyByNextToken = async ({ sellerId, authToken, nextToken }) => {
  printLogs({
    endpoint: 'ListInventorySupplyByNextToken',
    params: {
      sellerId,
      nextToken
    }
  });

  const request = new MWS.Fbs.requests.inventory.ListInventorySupplyByNextToken();
  request.set('NextToken', nextToken);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listInventorySupplyByNextTokenResult;

  let invenotrySupplyList = (result.inventorySupplyList && result.inventorySupplyList.member) || [];

  if (result.nextToken) {
    await sleep(500);
    const nextInventorySupplyList = await ListInventorySupplyByNextToken({ sellerId, authToken, nextToken: result.nextToken });
    invenotrySupplyList = invenotrySupplyList.concat(nextInventorySupplyList);
  }

  return invenotrySupplyList;
};

export default ListInventorySupplyByNextToken;
