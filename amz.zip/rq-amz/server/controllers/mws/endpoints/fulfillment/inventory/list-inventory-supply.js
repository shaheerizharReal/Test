import MWS from '@minmaxindustries/mws-sdk';
import moment from 'moment';

import ListInventorySupplyByNextToken from './list-inventory-supply-by-next-token';
import invokeRequest from '../../utils/invoke-request';
import { printLogs } from '../../utils/logs';
import { sleep } from '../../utils/utils';

const ListInventorySupply = async ({ sellerId, authToken, skuList, queryStartDateTime, responseGroup, marketplaceId }) => {
  let invenotrySupplyList = [];
  if (skuList && skuList.length > 50) {
    const otherInventorySupplyList = await ListInventorySupply({
      sellerId,
      authToken,
      skuList: skuList.splice(50),
      queryStartDateTime,
      responseGroup,
      marketplaceId
    });
    invenotrySupplyList = invenotrySupplyList.concat(otherInventorySupplyList);
    await sleep(500);
  }

  printLogs({
    endpoint: 'ListInventorySupply',
    params: {
      sellerId,
      skuList,
      queryStartDateTime,
      responseGroup,
      marketplaceId
    }
  });

  const request = new MWS.Fbs.requests.inventory.ListInventorySupply();
  if (skuList && skuList.length > 0) request.set('SellerSkus', skuList);
  if (queryStartDateTime) request.set('QueryStartDateTime', moment(queryStartDateTime).toDate());
  if (responseGroup) request.set('ResponseGroup', responseGroup);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listInventorySupplyResult;
  invenotrySupplyList = invenotrySupplyList.concat(result.inventorySupplyList.member);

  if (result.nextToken) {
    const nextInventorySupplyList = await ListInventorySupplyByNextToken({ sellerId, authToken, nextToken: result.nextToken });
    invenotrySupplyList = invenotrySupplyList.concat(nextInventorySupplyList);
  }

  return invenotrySupplyList;
};

export default ListInventorySupply;
