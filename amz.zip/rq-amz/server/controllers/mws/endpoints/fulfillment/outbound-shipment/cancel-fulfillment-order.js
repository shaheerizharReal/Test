import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';
import { printLogs } from '../../utils/logs';

const CancelFulfillmentOrder = async ({ sellerId, authToken, sellerFulfillmentOrderId }) => {
  printLogs({
    endpoint: 'CancelFulfillmentOrder',
    params: {
      sellerId,
      sellerFulfillmentOrderId
    }
  });

  const request = new MWS.Fbs.requests.outbound.CancelFulfillmentOrder();
  if (sellerFulfillmentOrderId) request.set('SellerFulfillmentOrderId', sellerFulfillmentOrderId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  return true;
};

export default CancelFulfillmentOrder;
