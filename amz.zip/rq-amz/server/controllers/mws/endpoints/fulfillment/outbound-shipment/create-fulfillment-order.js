import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';
import { printLogs } from '../../utils/logs';

const CreateFulfillmentOrder = async ({ sellerId, authToken, orderDetails }) => {
  printLogs({
    endpoint: 'CreateFulfillmentOrder',
    params: {
      sellerId,
      orderDetails
    }
  });

  const request = new MWS.Fbs.requests.outbound.CreateFulfillmentOrder();
  request.set('SellerFulfillmentOrderId', orderDetails.SellerFulfillmentOrderId);
  request.set('DisplayableOrderId', orderDetails.DisplayableOrderId);
  request.set('ShippingSpeedCategory', orderDetails.ShippingSpeedCategory);
  request.set('DisplayableOrderDateTime', new Date(orderDetails.DisplayableOrderDateTime));
  request.set('DisplayableOrderComment', orderDetails.DisplayableOrderComment);
  request.set('NotificationEmailList.member', [orderDetails.NotificationEmail]);
  request.set('DestinationAddress.Name', orderDetails.DestName);
  request.set('DestinationAddress.Line1', orderDetails.DestAddressLine1);
  request.set('DestinationAddress.Line2', '');
  request.set('DestinationAddress.City', orderDetails.DestCity);
  request.set('DestinationAddress.CountryCode', orderDetails.DestCountryCode);
  request.set('DestinationAddress.StateOrProvinceCode', orderDetails.DestStateOrProvince);
  request.set('DestinationAddress.PostalCode', orderDetails.DestPostalCode);
  request.set('DestinationAddress.PhoneNumber', orderDetails.DestPhoneNumber);

  const lineItems = new MWS.Fbs.complex.CreateLineItems();

  // add(comment, giftMessage, decUnitValue, decValueCurrency, quantity, orderItemId, sellerSku)
  lineItems.add('', '', orderDetails.LineItems.PerUnitDeclaredValue, orderDetails.LineItems.PerUnitDeclaredCurrencyCode, orderDetails.LineItems.Quantity, orderDetails.LineItems.SellerFulfillmentOrderItemId, orderDetails.LineItems.SellerSKU);


  request.set('LineItems', lineItems);
  const response = invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }
  return response.responseMetadata.requestId;
};

export default CreateFulfillmentOrder;
