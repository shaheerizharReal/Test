import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../../utils/invoke-request';
import { printLogs } from '../../utils/logs';

const GetFulfillmentOrder = async ({ sellerId, authToken, sellerFulfillmentOrderId }) => {
  printLogs({
    endpoint: 'GetFulfillmentOrder',
    params: {
      sellerId,
      sellerFulfillmentOrderId
    }
  });

  const request = new MWS.Fbs.requests.outbound.GetFulfillmentOrder();
  if (sellerFulfillmentOrderId) request.set('SellerFulfillmentOrderId', sellerFulfillmentOrderId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getFulfillmentOrderResult;

  return result;
};

export default GetFulfillmentOrder;
