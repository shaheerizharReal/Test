import MWS from '@minmaxindustries/mws-sdk';
import { concat } from 'lodash';

import invokeRequest from '../utils/invoke-request';
import { toArray, sleep } from '../utils/utils';
import { printLogs } from '../utils/logs';

const GetOrder = async ({ sellerId, authToken, amazonOrderIdList }) => {

  let orders = [];
  if (amazonOrderIdList && amazonOrderIdList.length > 50) {
    const otherOrders = await GetOrder({
      sellerId,
      authToken,
      amazonOrderIdList: amazonOrderIdList.splice(50)
    });
    orders = orders.concat(otherOrders);
    await sleep(60000);
  }

  printLogs({
    endpoint: 'GetOrder',
    params: {
      sellerId,
      amazonOrderIdList
    }
  });

  const request = new MWS.Orders.requests.GetOrder();
  if (amazonOrderIdList) request.set('AmazonOrderId', amazonOrderIdList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getOrderResult;
  orders = concat(orders, toArray(result.orders.order || []));

  return orders;
};

export default GetOrder;
