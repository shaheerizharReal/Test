import MWS from '@minmaxindustries/mws-sdk';
import { isArray } from 'lodash';

import { sleep } from '../utils/utils';
import invokeRequest from '../utils/invoke-request';
import { printLogs } from '../utils/logs';
import { parseOrderItems } from './utils';

const ListOrderItemsByNextToken = async ({ sellerId, authToken, nextToken }) => {
  printLogs({
    endpoint: 'ListOrderItemsByNextToken',
    params: {
      sellerId,
      nextToken
    }
  });

  const request = new MWS.Orders.requests.ListOrderItemsByNextToken();
  request.set('NextToken', nextToken);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listOrderItemsResult;
  let orderItems = (result.orderItems && result.orderItems.orderItem) || [];

  orderItems = isArray(orderItems) ? orderItems : [orderItems];
  orderItems = parseOrderItems(orderItems);

  if (result.nextToken) {
    sleep(2000);
    const nextOrderItems = await ListOrderItemsByNextToken({ sellerId, authToken, nextToken: result.nextToken });
    orderItems = orderItems.concat(nextOrderItems);
  }

  return orderItems;
};

export default ListOrderItemsByNextToken;
