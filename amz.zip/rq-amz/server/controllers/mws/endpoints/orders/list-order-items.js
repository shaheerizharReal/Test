import MWS from '@minmaxindustries/mws-sdk';

import ListOrderItemsByNextToken from './list-order-items-by-next-token';
import invokeRequest from '../utils/invoke-request';
import { printLogs } from '../utils/logs';
import { parseOrderItems } from './utils';
import { toArray } from '../utils/utils';

const ListOrderItems = async ({ sellerId, authToken, amazonOrderId }) => {
  printLogs({
    endpoint: 'ListOrderItems',
    params: {
      sellerId,
      amazonOrderId
    }
  });

  const request = new MWS.Orders.requests.ListOrderItems();
  if (amazonOrderId) request.set('AmazonOrderId', amazonOrderId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listOrderItemsResult;
  let orderItems = result.orderItems ? result.orderItems.orderItem : [];

  orderItems = toArray(orderItems);
  orderItems = parseOrderItems(orderItems);

  if (result.nextToken) {
    const nextOrderItems = await ListOrderItemsByNextToken({ sellerId, authToken, nextToken: result.nextToken });
    orderItems = orderItems.concat(nextOrderItems);
  }

  return orderItems;
};

export default ListOrderItems;
