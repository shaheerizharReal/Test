import MWS from '@minmaxindustries/mws-sdk';

import invokeRequest from '../utils/invoke-request';
import { toArray, sleep } from '../utils/utils';
import { printLogs } from '../utils/logs';

const ListOrdersByNextToken = async ({ sellerId, authToken, nextToken }) => {
  printLogs({
    endpoint: 'ListOrdersByNextToken',
    params: {
      sellerId,
      nextToken
    }
  });

  const request = new MWS.Orders.requests.ListOrdersByNextToken();
  request.set('NextToken', nextToken);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listOrdersByNextTokenResult;
  let orders = (result.orders && result.orders.order) || [];

  orders = toArray(orders);

  return {
    orders,
    nextToken: result.nextToken
  }
};

export default ListOrdersByNextToken;
