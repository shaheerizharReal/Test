import MWS from '@minmaxindustries/mws-sdk';
import { toArray } from '../utils/utils';

import ListOrdersByNextToken from './list-orders-by-next-token';
import { printLogs } from '../utils/logs';
import invokeRequest from '../utils/invoke-request';
import { parseDate } from '../utils/utils';

const ListOrders = async ({ sellerId, authToken, marketplaceId, createdAfter, createdBefore, lastUpdatedAfter, lastUpdatedBefore, orderStatusList, fulfillmentChannelList, paymentMethodList, buyerEmail }) => {
  printLogs({
    endpoint: 'ListOrders',
    params: {
      sellerId,
      marketplaceId,
      createdAfter,
      createdBefore,
      lastUpdatedAfter,
      lastUpdatedBefore,
      orderStatusList,
      fulfillmentChannelList,
      paymentMethodList
    }
  });

  const request = new MWS.Orders.requests.ListOrders();
  if (marketplaceId) request.set('MarketplaceId', marketplaceId);
  if (createdAfter) request.set('CreatedAfter', parseDate('createdAfter', createdAfter));
  if (createdBefore) request.set('CreatedBefore', parseDate('createdBefore', createdBefore));
  if (lastUpdatedAfter) request.set('LastUpdatedAfter', parseDate('lastUpdatedAfter', lastUpdatedAfter));
  if (lastUpdatedBefore) request.set('LastUpdatedBefore', parseDate('lastUpdatedBefore', lastUpdatedBefore));
  if (orderStatusList) request.set('OrderStatus', orderStatusList);
  if (fulfillmentChannelList) request.set('FulfillmentChannel', fulfillmentChannelList);
  if (paymentMethodList) request.set('PaymentMethod', paymentMethodList);
  if (buyerEmail) request.set('BuyerEmail', buyerEmail);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listOrdersResult;
  let orders = result.orders ? result.orders.order : [];

  orders = toArray(orders);

  return {
    orders,
    nextToken: result.nextToken
  }
};

export default ListOrders;
