import lodash from 'lodash';

const addAmount = (currentPrice, nextPrice) => {
  return currentPrice + ((nextPrice && nextPrice.amount) || 0);
};

export const parseOrderItems = (orderItems) => {
  const itemGroups = lodash(orderItems)
    .groupBy(item => item.sellerSku);

  const defaultOrderItem = { quantityOrdered: 0,
    quantityShipped: 0,
    itemPrice: 0,
    itemTax: 0,
    shippingPrice: 0,
    shippingTax: 0,
    shippingDiscount: 0,
    giftWrapPrice: 0,
    giftWrapTax: 0,
    promotionDiscount: 0,
    promotionIds: [],
    orderItemIds: []
  };

  const mergePromotionIds = (currentPromotion, nextPromotion) => {
    const promotionId = !!nextPromotion && nextPromotion.promotionId;
    if (promotionId && !currentPromotion.includes(promotionId)) {
      currentPromotion.push(promotionId);
    }
    return currentPromotion;
  };

  const mergeItemIds = (itemIds, nextItemId) => {
    if (!itemIds.includes(nextItemId)) {
      itemIds.push(nextItemId);
    }
    return itemIds;
  };

  return (itemGroups.map((itemGroup) => {
    const reducedItem = lodash.reduce(itemGroup, (current, next) => {
      return {
        quantityOrdered: current.quantityOrdered + next.quantityOrdered,
        quantityShipped: current.quantityShipped + next.quantityShipped,
        itemPrice: addAmount(current.itemPrice, next.itemPrice),
        itemTax: addAmount(current.itemTax, next.itemTax),
        shippingPrice: addAmount(current.shippingPrice, next.shippingPrice),
        shippingTax: addAmount(current.shippingTax, next.shippingTax),
        shippingDiscount: addAmount(current.shippingDiscount, next.shippingDiscount),
        giftWrapPrice: addAmount(current.giftWrapPrice, next.giftWrapPrice),
        giftWrapTax: addAmount(current.giftWrapTax, next.giftWrapTax),
        promotionDiscount: addAmount(current.promotionDiscount, next.promotionDiscount),
        promotionIds: mergePromotionIds(current.promotionIds, next.promotionIds),
        orderItemIds: mergeItemIds(current.orderItemIds, next.orderItemId)
      };
    }, defaultOrderItem);

    let itemStatus;
    if (reducedItem.quantityOrdered === 0) {
      itemStatus = 'Cancelled';
    } else {
      itemStatus = (reducedItem.quantityOrdered === reducedItem.quantityShipped) ? 'Shipped' : 'Unshipped';
    }

    return {
      ...reducedItem,
      currency: (itemGroup[0].itemPrice ? itemGroup[0].itemPrice.currencyCode : ''),
      itemStatus,
      asin: itemGroup[0].asin,
      sellerSku: itemGroup[0].sellerSku,
      title: itemGroup[0].title
    };
  })
    .value());
};
