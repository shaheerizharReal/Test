import MWS from '@minmaxindustries/mws-sdk';
import { isArray } from 'lodash';

import invokeRequest from '../utils/invoke-request';
import { mapCompetitivePricingResult } from './utils';

const GetCompetitivePricingForASIN = async ({ sellerId, authToken, marketplaceId, asinList }) => {
  const request = new MWS.Products.requests.GetCompetitivePricingForASIN();
  request.set('MarketplaceId', marketplaceId);
  request.set('ASINList', asinList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getCompetitivePricingForAsinResult;
  const products = [];
  if (isArray(result)) {
    result.filter(r => r.status === 'Success').forEach(({ asin, product }) => {
      if (product) {
        const p = mapCompetitivePricingResult(product);
        products.push({
          asin, ...p
        });
      }
    });
  } else if (result.status === 'Success') {
    if (result.product) {
      const p = mapCompetitivePricingResult(result.product);
      products.push({
        asin: result.asin,
        ...p
      });
    }
  }

  return products;
};

export default GetCompetitivePricingForASIN;
