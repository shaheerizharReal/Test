import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';

const GetCompetitivePricingForSKU = async ({ sellerId, authToken, marketplaceId, skuList }) => {
  const request = new MWS.Products.requests.GetCompetitivePricingForSKU();
  request.set('MarketplaceId', marketplaceId);
  request.set('SellerSKUList', skuList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getCompetitivePricingForSkuResult;
  return result;
};

export default GetCompetitivePricingForSKU;
