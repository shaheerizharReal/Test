import MWS from '@minmaxindustries/mws-sdk';
import { isArray } from 'lodash';

import invokeRequest from '../utils/invoke-request';
import { mapLowestOfferListings } from './utils';

const GetLowestOfferListingsForASIN = async ({ sellerId, authToken, marketplaceId, asinList, condition }) => {
  const request = new MWS.Products.requests.GetLowestOfferListingsForASIN();
  request.set('MarketplaceId', marketplaceId);
  request.set('ASINList', asinList);
  if (condition) request.set('ItemCondition', condition);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getLowestOfferListingsForAsinResult;

  const products = [];
  if (isArray(result)) {
    result.filter(({ status }) => status === 'Success').forEach(({ asin, product }) => {
      if (product) {
        const p = mapLowestOfferListings(product);
        products.push({
          asin, ...p
        });
      }
    });
  } else if (result.status === 'Success') {
    if (result.product) {
      const p = mapLowestOfferListings(result.product);
      products.push({
        asin: result.asin,
        ...p
      });
    }
  }

  return products;
};

export default GetLowestOfferListingsForASIN;
