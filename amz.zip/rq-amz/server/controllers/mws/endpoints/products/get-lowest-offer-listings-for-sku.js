import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';

const GetLowestOfferListingsForSKU = async ({ sellerId, authToken, marketplaceId, skuList, condition }) => {
  const request = new MWS.Products.requests.GetLowestOfferListingsForSKU();
  request.set('MarketplaceId', marketplaceId);
  request.set('SellerSKUList', skuList);
  if (condition) request.set('ItemCondition', condition);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getLowestOfferListingsForSkuResult;
  return result;
};

export default GetLowestOfferListingsForSKU;
