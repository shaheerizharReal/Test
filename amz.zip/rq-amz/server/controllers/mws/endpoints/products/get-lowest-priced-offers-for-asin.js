import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { mapLowestPricedOffers } from './utils';

const GetLowestPricedOffersForASIN = async ({ sellerId, authToken, marketplaceId, asin, condition }) => {
  const opts = {
    name: 'Products',
    group: 'Products',
    path: '/Products/2011-10-01',
    version: '2011-10-01',
    legacy: false,
    action: 'GetLowestPricedOffersForASIN',
    params: {
      MarketplaceId: { name: 'MarketplaceId', required: true },
      ASIN: { name: 'ASIN', required: true },
      ItemCondition: { name: 'ItemCondition', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('MarketplaceId', marketplaceId);
  request.set('ASIN', asin);
  request.set('ItemCondition', condition);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  let result = response.getLowestPricedOffersForAsinResult;
  result = mapLowestPricedOffers(result, 'identifier');
  return result;
};

export default GetLowestPricedOffersForASIN;
