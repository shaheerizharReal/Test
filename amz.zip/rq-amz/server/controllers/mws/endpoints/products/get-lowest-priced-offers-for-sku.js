import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { mapLowestPricedOffers } from './utils';

const GetLowestPricedOffersForSKU = async ({ sellerId, authToken, marketplaceId, sellerSKU, condition }) => {
  const opts = {
    name: 'Products',
    group: 'Products',
    path: '/Products/2011-10-01',
    version: '2011-10-01',
    legacy: false,
    action: 'GetLowestPricedOffersForSKU',
    params: {
      MarketplaceId: { name: 'MarketplaceId', required: true },
      SellerSKU: { name: 'SellerSKU', required: true },
      ItemCondition: { name: 'ItemCondition', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('MarketplaceId', marketplaceId);
  request.set('SellerSKU', sellerSKU);
  request.set('ItemCondition', condition);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  let result = response.getLowestPricedOffersForSkuResult;
  result = mapLowestPricedOffers(result, 'identifier');
  return result;
};

export default GetLowestPricedOffersForSKU;
