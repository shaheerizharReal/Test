import MWS from '@minmaxindustries/mws-sdk';
import { isArray } from 'lodash';

import invokeRequest from '../utils/invoke-request';
import { printLogs } from '../utils/logs';
import { mapProduct } from './utils';
import { toArray } from '../utils/utils';

// IdType = [ASIN, GCID, SellerSKU, UPC, EAN, ISBN, JAN]

const GetMatchingProductForId = async ({ sellerId, authToken, marketplaceId, idType, idList }) => {

  const request = new MWS.Products.requests.GetMatchingProductForId();
  request.set('MarketplaceId', marketplaceId);
  request.set('IdType', idType);
  request.set('IdList', idList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if(response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getMatchingProductForIdResult;
  let products = [];
  if (isArray(result)) {
    result.filter(r => r.status === 'Success').forEach((r) => {
      let productList = toArray(r.products.product);
      productList = productList.map(product => mapProduct(product));

      products.push({
        id: r.id,
        idType: r.idType,
        products: productList
      });
    });
  } else if (result.status === 'Success') {
    let productList = toArray(result.products.product);
    productList = productList.map(product => mapProduct(product));
    products.push({
      id: result.id,
      idType: result.idType,
      products: productList
    });
  }

  return products;
};

export default GetMatchingProductForId;
