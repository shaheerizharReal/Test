import MWS from '@minmaxindustries/mws-sdk';
import { isArray } from 'lodash';

import invokeRequest from '../utils/invoke-request';
import { mapProduct } from './utils';

const GetMatchingProduct = async ({ sellerId, authToken, marketplaceId, asinList }) => {
  const request = new MWS.Products.requests.GetMatchingProduct();
  request.set('MarketplaceId', marketplaceId);
  request.set('ASINList', asinList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getMatchingProductResult;

  let products = [];
  if (isArray(result)) {
    products = result.filter(r => r.status === 'Success').map(r => mapProduct(r.product));
  } else if (result && result.status === 'Success') {
    products.push(mapProduct(result.product));
  }

  return products;
};

export default GetMatchingProduct;
