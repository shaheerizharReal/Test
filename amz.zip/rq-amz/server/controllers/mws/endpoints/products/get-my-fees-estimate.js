import MWS from '@minmaxindustries/mws-sdk';
import { isArray, pick, extend } from 'lodash';

import invokeRequest from '../utils/invoke-request';

const SetFeesEstimateRequestList = function() {
  const obj = new MWS.ComplexList('FeesEstimateRequestList.FeesEstimateRequest');
  obj.add = ({ marketplaceId, idType, idValue, isAmazonFulfilled, listingPrice }) => {
    obj.members.push({
      MarketplaceId: marketplaceId,
      IdType: idType,
      IdValue: idValue,
      IsAmazonFulfilled: isAmazonFulfilled,
      Identifier: 'UNIQUE_IDENTIFIER',
      'PriceToEstimateFees.ListingPrice.CurrencyCode': listingPrice.currencyCode,
      'PriceToEstimateFees.ListingPrice.Amount': listingPrice.amount
    });
    return obj;
  };
  return obj;
};

const mapFeeEstimate = (response) => {
  const feeEstimate = response.feesEstimate;
  const result = pick(feeEstimate, [
    'totalFeesEstimate',
    'timeOfFeesEstimation'
  ]);

  extend(result, { feeDetailList: feeEstimate.feeDetailList.feeDetail });
  extend(result, { feesEstimateIdentifier: response.feesEstimateIdentifier });
  return result;
};

const GetMyFeesEstimate = async ({ sellerId, authToken,
  marketplaceId,
  asin,
  isAmazonFulfilled,
  listingPrice,
  feeRequestList
}) => {
  const opts = {
    name: 'GetMyFeesEstimate',
    group: 'Products',
    path: '/Products/2011-10-01',
    version: '2011-10-01',
    legacy: false,
    action: 'GetMyFeesEstimate',
    params: {
      FeesEstimateRequestList: {
        name: 'FeesEstimateRequestList.FeesEstimateRequest',
        type: 'Complex',
        required: true,
        construct: SetFeesEstimateRequestList
      }
    }
  };

  const request = new MWS.Request(opts);
  const feeEstimateRequestList = new SetFeesEstimateRequestList();
  if (feeRequestList) {
    feeRequestList.forEach((feeRequest) => {
      feeEstimateRequestList.add({
        marketplaceId: (feeRequest.marketplaceId || marketplaceId),
        isAmazonFulfilled: feeRequest.isAmazonFulfilled,
        listingPrice: feeRequest.listingPrice,
        idType: feeRequest.idType,
        idValue: feeRequest.idValue
      });
    });
  } else {
    feeEstimateRequestList.add({
      marketplaceId,
      isAmazonFulfilled,
      listingPrice,
      idType: 'ASIN',
      idValue: asin
    });
  }

  request.set('FeesEstimateRequestList', feeEstimateRequestList);

  let response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  response = response.getMyFeesEstimateResult.feesEstimateResultList.feesEstimateResult;

  if (feeRequestList) {
    const result = [];
    const responseList = (isArray(response) ? response : [response]);
    responseList.forEach((r) => {
      if (r.status === 'Success') {
        result.push({
          ...mapFeeEstimate(r)
        });
      }
    });

    return result;
  }

  if (response.status !== 'Success') {
    throw new Error(`${response.error.code}: ${response.error.message}`);
  }

  return mapFeeEstimate(response);
};

export default GetMyFeesEstimate;
