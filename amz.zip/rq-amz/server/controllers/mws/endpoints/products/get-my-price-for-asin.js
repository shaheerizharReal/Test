import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { mapMyPriceResponse } from './utils';

const GetMyPriceForASIN = async ({ sellerId, authToken, marketplaceId, asinList }) => {
  const request = new MWS.Products.requests.GetMyPriceForASIN();
  request.set('MarketplaceId', marketplaceId);
  request.set('ASINList', asinList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getMyPriceForAsinResult;
  const products = mapMyPriceResponse(result);
  return products;
};

export default GetMyPriceForASIN;
