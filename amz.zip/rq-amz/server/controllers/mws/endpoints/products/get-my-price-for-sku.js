import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { mapMyPriceResponse } from './utils';

const GetMyPriceForSKU = async ({ sellerId, authToken, marketplaceId, sellerSkuList }) => {
  const request = new MWS.Products.requests.GetMyPriceForSKU();
  request.set('MarketplaceId', marketplaceId);
  request.set('SellerSKUList', sellerSkuList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getMyPriceForSkuResult;

  const products = mapMyPriceResponse(result);
  return products;
};

export default GetMyPriceForSKU;
