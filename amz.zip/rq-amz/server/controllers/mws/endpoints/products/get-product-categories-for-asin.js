import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { printLogs } from '../utils/logs';

const GetProductCategoriesForASIN = async ({ sellerId, authToken, marketplaceId, asin }) => {

  const request = new MWS.Products.requests.GetProductCategoriesForASIN();
  request.set('MarketplaceId', marketplaceId);
  request.set('ASIN', asin);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getProductCategoriesForAsinResult;

  printLogs({
    group: 'Products',
    endpoint: 'GetProductCategoriesForASIN',
    response: result,
    params: {
      sellerId,
      marketplaceId,
      asin
    }
  });

  return result && result.self;
};

export default GetProductCategoriesForASIN;
