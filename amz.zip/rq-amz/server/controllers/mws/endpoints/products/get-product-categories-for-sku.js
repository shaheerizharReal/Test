import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { printLogs } from '../utils/logs';

const GetProductCategoriesForSKU = async ({ sellerId, authToken, marketplaceId, sellerSKU }) => {
  const request = new MWS.Products.requests.GetProductCategoriesForASIN();
  request.set('MarketplaceId', marketplaceId);
  request.set('SellerSKU', sellerSKU);

  const response = await invokeRequest({ sellerId, authToken, request });

  if(response.error) {
    const error = response.error;
    throw new Error(error.message);
  }

  const result = response.getProductCategoriesForSKUResult;

  printLogs({
    group: 'Products',
    endpoint: 'GetProductCategoriesForASIN',
    response: result,
    params: {
      sellerId,
      marketplaceId,
      sellerSKU
    }
  });

  return result && result.self;
};

export default GetProductCategoriesForSKU;
