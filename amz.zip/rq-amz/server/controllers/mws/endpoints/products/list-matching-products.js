import MWS from '@minmaxindustries/mws-sdk';
import { isArray } from 'lodash';

import invokeRequest from '../utils/invoke-request';
import { mapProduct } from './utils';

const ListMatchingProducts = async ({ sellerId, authToken, marketplaceId, query, queryContextId }) => {
  const request = new MWS.Products.requests.ListMatchingProducts();
  request.set('MarketplaceId', marketplaceId);
  request.set('Query', query);
  if (queryContextId) request.set('QueryContextId', queryContextId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listMatchingProductsResult.products.product;

  let products = [];
  if (isArray(result)) {
    products = result.map(p => mapProduct(p));
  } else if (result) {
    products.push(mapProduct(result));
  }

  return products;
};

export default ListMatchingProducts;
