import { isArray, omit, extend, isObject, pick, isEmpty } from 'lodash';

export const mapProductRelationships = (relationships) => {
  const relationship = {};

  const parent = !!relationships.variationParent && relationships.variationParent;
  const children = !!relationships.variationChild && relationships.variationChild;

  if (children) {
    relationship.children = [];

    if (isArray(children)) {
      children.forEach((child) => {
        const attributes = omit(child, 'identifiers');
        relationship.children.push({
          asin: child.identifiers.marketplaceAsin.asin,
          ...attributes
        });
      });
    } else {
      const attributes = omit(children, 'identifiers');
      relationship.children.push({
        asin: children.identifiers.marketplaceAsin.asin,
        ...attributes
      });
    }
  }

  if (parent) {
    const attributes = omit(parent, 'identifiers');
    relationship.parent = {
      asin: parent.identifiers.marketplaceAsin.asin,
      ...attributes
    };
  }

  return relationship;
};

export const mapLowestOfferListings = ({ lowestOfferListings, identifiers }) => {
  const result = {
    lowestOfferListings: []
  };
  const { lowestOfferListing } = lowestOfferListings;

  if (lowestOfferListing && isArray(lowestOfferListing)) {
    lowestOfferListing.forEach((listing) => {
      const qualifiers = listing.qualifiers;
      const offer = omit(listing, 'qualifiers');
      result.lowestOfferListings.push({
        ...qualifiers,
        ...offer
      });
    });
  } else if (lowestOfferListing) {
    const qualifiers = lowestOfferListing.qualifiers;
    const offer = omit(lowestOfferListing, 'qualifiers');
    result.lowestOfferListings.push({
      ...qualifiers,
      ...offer
    });
  }

  return result;
};

export const mapCompetitivePricingResult = ({ competitivePricing, identifiers, salesRankings }) => {
  const result = {
    competitivePrices: [],
    numberOfOfferListings: [],
    salesRankings: []
  };

  const mapCompetitivePriceObj = (competitivePrice) => {
    const { listingPrice, shipping, landedPrice } = competitivePrice.price;
    if (!landedPrice) {
      let nLandedPrice = (((listingPrice && listingPrice.amount) || 0) + ((shipping && shipping.amount) || 0));
      nLandedPrice = Number(nLandedPrice.toFixed(2));
      return {
        ...competitivePrice,
        price: {
          ...competitivePrice.price,
          landedPrice: {
            amount: nLandedPrice,
            currencyCode: listingPrice.currencyCode
          }
        }
      };
    }

    return competitivePrice;
  };

  const { competitivePrices, numberOfOfferListings } = competitivePricing;

  if (competitivePrices && isArray(competitivePrices.competitivePrice)) {
    competitivePrices.competitivePrice.forEach(price => result.competitivePrices.push(mapCompetitivePriceObj(price)));
  } else if (competitivePrices && competitivePrices.competitivePrice) {
    const priceObj = mapCompetitivePriceObj(competitivePrices.competitivePrice);
    result.competitivePrices.push(priceObj);
  }

  if (numberOfOfferListings && isArray(numberOfOfferListings.offerListingCount)) {
    numberOfOfferListings.offerListingCount.forEach(listingCount => result.numberOfOfferListings.push(listingCount));
  } else if (numberOfOfferListings && numberOfOfferListings.offerListingCount) {
    result.numberOfOfferListings.push(numberOfOfferListings.offerListingCount);
  }


  if (salesRankings && isArray(salesRankings.salesRank)) {
    salesRankings.salesRank.forEach(rank => result.salesRankings.push(rank));
  } else if (salesRankings && salesRankings.salesRank) {
    result.salesRankings.push(salesRankings.salesRank);
  }

  return result;
};

export const mapProduct = (p) => {
  let imageUrl = p.attributeSets.itemAttributes.smallImage.url;
  if (!imageUrl.includes('no-img')) {
    imageUrl = imageUrl.replace('._SL75_.', '.');
    imageUrl = imageUrl.split('/')[imageUrl.split('/').length - 1];
  } else {
    imageUrl = '';
  }

  let salesRank = 'N/A';
  if (p.salesRankings && p.salesRankings.salesRank) {
    if (isArray(p.salesRankings.salesRank)) {
      salesRank = p.salesRankings.salesRank[0].rank;
    } else {
      salesRank = p.salesRankings.salesRank.rank;
    }
  }
  const attributes = omit(p.attributeSets.itemAttributes, ['smallImage']);
  return {
    asin: p.identifiers.marketplaceAsin.asin,
    marketplaceId: p.identifiers.marketplaceAsin.marketplaceId,
    imageUrl,
    salesRank,
    ...attributes,
    salesRankings: p.salesRankings,
    relationships: p.relationships && mapProductRelationships(p.relationships)
  };
};

export const mapLowestPricedOffers = (offersResult) => {
  const result = pick(offersResult, [
    'asin',
    'marketplaceId',
    'status',
    'itemCondition'
  ]);

  extend(result, { timeOfOfferChange: offersResult.identifier.timeOfOfferChange });

  const offers = [];
  if (!isEmpty(offersResult.offers)) {
    if (isArray(offersResult.offers.offer)) {
      offersResult.offers.offer.forEach((offer) => {
        offers.push({
          ...offer,
          landedPrice: {
            currencyCode: offer.listingPrice.currencyCode,
            amount: Number((offer.listingPrice.amount + offer.shipping.amount).toFixed(2))
          }
        });
      });
    } else {
      const offer = offersResult.offers.offer;
      offers.push({
        ...offer,
        landedPrice: {
          currencyCode: offer.listingPrice.currencyCode,
          amount: Number((offer.listingPrice.amount + offer.shipping.amount).toFixed(2))
        }
      });
    }
  } else {
    extend(result, { status: 'NoBuyableOffers' });
  }

  const summary = pick(offersResult.summary, [
    'totalOfferCount',
    'listPrice'
  ]);

  let numberOfOffers = [];
  let lowestPrices = [];
  let buyBoxPrices = [];
  let buyBoxEligibleOffers = [];

  if (offersResult.summary) {
    if (!isEmpty(offersResult.summary.numberOfOffers)) {
      if (isArray(offersResult.summary.numberOfOffers.offerCount)) {
        numberOfOffers = offersResult.summary.numberOfOffers.offerCount;
      } else {
        numberOfOffers = [offersResult.summary.numberOfOffers.offerCount];
      }
    }

    if (!isEmpty(offersResult.summary.lowestPrices)) {
      if (isArray(offersResult.summary.lowestPrices.lowestPrice)) {
        lowestPrices = offersResult.summary.lowestPrices.lowestPrice;
      } else {
        lowestPrices = [offersResult.summary.lowestPrices.lowestPrice];
      }
    }

    if (!isEmpty(offersResult.summary.buyBoxPrices)) {
      if (isArray(offersResult.summary.buyBoxPrices.buyBoxPrice)) {
        buyBoxPrices = offersResult.summary.buyBoxPrices.buyBoxPrice;
      } else {
        buyBoxPrices = [offersResult.summary.buyBoxPrices.buyBoxPrice];
      }
    }

    if (!isEmpty(offersResult.summary.buyBoxEligibleOffers)) {
      if (isArray(offersResult.summary.buyBoxEligibleOffers.offerCount)) {
        buyBoxEligibleOffers = offersResult.summary.buyBoxEligibleOffers.offerCount;
      } else {
        buyBoxEligibleOffers = [offersResult.summary.buyBoxEligibleOffers.offerCount];
      }
    }
  }
  extend(summary, { numberOfOffers, lowestPrices, buyBoxPrices, buyBoxEligibleOffers });

  extend(result, { offers, summary });

  return result;
};

export const mapMyPriceResponse = (result) => {
  let response = [];
  if (isArray(result)) {
    response = result;
  } else {
    response = [result];
  }

  response = response.map(({ asin, product, status, error }) => {
    let offers = (product && product.offers && product.offers.offer) || [];
    if (offers && isArray(offers)) {
      offers = offers.map(({
        fulfillmentChannel,
        itemCondition,
        itemSubCondition,
        sellerId,
        sellerSku,
        buyingPrice,
        regularPrice
      }) => ({
        fulfillmentChannel,
        itemCondition,
        itemSubCondition,
        sellerId,
        sellerSku,
        regularPrice,
        ...buyingPrice
      }));
    } else if (offers && isObject(offers)) {
      const {
        fulfillmentChannel,
        itemCondition,
        itemSubCondition,
        sellerId,
        sellerSku,
        regularPrice,
        buyingPrice
      } = offers;
      offers = [{
        fulfillmentChannel,
        itemCondition,
        itemSubCondition,
        sellerId,
        sellerSku,
        regularPrice,
        ...buyingPrice
      }];
    }
    return { asin, status, offers, error };
  });

  return response;
};
