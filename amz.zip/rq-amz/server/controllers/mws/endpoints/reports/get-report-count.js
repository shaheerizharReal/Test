import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { parseDate } from '../utils/utils';

const GetReportCount = async ({ sellerId, authToken, reportTypeList, acknowledged, availableFromDate, availableToDate }) => {
  const request = new MWS.Reports.requests.GetReportCount();

  if (reportTypeList) request.set('ReportTypeList', reportTypeList);
  if (acknowledged) request.set('Acknowledged', acknowledged);
  if (availableFromDate) request.set('AvailableFromDate', parseDate('availableFromDate', availableFromDate));
  if (availableToDate) request.set('AvailableToDate', parseDate('availableToDate', availableToDate));

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getReportCountResult;
  result.reportType = reportTypeList;

  return result;
};

export default GetReportCount;
