import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { printLogs } from '../utils/logs';
import { sleep } from '../utils/utils';

const GetReportListByNextToken = async ({ sellerId, authToken, nextToken }) => {
  printLogs({
    group: 'Reports',
    endpoint: 'GetReportListByNextToken',
    params: { sellerId, nextToken }
  });

  const request = new MWS.Reports.requests.GetReportListByNextToken();
  if (nextToken) request.set('NextToken', nextToken);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getReportListByNextTokenResult;
  let reportList = result.reportInfo;

  if (result.nextToken) {
    await sleep(500);
    const nextReportList = await GetReportListByNextToken({ sellerId, authToken, nextToken: result.nextToken });
    reportList = reportList.concat(nextReportList);
  }

  return reportList;
};

export default GetReportListByNextToken;
