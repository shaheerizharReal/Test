import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';

import GetReportListByNextToken from './get-report-list-by-next-token';

const GetReportList = async ({ sellerId, authToken, reportRequestIdList, reportTypeList }) => {
  const request = new MWS.Reports.requests.GetReportList();
  if (reportRequestIdList) request.set('ReportRequestIdList', reportRequestIdList);
  if (reportTypeList) request.set('ReportTypeList', reportTypeList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getReportListResult;
  let reportList = result.reportInfo || [];

  if (result.nextToken) {
    const nextReportList = await GetReportListByNextToken({ sellerId, authToken, nextToken: result.nextToken });
    reportList = reportList.concat(nextReportList);
  }

  return reportList;
};

export default GetReportList;
