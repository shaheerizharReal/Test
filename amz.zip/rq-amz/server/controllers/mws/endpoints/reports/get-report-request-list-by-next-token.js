import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { printLogs } from '../utils/logs';
import { sleep } from '../utils/utils';

const GetReportRequestListByNextToken = async ({ sellerId, authToken, nextToken }) => {
  printLogs({
    group: 'Reports',
    endpoint: 'GetReportRequestListByNextToken',
    params: {
      sellerId,
      nextToken
    }
  });

  const request = new MWS.Reports.requests.GetReportRequestListByNextToken();
  if (nextToken) request.set('NextToken', nextToken);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getReportRequestListByNextTokenResult;
  let reportRequests = result.reportRequestInfo;
  if (result.nextToken) {
    await sleep(500);
    const nextReportRequests = await GetReportRequestListByNextToken({ sellerId, authToken, nextToken: result.nextToken });
    reportRequests = reportRequests.concat(nextReportRequests);
  }

  return reportRequests;
};

export default GetReportRequestListByNextToken;
