import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { parseDate, toArray } from '../utils/utils';

import GetReportRequestListByNextToken from './get-report-request-list-by-next-token';

const GetReportRequestList = async ({
  sellerId,
  authToken,
  reportRequestIdList,
  reportTypeList,
  reportProcessingStatusList,
  maxCount,
  requestedFromDate,
  requestedToDate
}) => {
  const request = new MWS.Reports.requests.GetReportRequestList();

  if (reportRequestIdList) request.set('ReportRequestIdList', reportRequestIdList);
  if (reportTypeList) request.set('ReportTypeList', reportTypeList);
  if (reportProcessingStatusList) request.set('ReportProcessingStatuses', reportProcessingStatusList);
  if (maxCount) request.set('MaxCount', maxCount);
  if (requestedFromDate) request.set('RequestedFromDate', parseDate('requestedFromDate', requestedFromDate));
  if (requestedToDate) request.set('RequestedToDate', parseDate('requestedToDate', requestedToDate));

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.getReportRequestListResult;
  let reportRequests = toArray(result.reportRequestInfo);

  // if (result.nextToken) {
  //   const nextReportRequests = await GetReportRequestListByNextToken({ sellerId, authToken, nextToken: result.nextToken });
  //   reportRequests = reportRequests.concat(nextReportRequests);
  // }

  return reportRequests;
};

export default GetReportRequestList;
