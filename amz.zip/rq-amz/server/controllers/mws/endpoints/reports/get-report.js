import MWS from '@minmaxindustries/mws-sdk';
import { isEmpty } from 'lodash';
import { parseXML, parseTSV } from '../utils/parse';

import Settings from '../../../../../config/settings';

const GetReport = async ({ sellerId, authToken, reportId }) => {
  const request = new MWS.Reports.requests.GetReport();
  request.set('ReportId', reportId);

  const client = new MWS.Client(Settings.MWS.accessKeyId,
    Settings.MWS.secretKey, sellerId, { authToken });
  const response = await client.invoke(request);

  if (isEmpty(response)) {
    throw new Error('empty response');
  }

  if (response.slice(0, 5) === '<?xml') {
    const { error } = parseXML(response);
    throw new Error(error.message);
  }

  const reportJSON = await parseTSV(response);
  return reportJSON;
};

export default GetReport;
