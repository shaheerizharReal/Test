import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';
import { parseDate } from '../utils/utils';

const RequestReport = async ({ sellerId, authToken, marketplaceId, reportType, reportOptions, startDate, endDate }) => {
  const request = new MWS.Reports.requests.RequestReport();

  if (reportType) request.set('ReportType', reportType);
  if (startDate) request.set('StartDate', parseDate('startDate', startDate));
  if (endDate) request.set('EndDate', parseDate('endDate', endDate));
  if (marketplaceId) request.set('MarketplaceIdList', [marketplaceId]);
  if (reportOptions) {
    request.set('ReportOptions', reportOptions);
  }

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response && response.error) {
    throw new Error(response.error.message);
  }

  const reportRequest = response.requestReportResult.reportRequestInfo;
  return reportRequest;
};

export default RequestReport;
