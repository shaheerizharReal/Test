import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';

const ListMarketplaceParticipationsByNextToken = async ({ sellerId, authToken, nextToken }) => {
  const request = new MWS.Sellers.requests.ListMarketplaceParticipationsByNextToken();
  request.set('NextToken', nextToken);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listMarketplaceParticipationsByNextTokenResult;
  return result;
};

export default ListMarketplaceParticipationsByNextToken;
