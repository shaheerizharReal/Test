import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';

const ListMarketplaceParticipations = async ({ sellerId, authToken }) => {
  const request = new MWS.Sellers.requests.ListMarketplaceParticipations();
  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  const result = response.listMarketplaceParticipationsResult;
  const participations = result.listParticipations.participation;
  const marketplaces = result.listMarketplaces.marketplace;

  const participationsList = [];
  participations.forEach((participation) => {
    const marketplace = marketplaces.find(m => m.marketplaceId === participation.marketplaceId);
    participationsList.push({ ...participation, ...marketplace });
  });

  return participationsList;
};

export default ListMarketplaceParticipations;
