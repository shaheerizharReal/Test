import MWS from '@minmaxindustries/mws-sdk';

import invokeRequest from '../utils/invoke-request';
import { SubscriptionAttributeList } from './utils';
import { AWS } from '../../../../../config/settings';

const CreateSubscription = async ({ sellerId, authToken, marketplaceId, notificationType }) => {
  const opts = {
    name: 'CreateSubscription',
    group: 'Subscriptions',
    path: '/Subscriptions/2013-07-01',
    version: '2013-07-01',
    legacy: false,
    action: 'CreateSubscription',
    params: {
      MarketplaceId: { name: 'MarketplaceId', required: true },
      Destination: { name: 'AttributeList', type: 'Complex', required: true, construct: SubscriptionAttributeList },
      DeliveryChannel: { name: 'Subscription.Destination.DeliveryChannel', required: true },
      IsEnabled: { name: 'Subscription.IsEnabled', required: true },
      NotificationType: { name: 'Subscription.NotificationType', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('MarketplaceId', marketplaceId);
  request.set('DeliveryChannel', 'SQS');
  request.set('IsEnabled', true);
  request.set('NotificationType', notificationType);
  const subsAttributeList = new SubscriptionAttributeList();
  subsAttributeList.add('sqsQueueUrl', AWS.mwsSubscriptionSqs);
  request.set('Destination', subsAttributeList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }
  return response;
};

export default CreateSubscription;
