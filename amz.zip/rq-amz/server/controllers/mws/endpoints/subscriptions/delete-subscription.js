import MWS from '@minmaxindustries/mws-sdk';

import invokeRequest from '../utils/invoke-request';
import { DestinationAttributeList } from './utils';
import { AWS } from '../../../../../config/settings';

const DeleteSubscription = async ({ sellerId, authToken, marketplaceId, notificationType }) => {
  const opts = {
    name: 'DeleteSubscription',
    group: 'Subscriptions',
    path: '/Subscriptions/2013-07-01',
    version: '2013-07-01',
    legacy: false,
    action: 'DeleteSubscription',
    params: {
      MarketplaceId: { name: 'MarketplaceId', required: true },
      Destination: { name: 'AttributeList', type: 'Complex', required: true, construct: DestinationAttributeList },
      DeliveryChannel: { name: 'Destination.DeliveryChannel', required: true },
      NotificationType: { name: 'NotificationType', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('MarketplaceId', marketplaceId);
  request.set('DeliveryChannel', 'SQS');
  request.set('NotificationType', notificationType);
  const subsAttributeList = new DestinationAttributeList();
  subsAttributeList.add('sqsQueueUrl', AWS.mwsSubscriptionSqs);
  request.set('Destination', subsAttributeList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }
  return response;
};

export default DeleteSubscription;
