import MWS from '@minmaxindustries/mws-sdk';

import invokeRequest from '../utils/invoke-request';
import { DestinationAttributeList } from './utils';
import { AWS } from '../../../../../config/settings';

const DeregisterDestination = async ({ sellerId, authToken, marketplaceId }) => {
  const opts = {
    name: 'DeregisterDestination',
    group: 'Subscriptions',
    path: '/Subscriptions/2013-07-01',
    version: '2013-07-01',
    legacy: false,
    action: 'DeregisterDestination',
    params: {
      MarketplaceId: { name: 'MarketplaceId', required: true },
      Destination: { name: 'AttributeList', type: 'Complex', required: true, construct: DestinationAttributeList },
      DeliveryChannel: { name: 'Destination.DeliveryChannel', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('MarketplaceId', marketplaceId);
  request.set('DeliveryChannel', 'SQS');
  const attributeList = new DestinationAttributeList();
  attributeList.add('sqsQueueUrl', AWS.mwsSubscriptionSqs);
  request.set('Destination', attributeList);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }
  return response;
};

export default DeregisterDestination;
