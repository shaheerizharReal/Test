import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';

const ListRegisteredDestinations = async ({ sellerId, authToken, marketplaceId }) => {
  const opts = {
    name: 'ListRegisteredDestinations',
    group: 'Subscriptions',
    path: '/Subscriptions/2013-07-01',
    version: '2013-07-01',
    legacy: false,
    action: 'ListRegisteredDestinations',
    params: {
      MarketplaceId: { name: 'MarketplaceId', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('MarketplaceId', marketplaceId);

  const response = await invokeRequest({ sellerId, authToken, request });

  if (response.error) {
    throw new Error(response.error.message);
  }

  return response;
};

export default ListRegisteredDestinations;
