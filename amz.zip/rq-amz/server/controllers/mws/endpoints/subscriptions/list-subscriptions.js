import MWS from '@minmaxindustries/mws-sdk';
import invokeRequest from '../utils/invoke-request';

const ListSubscriptions = async ({ sellerId, authToken, marketplaceId }) => {
  const opts = {
    name: 'ListSubscriptions',
    group: 'Subscriptions',
    path: '/Subscriptions/2013-07-01',
    version: '2013-07-01',
    legacy: false,
    action: 'ListSubscriptions',
    params: {
      MarketplaceId: { name: 'MarketplaceId', required: true }
    }
  };

  const request = new MWS.Request(opts);
  request.set('MarketplaceId', marketplaceId);

  const response = await invokeRequest({ sellerId, authToken, request });
  if (response.error) {
    throw new Error(response.error.message);
  }

  return response;
};

export default ListSubscriptions;
