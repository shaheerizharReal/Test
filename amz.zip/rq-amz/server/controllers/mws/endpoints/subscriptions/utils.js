import MWS from '@minmaxindustries/mws-sdk'

export const DestinationAttributeList = function() {
  let obj = new MWS.ComplexList('Destination.AttributeList.member');
  obj.add = function(key, value) {
    obj.members.push({
      'Key': key,
      'Value': value
    });
    return obj;
  };
  return obj;
};


export const SubscriptionAttributeList = function() {
  let obj = new MWS.ComplexList('Subscription.Destination.AttributeList.member');
  obj.add = function(key, value) {
    obj.members.push({
      'Key': key,
      'Value': value
    });
    return obj;
  };
  return obj;
};
