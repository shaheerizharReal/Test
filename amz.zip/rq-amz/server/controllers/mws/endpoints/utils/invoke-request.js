import MWS from '@minmaxindustries/mws-sdk';
import { isEmpty } from 'lodash';

import { parseXML } from './parse';
import Settings from '../../../../../config/settings';

const invokeRequest = async ({ sellerId, authToken, request }) => {
  const client = new MWS.Client(Settings.MWS.accessKeyId,
    Settings.MWS.secretKey, sellerId, { authToken });

  const responseXML = await client.invoke(request);

  const responseJSON = await parseXML(responseXML);

  if (isEmpty(responseJSON)) {
    throw new Error('empty response');
  }

  // console.log('responseJSON', JSON.stringify(responseJSON, null, 2));
  return responseJSON;
};

export default invokeRequest;
