import { isUndefined, isBoolean, isEmpty, has, isObject, isArray } from 'lodash';
import { MWS } from '../../../../../config/settings';

export const isLogsEnabled = (endpoint) => {
  const MWSLogsEnabled = MWS.logsEnabled;

  if (!isUndefined(MWSLogsEnabled) && !isEmpty(MWSLogsEnabled)) {
    if (isBoolean(MWSLogsEnabled) && MWSLogsEnabled) {
      return true;
    } else if (isObject(MWSLogsEnabled) && has(MWSLogsEnabled, endpoint)) {
      return MWSLogsEnabled[endpoint];
    }
  }
  return false;
};

export const printLogs = ({ endpoint, response, error, params }) => {

  if(isLogsEnabled(endpoint)) {
    console.log('\n\n\n\n\n');
    console.log('***************************************************************');
    console.log('*************************   MWS API   *************************');
    console.log('***************************************************************');

    console.log(`Endpoint:  ${endpoint}`);
    for (let key in params) {
      const value = params[key];
      if (value) {
        if (isArray(value) && value.length > 1) {
          console.log(`${key}: ${value.length} - [${value[0]}, ... ,${value[value.length - 1]}]`);
        } else if (isObject(value)) {
          console.log(`${key}: ${JSON.stringify(value)}`);
        } else {
          console.log(`${key}: ${value}`);
        }
      }
    }

    if (response) {
      console.log('***************************************************************');
      console.log('*********************   START RESPONSE   **********************');
      console.log('***************************************************************');

      if(isArray(response)) {
        console.log(`Response Length: ${response.length}`);
        console.log('*************************   TOP 2   ***************************');
        console.log(JSON.stringify(response.slice(0, 2), null, 2));
      } else {
        console.log(JSON.stringify(response, null, 2));
      }

      console.log('***************************************************************');
      console.log('**********************   END RESPONSE   ***********************');
      console.log('***************************************************************');
    }

    if (error) {
      console.log('***************************************************************');
      console.log('*********************   START ERROR   *************************');
      console.log('***************************************************************');

      console.log(JSON.stringify(error, null, 2));

      console.log('***************************************************************');
      console.log('**********************   END ERROR   **************************');
      console.log('***************************************************************');
    }

    console.log('***************************************************************');
    console.log('**********************   END MWS API   ************************');
    console.log('***************************************************************');
    console.log('\n\n\n\n\n');
  }
};
