import moment from 'moment';
import { isArray } from 'lodash';

export const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

export const toArray = (data) => {
  let array = [];
  if (data) {
    array = isArray(data) ? data : [data];
  }
  return array;
};

export const parseDate = (paramName, paramValue) => {
  if (!moment(paramValue).isValid()) throw new Error(`${paramName}: Invalid Date Format`);

  return moment(paramValue).toDate();
};

export const parseDateToISO = (paramName, paramValue) => {
  if (!moment(paramValue).isValid()) throw new Error(`${paramName}: Invalid Date Format`);

  return moment(paramValue).toISOString();
};
