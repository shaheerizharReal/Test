import MWS from '@minmaxindustries/mws-sdk';
import { extend, isArray } from 'lodash';
import moment from 'moment';

import * as MWSEndpoints from './endpoints';
import { printLogs } from './endpoints/utils/logs';
import { RETRYABLE_ERRORS } from '../../../config/constants';
import { ThrottlingException, MWSErrorException } from '../utils/custom-exceptions';

import Users from '../../models/users';

const MwsAPI = async ({ endpoint, params }) => {
  const { userId } = params;
  const user = await Users.findOne({ _id: userId });

  const { sellerId, authToken, marketplaceId } = ((user && user.mws) || {});

  if (params.authToken && params.sellerId) {
    extend(params, { userId });
  } else if (params.marketplaceId) {
    extend(params, { sellerId, authToken, userId });
  } else {
    extend(params, { sellerId, authToken, marketplaceId, userId });
  }

  try {
    const response = await MWSEndpoints[endpoint](params);
    printLogs({ endpoint, response, params });

    return response;
  } catch (e) {
    console.log('Error: ', e);

    for (let i = 0; i < RETRYABLE_ERRORS.length; i += 1) {
      const message = RETRYABLE_ERRORS[i];
      const errorMessage = (isArray(e.message) ? e.message[0] : e.message);
      if (errorMessage.includes(message)) {
        const nextAvailableAt = moment().add(60, 'seconds').toDate();

        throw new ThrottlingException({
          message: e.message,
          nextAvailableAt,
          endpoint,
          userId
        });
      }
    }

    throw new MWSErrorException({
      message: e.message,
      endpoint,
      userId
    });
  }
};


export default MwsAPI;
