import Grants from '../../models/grants';

const AddRolesGrants = async () => {
  await Grants.deleteMany();

  const allRoleAndGrants = [
    {
      role: 'Default',
      resource: 'Dashboard',
      action: 'read',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Inventory',
      action: 'read',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Payment',
      action: 'read',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'MWS',
      action: 'read',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Invite User',
      action: 'read',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Whats New',
      action: 'read',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Export Inventory',
      action: 'read',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Import Inventory',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Cost Price',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Decided Buy Quantity',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Ship by',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Purchase Link',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Suppliers',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Store Section',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Default',
      resource: 'Notes Section',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Can View Dashboard',
      resource: 'Dashboard',
      action: 'read',
      possession: 'any'
    },
    {
      role: 'Can Export Inventory',
      resource: 'Export Inventory',
      action: 'read',
      possession: 'any'
    },
    {
      role: 'Can Import Inventory',
      resource: 'Import Inventory',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Can Set Decided Buy Quantity',
      resource: 'Decided Buy Quantity',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Can Set Cost Price',
      resource: 'Cost Price',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Can Set Purchase Link',
      resource: 'Purchase Link',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Can Set Suppliers',
      resource: 'Suppliers',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Can Set Store Section',
      resource: 'Store Section',
      action: 'update',
      possession: 'any'
    },
    {
      role: 'Can Set Notes Section',
      resource: 'Notes Section',
      action: 'update',
      possession: 'any'
    }
  ];

  await Grants.insertMany(allRoleAndGrants);
};

export default AddRolesGrants;
