import Users from '../../models/users';
import Affiliates from '../../models/affiliates';
import CustomASINShortcuts from '../../models/custom-asin-shortcuts';
import Coupons from '../../models/coupons';
import EmailData from '../../models/email-data';
import ExportProducts from '../../models/export-products';
import Grants from '../../models/grants';
import LastUpdateTracker from '../../models/last-update-tracker';
import Orders from '../../models/orders';
import Products from '../../models/products';
import SalesData from '../../models/sales-data';
import SalesDailyHistory from '../../models/sales-daily-history';

// http://localhost:5200/api/v1/script?method=clearLocalDatabase
const ClearLocalDB = async () => {
  let users = await Users.find({
    email: {
      $in: [
        'karl.jacobi@jacobienterprises.com',
        'jdsbls0410@gmail.com',
        'travis@ictrealinvestments.com'
      ]
    }
  }).select({
    name: 1
  });
  console.log('\n\n', 'users', users.length, users);

  let userIds = users.map(u => u._id.toString());
  console.log('\n\n', 'userIds', userIds.length, userIds);

  await Affiliates.deleteMany({
  });

  await CustomASINShortcuts.deleteMany({
    userId: { $nin: userIds }
  });

  await Coupons.deleteMany({
  });

  await EmailData.deleteMany({
  });

  await ExportProducts.deleteMany({
  });

  await Grants.deleteMany({
    $and: [
      { userId: { $exists: true } },
      { userId: { $nin: userIds } }
    ]
  });

  await LastUpdateTracker.deleteMany({
    userId: { $nin: userIds }
  });

  await Orders.deleteMany({
    userId: { $nin: userIds }
  });

  await Products.deleteMany({
    userId: { $nin: userIds }
  });

  await SalesData.deleteMany({
    userId: { $nin: userIds }
  });

  await SalesDailyHistory.deleteMany({
    userId: { $nin: userIds }
  });

  users = await Users.find({
    email: {
      $in: [
        'karl.jacobi@jacobienterprises.com',
        'jdsbls0410@gmail.com',
        'travis@ictrealinvestments.com',
        'support@replendashboard.com',
        'admin@replen.com'
      ]
    }
  }).select({
    name: 1
  });
  console.log('\n\n', 'users', users.length, users);

  userIds = users.map(u => u._id.toString());
  console.log('\n\n', 'userIds', userIds.length, userIds);

  await Users.deleteMany({
    _id: { $nin: userIds }
  });

  console.log('\n\n', 'end');
};

export default ClearLocalDB;
