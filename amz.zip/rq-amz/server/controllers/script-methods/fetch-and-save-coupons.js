import { ListCoupons } from '../stripe';
import Coupons from '../../models/coupons';

const FetchAndSaveCoupons = async () => {
  const couponsObj = await ListCoupons();
  if (couponsObj && couponsObj.data && couponsObj.data.length > 0) {
    const coupons = couponsObj.data;
    const writeData = coupons.map((coupon) => {
      const {
        id: _id,
        name,
        duration,
        percent_off: couponOffPercent
      } = coupon;

      return {
        updateOne: {
          filter: {
            _id
          },
          update: {
            $set: {
              name,
              duration,
              couponOffPercent
            }
          },
          upsert: true
        }
      };
    });

    console.log('\n\n', 'save', writeData.length, 'coupons');
    if (writeData.length > 0) {
      await Coupons.bulkWrite(writeData);
    }
  }
};

export default FetchAndSaveCoupons;
