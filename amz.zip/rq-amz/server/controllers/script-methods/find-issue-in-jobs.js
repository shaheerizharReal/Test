import Users from '../../models/users';
import AgendaJobs from '../../models/agenda-jobs';

const FindIssueInJobs = async () => {
  const userIds = await AgendaJobs.distinct('data.userId', {
    name: {
      $in: [
        'inventory:listing',
        'inventory:quantity',
        'inventory:images',
        'pricing-data-api',
        'inventory:fees',
        'orders',
        'inventory:snl',
        'summary.by.orders'
      ]
    }
  });

  console.log('\n\n', '$$$$$ userIds', userIds.length);
  console.log('\n\n');

  for (let i = 0; i < userIds.length; i += 1) {
    const jobs = await AgendaJobs.find({
      'data.userId': userIds[i]
    });
    if (jobs.length < 8) {
      const user = await Users.findOne({
        _id: userIds[i]
      });
      console.log('\n\n', '$$$$$', userIds[i], '$$$$$', jobs.length, '$$$$$', user.name, '$$$$$');
    }
  }

  console.log('\n\n', '$$$$$ end');
};

export default FindIssueInJobs;
