import FetchAndSaveCoupons from './fetch-and-save-coupons';

const ScriptMethods = (method) => {
  console.log('\n\n', 'method', method);

  switch (method) {
    // case 'addRolesGrants': {
    //   AddRolesGrants();
    //   break;
    // }

    // case 'clearLocalDatabase': {
    //   ClearLocalDB();
    //   break;
    // }

    case 'fetchAndSaveCoupons': {
      FetchAndSaveCoupons();
      break;
    }

    // case 'findIssueInJobs': {
    //   FindIssueInJobs();
    //   break;
    // }

    // case 'setDefaultRole': {
    //   SetDefaultRole();
    //   break;
    // }

    // case 'startJobs': {
    //   StartJobs();
    //   break;
    // }

    default: {
      break;
    }
  }
};

export default ScriptMethods;
