import Users from '../../models/users';

const SetDefaultRole = async () => {
  const users = await Users.find({
    admin: { $exists: false },
    status: { $ne: 'Child User' }
  });
  console.log({ users });
  for (let i = 0; i < users.length; i += 1) {
    await Users.updateOne({ _id: users[i]._id }, {
      $set: {
        permission: [{
          role: ['Default'],
          parentId: null
        }]
      }
    });
  }
};

export default SetDefaultRole;
