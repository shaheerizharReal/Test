import Users from '../../models/users';

import RunSignUpJobs from '../agenda/start-jobs';

// http://localhost:5200/api/v1/script?method=startJobs
// https://app.replendashboard.com/api/v1/script?method=startJobs
const StartJobs = async () => {
  const users = await Users.find({
    email: {
      $in: ['carl_77@yahoo.com']
    }
  });
  for (let i = 0; i < users.length; i += 1) {
    await RunSignUpJobs(users[i]._id);
  }
};

export default StartJobs;
