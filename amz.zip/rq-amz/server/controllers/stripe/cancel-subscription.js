import stripe from '../../config/stripe';

const CancelSubscription = ({ subscriptionId }) => stripe.subscriptions.del(subscriptionId);

export default CancelSubscription;
