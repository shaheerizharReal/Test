import stripe from '../../config/stripe';

const CreateCoupon = (name, amountOff, duration) => stripe.coupons.create({
  id: name,
  name,
  percent_off: amountOff,
  duration
});

export default CreateCoupon;
