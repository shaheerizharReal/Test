import stripe from '../../config/stripe';

const CreateCustomer = ({ name, email, metaData }) => stripe.customers.create({
  description: name,
  email,
  metadata: metaData
});

export default CreateCustomer;
