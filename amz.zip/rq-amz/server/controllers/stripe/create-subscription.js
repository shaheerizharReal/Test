import { extend } from 'lodash';

import stripe from '../../config/stripe';

const CreateSubscription = ({
  planId,
  customerId,
  coupon,
  quantity,
  lmref
}) => {
  const subscriptionOptions = {
    customer: customerId,
    items: [{
      plan: planId,
      quantity
    }]
  };

  if (coupon) extend(subscriptionOptions, { coupon });

  if (lmref) {
    extend(subscriptionOptions, {
      metadata: {
        lm_data: lmref // received from front end
      }
    });
  }
  return stripe.subscriptions.create({
    ...subscriptionOptions
  });
};

export default CreateSubscription;
