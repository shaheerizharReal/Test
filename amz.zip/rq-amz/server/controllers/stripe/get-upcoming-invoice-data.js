import stripe from '../../config/stripe';

const RetreiveUpcomingInvoiceData = ({ customer }) => stripe.invoices.retrieveUpcoming({
  customer
});

export default RetreiveUpcomingInvoiceData;
