import stripe from '../../config/stripe';

const ListCoupons = () => stripe.coupons.list();

export default ListCoupons;
