import stripe from '../../config/stripe';

const ListPlans = () => stripe.plans.list();

export default ListPlans;
