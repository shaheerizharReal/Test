import stripe from '../../config/stripe';

const RetrieveSubscription = ({ subscriptionId }) => stripe.subscriptions.retrieve(subscriptionId);

export default RetrieveSubscription;
