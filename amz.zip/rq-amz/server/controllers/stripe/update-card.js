import stripe from '../../config/stripe';

const UpdateCard = (customerId, { token }) => {
  return stripe.customers.update(customerId, { source: token });
};

export default UpdateCard;
