import { extend } from 'lodash';
import stripe from '../../config/stripe';

const UpdateCustomer = (customerId, { token, coupon }) => {
  const customerOptions = {};

  if (token) extend(customerOptions, { source: token });
  if (coupon) extend(customerOptions, { coupon });


  console.log('Update Customer Options: ', customerOptions)

  return stripe.customers.update(customerId, {
    ...customerOptions
  });
};

export default UpdateCustomer;
