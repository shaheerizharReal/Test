import { extend } from 'lodash';

import stripe from '../../config/stripe';

const UpdateSubscription = ({
  subscriptionId,
  itemId,
  planId,
  quantity,
  lmref
}) => {
  const subscriptionOptions = {
    items: [{
      id: itemId,
      plan: planId,
      quantity
    }],
    prorate: true
  };

  if (lmref) {
    extend(subscriptionOptions, {
      metadata: {
        lm_data: lmref // received from front end
      }
    });
  }

  return stripe.subscriptions.update(subscriptionId, {
    ...subscriptionOptions
  });
};

export default UpdateSubscription;
