import {
  CancelSubscription
} from '../stripe';
import Users from '../../models/users';

const CancelStripeSubscription = async ({ userId, subscriptionId }) => {
  const { current_period_end } = await CancelSubscription({
    subscriptionId
  });

  await Users.updateOne({
    _id: userId
  }, {
    $set: {
      'payment.subscriptionEndDate': current_period_end
    },
    $unset: {
      'payment.subscriptionId': '',
      'payment.subscribedAt': '',
      'payment.nextInvoicedChargedAt': '',
      'payment.planID': '',
      'payment.planName': '',
      'payment.planAmount': '',
      'payment.tierNo': ''
    }
  });
};

export default CancelStripeSubscription;
