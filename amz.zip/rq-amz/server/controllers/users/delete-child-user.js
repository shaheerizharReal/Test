import Users from '../../models/users';

const DeleteChildUser = async ({ _id }) => {
  await Users.deleteOne({ _id });
};

export default DeleteChildUser;
