import mongoose from 'mongoose';

import Users from '../../models/users';
import AgendaJobs from '../../models/agenda-jobs';
import ExportProducts from '../../models/export-products';
import LastUpdateTracker from '../../models/last-update-tracker';
import Orders from '../../models/orders';
import Products from '../../models/products';
import SalesData from '../../models/sales-data';

const { ObjectId } = mongoose.Types;

const deleteUser = async ({ userId, status }) => {
  if (status !== 'Child User') {
    await AgendaJobs.deleteMany({ 'data.userId': ObjectId(userId) });
    await ExportProducts.deleteMany({ userId });
    await LastUpdateTracker.deleteMany({ userId });
    await Orders.deleteMany({ userId });
    await Products.deleteMany({ userId });
    await SalesData.deleteMany({ userId });
  }

  await Users.deleteOne({ _id: userId });
};

export default deleteUser;
