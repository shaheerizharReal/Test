import Grants from '../../models/grants';

const FetchAttributesToUpdateRole = async ({ userId, roleToFetchAttribute: role }) => {
  const [grant] = await Grants.find({ role, userId });
  const attributes = grant.attributes.split(',');
  return attributes;
};

export default FetchAttributesToUpdateRole;
