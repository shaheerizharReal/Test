import crypto from 'crypto';

import Users from '../../models/users';
import { sendMail } from '../utils';

require('dotenv').config();

const sendResetPasswordMail = async ({ toEmail, resetToken, user }) => {
  // TODO: change this to actula server or keep a constant
  const serverUrl = ((process.env.NODE_ENV === 'development') ? 'http://localhost:5200' : 'http://app.replendashboard.com');
  let subject = 'Link To Reset Password';
  let body = `<div>
    <p>
      You are receiving this because you (or someone else) have requested the reset of the password for your account.
    </p>
    <p>
      Click <a href="${serverUrl}/auth/reset/${resetToken}">here</a> to reset your password
    </p>
    <p>
      If you did not request this, please ignore this email and your password will remain unchanged.
    </p>
  </div>`;

  if (!user.password) {
    const parentUser = await Users.findOne({ _id: user.permission[0].parentId });

    subject = 'Please Set Your Password';
    body = `<div>
      <p>
        You are receiving this because you have been Invited by ${(parentUser) ? parentUser.name : ' a User'}.
      </p>
      <p>
        Click <a href="${serverUrl}/auth/reset/${resetToken}">here</a> to set your password.
      </p>
    </div>`;
  }

  await sendMail({
    toEmail,
    subject,
    body
  });
};

const ForgotPassword = async ({ email }) => {
  const user = await Users.findOne({ email });
  let expireTime = 360000;

  if (!user) {
    throw new Error('Email not found !');
  }
  if (!user.password) {
    expireTime = 260000000;
  }
  const token = crypto.randomBytes(20).toString('hex');

  await sendResetPasswordMail({
    toEmail: user.email,
    resetToken: token,
    user
  });

  await Users.updateOne({ _id: user._id }, {
    resetPasswordToken: token,
    resetPasswordExpires: (Date.now() + expireTime)
  });

  return Users.findOne({ email });
};

export default ForgotPassword;
