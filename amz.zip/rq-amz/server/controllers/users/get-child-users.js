import Users from '../../models/users';

const GetChildUsers = async ({ userId }) => {
  const child = await Users.aggregate([
    {
      $match: {
        admin: { $exists: false },
        status: 'Child User',
        'permission.parentId': userId.toString()
      }
    }
  ]);

  return child;
};

export default GetChildUsers;
