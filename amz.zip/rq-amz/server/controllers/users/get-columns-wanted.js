import Users from '../../models/users';

const GetColumnsWanted = async ({ userId }) => {
  const user = await Users.findOne({ _id: userId });

  return ((user && user.columnsWanted) || []);
};

export default GetColumnsWanted;
