import Users from '../../models/users';

const GetDefaultCalculationPrice = async ({ userId }) => {
  let user = await Users.findOne({
    _id: userId
  }).select({
    profitCalculatedBy: 1
  });
  if (!(user.profitCalculatedBy)) {
    user.profitCalculatedBy = 'listPrice';
  }
  return user;
};

export default GetDefaultCalculationPrice;
