import Users from '../../models/users';

const GetDefaultShippingRate = async ({ userId }) => {
  const shippingData = await Users.findOne({
    _id: userId
  }).select({
    fbaInboundShippingCost: 1
  });
  return { shippingData };
};

export default GetDefaultShippingRate;
