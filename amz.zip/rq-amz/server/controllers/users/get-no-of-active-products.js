import Users from '../../models/users';
import Products from '../../models/products';

const GetNoOfActiveProducts = async ({ _id }) => {
  const noOfActiveProducts = await Products.find({ userId: _id, status: 'Active' }).countDocuments();

  await Users.updateOne({ _id }, {
    $set: {
      noOfActiveProducts
    }
  });
  return noOfActiveProducts;
};

export default GetNoOfActiveProducts;
