import Users from '../../models/users';

const GetParentUserStatus = async ({ parentId }) => {  
  const user = await Users.findOne({ _id: parentId }).select({ status: 1 });
  return user.status;
};

export default GetParentUserStatus;
