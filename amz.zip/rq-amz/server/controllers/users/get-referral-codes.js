import Users from '../../models/users';

const GetReferralCodes = async () => {
  const referralCodes = await Users.distinct('referralCode', {
    $and: [{
      referralCode: { $exists: true }
    }, {
      referralCode: { $ne: '' }
    }]
  });
  referralCodes.push('N/A');
  return referralCodes;
};
export default GetReferralCodes;
