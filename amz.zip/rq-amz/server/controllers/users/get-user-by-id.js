import Users from '../../models/users';

const GetUserById = async ({ userId }) => {
  const user = await Users.findOne({ _id: userId });
  const [aggregatedUser] = await Users.aggregate([
    { $match: { email: user.email } },
    {
      $unwind: {
        path: '$permission',
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $lookup: {
        from: 'grants',
        localField: 'permission.role',
        foreignField: 'role',
        as: 'roles'
      }
    },
    {
      $project: {
        columnsWanted: 1,
        email: 1,
        name: 1,
        admin: 1,
        status: 1,
        password: 1,
        payment: 1,
        referralCode: 1,
        noOfActiveProducts: 1,
        mws: 1,
        permission: 1,
        roles: {
          $filter: {
            input: '$roles',
            as: 'rol',
            cond: {
              $or: [
                { $not: ['$$rol.userId'] },
                {
                  $and: [
                    { $eq: ['$$rol.userId', '$permission.parentId'] },
                    { $in: ['$$rol.role', '$permission.role'] }
                  ]
                }
              ]
            }
          }
        },
        fbaInboundShippingCost: 1
      }
    }
  ]);

  return aggregatedUser;
};

export default GetUserById;
