import Users from '../../models/users';

const GetUserMwsCredentials = async ({ userId }) => {
  const user = await Users.findOne({ _id: userId });

  return ((user && user.mws) || {});
};

export default GetUserMwsCredentials;
