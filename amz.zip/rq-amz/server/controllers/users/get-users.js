import { extend } from 'lodash';
import User from '../../models/users';

const getAllUsers = async ({
  skip,
  limit,
  filters,
  sort
}) => {
  const selector = { admin: { $ne: true } };
  Object.keys(filters).forEach((key) => {
    const filter = filters[key];
    switch (key) {
      case 'keyword':
        extend(selector, {
          $or: [
            { name: { $regex: `.*${filter.value}.*`, $options: 'i' } },
            { email: { $regex: `.*${filter.value}.*`, $options: 'i' } }
          ]
        });
        break;

      case 'status':
        extend(selector, { status: { $in: filter.values } });
        break;

      case 'referralCode': {
        if (filter.values.length > 0) {
          let notAttached = false;
          if (filter.values.includes('N/A')) {
            notAttached = true;
          }

          const referralCodes = filter.values.filter(ref => ref !== 'N/A');
          if (referralCodes.length > 0 && notAttached) {
            extend(selector, {
              $or: [
                { referralCode: { $exists: false } },
                { referralCode: { $eq: '' } },
                { referralCode: { $in: referralCodes } }
              ]
            });
          } else if (referralCodes.length > 0) {
            extend(selector, { referralCode: { $in: referralCodes } });
          } else {
            extend(selector, {
              $or: [
                { referralCode: { $exists: false } },
                { referralCode: { $eq: '' } }
              ]
            });
          }
        } else {
          extend(selector, { referralCode: { $in: filter.values } });
        }
        break;
      }

      case 'mwsSynced': {
        if (filter.values.length > 0 && filter.values.length === 1) {
          if (filter.values[0] === 'Yes') {
            extend(selector, { mws: { $exists: true } });
          } else if (filter.values[0] === 'No') {
            extend(selector, { mws: { $exists: false } });
          }
        }
        break;
      }

      default:
        break;
    }
  });
  const total = await User.find(selector).countDocuments();
  let users = [];
  if (limit) {
    users = await User
      .find(selector)
      .sort(sort)
      .skip(skip)
      .limit(limit);
  } else {
    users = await User
      .find(selector);
  }

  users = users.map(({
    _id,
    name,
    email,
    status,
    referralCode,
    payment,
    signedUp,
    mws,
    noOfActiveProducts
  }) => ({
    _id,
    name,
    email,
    status,
    referralCode: referralCode || 'N/A',
    payment,
    signedUp,
    mwsSynced: mws ? 'Yes' : 'No',
    noOfActiveProducts
  }));
  return { users, total };
};

export default getAllUsers;
