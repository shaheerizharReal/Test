import { GetCoupon } from '../stripe';

const IsValidCoupon = async ({ couponId }) => {
  try {
    const coupon = await GetCoupon(couponId);

    if (coupon && coupon.valid) {
      return coupon;
    }

    throw new Error('Invalid Coupon');
  } catch (e) {
    throw new Error('Invalid Coupon');
  }
};

export default IsValidCoupon;
