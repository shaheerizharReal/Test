import moment from 'moment';
import {
  find,
  round,
  isEmpty,
  sample
} from 'lodash';

import Users from '../../models/users';
import Products from '../../models/products';
import SalesData from '../../models/sales-data';
import SalesDailyHistory from '../../models/sales-daily-history';

import { FULLFILMENT_TYPE } from '../../../config/constants';

const CalculateSalesHistory = async ({
  userId,
  name,
  startDate,
  endDate,
  randomValue
}) => {
  // Get SellerSku List
  const sellerSkuList = await SalesDailyHistory.distinct('sellerSku', {
    userId,
    timestamp: { $gte: new Date(startDate), $lte: new Date(endDate) }
  });

  const products = await Products.find({
    userId,
    sellerSku: { $in: sellerSkuList }
  }).select({
    sellerSku: 1,
    costPrice: 1,
    shipBy: 1,
    shippingRate: 1,
    packageDimensions: 1,
    fee: 1,
    fulfilmentType: 1,
    sellableQuantity: 1,
    afnInboundShippedQuantity: 1,
    afnReservedQuantity: 1,
    openDate: 1
  });

  // Get Sales Data
  const salesDataArr = await SalesDailyHistory.aggregate([
    {
      $match: {
        userId: userId.toString(),
        timestamp: { $gte: new Date(startDate), $lte: new Date(endDate) }
      }
    },
    {
      $group: {
        _id: '$sellerSku',
        sellerSku: { $first: '$sellerSku' },
        orders: { $sum: '$orders' },
        pendingOrders: { $sum: '$pendingOrders' },
        unitsSold: { $sum: '$unitsSold' },
        saleAmount: { $sum: '$saleAmount' },
        promotionDiscount: { $sum: '$promotionDiscount' }
      }
    }
  ]);

  const productSalesDataArr = [];

  // Make Data To Be Inserted In Collection
  let totalOrders = 0;
  let totalUnitsSold = 0;
  let totalSaleAmount = 0.0;
  let totalPromotionDiscount = 0.0;
  let totalUnitsInStock = 0;
  let totalFees = 0;
  let totalGrossProfit = 0.0;
  let totalNetProfit = 0.0;
  let totalProfitPercentage = 0.0;
  let totalRoiPercentage = 0.0;
  for (let i = 0; i < salesDataArr.length; i += 1) {
    const sale = salesDataArr[i];

    const {
      sellerSku,
      orders,
      unitsSold,
      saleAmount,
      promotionDiscount
    } = sale;
    let { pendingOrders } = sale;
    const product = find(products, { sellerSku });
    const { openDate } = product || {};
    const productsAge = moment().diff(moment(new Date(openDate)), 'days');

    if (!isEmpty(product)) {
      if (name === '30 Days') {
        let unitsPer30Days = 0;
        let suggestedBuyQuantity30Days = 0;
        unitsPer30Days = round(unitsSold / 30);
        if (unitsSold > 0 && product) {
          if (product.fulfilmentType === FULLFILMENT_TYPE.AMAZON) {
            const {
              sellableQuantity,
              afnInboundShippedQuantity,
              afnReservedQuantity
            } = product;

            if (pendingOrders > afnReservedQuantity) {
              if (randomValue % 2 !== 0) {
                pendingOrders = afnReservedQuantity;
              } else if (afnReservedQuantity >= 0) {
                pendingOrders = afnReservedQuantity - 1;
              }
            }
            if (productsAge <= 30) {
              suggestedBuyQuantity30Days = (30 * unitsPer30Days) - (
                (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                  (afnReservedQuantity || 0) - pendingOrders
                )
              );
            } else {
              suggestedBuyQuantity30Days = unitsSold + pendingOrders - (
                (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                  (afnReservedQuantity || 0) - pendingOrders
                )
              );
            }
          }

          if (suggestedBuyQuantity30Days < 0) {
            suggestedBuyQuantity30Days = 0;
          }
        }
        productSalesDataArr.push({
          updateOne: {
            filter: {
              userId,
              sellerSku
            },
            update: {
              $set: {
                suggestedBuyQuantity30Days,
                unitsPer30Days,
                salesLast30Days: unitsSold,
                salesAmountLast30Days: round(saleAmount, 2),
                totalOrdersLast30Days: orders,
                totalPendingOrdersLast30Days: pendingOrders,
                updatedAt: new Date()
              }
            }
          }
        });
      } else if (name === '60 Days') {
        let unitsPer60Days = 0;
        let suggestedBuyQuantity60Days = 0;

        unitsPer60Days = round(unitsSold / 60);
        if (unitsSold > 0 && product) {
          if (product.fulfilmentType === FULLFILMENT_TYPE.AMAZON) {
            const {
              sellableQuantity,
              afnInboundShippedQuantity,
              afnReservedQuantity
            } = product;

            if (pendingOrders > afnReservedQuantity) {
              if (randomValue % 2 !== 0) {
                pendingOrders = afnReservedQuantity;
              } else if (afnReservedQuantity >= 0) {
                pendingOrders = afnReservedQuantity - 1;
              }
            }
            if (productsAge <= 30) {
              suggestedBuyQuantity60Days = (30 * unitsPer60Days) - (
                (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                  (afnReservedQuantity || 0) - pendingOrders
                )
              );
            } else {
              suggestedBuyQuantity60Days = unitsSold + pendingOrders - (
                (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                  (afnReservedQuantity || 0) - pendingOrders
                )
              );
            }
          }

          if (suggestedBuyQuantity60Days < 0) {
            suggestedBuyQuantity60Days = 0;
          }
        }
        productSalesDataArr.push({
          updateOne: {
            filter: {
              userId,
              sellerSku
            },
            update: {
              $set: {
                suggestedBuyQuantity60Days,
                unitsPer60Days,
                salesLast60Days: unitsSold,
                salesAmountLast60Days: round(saleAmount, 2),
                totalOrdersLast60Days: orders,
                totalPendingOrdersLast60Days: pendingOrders,
                updatedAt: new Date()
              }
            }
          }
        });
      } else if (name === '90 Days') {
        let unitsPer90Days = 0;
        let suggestedBuyQuantity90Days = 0;

        unitsPer90Days = round(unitsSold / 90);
        if (unitsSold > 0 && product) {
          if (product.fulfilmentType === FULLFILMENT_TYPE.AMAZON) {
            const {
              sellableQuantity,
              afnInboundShippedQuantity,
              afnReservedQuantity
            } = product;

            if (pendingOrders > afnReservedQuantity) {

              if (randomValue % 2 !== 0) {
                pendingOrders = afnReservedQuantity;
              } else if (afnReservedQuantity >= 0) {
                pendingOrders = afnReservedQuantity - 1;
              }
            }
            if (productsAge <= 30) {
              suggestedBuyQuantity90Days = (30 * unitsPer90Days) - (
                (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                  (afnReservedQuantity || 0) - pendingOrders
                )
              );
            } else {
              suggestedBuyQuantity90Days = unitsSold + pendingOrders - (
                (sellableQuantity || 0) + (afnInboundShippedQuantity || 0) + (
                  (afnReservedQuantity || 0) - pendingOrders
                )
              );
            }
          }

          if (suggestedBuyQuantity90Days < 0) {
            suggestedBuyQuantity90Days = 0;
          }
        }

        productSalesDataArr.push({
          updateOne: {
            filter: {
              userId,
              sellerSku
            },
            update: {
              $set: {
                suggestedBuyQuantity90Days,
                unitsPer90Days,
                salesLast90Days: unitsSold,
                salesAmountLast90Days: round(saleAmount, 2),
                totalOrdersLast90Days: orders,
                totalPendingOrdersLast90Days: pendingOrders,
                updatedAt: new Date()
              }
            }
          }
        });
      }
    }

    let unitsInStock = 0;
    let costPrice = 0.0;
    let fees = 0.0;
    if (product) {
      if (product.costPrice) {
        ({ costPrice } = product);
        costPrice *= unitsSold;
      }

      const {
        fee,
        fulfilmentType,
        sellableQuantity
      } = product;
      if (fee) {
        if (fee.feePercentage) {
          fees += round(saleAmount * (fee.feePercentage / 100), 2);
        }

        if (fee.otherFees) {
          fees += round((fee.otherFees * unitsSold), 2);
        }
      }

      if (fulfilmentType === FULLFILMENT_TYPE.AMAZON) {
        if (sellableQuantity) {
          unitsInStock = sellableQuantity;
        }

        if (fee) {
          if ([9, 10, 11].includes(moment().month()) && fee.monthlyStorageFeeOct) {
            fees += round((fee.monthlyStorageFeeOct * unitsSold), 2);
          } else if (fee.monthlyStorageFeeJan) {
            fees += round((fee.monthlyStorageFeeJan * unitsSold), 2);
          }
        }
      }
    }
    const {
      shipBy,
      shippingRate,
      packageDimensions
    } = product;
    const weight = (!isEmpty(packageDimensions) && (packageDimensions.weight))
      ? packageDimensions.weight : 0;

    let shippingCost = 0.0;
    shippingCost = (shipBy === 'byItem' ? shippingRate : (shipBy === 'byWeight' && (shippingRate * weight)));
    const grossProfit = (
      saleAmount - costPrice - shippingCost
    );

    const netProfit = (
      (saleAmount - fees) - costPrice - shippingCost
    );

    const profit = round(netProfit, 2);
    const profitPercentage = saleAmount > 0 ? round(((profit / saleAmount) * 100), 2) : 0;
    const roiPercentage = costPrice > 0 ? round(((profit / costPrice) * 100), 2) : 0;
    totalOrders += orders;
    totalUnitsSold += unitsSold;
    totalSaleAmount += saleAmount;
    totalPromotionDiscount += promotionDiscount;
    totalUnitsInStock += unitsInStock;
    totalFees += fees;
    totalGrossProfit += grossProfit;
    totalNetProfit += netProfit;
    totalProfitPercentage += profitPercentage;
    totalRoiPercentage += roiPercentage;
  }

  if (salesDataArr.length > 0) {
    totalProfitPercentage = round((totalProfitPercentage / salesDataArr.length), 2);
    totalRoiPercentage = round((totalRoiPercentage / salesDataArr.length), 2);
  }

  if (productSalesDataArr.length > 0) {
    await Products.bulkWrite(productSalesDataArr);
  }
  return {
    totalOrders,
    totalUnitsSold,
    totalSaleAmount: round(totalSaleAmount, 2),
    totalPromotionDiscount: round(totalPromotionDiscount, 2),
    totalUnitsInStock,
    totalFees: round(totalFees, 2),
    totalGrossProfit: round(totalGrossProfit, 2),
    totalNetProfit: round(totalNetProfit, 2),
    totalProfitPercentage: round(totalProfitPercentage, 2),
    totalRoiPercentage: round(totalRoiPercentage, 2)
  };
};

const SetupDemoAccount = async () => {
  const demoUser = await Users.findOne({
    email: 'support@replendashboard.com'
  });

  console.log('\n\n', 'demoUser', demoUser);
  if (demoUser) {
    const { _id: demoUserId } = demoUser;
    console.log('\n\n', 'demoUserId', demoUserId);

    await Users.updateOne({
      _id: demoUserId
    }, {
      $unset: {
        fbaInboundShippingCost: 1
      }
    });
    console.log('\n\n', 'FBA Inbound Shipping Cost reseted for demo user');

    const resultOfProducts = await Products.deleteMany({
      userId: demoUserId
    });
    console.log('\n\n', 'Delete Products', resultOfProducts);

    const productsList = [];
    const productsDataForSalesDailyHistory = [];
    for (let i = 0; i < 100; i += 1) {
      const sellerSku = `My SKU ${i + 1}`;
      const salesRankList = [59977, 140602, 450702, 353416, 232659, 281690, 613818, 11701, 1181131];

      const afnInboundShippedQuantity = Math.floor(Math.random() * 10);
      const afnReservedQuantity = Math.floor(Math.random() * 10);
      const sellableQuantity = Math.floor(Math.random() * 10);
      const afnUnsellableQuantity = Math.floor(Math.random() * 10);
      const afnTotalQuantity = afnInboundShippedQuantity + afnReservedQuantity
        + sellableQuantity + afnUnsellableQuantity;

      const openDate = moment().subtract(i, 'days').toDate();

      const listPrice = Math.floor(Math.random() * 10);
      const monthlyStorageFeesList = [
        0.01,
        0.03,
        0.05,
        0.06,
        0.07,
        0.09,
        0.1,
        0.15,
        0.17,
        0.25,
        0.4,
        0.6,
        0.7,
        0.8,
        0.9,
        1.0
      ];
      const fee = {
        feePercentage: ((15 / 100) * listPrice),
        otherFees: sample([1, 2]),
        monthlyStorageFeeOct: sample(monthlyStorageFeesList),
        monthlyStorageFeeJan: sample(monthlyStorageFeesList)
      };
      productsDataForSalesDailyHistory.push({
        sellerSku,
        openDate,
        listPrice
      });

      let fees = 0;
      if (fee) {
        if (fee.feePercentage) {
          fees += round(listPrice * (fee.feePercentage / 100), 2);
        }

        if (fee.otherFees) {
          fees += round((fee.otherFees), 2);
        }
      }

      if (fee) {
        if ([9, 10, 11].includes(moment().month()) && fee.monthlyStorageFeeOct) {
          fees += round((fee.monthlyStorageFeeOct), 2);
        } else if (fee.monthlyStorageFeeJan) {
          fees += round((fee.monthlyStorageFeeJan), 2);
        }
      }

      const netProfit = (
        (listPrice - fees)
      );

      const profit = round(netProfit, 2);
      const profitPercentage = listPrice > 0 ? round(((profit / listPrice) * 100), 2) : 0;
      const roiPercentage = 0;

      productsList.push({
        updateOne: {
          filter: {
            userId: demoUserId,
            sellerSku
          },
          update: {
            $set: {
              title: `My Product Title ${i + 1}`,
              sellerSku: `My SKU ${i + 1}`,
              asin: `B0${Math.floor(Math.random() * 10)}XXXXXXX`,
              imageUrl: '41tRIT4oUvL.jpg',
              fnsku: `My FNSKU ${i + 1}`,
              fulfilmentType: 'AFN',
              condition: '11',
              status: 'Active',
              afnInboundShippedQuantity,
              afnReservedQuantity,
              sellableQuantity,
              afnUnsellableQuantity,
              afnTotalQuantity,
              listPrice,
              profit,
              profitPercentage,
              roiPercentage,
              buyBoxPrice: Math.floor(Math.random() * 10),
              lowestOfferPrice: Math.floor(Math.random() * 10),
              lowestFBAOfferPrice: Math.floor(Math.random() * 10),
              noOfSellers: Math.floor(Math.random() * 10),
              supplier: null,
              fee,
              salesRank: sample(salesRankList),
              productGroup: 'Fashion',
              purchaseLink: null,
              storeSection: null,
              notesSection: null,
              enrolledInSnL: sample([true, false]),
              isReplen: false,
              openDate
            },
            $setOnInsert: {
              createdAt: new Date()
            }
          },
          upsert: true
        }
      });
    }

    if (productsList.length) {
      await Products.bulkWrite(productsList);
    }

    const resultOfSalesDailyHistoryData = await SalesDailyHistory.deleteMany({
      userId: demoUserId
    });
    console.log('\n\n', 'Delete Sales Daily History Data', resultOfSalesDailyHistoryData);

    const resultOfSalesData = await SalesData.deleteMany({
      userId: demoUserId
    });
    console.log('\n\n', 'Delete Sales Data', resultOfSalesData);

    const salesDailyData = [];
    for (let i = 0; i < productsDataForSalesDailyHistory.length; i += 1) {
      let { openDate } = productsDataForSalesDailyHistory[i];
      const { listPrice } = productsDataForSalesDailyHistory[i];
      const { sellerSku } = productsDataForSalesDailyHistory[i];
      
      for (; openDate <= moment().toDate(); openDate = moment(openDate).add(1, 'days').toDate()) {
        const orders = Math.floor(Math.random() * 16) + 5;
        const unitsSold = sample([orders, orders + 1, orders + 2]);

        salesDailyData.push({
          updateOne: {
            filter: {
              userId: demoUserId,
              timestamp: openDate,
              sellerSku
            },
            update: {
              $setOnInsert: {
                createdAt: new Date()
              },
              $set: {
                orders,
                pendingOrders: orders % 2 === 0 ? 0 : 1,
                unitsSold,
                saleAmount: round(listPrice * unitsSold, 2),
                promos: sample([0, 1, 2]),
                updatedAt: new Date()
              }
            },
            upsert: true
          }
        });
      }
    }

    if (salesDailyData.length > 0) {
      await SalesDailyHistory.bulkWrite(salesDailyData);
    }

    const durations = [
      { period: 0, unit: 'today', name: 'Today' },
      { period: 0, unit: 'yesterday', name: 'Yesterday' },
      { period: 15, unit: 'days', name: '15 Days' },
      { period: 30, unit: 'days', name: '30 Days' },
      { period: 60, unit: 'days', name: '60 Days' },
      { period: 90, unit: 'days', name: '90 Days' }
    ];

    const randomValue = Math.floor(Math.random() * 10);
    const salesDataArr = [];
    for (let i = 0; i < durations.length; i += 1) {
      const { period, unit, name } = durations[i];

      let startDate = null;
      let endDate = moment.tz('America/Los_Angeles')
        .utc()
        .format();
      if (unit === 'today') {
        startDate = moment.tz('America/Los_Angeles').startOf('day')
          .utc()
          .format();
      } else if (unit === 'yesterday') {
        startDate = moment.tz('America/Los_Angeles').subtract(1, 'days').startOf('day')
          .utc()
          .format();
        endDate = moment.tz('America/Los_Angeles').subtract(1, 'days').endOf('day')
          .utc()
          .format();
      } else if (unit === 'days') {
        startDate = moment.tz('America/Los_Angeles').subtract(period - 1, 'days').startOf('day')
          .utc()
          .format();
      }
      const {
        totalOrders,
        totalUnitsSold,
        totalSaleAmount,
        totalPromotionDiscount,
        totalUnitsInStock,
        totalFees,
        totalGrossProfit,
        totalNetProfit,
        totalProfitPercentage,
        totalRoiPercentage
      } = await CalculateSalesHistory({
        userId: demoUserId,
        name,
        startDate,
        endDate,
        randomValue
      });
      salesDataArr.push({
        updateOne: {
          filter: {
            userId: demoUserId,
            period: period > 0 ? `${period}-${unit}` : unit
          },
          update: {
            $set: {
              name,
              totalOrders,
              totalUnitsSold,
              totalSaleAmount,
              totalPromotionDiscount,
              totalUnitsInStock,
              totalFees,
              totalGrossProfit,
              totalNetProfit,
              totalProfitPercentage,
              totalRoiPercentage,
              updatedAt: new Date()
            },
            $setOnInsert: {
              createdAt: new Date()
            }
          },
          upsert: true
        }
      });
    }

    if (salesDataArr.length > 0) {
      await SalesData.bulkWrite(salesDataArr);
    }
    console.log('DEMO ACCOUNT DATA LOADED SUCCESSFULLY!');
  }
};

export default SetupDemoAccount;
