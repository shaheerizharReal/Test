import mongoose from 'mongoose';

import Products from '../../models/products';
import Users from '../../models/users';
import AgendaJobs from '../../models/agenda-jobs';
import agenda from '../agenda';

const { ObjectId } = mongoose.Types;

const SaveDefaultShippingRate = async ({ userId, shipBy, shippingRate }) => {
  await Products.updateMany({ userId }, {
    $set: {
      shipBy,
      shippingRate,
      profit: null,
      profitPercentage: null,
      roiPercentage: null
    }
  });
  await Users.updateOne({
    _id: userId
  }, {
    $set: {
      fbaInboundShippingCost: {
        shipBy,
        shippingRate
      }
    }
  });
  await AgendaJobs.deleteOne({ 'data.userId': ObjectId(userId), name: 'profit-recalculation:shipping-rate' });
  agenda.create('profit-recalculation:shipping-rate', { userId })
    .unique({ 'data.userId': userId })
    .save();
};

export default SaveDefaultShippingRate;
