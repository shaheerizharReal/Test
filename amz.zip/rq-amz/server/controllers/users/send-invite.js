import ForgotPassword from './forgot-password';
import Users from '../../models/users';

const SendInvite = async ({
  parentId,
  name,
  email,
  role
}) => {
  try {
    await Users.create({
      email,
      name,
      status: 'Child User',
      permission: [{
        parentId: parentId.toString(),
        role
      }]
    }).then((newUser) => {
      console.log('Child User Created :', newUser);
      ForgotPassword({ email });
    }).catch((error) => {
      console.log(error);
      return { status: false, message: error };
    });
    const newChild = await Users.findOne({ email });
    return { status: true, newChild };
  } catch (error) {
    console.log('ERROR IN SendInvite is ', error);
    return { status: false, message: error.message };
  }
};
export default SendInvite;
