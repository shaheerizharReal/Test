import Users from '../../models/users';

const SetRole = async ({ _id, parentId, role }) => {
  await Users.updateOne({ _id }, {
    $set: {
      permission: [{
        role,
        parentId: parentId.toString()
      }]
    }
  });
};

export default SetRole;
