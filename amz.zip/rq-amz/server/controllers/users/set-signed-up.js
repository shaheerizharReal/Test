import Users from '../../models/users';

const SetSignedUp = async ({ _id, signedUp }) => {
  await Users.updateOne({ _id }, {
    $set: {
      signedUp
    }
  });
};

export default SetSignedUp;
