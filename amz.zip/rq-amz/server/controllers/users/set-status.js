import Users from '../../models/users';

const SetStatus = async ({ _id, status }) => {
  await Users.updateOne({ _id }, {
    $set: {
      status
    }
  });
};

export default SetStatus;
