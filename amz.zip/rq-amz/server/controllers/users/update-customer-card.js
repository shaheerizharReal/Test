import Users from '../../models/users';
import {
  CreateCustomer,
  UpdateCard
} from '../stripe';

const getStripeUserId = async (userId) => {
  const user = await Users.findOne({ _id: userId });
  const stripeUserId = (user && user.payment && user.payment.stripeUserId);

  if (stripeUserId) return stripeUserId;

  const customer = await CreateCustomer({
    name: user.name,
    email: user.email
  });

  await Users.updateOne({ _id: userId }, {
    $set: {
      'payment.stripeUserId': customer.id
    }
  });

  return customer.id;
};

const UpdateCustomerCard = async ({
  userId,
  token
}) => {
  const stripeUserId = await getStripeUserId(userId);
  await UpdateCard(stripeUserId, { token });

  console.log('UpdateCustomerCard ....', userId, stripeUserId, token);
};

export default UpdateCustomerCard;
