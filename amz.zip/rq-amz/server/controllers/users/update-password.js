import bcrypt from 'bcrypt';
import moment from 'moment';
import { extend } from 'lodash';

import Users from '../../models/users';

const UpdatePassword = async ({ resetPasswordToken, password }) => {
  const user = await Users.findOne({
    resetPasswordToken,
    resetPasswordExpires: {
      $gt: Date.now()
    }
  });

  console.log('user in update password', { user });
  if (!user) {
    throw new Error('Invalid reset link or reset link expired !');
  }

  const hashedPassword = bcrypt.hashSync(password, 12);
  const setObj = {
    password: hashedPassword
  };

  if (!user.password) {
    extend(setObj, { signedUp: moment() });
  }
  await Users.updateOne({ _id: user._id }, {
    $set: setObj,
    $unset: {
      resetPasswordToken: '',
      resetPasswordExpires: ''
    }
  });
};

export default UpdatePassword;
