import Users from '../../models/users';

const updateReferralCode = async ({ _id, referralCode }) => {
  await Users.updateOne({ _id }, {
    $set: {
      referralCode
    }
  });
};

export default updateReferralCode;
