import Users from '../../models/users';
import {
  CreateCustomer,
  UpdateCustomer,
  UpdateSubscription,
  RetrieveSubscription,
  RetreiveUpcomingInvoiceData
} from '../stripe';

const getStripeUserId = async (userId) => {
  const user = await Users.findOne({ _id: userId });
  const stripeUserId = (user && user.payment && user.payment.stripeUserId);

  if (stripeUserId) return stripeUserId;

  const customer = await CreateCustomer({
    name: user.name,
    email: user.email
  });

  await Users.updateOne({ _id: userId }, {
    $set: {
      'payment.stripeUserId': customer.id
    }
  });

  return customer.id;
};

const UpdateStripeSubscription = async ({
  userId,
  token,
  coupon,
  subscriptionId,
  planId,
  planName,
  planAmount,
  tierNo,
  quantity,
  lmref
}) => {
  const stripeUserId = await getStripeUserId(userId);
  await UpdateCustomer(stripeUserId, { token, coupon });

  console.log('Customer Updated ....', stripeUserId, token);

  const subscriptionBefore = await RetrieveSubscription({
    subscriptionId
  });

  const subscription = await UpdateSubscription({
    subscriptionId,
    itemId: subscriptionBefore.items.data[0].id,
    planId,
    quantity,
    lmref
  });

  console.log('Subscription Updated ....', stripeUserId, token);

  let name;
  if (tierNo === 0) {
    name = `${planName} Pro`;
  } else if (tierNo === 1) {
    name = `${planName} Expert`;
  } else if (tierNo === 2) {
    name = `${planName} Professional`;
  }

  const { period_end } = await RetreiveUpcomingInvoiceData({
    customer: stripeUserId
  });
  await Users.updateOne({ _id: userId }, {
    $set: {
      'payment.subscriptionId': subscription.id,
      'payment.subscribedAt': new Date(),
      'payment.nextInvoicedChargedAt': period_end,
      'payment.planID': planId,
      'payment.tierNo': tierNo,
      'payment.planName': name,
      'payment.planAmount': planAmount,
      status: 'Active'
    },
    $unset: {
      'payment.unsubscribedAt': '',
      'payment.subscriptionEndDate': ''
    }
  });
};

export default UpdateStripeSubscription;
