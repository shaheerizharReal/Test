import Users from '../../models/users';
import MwsAPI from '../mws';
import runSignUpJobs from '../agenda/start-jobs';

const UpdateUserMwsCredentials = async ({ userId, mws }) => {
  const { sellerId, authToken, marketplaceId } = mws;

  const participations = await MwsAPI({
    endpoint: 'ListMarketplaceParticipations',
    params: {
      userId,
      sellerId,
      authToken
    }
  });

  const marketplaceExists = participations.find(p => p.marketplaceId === marketplaceId);

  if (!marketplaceExists) {
    throw new Error('Invalid Marketplace: Please provide valid Marketplace ID');
  }

  await Users.updateOne({ _id: userId }, {
    $set: {
      mws
    }
  });

  runSignUpJobs(userId);

  return mws;
};

export default UpdateUserMwsCredentials;
