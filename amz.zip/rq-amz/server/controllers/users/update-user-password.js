import bcrypt from 'bcrypt';
import Users from '../../models/users';

const UpdateUserPassword = async ({ userId, oldPassword, newPassword }) => {
  const user = await Users.findOne({ _id: userId });
  if (user) {
    const passwordFound = await bcrypt.compare(oldPassword, user.password);

    if (!passwordFound) {
      return { status: false, message: 'Enter your correct old password' };
    }

    const hashedPassword = bcrypt.hashSync(newPassword, 12);

    await Users.updateOne({ _id: userId }, {
      $set: {
        password: hashedPassword
      }
    });
    return { status: true, message: 'Password successfully changed!' };
  }
  return { status: false, message: 'User does not exist' };
};

export default UpdateUserPassword;
