export class ThrottlingException extends Error {
  constructor({ nextAvailableAt, message, endpoint, userId }) {
    super(message);

    this.nextAvailableAt = nextAvailableAt;
    this.endpoint = endpoint;
    this.userId = userId;
  }
}

export class MWSErrorException extends Error {
  constructor({ message, endpoint, userId }) {
    super(message);

    this.endpoint = endpoint;
    this.userId = userId;
  }
}

export class GenerateReportException extends Error {
  constructor({ message, nextAvailableAt, reportId, reportRequestId, reportRequestStatus, retries }) {
    super(message);

    this.nextAvailableAt = nextAvailableAt;
    this.reportId = reportId;
    this.reportRequestId = reportRequestId;
    this.reportRequestStatus = reportRequestStatus;
    this.retries = retries;
  }
}

export class GenerateFeedException extends Error {
  constructor({ message, nextAvailableAt, feedSubmissionId, feedProcessingStatus, retries }) {
    super(message);

    this.nextAvailableAt = nextAvailableAt;
    this.feedSubmissionId = feedSubmissionId;
    this.feedProcessingStatus = feedProcessingStatus;
    this.retries = retries;
  }
}
