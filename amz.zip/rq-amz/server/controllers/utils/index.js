import nodemailer from 'nodemailer';

import { CONDITION_TYPE } from '../../../config/constants';
import { MAIL } from '../../../config/settings.json';

export const getImageUrl = ({ imageUrl }) => {
  return imageUrl ? `https://images-na.ssl-images-amazon.com/images/I/${imageUrl}` : '/dist/images/no-image.png';
};

export const mapCondition = (conditionValue) => {
  const condition = Object.values(CONDITION_TYPE)
    .find(conditionType => conditionType.value === parseInt(conditionValue, 10));

  return !!condition && condition.label;
};

export const sendMail = ({
  toEmail,
  subject,
  body
}) => {
  const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
      user: MAIL.user,
      pass: MAIL.password
    }
  });

  const mailOptions = {
    from: 'support@replendashboard.com',
    to: `${toEmail}`,
    subject,
    html: body
  };

  return new Promise((resolve, reject) => {
    transporter.sendMail(mailOptions, (err, info) => {
      if (err) {
        reject(err);
      } else {
        resolve(info);
      }
    });
  });
};
