import { extend } from 'lodash';
import moment from 'moment';
import passport from 'passport';
import bcrypt from 'bcrypt';
import { Strategy as LocalStrategy } from 'passport-local';
import { Strategy as JWTstrategy, ExtractJwt } from 'passport-jwt';

import Users from '../models/users';
import Coupons from '../models/coupons';
import { jwtSecret } from '../../config/settings';
import { sendMail } from '../controllers/utils/index';

const BCRYPT_SALT_ROUNDS = 12;

const SignupStrategy = new LocalStrategy({
  usernameField: 'email',
  passwordField: 'password',
  passReqToCallback: true,
  session: false
}, (req, email, password, done) => {
  const { userName, referralCode } = req.body;

  Users.findOne({
    email
  }).then((user) => {
    if (user) {
      return done({ message: 'Email already used' }, false);
    }

    bcrypt.hash(password, BCRYPT_SALT_ROUNDS).then((hashedPassword) => {
      const userCreateAttribite = {
        email,
        name: userName,
        status: 'Trial',
        password: hashedPassword,
        signedUp: moment(),
        permission: [{
          role: ['Default'],
          parentId: null
        }]
      };
      if (referralCode) {
        extend(userCreateAttribite, { referralCode });

        if (referralCode === 'CoachingPartnership') {
          extend(userCreateAttribite, { status: 'Free' });
        }
      }

      Users.create(userCreateAttribite).then((user) => {
        Users.aggregate([
          { $match: { email } },
          {
            $unwind: {
              path: '$permission',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $lookup: {
              from: 'grants',
              localField: 'permission.role',
              foreignField: 'role',
              as: 'roles'
            }
          },
          {
            $project: {
              columnsWanted: 1,
              email: 1,
              name: 1,
              status: 1,
              admin: 1,
              permission: 1,
              password: 1,
              referralCode: 1,
              roles: {
                $filter: {
                  input: '$roles',
                  as: 'rol',
                  cond: {
                    $or: [
                      { $not: ['$$rol.userId'] },
                      {
                        $and: [
                          { $eq: ['$$rol.userId', '$permission.parentId'] },
                          { $in: ['$$rol.role', '$permission.role'] }
                        ]
                      }
                    ]
                  }
                }
              }
            }
          }
        ]).then((newuser) => {
          if (userCreateAttribite.referralCode === 'CoachingPartnership') {
            sendMail({
              toEmail: email,
              subject: 'Free User',
              body: `<div>
                <p>
                  Congrats, you have become a Free User.
                </p>
              </div>`
            });

            return done(null, newuser[0]);
          }

          if (userCreateAttribite.referralCode) {
            Coupons.findOne({
              _id: referralCode
            }).then((coupon) => {
              if (!coupon) {
                sendMail({
                  toEmail: email,
                  subject: 'Invalid Referral Code',
                  body: `<div>
                    <p>
                      Referral Code you have entered is not valid.
                    </p>
                    <p>
                      Kindly coordinate with your Affiliator.
                    </p>
                  </div>`
                });
                const invalidReferralCode = true;
                return done(null, newuser[0], invalidReferralCode);
              }

              return done(null, newuser[0]);
            }).catch((err) => {
              done(err);
            });
          } else {
            return done(null, newuser[0]);
          }
        }).catch(err => done(err));
      }).catch((err) => {
        done(err);
      });
    });
  }).catch((err) => {
    done(err);
  });
});

const LoginStrategy = new LocalStrategy({
  usernameField: 'email',
  passwordField: 'password',
  session: false
}, (email, password, done) => {
  Users.aggregate([
    { $match: { email } },
    {
      $unwind: {
        path: '$permission',
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $lookup: {
        from: 'grants',
        localField: 'permission.role',
        foreignField: 'role',
        as: 'roles'
      }
    },
    {
      $project: {
        columnsWanted: 1,
        email: 1,
        name: 1,
        admin: 1,
        status: 1,
        password: 1,
        payment: 1,
        referralCode: 1,
        noOfActiveProducts: 1,
        mws: 1,
        permission: 1,
        roles: {
          $filter: {
            input: '$roles',
            as: 'rol',
            cond: {
              $or: [
                { $not: ['$$rol.userId'] },
                {
                  $and: [
                    { $eq: ['$$rol.userId', '$permission.parentId'] },
                    { $in: ['$$rol.role', '$permission.role'] }
                  ]
                }
              ]
            }
          }
        }
      }
    }
  ]).then((userToEdit) => {
    if (userToEdit && userToEdit.length) {
      const user = userToEdit[0];
      bcrypt.compare(password, user.password).then((response) => {
        if (response !== true) {
          return done({ message: 'Passwords do not match !' }, false);
        }
        if (!user.admin) {
          if (user.status === 'Child User' && user.permission.parentId) {
            Users.findOne({
              _id: user.permission.parentId
            }).then((parentStatusObject) => {
              if (parentStatusObject.status !== 'Trial Expire') {
                user.personelId = user._id;
                user._id = user.permission.parentId;
                done(null, user);
              } else {
                return done({ message: 'Trial Expire: Please Contact your Admin User!' }, false);
              }
            });
          } else {
            done(null, user);
          }
        } else {
          done(null, user);
        }
      });
    } else {
      return done({ message: 'Invalid Email !' }, false);
    }
  }).catch(err => done(err));
});

const JWTStrategy = new JWTstrategy({
  jwtFromRequest: ExtractJwt.fromAuthHeaderWithScheme('JWT'),
  secretOrKey: jwtSecret
}, (email, done) => {
  Users.aggregate([
    { $match: { email } },
    {
      $unwind: {
        path: '$permission',
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $lookup: {
        from: 'grants',
        localField: 'permission.role',
        foreignField: 'role',
        as: 'roles'
      }
    },
    {
      $project: {
        columnsWanted: 1,
        email: 1,
        name: 1,
        admin: 1,
        status: 1,
        password: 1,
        payment: 1,
        referralCode: 1,
        noOfActiveProducts: 1,
        mws: 1,
        permission: 1,
        roles: {
          $filter: {
            input: '$roles',
            as: 'rol',
            cond: {
              $or: [
                { $not: ['$$rol.userId'] },
                {
                  $and: [
                    { $eq: ['$$rol.userId', '$permission.parentId'] },
                    { $in: ['$$rol.role', '$permission.role'] }
                  ]
                }
              ]
            }
          }
        },
        fbaInboundShippingCost: 1
      }
    }
  ]).then(async (userToEdit) => {
    if (userToEdit && userToEdit.length) {
      const user = userToEdit[0];
      if (!user.admin) {
        if (user.status === 'Child User' && user.permission.parentId) {
          Users.findOne({
            _id: user.permission.parentId
          }).then((parentStatusObject) => {
            if (parentStatusObject.status !== 'Trial Expire') {
              user.personelId = user._id;
              user._id = user.permission.parentId;
              done(null, user);
            } else {
              return done({ message: 'Trial Expire: Please Contact your Admin User!' }, false);
            }
          });
        } else {
          done(null, user);
        }
      } else {
        done(null, user);
      }
    } else {
      done({ message: 'User not found !' }, false);
    }
  }).catch(err => done(err));
});

passport.use('login', LoginStrategy);
passport.use('signup', SignupStrategy);
passport.use('jwt', JWTStrategy);
