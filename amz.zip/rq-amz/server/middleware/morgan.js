import logger from 'morgan';
import app from '../config/express';

app.use(logger('dev'));
