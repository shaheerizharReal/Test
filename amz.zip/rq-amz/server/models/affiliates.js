import mongoose from 'mongoose';

const Affiliates = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  referralCode: { type: String, required: false },
  couponOffPercent: { type: Number, required: false },
  duration: { type: String, required: false }
});

export default mongoose.model('affiliates', Affiliates, 'affiliates');
