import mongoose from 'mongoose';

const AgendaJobs = new mongoose.Schema({
  state: { type: String },
  data: { type: Object },
  name: { type: String },
  progress: { type: Number },
  lockedAt: { type: Date },
  lastRunAt: { type: Date },
  nextRunAt: { type: Date },
  userName: { type: String },
  lastFinishedAt: { type: Date }
});

AgendaJobs.index({
  'data.userId': 1, name: 1
}, {
  unique: true
});

export default mongoose.model('agendaJobs', AgendaJobs, 'agendaJobs');
