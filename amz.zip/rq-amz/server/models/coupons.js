import mongoose from 'mongoose';

const Coupons = new mongoose.Schema({
  _id: { type: String, required: true },
  name: { type: String, required: false },
  duration: { type: String, required: false },
  couponOffPercent: { type: Number, required: false }
});

export default mongoose.model('coupons', Coupons, 'coupons');
