import mongoose from 'mongoose';

const AsinShortcuts = new mongoose.Schema({
  userId: { type: String, required: true },
  url: { type: String },
  displayName: { type: String },
  iconText: { type: String },
  visibility: { type: Boolean }
});

export default mongoose.model('asinShortcuts', AsinShortcuts, 'asinShortcuts');
