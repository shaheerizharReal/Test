import mongoose from 'mongoose';

const EmailData = new mongoose.Schema({
  _id: { type: String },
  userId: { type: String },
  trialWillExpire: { type: Boolean },
  trialExpired: { type: Boolean },
  isInGracePeriod: { type: Boolean },
  isDeactivated: { type: Boolean },
  updatedAt: { type: Date },
  createdAt: { type: Date }
});

EmailData.index({
  userId: 1
}, {
  unique: true
});

export default mongoose.model('emailData', EmailData, 'emailData');
