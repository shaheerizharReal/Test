import mongoose from 'mongoose';

const ExportProducts = new mongoose.Schema({
  _id: { type: String },
  skuList: { type: Array },
  columnsWanted: { type: Array }
});

export default mongoose.model('exportProducts', ExportProducts, 'exportProducts');
