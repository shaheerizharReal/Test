import mongoose from 'mongoose';

const Grants = new mongoose.Schema({
  role: { type: String, required: true },
  resource: { type: String, required: true },
  action: { type: String, required: false },
  possession: { type: String, required: false },
  attributes: { type: String, required: false },
  userId: { type: String, required: false }
});

export default mongoose.model('grants', Grants, 'grants');
