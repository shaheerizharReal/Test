import mongoose from 'mongoose';

const LastUpdateTracker = new mongoose.Schema({
  _id: { type: String },
  userId: { type: String },
  name: { type: String },
  lastUpdatedAt: { type: Date }
});

LastUpdateTracker.index({
  userId: 1, name: 1
}, {
  unique: true
});

export default mongoose.model('lastUpdateTracker', LastUpdateTracker, 'lastUpdateTracker');
