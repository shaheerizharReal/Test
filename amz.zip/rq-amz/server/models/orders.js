import mongoose from 'mongoose';

const Orders = new mongoose.Schema({
  userId: { type: String },
  amazonOrderId: { type: String },
  sellerSku: { type: String },
  asin: { type: String },
  sellerOrderId: { type: String },
  purchaseDate: { type: Date },
  lastUpdatedDate: { type: Date },
  orderStatus: { type: String },
  fulfillmentChannel: { type: String },
  salesChannel: { type: String },
  title: { type: String },
  itemStatus: { type: String },
  currency: { type: String },
  isBusinessOrder: { type: Boolean },
  isReplacementOrder: { type: Boolean },
  originalOrderId: { type: String },
  quantity: { type: Number },
  itemTax: { type: Number },
  itemPrice: { type: Number },
  shippingPrice: { type: Number },
  shippingTax: { type: Number },
  giftWrapPrice: { type: Number },
  giftWrapTax: { type: Number },
  shipPromotionDiscount: { type: Number },
  itemPromotionDiscount: { type: Number },
  orderReconcileStatus: { type: String },
  updatedAt: { type: Date },
  createdAt: { type: Date }
});

Orders.index({
  userId: 1, purchaseDate: 1, orderStatus: 1, sellerSku: 1
}, {
  unique: false
});
Orders.index({
  userId: 1, amazonOrderId: 1, sellerSku: 1
}, {
  unique: false
});
Orders.index({
  userId: 1, orderReconcileStatus: 1
}, {
  unique: false
});
Orders.index({
  userId: 1, purchaseDate: 1, sellerSku: 1
}, {
  unique: false
});
Orders.index({
  _id: 1, orderReconcileStatus: 1
}, {
  unique: false
});

export default mongoose.model('orders', Orders, 'orders');
