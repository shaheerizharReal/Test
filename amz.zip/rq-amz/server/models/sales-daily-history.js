import mongoose from 'mongoose';

const SalesDailyHistory = new mongoose.Schema({
  _id: { type: String },
  userId: { type: String },
  sellerSku: { type: String },
  timestamp: { type: Date },
  orders: { type: Number },
  pendingOrders: { type: Number },
  unitsSold: { type: Number },
  saleAmount: { type: Number },
  promotionDiscount: { type: Number },
  updatedAt: { type: Date },
  createdAt: { type: Date }
});

SalesDailyHistory.index({
  userId: 1, timestamp: 1, sellerSku: 1
}, {
  unique: true
});

export default mongoose.model('salesDailyHistory', SalesDailyHistory, 'salesDailyHistory');
