import mongoose from 'mongoose';

const SalesData = new mongoose.Schema({
  _id: { type: String },
  userId: { type: String },
  period: { type: String },
  name: { type: String },
  totalOrders: { type: Number },
  totalUnitsSold: { type: Number },
  totalSaleAmount: { type: Number },
  totalPromotionDiscount: { type: Number },
  totalUnitsInStock: { type: Number },
  totalFees: { type: Number },
  totalGrossProfit: { type: Number },
  totalNetProfit: { type: Number },
  totalProfitPercentage: { type: Number },
  totalRoiPercentage: { type: Number },
  updatedAt: { type: Date },
  createdAt: { type: Date }
});

SalesData.index({
  userId: 1, period: 1
}, {
  unique: true
});

export default mongoose.model('salesData', SalesData, 'salesData');
