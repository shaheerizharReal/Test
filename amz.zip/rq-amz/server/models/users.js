import mongoose from 'mongoose';

const Users = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  status: { type: String, required: true },
  password: { type: String, required: false },
  resetPasswordToken: { type: String, required: false },
  resetPasswordExpires: { type: Date, required: false },
  mws: { type: Object, required: false },
  payment: { type: Object, required: false },
  columnsWanted: { type: [String], required: false },
  signedUp: { type: Date, required: false },
  referralCode: { type: String, required: false },
  noOfActiveProducts: { type: Number, required: false },
  permission: { type: Array, required: false },
  fbaInboundShippingCost: { type: Object, required: false },
  profitCalculatedBy: { type: String, required: false }
});

Users.index({
  admin: 1
}, {
  unique: false
});
Users.index({
  referralCode: 1
}, {
  unique: false
});
Users.index({
  status: 1
}, {
  unique: false
});
Users.index({
  email: 1, name: 1
}, {
  unique: false
});
Users.index({
  name: 1, email: 1
}, {
  unique: false
});
Users.index({
  resetPasswordToken: 1, resetPasswordExpires: 1
}, {
  unique: false
});
Users.index({
  'payment.stripeUserId': 1
}, {
  unique: false
});

export default mongoose.model('users', Users, 'users');
