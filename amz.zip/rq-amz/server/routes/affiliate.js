import express from 'express';
import {
  AddAffiliate,
  GetAffiliates,
  DeleteAffiliates
} from '../controllers/affiliate';

const Router = express.Router();

Router.post('/add-affiliate', (req, res) => {
  const {
    name,
    email,
    referralCode,
    couponOffPercent,
    duration
  } = req.body;

  AddAffiliate({
    name,
    email,
    referralCode,
    couponOffPercent,
    duration
  }).then((affiliates) => {
    res.send({
      affiliates
    });
  }).catch((error) => {
    res.status(500).send(error.message);
  });
});

Router.get('/get-affiliates', (req, res) => {
  GetAffiliates().then((affiliatesData) => {
    res.send({ affiliatesData });
  }).catch((error) => {
    res.status(500).send(error.message);
  });
});

Router.delete('/delete-affiliates', (req, res) => {
  const { delAffiliates } = req.query;

  DeleteAffiliates({
    delAffiliates
  }).then(() => {
    res.send({ status: true });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

export default Router;
