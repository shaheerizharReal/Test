import express from 'express';
import { RequeueAgendaJob, RemoveAgendaJob, GetAgendaJobs } from '../controllers/agendaJobs';

const Router = express.Router();

Router.route('/fetchJobs').get((req, res) => {
  const { filters, skip, limit } = req.query;

  GetAgendaJobs({
    filters: filters ? JSON.parse(filters) : [],
    skip: Number(skip),
    limit: Number(limit)
  }).then((result) => {
    res.send(result);
  }).catch((error) => {
    res.send(error);
  });
});

Router.route('/requeueJob').post((req, res) => {
  const { id, filters } = req.query;
  RequeueAgendaJob({
    _id: id,
    filters: filters ? JSON.parse(filters) : []
  }).then((result) => {
    res.send(result);
  }).catch((error) => {
    res.send(error);
  });
});

Router.route('/removeJob').delete((req, res) => {
  const { id, filters } = req.query;
  RemoveAgendaJob({
    _id: id,
    filters: filters ? JSON.parse(filters) : []
  }).then((result) => {
    res.send(result);
  }).catch((error) => {
    res.send(error);
  });
});

export default Router;
