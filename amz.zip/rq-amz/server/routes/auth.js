import express from 'express';
import jwt from 'jsonwebtoken';
import passport from 'passport';
import url from 'url';

import { jwtSecret } from '../../config/settings';

import {
  ForgotPassword,
  UpdatePassword,
  GetUserById,
  GetParentUserStatus
} from '../controllers/users';

import {
  ExportProducts
} from '../controllers/inventory';
import {
  GetAffiliatesExport
} from '../controllers/affiliate';

import ScriptMethods from '../controllers/script-methods';

const Router = express.Router();

Router.post('/register', (req, res, next) => {
  passport.authenticate('signup', { session: false }, (err, user, invalidReferralCode) => {
    console.log('Register: ', { err, user, invalidReferralCode });
    if (err || !user) {
      return res.status(400).send(err && err.message);
    }

    req.login(user, { session: false }, (error) => {
      if (error) {
        return res.status(500).send(err && err.message);
      }

      const token = jwt.sign(user.email, jwtSecret);

      return res.json({ user, token, invalidReferralCode });
    });
  })(req, res, next);
});

Router.post('/login', (req, res) => {
  passport.authenticate('login', { session: false }, (err, user, info) => {
    console.log('Login: ', { err, user, info });

    if (err || !user) {
      return res.status(400).send(err && err.message);
    }

    req.login(user, { session: false }, (error) => {
      if (error) {
        return res.status(500).send(err && err.message);
      }

      const token = jwt.sign(user.email, jwtSecret);
      return res.json({ user, token });
    });
  })(req, res);
});

Router.get('/findUser', (req, res) => {
  passport.authenticate('jwt', { session: false }, (err, user, info) => {
    console.log('Find User: ', { err, user, info });

    if (err || !user) {
      return res.status(400).send(err && err.message);
    }

    return res.json({ user });

  })(req, res);
});

Router.route('/forgot-password').post((req, res) => {
  const { email } = req.body;

  ForgotPassword({ email })
    .then(() => {
      res.send({ status: true });
    })
    .catch((error) => {
      console.log('Error Message: ', error.message);
      res.status(500).send(error.message)
    });
});

Router.route('/update-password').post((req, res) => {
  const { resetPasswordToken, password } = req.body;

  UpdatePassword({ resetPasswordToken, password })
    .then(() => {
      res.send({ status: true });
    })
    .catch((error) => {
      console.log('Error Message: ', error.message);
      res.status(500).send(error.message)
    });
});

Router.route('/impersonate').post((req, res) => {
  const { userId } = req.body;

  GetUserById({ userId })
    .then((user) => {
      if (user.status === 'Child User' && user.permission.parentId) {
        GetParentUserStatus({ parentId: user.permission.parentId })
          .then((status) => {
            if (status === 'Trial Expire') {
              res.status(400).send("This Child User's Admin's Trial has been Expired");
            } else {
              const token = jwt.sign(user.email, jwtSecret);
              res.json({ user, token });
            }
          });
      } else {
        const token = jwt.sign(user.email, jwtSecret);
        res.json({ user, token });
      }
    })
    .catch((error) => {
      console.log('Error Message: ', error.message);
      res.status(500).send(error.message);
    });
});

Router.route('/export-products').get(ExportProducts);

Router.route('/get-affiliates-export').get(GetAffiliatesExport);

// http://localhost:5200/api/v1/script?method=addSignedUp
Router.route('/script').get((req, res) => {
  const { query } = url.parse(req.url, true);
  const { method } = query;

  ScriptMethods(method);
});

export default Router;
