import express from 'express';
import {
  AddShortcut,
  EditShortcut,
  GetShortcuts,
  DeleteShortcut
} from '../controllers/custom-asin-shortcuts';

const Router = express.Router();

Router.post('/add-shortcut', (req, res) => {
  const { _id: userId } = req.user;
  const {
    url,
    displayName,
    iconText,
    visibility
  } = req.body;

  AddShortcut({
    userId,
    url,
    displayName,
    iconText,
    visibility
  }).then((shortcuts) => {
    res.send({ shortcuts });
  }).catch((error) => {
    res.status(500).send(error.message);
  });
});

Router.get('/get-shortcuts', (req, res) => {
  const { _id: userId } = req.user;

  GetShortcuts({
    userId
  }).then((shortcuts) => {
    res.send({ shortcuts });
  }).catch((error) => {
    res.status(500).send(error.message);
  });
});

Router.post('/edit-shortcut', (req, res) => {
  const { _id: userId } = req.user;
  const {
    shortcutId,
    setObj
  } = req.body;

  EditShortcut({
    userId,
    shortcutId,
    setObj
  }).then((shortcut) => {
    res.send(shortcut);
  }).catch((error) => {
    res.status(500).send(error.message);
  });
});

Router.route('/delete-shortcut').delete((req, res) => {
  const { shortcutId } = req.query;

  DeleteShortcut({
    shortcutId
  }).then(() => {
    res.send({ status: true, shortcutId });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

export default Router;
