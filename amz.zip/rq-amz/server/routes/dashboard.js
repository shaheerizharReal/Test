import express from 'express';
import AccessControl from 'accesscontrol';

import {
  GetSales
} from '../controllers/dashboard';

const Router = express.Router();

Router.route('/get-sales').get((req, res) => {
  const { _id: userId } = req.user;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).readAny('Dashboard');

  if (permission.granted) {
    GetSales({
      userId
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

export default Router;
