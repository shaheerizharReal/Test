import express from 'express';

import {
  NewGrant,
  GetGrants,
  DeleteRole,
  GetDistinctRoles
} from '../controllers/grants';

const Router = express.Router();

Router.route('/new-grant').post((req, res) => {
  const { _id: userId } = req.user;

  const {
    name, modules, grantType
  } = req.body;

  NewGrant({
    name,
    modules,
    grantType,
    userId
  }).then((result) => {
    res.send(result);
  }).catch((error) => {
    res.send(error);
  });
});

Router.route('/get-grant').get((req, res) => {
  GetGrants().then((result) => {
    res.send(result);
  }).catch((error) => {
    res.send(error);
  });
});

Router.route('/delete-grant').delete((req, res) => {
  const { _id } = req.query;

  DeleteRole({
    _id
  }).then(() => {
    res.send({ status: true, _id });
  }).catch((error) => {
    res.send(error);
  });
});

Router.route('/get-distinct-roles-for-dropdown').get((req, res) => {
  const userId = req.user._id;

  GetDistinctRoles({
    userId
  }).then((distinctRoles) => {
    res.send({
      status: true,
      distinctRoles
    });
  }).catch((error) => {
    console.log('Error: ', error.message);
    res.send(error);
  });
});

export default Router;
