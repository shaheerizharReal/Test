import express from 'express';
import path from 'path';
import passport from 'passport';

import app from '../config/express';

import InventoryRouter from './inventory';
import DashboardRouter from './dashboard';
import AgendaJobsRouter from './agendaJobs';
import AuthenticationRouter from './auth';
import UsersRouter from './users';
import StripeRouter from './stripe';
import AffiliateRouter from './affiliate';
import Grant from './grant';
import ShortcutRouter from './custom-asin-shortcuts';

import './payment';

app.use('/api/v1', AuthenticationRouter);
app.use(passport.initialize());
app.use('/api/v1/users', passport.authenticate('jwt', { session: false }), UsersRouter);
app.use('/api/v1/agendaJobs', passport.authenticate('jwt', { session: false }), AgendaJobsRouter);
app.use('/api/v1/inventory', passport.authenticate('jwt', { session: false }), InventoryRouter);
app.use('/api/v1/dashboard', passport.authenticate('jwt', { session: false }), DashboardRouter);
app.use('/api/v1/affiliate', passport.authenticate('jwt', { session: false }), AffiliateRouter);
app.use('/api/v1/grants', passport.authenticate('jwt', { session: false }), Grant);
app.use('/api/v1/custom-asin-shortcut', passport.authenticate('jwt', { session: false }), ShortcutRouter);
app.use('/api/v1/stripe', StripeRouter);

const distPath = path.join(__dirname, '../../dist/client');
app.use(express.static(distPath));
app.get('*', (_, res) => res.sendFile(path.join(distPath, 'index.html')));
