import express from 'express';
import fs from 'fs';
import formidableMiddleware from 'express-formidable';
import AccessControl from 'accesscontrol';

import {
  GetInventory,
  GetCategoriesAndSuppliers,
  SetCostPrice,
  SetDecideBuyQuantity,
  ResetDecidedQuantities,
  SetSupplier,
  SetPurchaseLink,
  SaveExportProductsParams,
  ImportProducts,
  SetStoreSection,
  SetNotesSection,
  SetToReplen,
  SetShippingCost
} from '../controllers/inventory';

const Router = express.Router();

Router.route('/').get((req, res) => {
  const {
    limit,
    skip,
    sort,
    filters
  } = req.query;

  const { _id: userId, roles, permission } = req.user;
  const ac = new AccessControl(roles);

  if (ac.can(req.user.permission.role).readAny('Inventory').granted) {
    GetInventory({
      userId,
      roles,
      permission,
      filters: filters ? JSON.parse(filters) : {},
      skip: Number(skip),
      limit: Number(limit),
      sort: sort ? JSON.parse(sort) : {}
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/get-suppliers-and-categories').get((req, res) => {
  const { _id: userId } = req.user;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).readAny('Inventory');

  if (permission.granted) {
    GetCategoriesAndSuppliers({
      userId
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/set-cost-price').post((req, res) => {
  const { _id: userId } = req.user;
  const { sellerSku, costPrice } = req.query;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).updateAny('Cost Price');

  if (permission.granted) {
    SetCostPrice({
      userId,
      sellerSku,
      costPrice
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/set-decide-buy-quantity').post((req, res) => {
  const { _id: userId } = req.user;
  const { sellerSku, decidedBuyQuantity } = req.query;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).updateAny('Decided Buy Quantity');

  if (permission.granted) {
    SetDecideBuyQuantity({
      userId,
      sellerSku,
      decidedBuyQuantity
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/set-shipping-cost').post((req, res) => {
  const { _id: userId } = req.user;
  const {
    sellerSku,
    shipBy,
    shippingRate
  } = req.query;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).updateAny('Ship by');

  if (permission.granted) {
    SetShippingCost({
      userId,
      sellerSku,
      shipBy,
      shippingRate: Number(shippingRate)
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/set-supplier').post((req, res) => {
  const { _id: userId } = req.user;
  const { sellerSku, supplier } = req.query;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).updateAny('Suppliers');

  if (permission.granted) {
    SetSupplier({
      userId,
      sellerSku,
      supplier
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/set-purchase-link').post((req, res) => {
  const { _id: userId } = req.user;
  const { sellerSku, purchaseLink } = req.query;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).updateAny('Purchase Link');

  if (permission.granted) {
    SetPurchaseLink({
      userId,
      sellerSku,
      purchaseLink
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/set-store-section').post((req, res) => {
  const { _id: userId } = req.user;
  const { sellerSku, storeSection } = req.query;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).updateAny('Store Section');

  if (permission.granted) {
    SetStoreSection({
      userId,
      sellerSku,
      storeSection
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/set-notes-section').post((req, res) => {
  const { _id: userId } = req.user;
  const { sellerSku, notesSection } = req.query;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).updateAny('Notes Section');

  if (permission.granted) {
    SetNotesSection({
      userId,
      sellerSku,
      notesSection
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/reset-decided-quantities').post((req, res) => {
  const { _id: userId } = req.user;

  ResetDecidedQuantities({
    userId
  }).then((result) => {
    res.send(result);
  }).catch((error) => {
    res.send(error);
  });
});

Router.route('/import-products').post(formidableMiddleware(), (req, res) => {
  const { _id: userId } = req.user;

  const file = req.files.document;
  const rawdata = fs.readFileSync(file.path);
  const products = JSON.parse(rawdata);

  const fileCostCheck = req.files.costCheck;
  const rawdataCostCheck = fs.readFileSync(fileCostCheck.path);
  const costCheck = JSON.parse(rawdataCostCheck);

  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).updateAny('Import Inventory');

  if (permission.granted) {
    ImportProducts({
      userId,
      products,
      costCheck
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/save-export-products-params').post(formidableMiddleware(), (req, res) => {
  const { _id: userId } = req.user;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).readAny('Export Inventory');

  if (permission.granted) {
    const fileSelectedItems = req.files.selectedItems;
    const rawdataSelectedItems = fs.readFileSync(fileSelectedItems.path);
    const skuList = JSON.parse(rawdataSelectedItems);

    const fileColumnsWanted = req.files.columnsWanted;
    const rawdataColumnsWanted = fs.readFileSync(fileColumnsWanted.path);
    const columnsWanted = JSON.parse(rawdataColumnsWanted);

    SaveExportProductsParams({
      userId,
      skuList,
      columnsWanted
    }).then((result) => {
      res.send(result);
    }).catch((error) => {
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/set-to-replen').post((req, res) => {
  const { _id: userId } = req.user;
  const { skuList, isReplen } = req.query;

  SetToReplen({
    userId,
    skuList,
    isReplen
  }).then((result) => {
    res.send(result);
  }).catch((error) => {
    res.send(error);
  });
});

export default Router;
