import moment from 'moment';

import bodyParser from 'body-parser';
import app from '../config/express';
import Users from '../models/users';
import AgendaJobs from '../models/agenda-jobs';
import runSignUpJobs from '../controllers/agenda/start-jobs';
import {
  RetreiveUpcomingInvoiceData
} from '../controllers/stripe';

app.post('/payment', bodyParser.raw({ type: 'application/json' }), async (request, response) => {
  const webhook = request.body;
  console.log('\n\n', 'In Payment', webhook.type);
  const {
    customer
  } = webhook.data.object;
  console.log('\n\n', 'Customer', customer);

  switch (webhook.type) {
    case 'invoice.payment_failed': {
      await Users.updateOne({
        'payment.stripeUserId': customer
      }, {
        $set: {
          status: 'Trial Expire',
          'payment.unsubscribedAt': new Date()
        },
        $unset: {
          'payment.subscriptionId': '',
          'payment.subscribedAt': '',
          'payment.nextInvoicedChargedAt': '',
          'payment.subscriptionEndDate': '',
          'payment.planID': '',
          'payment.planName': '',
          'payment.planAmount': '',
          'payment.tierNo': ''
        }
      });

      break;
    }

    case 'invoice.payment_succeeded': {
      const user = await Users.findOne({ 'payment.stripeUserId': customer });
      if (user) {
        const { payment } = user;
        const { stripeUserId } = payment;

        const { period_end } = await RetreiveUpcomingInvoiceData({
          customer: stripeUserId
        });

        await Users.updateOne({ 'payment.stripeUserId': customer }, {
          $set: {
            status: 'Active',
            'payment.nextInvoicedChargedAt': period_end
          },
          $unset: {
            'payment.subscriptionEndDate': ''
          }
        });

        runSignUpJobs(user._id);
      }

      break;
    }

    case 'customer.subscription.deleted': {
      const user = await Users.findOne({ 'payment.stripeUserId': customer });
      if (user) {
        await AgendaJobs.deleteMany({ 'data.userId': user._id });

        await Users.updateOne({
          'payment.stripeUserId': customer
        }, {
          $set: {
            status: 'Trial Expire',
            'payment.unsubscribedAt': new Date()
          },
          $unset: {
            'payment.subscriptionId': '',
            'payment.subscribedAt': '',
            'payment.planID': '',
            'payment.planName': '',
            'payment.planAmount': '',
            'payment.tierNo': ''
          }
        });
      }

      break;
    }

    default:
      break;
  }

  response.send(200);
});
