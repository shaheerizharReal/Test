import express from 'express';

import {
  ListPlans
} from '../controllers/stripe';

import Coupons from '../models/coupons';

const Router = express.Router();

Router.route('/get-stripe-data').get(async (req, res) => {
  const stripeCoupons = await Coupons.find();

  ListPlans()
    .then((result) => {
      const stripePlans = result && result.data && result.data.length > 0 ? result.data : [];

      res.send({
        stripePlans,
        stripeCoupons
      });
    }).catch((error) => {
      res.send(error);
    });
});

export default Router;
