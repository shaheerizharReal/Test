import express from 'express';
import AccessControl from 'accesscontrol';

import {
  GetUserMwsCredentials,
  UpdateUserMwsCredentials,
  CreateStripeSubscription,
  IsValidCoupon,
  UpdateCustomerCard,
  getAllUsers,
  UpdateUserPassword,
  GetColumnsWanted,
  CancelStripeSubscription,
  UpdateStripeSubscription,
  SetStatus,
  GetNoOfActiveProducts,
  UpdateReferralCode,
  SetSignedUp,
  DeleteUser,
  SendInvite,
  GetChildUsers,
  SetRole,
  DeleteChildUser,
  FetchAttributesToUpdateRole,
  GetReferralCodes,
  ForgotPassword,
  LoadDemoUserData,
  SaveDefaultShippingRate,
  GetDefaultShippingRate,
  SavePriceForCalculation,
  GetDefaultCalculationPrice
} from '../controllers/users';
import { InventoryReadGrant } from '../controllers/grants';
import Users from '../models/users';

const Router = express.Router();

Router.route('/mws').get((req, res) => {
  const userId = req.user._id;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).readAny('MWS');

  if (permission.granted) {
    GetUserMwsCredentials({
      userId
    }).then((mws) => {
      res.send({
        status: true,
        mws
      });
    }).catch((error) => {
      console.log('Error: ', error.message);
      res.send(error);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/columnsWanted').get((req, res) => {
  const userId = req.user._id;

  GetColumnsWanted({
    userId
  }).then((columnsWanted) => {
    res.send({
      status: true,
      columnsWanted
    });
  }).catch((error) => {
    console.log('Error: ', error.message);
    res.send(error);
  });
});

Router.route('/loadDemoAccountData').get((req, res) => {
  LoadDemoUserData().then(() => {
    res.send({ status: true });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/fetchUsers').get((req, res) => {
  const {
    limit,
    skip,
    filters,
    sort
  } = req.query;

  getAllUsers({
    filters: filters ? JSON.parse(filters) : [],
    skip: Number(skip),
    limit: Number(limit),
    sort: sort ? JSON.parse(sort) : {}
  }).then((result) => {
    res.send(result);
  }).catch((error) => {
    res.send(error);
  });
});

Router.route('/fetchAllUsersAgendaJobs').get((req, res) => {
  const {
    filters
  } = req.query;

  getAllUsers({
    filters: filters ? JSON.parse(filters) : []
  }).then((result) => {
    res.send(result);
  }).catch((error) => {
    res.send(error);
  });
});

Router.route('/get-referral-codes').get((req, res) => {
  GetReferralCodes().then((result) => {
    res.send(result);
  }).catch((error) => {
    res.send(error);
  });
});

Router.route('/update-user-password').post((req, res) => {
  let userId;
  const { oldPassword, newPassword } = req.body;

  if (req.user.status === 'Child User') {
    ({ personelId: userId } = req.user);
  } else {
    ({ _id: userId } = req.user);
  }
  UpdateUserPassword({ userId, oldPassword, newPassword })
    .then((result) => {
      res.send(result);
    })
    .catch((error) => {
      res.status(500).send(error.message);
    });
});

Router.route('/update-mws-credentials').post((req, res) => {
  const { mws } = req.body;
  const userId = req.user._id;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).readAny('MWS');

  if (permission.granted) {
    UpdateUserMwsCredentials({ userId, mws })
      .then((mws) => {
        res.send({
          status: true,
          mws
        });
      });
  } else {
    res.status(403).end();
  }
});

Router.route('/create-subscription').post(async (req, res) => {
  const {
    token,
    coupon,
    planId,
    planName,
    planAmount,
    tierNo,
    quantity,
    lmref
  } = req.body;
  const userId = req.user._id;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).readAny('Payment');

  if (permission.granted) {
    const user = await Users.findOne({ _id: userId });
    const { payment } = user;
    if (payment && payment.subscriptionId) {
      UpdateStripeSubscription({
        userId,
        token,
        coupon,
        subscriptionId: payment.subscriptionId,
        planId,
        planName,
        planAmount,
        tierNo,
        quantity,
        lmref
      }).then(() => {
        res.send({ status: true });
      }).catch((error) => {
        console.log('Error Message: ', error.message);
        res.status(500).send(error.message);
      });
    } else {
      CreateStripeSubscription({
        userId,
        token,
        coupon,
        planId,
        planName,
        planAmount,
        tierNo,
        quantity,
        lmref
      }).then(() => {
        res.send({ status: true });
      }).catch((error) => {
        console.log('Error Message: ', error.message);
        res.status(500).send(error.message);
      });
    }
  } else {
    res.status(403).end();
  }
});

Router.route('/update-card').post(async (req, res) => {
  const {
    token
  } = req.body;
  const userId = req.user._id;

  UpdateCustomerCard({
    userId,
    token
  }).then(() => {
    res.send({ status: true });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/cancel-subscription').delete((req, res) => {

  const { subscriptionId } = req.query;
  const userId = req.user._id;
  const ac = new AccessControl(req.user.roles);
  const permission = ac.can(req.user.permission.role).readAny('Payment');

  if (permission.granted) {
    CancelStripeSubscription({
      userId,
      subscriptionId
    }).then(() => {
      res.send({ status: true });
    }).catch((error) => {
      console.log('Error Message: ', error.message);
      res.status(500).send(error.message);
    });
  } else {
    res.status(403).end();
  }
});

Router.route('/validate-coupon').post((req, res) => {
  const { couponId } = req.body;

  IsValidCoupon({
    couponId
  }).then((coupon) => {
    res.send({ status: true, coupon });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/no-of-active-products').get((req, res) => {
  const { user } = req;
  const { _id } = user;

  GetNoOfActiveProducts({ _id }).then((noOfActiveProducts) => {
    res.send({ noOfActiveProducts });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/update-referral-code').post((req, res) => {
  const { referralCode } = req.query;
  const { _id } = req.user;

  UpdateReferralCode({
    _id,
    referralCode
  }).then(() => {
    res.send({ status: true, referralCode });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/delete-user').delete((req, res) => {
  const { userId, status } = req.query;

  DeleteUser({
    userId,
    status
  }).then(() => {
    res.send({ status: true, userId });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/get-default-shipping-rate').get((req, res) => {
  const { _id } = req.user;
  GetDefaultShippingRate({
    userId: _id
  }).then(({ shippingData }) => {
    res.send({ status: true, shippingData });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/set-default-shipping-rate').post((req, res) => {
  const { shipBy, shippingRate } = req.query;
  const { _id } = req.user;

  SaveDefaultShippingRate({
    userId: _id,
    shipBy,
    shippingRate: Number(shippingRate)
  }).then(() => {
    res.send({ status: true });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/get-default-calculation-price').get((req, res) => {
  const { _id } = req.user;
  GetDefaultCalculationPrice({
    userId: _id
  }).then(({ profitCalculatedBy }) => {
    res.send({ status: true, profitCalculatedBy });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/set-default-calculation-price').post((req, res) => {
  const { profitCalculatedBy } = req.query;
  const { _id } = req.user;

  SavePriceForCalculation({
    userId: _id,
    profitCalculatedBy
  }).then(() => {
    res.send({ status: true });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/set-user-status').post((req, res) => {
  const user = req.query;
  const { _id, status } = user;

  SetStatus({
    _id,
    status
  }).then(() => {
    res.send({ status: true, user });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.post('/set-referral-code', (req, res) => {
  const user = req.query;
  const { _id, referralCode } = user;

  UpdateReferralCode({
    _id,
    referralCode
  }).then(() => {
    res.send({ status: true, user });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/set-signed-up').post((req, res) => {
  const user = req.query;
  const { _id, signedUp } = user;

  SetSignedUp({
    _id,
    signedUp
  }).then(() => {
    res.send({ status: true, user });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.post('/send-invite', async (req, res) => {
  const user = req.query;
  const { _id } = req.user;

  const {
    name,
    email,
    attributes
  } = user;
  let { role } = user;

  let roleName = null;
  if (attributes) {
    roleName = await InventoryReadGrant({
      userId: _id,
      attributes
    });
    role = role.filter(rol => rol !== 'New Inventory Read');
    role.push(roleName);
  }

  SendInvite({
    parentId: _id,
    name,
    email,
    role
  }).then((response) => {
    res.send(response);
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.post('/send-invite-again', async (req, res) => {
  const { email } = req.query;

  ForgotPassword({
    email
  }).then((user) => {
    res.send({ status: true, updatedChild: user });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/get-child-users').get((req, res) => {
  const userId = req.user._id;

  GetChildUsers({
    userId
  }).then((childUsers) => {
    res.send({
      status: true,
      childUsers
    });
  }).catch((error) => {
    console.log('Error: ', error.message);
    res.send(error);
  });
});

Router.route('/set-child-user-role').post(async (req, res) => {
  const childUser = req.query;
  const parentId = req.user._id;
  let { role } = childUser;
  const {
    _id,
    attributes,
    roleWithAttributes: roleName
  } = childUser;
  const { _id: userId } = req.user;

  if (attributes) {
    const updatedRoleForChildUser = await InventoryReadGrant({
      userId,
      attributes: attributes.toString(),
      roleName
    });

    if (!role.includes(updatedRoleForChildUser)) {
      role = role.filter(rol => rol !== 'New Inventory Read');
      role.push(updatedRoleForChildUser);
      childUser.role = role;
    }
  }

  SetRole({
    _id,
    parentId,
    role
  }).then(() => {
    res.send({ status: true, childUser });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

Router.route('/delete-child-user').delete((req, res) => {
  const { _id } = req.query;

  DeleteChildUser({
    _id
  }).then(() => {
    res.send({ status: true, _id });
  }).catch((error) => {
    res.send(error);
  });
});

Router.route('/fetch-attributes-to-update-inventory-read-role').post((req, res) => {
  const { roleToFetchAttribute } = req.query;
  const userId = req.user._id;

  FetchAttributesToUpdateRole({
    roleToFetchAttribute,
    userId
  }).then((attributes) => {
    res.send({ status: true, attributes });
  }).catch((error) => {
    console.log('Error Message: ', error.message);
    res.status(500).send(error.message);
  });
});

export default Router;
