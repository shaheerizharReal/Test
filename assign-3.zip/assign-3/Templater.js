/**
 * CSE183 Assignment 3 - Basic
 */
class Templater {
  /**
   * Replace the contents of {{ }} tagged table header and data
   * elements in document with values found in the supplied JSON
   * @param {object} document
   * @param {string} json with propeties matching tags in document
   */
  byTag(document, json) {
    // Reference: https://www.w3schools.com/js/js_json_parse.asp
    const obj = JSON.parse(json);
    // Reference: https://www.w3schools.com/jsref/met_document_getelementsbytagname.asp
    const dataCell = document.getElementsByTagName('td');
    const headerCell = document.getElementsByTagName('th');
    let temp = '';
    let openBracketPosition;
    let closeBracketPosition;
    let key= '';
    let i;

    for (i=0; i<headerCell.length; i++) {
      temp = headerCell[i].innerHTML;
      // Reference: https://www.w3schools.com/jsref/jsref_lastindexof.asp
      openBracketPosition = temp.lastIndexOf('{');
      openBracketPosition++;
      // Reference: https://www.w3schools.com/jsref/jsref_indexof.asp
      closeBracketPosition = temp.indexOf('}');
      // Reference: https://www.w3schools.com/jsref/jsref_substring.asp
      key = temp.substring(openBracketPosition, closeBracketPosition);

      if (obj[key] != undefined) {
        headerCell[i].innerHTML = obj[key];
      } else {
        headerCell[i].innerHTML = '';
      }
    }

    for (i=0; i<dataCell.length; i++) {
      temp = dataCell[i].innerHTML;
      // Reference: https://www.w3schools.com/jsref/jsref_lastindexof.asp
      openBracketPosition = temp.lastIndexOf('{');
      openBracketPosition++;
      // Reference: https://www.w3schools.com/jsref/jsref_indexof.asp
      closeBracketPosition = temp.indexOf('}');
      // Reference: https://www.w3schools.com/jsref/jsref_substring.asp
      key = temp.substring(openBracketPosition, closeBracketPosition);

      if (obj[key] != undefined) {
        dataCell[i].innerHTML = obj[key];
      } else {
        dataCell[i].innerHTML = '';
      }
    }
  }

  /**
   * Replace the contents of table header and data elements in
   * in document with id'd content found in the supplied JSON
   * @param {object} document
   * @param {string} json with propeties matching element ids in document
   */
  byId(document, json) {
    const obj = JSON.parse(json);
    const dataCell = document.getElementsByTagName('td');
    const headerCell = document.getElementsByTagName('th');
    let id= '';
    let i;

    for (i=0; i<headerCell.length; i++) {
      // Filters out the id of each element
      // Stores it in variable id
      id=headerCell[i].id;

      if (obj[id] != undefined) {
        headerCell[i].innerHTML = obj[id];
      } else {
        headerCell[i].innerHTML = '';
      }
    }

    for (i=0; i<dataCell.length; i++) {
      // Filters out the id of each element
      // Stores it in variable id
      id = dataCell[i].id;

      if (obj[id] != undefined) {
        dataCell[i].innerHTML = obj[id];
      } else {
        dataCell[i].innerHTML = '';
      }
    }
  }
}
