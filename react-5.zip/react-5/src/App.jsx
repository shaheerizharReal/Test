import React from 'react';
import './App.css';

/**
 * Simple component with no state.
 *
 * See the basic-react from lecture 11 for an example of adding and
 * reacting to changes in state.
 */
class App extends React.Component {
  /**
   * @return {object} a <div> containing an <h2>
   */
  currentMonth = (containerId) => {
    const d = new Date(); // Current Date
    const monthRepresentation = ['January', 'February', 'March',
    'April', 'May', 'June', 'July', 'August', 'September',
    'October', 'November', 'December'];
    let firstDay; 
    let firstDayAsInt;
    let currentDate; let currentMonth; let currentYear;
    let daysInMonth; let daysInPreviousMonth;
    let temp;
    let tempFutureDate=1;
    let datesId;
    let i; let k;

    let todayDateString; let todaySplit;

    if (containerId.getElementById('overall').className=='') {
      // Current Values
      // Reference: https://www.w3schools.com/js/js_date_methods.asp
      currentYear = d.getFullYear();
      currentMonth = d.getMonth(); // January is 0
      currentDate = d.getDate();
    } else {
      todayDateString = containerId.getElementById('overall').className;
      todaySplit = todayDateString.split(' ');
      currentMonth = todaySplit[0];
      currentDate = todaySplit[1];
      currentYear = todaySplit[2];
    }
    currentMonth=parseInt(currentMonth);
    currentDate=parseInt(currentDate);
    currentYear=parseInt(currentYear);

    containerId.getElementById('display').innerHTML = monthRepresentation[currentMonth] +
    ' ' + currentYear;

    // Returns day name of the 1st of the month
    firstDay = p.getDay(currentMonth+1 + '/' + '1' + '/' + currentYear);

  	firstDayAsInt = p.convertDayToInt(firstDay);

    if (currentMonth==0) {
      daysInPreviousMonth = p.getDaysInMonth(11, currentYear-1);
    } else {
      daysInPreviousMonth = p.getDaysInMonth((currentMonth), currentYear);
    }

  	// Number of days in current month
  	daysInMonth = p.getDaysInMonth((currentMonth+1), currentYear);

  	temp=firstDayAsInt;
    // Set previous month's dates
    for ( k=temp-1; k>=0; k--) {
      datesId = 'd'+ k;
      containerId.getElementById(datesId).innerHTML = daysInPreviousMonth;
      containerId.getElementById(datesId).style.color = 'blue';
      daysInPreviousMonth--;
    }
    // Set current month's dates
  	for ( i=1; i<=daysInMonth; i++) {
  		datesId = 'd'+ temp;
		  containerId.getElementById(datesId).innerHTML = i;
      containerId.getElementById(datesId).style.color='black';


      if (currentDate==i) {
        containerId.getElementById(datesId).style.color = 'red';
        containerId.getElementById(datesId).style.fontWeight = 'bold';
        containerId.getElementById(datesId).className=datesId;
        containerId.getElementById(datesId).id='today';
        containerId.getElementById('overall').className=(currentMonth) + ' ' + currentDate + ' ' + currentYear;
      }

		  temp++;
  	}
    // Set next month's dates
    while (temp<=41) {
      datesId = 'd'+ temp;
      containerId.getElementById(datesId).innerHTML = tempFutureDate;
      containerId.getElementById(datesId).style.color='blue';
      tempFutureDate++;
      temp++;
    }
  }

  nextMonth = (containerId) => {
    let currentMonth; let currentYear; let currentDisplay;
    const monthRepresentation = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    let firstDay; let firstDayAsInt;
    let daysInMonth; let daysInPreviousMonth;
    let temp; let tempFutureDate=1;
    let datesId;
    let i; let k;
    let todayDate; let todayMonth; let todayYear;
    let todayDateString; let todaySplit; let todayClassName; let todayPresent;
    let splitDisplay;

    // Current Values (after next month)
  	// Reference: https://www.w3schools.com/js/js_date_methods.asp
    currentDisplay = containerId.getElementById('display').innerHTML;
    splitDisplay = currentDisplay.split(' ');
  	currentMonth = splitDisplay[0];
  	currentMonth = monthRepresentation.indexOf(currentMonth); // month integer, january is 0
    currentYear = splitDisplay[1];

    // If month is December and user selects next
  	// will go to january of the following year.
  	if (currentMonth != 11) {
  		currentMonth++;
  	} else {
  		currentMonth=0;
  		currentYear++;
  	}

    // Set month and year on display
    containerId.getElementById('display').innerHTML = monthRepresentation[currentMonth] + ' ' + currentYear;

    // Returns day name of the 1st of the month
  	firstDay = p.getDay(currentMonth+1 + '/' + '1' + '/' + currentYear);
  	firstDayAsInt = p.convertDayToInt(firstDay);

    // Number of days in previous month
    if (currentMonth==0) {
      daysInPreviousMonth = p.getDaysInMonth(11, currentYear-1);
    } else {
      daysInPreviousMonth = p.getDaysInMonth((currentMonth), currentYear);
    }

    // Number of days in current month
  	daysInMonth = p.getDaysInMonth((currentMonth+1), currentYear);

    // Get today's date
    todayDateString = containerId.getElementById('overall').className;
    todaySplit = todayDateString.split(' ');
    todayMonth = todaySplit[0];
    todayDate = todaySplit[1];
    todayYear = todaySplit[2];


    if (currentMonth==todayMonth && currentYear==todayYear) {
      todayPresent=true;
    } else {
      todayPresent=false;
    }

    if (containerId.getElementById('today')!=null) {
      todayClassName = containerId.getElementById('today').className;
      containerId.getElementById('today').id = todayClassName;
    }

    temp=firstDayAsInt;
    // Set previous month's dates
    for ( k=temp-1; k>=0; k--) {
      datesId = 'd'+ k;
      containerId.getElementById(datesId).innerHTML = daysInPreviousMonth;
      containerId.getElementById(datesId).style.color = 'blue';
      containerId.getElementById(datesId).style.fontWeight='normal';
      daysInPreviousMonth--;
    }
    // Set current month's dates
  	for ( i=1; i<=daysInMonth; i++) {
  		datesId = 'd'+ temp;
		  containerId.getElementById(datesId).innerHTML = i;
      containerId.getElementById(datesId).style.color='black';
      containerId.getElementById(datesId).style.fontWeight='normal';

      if (todayDate==i && todayPresent) {
        containerId.getElementById(datesId).style.color = 'red';
        containerId.getElementById(datesId).style.fontWeight = 'bold';
        containerId.getElementById(datesId).className=datesId;
        containerId.getElementById(datesId).id='today';
        containerId.getElementById('overall').className=currentMonth + ' ' + todayDate + ' ' + currentYear;
      }

		  temp++;
  	}
    // Set next month's dates
    while (temp<=41) {
      datesId = 'd'+ temp;
      containerId.getElementById(datesId).innerHTML = tempFutureDate;
      containerId.getElementById(datesId).style.color='blue';
      tempFutureDate++;
      temp++;
    }
  }

  previousMonth = (containerId) => {
  	const monthRepresentation = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  	let firstDay; let firstDayAsInt;
  	let currentMonth; let currentYear; let currentDisplay;
    let splitDisplay;
  	let daysInMonth; let daysInPreviousMonth;
  	let temp; let tempFutureDate=1;
    let todayDate; let todayMonth; let todayYear;
    let todayDateString; let todaySplit; let todayClassName; let todayPresent;
  	let datesId;
  	let i; let k;

  	// Current Values (after next month)
  	// Reference: https://www.w3schools.com/js/js_date_methods.asp
    currentDisplay = containerId.getElementById('display').innerHTML;
    splitDisplay = currentDisplay.split(' ');
  	currentMonth = splitDisplay[0];
  	currentMonth = monthRepresentation.indexOf(currentMonth); // month integer, january is 0
    currentYear = splitDisplay[1];

  	// If month is January and user selects previous
  	// will go to december of the previous year.
  	if (currentMonth!=0) {
  		currentMonth--;
  	} else {
  		currentMonth=11;
  		currentYear--;
  	}

    // Set month and year on display
    containerId.getElementById('display').innerHTML = monthRepresentation[currentMonth] + ' ' + currentYear;

  	// Returns day name of the 1st of the month
  	firstDay = p.getDay(currentMonth+1 + '/' + '1' + '/' + currentYear);
  	firstDayAsInt = p.convertDayToInt(firstDay);

    // Number of days in previous month
    if (currentMonth==0) {
      daysInPreviousMonth = p.getDaysInMonth(11, currentYear-1);
    } else {
      daysInPreviousMonth = p.getDaysInMonth((currentMonth), currentYear);
    }

  	// Number of days in current month
  	daysInMonth = p.getDaysInMonth((currentMonth+1), currentYear);

    // Get today's date
    todayDateString = containerId.getElementById('overall').className;
    todaySplit = todayDateString.split(' ');
    todayMonth = todaySplit[0];
    todayDate = todaySplit[1];
    todayYear = todaySplit[2];

    if (currentMonth==todayMonth && currentYear==todayYear) {
      todayPresent=true;
    } else {
      todayPresent=false;
    }

    if (containerId.getElementById('today')!=null) {
      todayClassName = containerId.getElementById('today').className;
      containerId.getElementById('today').id = todayClassName;
    }

    temp=firstDayAsInt;
    // Set previous month's dates
    for ( k=temp-1; k>=0; k--) {
      datesId = 'd'+ k;
      containerId.getElementById(datesId).innerHTML = daysInPreviousMonth;
      containerId.getElementById(datesId).style.color = 'blue';
      containerId.getElementById(datesId).style.fontWeight='normal';
      daysInPreviousMonth--;
    }
    // Set current month's dates
    for ( i=1; i<=daysInMonth; i++) {
      datesId = 'd'+ temp;
      containerId.getElementById(datesId).innerHTML = i;
      containerId.getElementById(datesId).style.color='black';
      containerId.getElementById(datesId).style.fontWeight='normal';

      if (todayDate==i && todayPresent) {
        containerId.getElementById(datesId).style.color = 'red';
        containerId.getElementById(datesId).style.fontWeight = 'bold';
        containerId.getElementById(datesId).className=datesId;
        containerId.getElementById(datesId).id='today';
        containerId.getElementById('overall').className=currentMonth+ + ' ' + todayDate + ' ' + currentYear;
      }

      temp++;
    }
    // Set next month's dates
    while (temp<=41) {
      datesId = 'd'+ temp;
      containerId.getElementById(datesId).innerHTML = tempFutureDate;
      containerId.getElementById(datesId).style.color='blue';
      tempFutureDate++;
      temp++;
    }
  }

  getCurrentDateID = () => {
    const d = new Date();
    let currentDate; let currentMonth; let currentYear;
    let firstDay; let firstDayAsInt;
    let temp;
    let i;
    let datesID;

    currentDate = d.getDate();
    currentMonth = d.getMonth();
    currentYear = d.getFullYear();

    firstDay = p.getDay(currentMonth+1 + '/' + '1' + '/' + currentYear);
    firstDayAsInt = p.convertDayToInt(firstDay);

    temp=firstDayAsInt;

    for (i=1; i!=currentDate; i++) {
      datesID = 'd' + temp;
      temp++;
    }

    datesID = 'd'+temp;

    return datesID;
  }

  // Reference: https://stackoverflow.com/questions/1184334/get-number-days-in-a-specified-month-using-javascript
  getDaysInMonth = (month, year) => {
  	return new Date(year, month, 0).getDate();
  }

  // Returns day, given full date
  // e.g. '08/10/2020'
  // Reference: https://stackoverflow.com/questions/24998624/day-name-from-date-in-js
  getDay = (dateStr, locale = 'en-US') => {
  	const date = new Date(dateStr);
  	return date.toLocaleDateString(locale, {weekday: 'long'});
  }

  // Gets day as string, returns as int value
  convertDayToInt = (dayAsString) => {
  	let temp;

  	switch (dayAsString) {
  		case 'Sunday':
  			temp=0;
  			break;
  		case 'Monday':
  			temp=1;
  			break;
  		case 'Tuesday':
  			temp=2;
  			break;
  		case 'Wednesday':
  			temp=3;
  			break;
      case 'Thursday':
  			temp=4;
  			break;
  		case 'Friday':
  			temp=5;
  			break;
  		case 'Saturday':
  			temp=6;
  			break;
  	}

  	return temp;
  }

  getCurrentDate = () => {
    const d = new Date();

    return d.getDate();
  }

  setCurrentDate = (month, date, year, containerId) => {
    containerId.getElementById('overall').className = month + ' ' + date + ' ' + year;
  }

  changeTodayColor = (dateId, containerId) => {
    let initialClassName;

    if (containerId.getElementById('today')!=null) {
      initialClassName=containerId.getElementById('today').className;
      containerId.getElementById('today').style.color='black';
      containerId.getElementById('today').style.fontWeight='normal';
      containerId.getElementById('today').id=initialClassName;
    }

    containerId.getElementById(dateId).style.color='red';
    containerId.getElementById(dateId).style.fontWeight='bold';
    containerId.getElementById(dateId).className=dateId;
    containerId.getElementById(dateId).id='today';
  }

  selectDate = (dateId, containerId) => {
    const monthRepresentation = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    let startId; let endId;
    let firstDay; let firstDayAsInt;
    let currentDisplay; let currentMonth; let currentYear; let currentDate;
    let daysInMonth;
    let splitDisplay;
    let dateIdNum;

    dateIdNum=dateId.substring(1);

    // Current Values (after next month)
  	// Reference: https://www.w3schools.com/js/js_date_methods.asp
    currentDisplay = containerId.getElementById('display').innerHTML;
    splitDisplay = currentDisplay.split(' ');
  	currentMonth = splitDisplay[0];
  	currentMonth = monthRepresentation.indexOf(currentMonth); // month integer, january is 0
    currentYear = splitDisplay[1];
    currentDate = containerId.getElementById(dateId).innerHTML;
    currentMonth=parseInt(currentMonth);
    currentYear=parseInt(currentYear);

    // Returns day name of the 1st of the month
  	firstDay = p.getDay(currentMonth+1 + '/' + '1' + '/' + currentYear);
  	firstDayAsInt = p.convertDayToInt(firstDay);
    daysInMonth = p.getDaysInMonth((currentMonth+1), currentYear);
    startId = firstDayAsInt; //
    endId = startId + daysInMonth -1;

    if (dateIdNum<startId) {
      this.setCurrentDate(currentMonth-1, currentDate, currentYear, containerId);
      this.previousMonth(containerId);
    } else if (dateIdNum>endId) {
      this.setCurrentDate(currentMonth+1, currentDate, currentYear, containerId);
      this.nextMonth(containerId);
    } else {
      this.setCurrentDate(currentMonth, currentDate, currentYear, containerId);
      this.changeTodayColor(dateId, containerId);
    }
  }

  render() {
    return (
      <div id="overall" class="">
        <h4>
        CSE183Summer 2021-Assignment4
        </h4>
      <table class="monthArrowHeader">
        <th id="prev" onclick="p.previousMonth(document);"> { '<'} </th>
        <th id="display" onclick="p.currentMonth(document)"></th>
        <th id="next" onclick="p.nextMonth(document);"> {'>'} </th>
      </table>
      <table class="calendar">
        <tr> 
          <th id="S">S</th>
          <th id="M">M</th>
          <th id="T">T</th>
          <th id="W">W</th>
          <th id="T">T</th>
          <th id="F">F</th>
          <th id="S">S</th>
        </tr> 
        <tr>
          <td id="d0" onclick="p.selectDate(this.id, document)"></td>
          <td id="d1" onclick="p.selectDate(this.id, document)"></td>
          <td id="d2" onclick="p.selectDate(this.id, document)"></td>
          <td id="d3" onclick="p.selectDate(this.id, document)"></td>
          <td id="d4" onclick="p.selectDate(this.id, document)"></td>
          <td id="d5" onclick="p.selectDate(this.id, document)"></td>
          <td id="d6" onclick="p.selectDate(this.id, document)"></td>				
        </tr>
        <tr>
          <td id="d7" onclick="p.selectDate(this.id, document)"></td>
          <td id="d8" onclick="p.selectDate(this.id, document)"></td>
          <td id="d9" onclick="p.selectDate(this.id, document)"></td>
          <td id="d10" onclick="p.selectDate(this.id, document)"></td>
          <td id="d11" onclick="p.selectDate(this.id, document)"></td>
          <td id="d12" onclick="p.selectDate(this.id, document)"></td>
          <td id="d13" onclick="p.selectDate(this.id, document)"></td>
          
        </tr>
        <tr>
          <td id="d14" onclick="p.selectDate(this.id, document)"></td>
          <td id="d15" onclick="p.selectDate(this.id, document)"></td>
          <td id="d16" onclick="p.selectDate(this.id, document)"></td>
          <td id="d17" onclick="p.selectDate(this.id, document)"></td>
          <td id="d18" onclick="p.selectDate(this.id, document)"></td>
          <td id="d19" onclick="p.selectDate(this.id, document)"></td>
          <td id="d20" onclick="p.selectDate(this.id, document)"></td>
          
        </tr>
        <tr> 
          <td id="d21" onclick="p.selectDate(this.id, document)"></td>
          <td id="d22" onclick="p.selectDate(this.id, document)"></td>
          <td id="d23" onclick="p.selectDate(this.id, document)"></td>
          <td id="d24" onclick="p.selectDate(this.id, document)"></td>
          <td id="d25" onclick="p.selectDate(this.id, document)"></td>
          <td id="d26" onclick="p.selectDate(this.id, document)"></td>
          <td id="d27" onclick="p.selectDate(this.id, document)"></td>
          
        </tr>
        <tr>
          <td id="d28" onclick="p.selectDate(this.id, document)"></td>
          <td id="d29" onclick="p.selectDate(this.id, document)"></td>
          <td id="d30" onclick="p.selectDate(this.id, document)"></td>
          <td id="d31" onclick="p.selectDate(this.id, document)"></td>
          <td id="d32" onclick="p.selectDate(this.id, document)"></td>
          <td id="d33" onclick="p.selectDate(this.id, document)"></td>
          <td id="d34" onclick="p.selectDate(this.id, document)"></td>
        </tr>
        <tr>
          <td id="d35" onclick="p.selectDate(this.id, document)"></td>
          <td id="d36" onclick="p.selectDate(this.id, document)"></td>
          <td id="d37" onclick="p.selectDate(this.id, document)"></td>
          <td id="d38" onclick="p.selectDate(this.id, document)"></td>
          <td id="d39" onclick="p.selectDate(this.id, document)"></td>
          <td id="d40" onclick="p.selectDate(this.id, document)"></td>
          <td id="d41" onclick="p.selectDate(this.id, document)"></td> 
        </tr>
      </table> 
    </div>
    );
  }
}

export default App;
